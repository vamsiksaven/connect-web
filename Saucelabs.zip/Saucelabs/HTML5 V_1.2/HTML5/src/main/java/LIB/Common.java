package LIB;

import java.awt.GraphicsConfiguration;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.ITestResult;
//import org.testng.annotations.AfterMethod;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.saucelabs.saucerest.SauceREST;

public class Common {
	public static WebDriver driver;
	/** The Report logger. */
	public static String imageLocation = "./images/";
	protected static ExtentTest extentTest = null;
	Actions action;
	public GraphicsConfiguration gc;
	public static BufferedWriter C_outputfile;
	public static String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	
	  public static final String USERNAME = "syed.wahabuddin";
	  public static final String ACCESS_KEY = "cba3622a-c943-4a48-91b8-39c37e5cfdd8";
	//public static final String USERNAME = "kirankumar.ayyagari";
	//public static final String ACCESS_KEY = "ec9ab75a-cce0-4b4c-8ce1-ef1bca58af03";
	  public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";

	  public static String sessionId;
	  public static WebDriverWait wait;
	  public static SauceUtils sauceUtils;
		
	  public static void Setup(String Report) throws Exception { 
	//Set up the ChromeOptions object, which will store the capabilities for the Sauce run
      //ChromeOptions caps = new ChromeOptions();
	  /*DesiredCapabilities caps = DesiredCapabilities.edge();
      caps.setCapability("version", "16.16299");
      caps.setCapability("platform", "Windows 10");
      caps.setCapability("name", "Login");*/
		  
		/*  DesiredCapabilities caps = DesiredCapabilities.chrome();
		  caps.setCapability("platform", "Windows 10");
		  caps.setCapability("version", "64.0");*/
		  
		  /*DesiredCapabilities caps = DesiredCapabilities.safari();
		  caps.setCapability("platform", "macOS 10.14");
		  caps.setCapability("version", "12.0");
		  caps.setCapability("name", "Login");*/
		  DesiredCapabilities caps = DesiredCapabilities.edge();
			caps.setCapability("platform", "Windows 10");
			caps.setCapability("browserVersion", "latest");
		  
		  
      //caps.setExperimentalOption("w3c", true);

      //Create a map of capabilities called "sauce:options", which contain the info necessary to run on Sauce
      // Labs, using the credentials stored in the environment variables. Also runs using the new W3C standard.
      MutableCapabilities sauceOptions = new MutableCapabilities();
      sauceOptions.setCapability("username", USERNAME);
      sauceOptions.setCapability("accessKey", ACCESS_KEY);
      sauceOptions.setCapability("seleniumVersion", "3.8.1");
      sauceOptions.setCapability("maxDuration", 10800);
      //sauceOptions.setCapability("name", scenario.getName());3.141.59

      //Assign the Sauce Options to the base capabilities
      caps.setCapability("sauce:options", sauceOptions);

      //Create a new RemoteWebDriver, which will initialize the test execution on Sauce Labs servers
      String SAUCE_REMOTE_URL = "https://ondemand.saucelabs.com/wd/hub";
      driver = new RemoteWebDriver(new URL(SAUCE_REMOTE_URL), caps);
      sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
      wait = new WebDriverWait(driver, 100);

      SauceREST sauceREST = new SauceREST(USERNAME, ACCESS_KEY);
      sauceUtils = new SauceUtils(sauceREST);
      
      Creatlogfile(Date_Time + "," + Report + ",Pass");
      
      
  }
	  
	/*  		
	// Start Chrome Browser
	public void Setup(String Browser, String Report) throws Exception {

		if (Browser.equals("Firefox")) {
			System.setProperty("webdriver.gecko.driver","D:\\QA_TheIce\\Firefox\\geckodriver.exe");
			driver = new FirefoxDriver();
			driver.get("https://connect-web.staging.dataservices.theice.com");
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else if (Browser.equals("IE")) {
			driver = new InternetExplorerDriver();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else if (Browser.equals("Chrome")) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			// System.setProperty("webdriver.chrome.driver","../QA_TheIce/Driver/chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println("Invalid Driver");
		}
	}*/

	public static void Creatlogfile(String Report) throws Exception {
		C_outputfile = new BufferedWriter(new FileWriter("./Results.csv", true));
		C_outputfile.append(Report + "\n");
		C_outputfile.close();
	}

	public void starturl(String url) {
		driver.get(url);
		//driver.navigate().to(url);
	}

	// Maximize Browser
	public void maximiseBrowser() {
		driver.manage().window().maximize();
	}

	// WebElement
	public WebElement webElementId(String identifier, String locator) {
		WebElement e = null;
		switch (identifier) {
		case "id":
			e = driver.findElement(By.id(locator));
			break;
		case "className":
			e = driver.findElement(By.className(locator));
			break;
		case "tagName":
			e = driver.findElement(By.tagName(locator));
			break;
		case "name":
			e = driver.findElement(By.name(locator));
			break;
		case "linkText":
			e = driver.findElement(By.linkText(locator));
			break;
		case "partialLinkText":
			e = driver.findElement(By.partialLinkText(locator));
			break;
		case "cssSelector":
			e = driver.findElement(By.cssSelector(locator));
			break;
		case "xpath":
			e = driver.findElement(By.xpath(locator));
			break;
		default:
			System.out.println("Locator not found");
			e = null;
		}
		return e;
	}

	// Sendkey general method
	public void sendKeys(String identifier, String locator, String content, String Report) throws Exception {

		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.sendKeys(content);
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// Clear text field method
	public void ClearTextField(String identifier, String locator, String Report) throws Exception {

		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.clear();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// click general method
	public void click(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.click();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// verify title of the page
	public void verifyTitle(String title, String Report) throws Exception {
		if (driver.getTitle().equals(title)) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(title + " displayed");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println("Failed to display " + title);
			return;
		}
	}

	// Wait until the Element is present
	public void waitUntilElementPresent(String elementpath) {

		WebElement elementpresent = (new WebDriverWait(driver, 10))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath(elementpath)));
	}

	// Verify Text
	public void verifyText(String identifier, String locator, String text, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.getText().equals(text)) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(text + " displayed");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println(text + "Did not displayed");
		}
	}

	// Verify Text Using String
	public void verifyText_Using_String(String identifier, String locator, String text, String Report)
			throws Exception {
		String e = webElementId(identifier, locator).getText();
		if (e.equals(text)) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(text + " displayed");
		} else {
			System.out.println(text + "Did not displayed");
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}
	
	// Get the Text Widget name
		public void widget_name()
				throws Exception {
			String e = webElementId("xpath", "//*[@class='widget-tab tab active css-1eeqky1']").getText();
			}
		// Verify Text box text text
	public void verify_text_box_text(String identifier, String locator, String text, String Report) throws Exception {
		String e = webElementId(identifier, locator).getAttribute("value");
		if (e.equals(text)) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(text + "is displayed");
		} else {
			System.out.println(text + "Did not displayed");
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// verify element present
	public void verifyElementPresent(String identifier, String locator, String Report) throws Exception {
		try{
			WebElement e = webElementId(identifier, locator);
			e.isDisplayed();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(Date_Time + "," + Report + ",Pass");
		}catch(Exception t){
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// verify pop closeing or not
	public void verify_pop_closeing_or_not(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);

		if (e.isDisplayed()) {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println("Element is not present");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println(Date_Time + "," + Report + ",Pass");
			System.out.println("Element present");
		}
	}

	// Element is Enabled or not
	public void verifyElementEnabled(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isEnabled()) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println("Element Enabled");
		} else {

			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println("Element is not Enabled");
		}
	}

	// Element is disable or not
	public void verifyElementdisable(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isEnabled()) {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		}
	}

	// Element is is Selected or not
	public void verifyElementisSelected(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isSelected()) {
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			System.out.println("Element is Selected");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
			System.out.println("Element is not Selected");
		}

	}

	// Thread sleep
	public void sleepThread(long sleeptime) {
		try {
			Thread.sleep(sleeptime);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Wait for page to load
	public void waitForPageToLoad() {
		try {
			for (int i = 0; i < 50;) {
				if (driver.getTitle().length() != 0) {
					System.out.println("Page loaded");
					i = 51;
					break;
				} else {
					Thread.sleep(1000);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// select frame by id
	public void selectFrameById(String locator) {
		driver.switchTo().frame(locator);
	}

	// Select frame default method
	public void selectFrameDefault() {
		driver.switchTo().defaultContent();
	}

	// getting data from table and verifying it with the required text
	public void verifyElementInTable(String xpathlocator, String text) {
		boolean a = false;
		List<WebElement> tdlist = driver.findElements(By.xpath(xpathlocator));
		for (WebElement el : tdlist) {
			if (el.getText().equals(text)) {
				a = true;
				break;
			}
		}

		if (a == true) {
			System.out.println(text + " was identifed");
		} else {
			System.out.println(text + " was not identifed");
		}
	}

	// Start action
	public void startAction() {
		action = new Actions(driver);
	}

	// move to element
	public void MouseOverToElement(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			action.moveToElement(e).perform();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	// move to click
	public void MouseOverToclickabl(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			action.moveToElement(e).click().perform();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}
	public void mouseovercontextClick(String identifier, String locator, String Report) throws Exception
	{
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			action.contextClick(e).perform();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}
	
	// click on Right click
	public void Rightclick(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		try{		
		    e.isDisplayed();
			action.contextClick(e).build().perform();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
			}catch(Exception t){
			Creatlogfile(Date_Time + "," + Report + ",Fail");
 		}
	}

	public void double_click_an_element(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			action.doubleClick(e).perform();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
	}

	//
	public void Click_on_drop_down_list(String xpathlocator, String text, String identifier, String locator,
			String Report) throws Exception {
		boolean a = false;
		List<WebElement> tdlist = driver.findElements(By.xpath(xpathlocator));
		for (WebElement el : tdlist) {
			if (el.isDisplayed()) {
				el.click();
				Creatlogfile(Date_Time + "," + Report + ",Pass");
			} else {
				Creatlogfile(Date_Time + "," + Report + ",Fail");
			}
		}
	}

	// put path to your image in a clipboard
	public void upload_file(String upload_file) throws Exception {
		StringSelection ss = new StringSelection(upload_file);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		// imitate mouse events like ENTER, CTRL+C, CTRL+V
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	public void handle_to_calendar(String Year_identifier, String Year_locator, String Month_identifier,
			String Month_locator, String year, int month, int day) throws Exception {
			WebElement e = webElementId(Year_identifier, Year_locator);
			Select sel = new Select(e);
			sel.selectByValue(year);
			Thread.sleep(3000);
			WebElement e1 = webElementId(Month_identifier, Month_locator);
			Select sel1 = new Select(e1);
			sel1.selectByIndex(month);
			Thread.sleep(3000);
			List<WebElement> allDateOfDesiredMonth = driver.findElements(By.xpath("//*[contains(@class,'DayPicker-Day')]"));
			for (WebElement d : allDateOfDesiredMonth) {
				if (d.getText().trim().equals(day)) {
					Thread.sleep(3000);
					d.click();
					break;
				}

			}
		}

	public void Scroll_down()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)", "");
	}
	public void Scroll_up() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,-250)", "");
	}
	public void KeyEvent(int down) throws Exception	
	{
		Robot robot = new Robot();
		robot.keyPress(down);
	}

	public void handling_alerts_accecpt()
	{
		 Alert alt=driver.switchTo().alert();
		 alt.accept();
	}
	
	public void handling_alerts_dismiss()
	{
		 Alert alt=driver.switchTo().alert();
		 alt.dismiss();		 
	}
		
	
	// Read property file
	public static Properties readPropertyByLogin() {
		Properties prop = new Properties();
		File dir1 = new File("../HTML5/Ide.Idp.Properties/Login.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}

	public static Properties readPropertyByWatch_List() {
		Properties prop = new Properties();
		File dir1 = new File("../HTML5/Ide.Idp.Properties/Watch_List.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}

	public static Properties readPropertyByChart() {
		Properties prop = new Properties();
		File dir1 = new File("../HTML5/Ide.Idp.Properties/Chart.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	public static Properties readPropertyByoptions() {
		Properties prop = new Properties();
		File dir1 = new File("../HTML5/Ide.Idp.Properties/Options.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	

	// Capture Screenshot
	public String captureScreenshot() {

		// final UUID uuid = UUID.randomUUID();
		String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH-mm-ss").format(Calendar.getInstance().getTime());
		final File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(imageLocation + timeStamp + ".png"));
		} catch (final IOException e) {
			e.printStackTrace();
		}
		try {
			extentTest.log(LogStatus.INFO, extentTest.addScreenCapture(imageLocation + timeStamp + ".png"));
		} catch (Exception e) {
			// logError("IOException thrown in SvmBaseTestCase.captureScreenshot", e);
		}
		// logDebug("Capturing :" + testNGReport + imageLocation + uuid + ".png");
		return imageLocation + timeStamp + ".png";
	}

	public void select_the_Drop_Down_values(String identifier, String locator, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		Select sel = new Select(e);
		List<WebElement> list = sel.getOptions();
		for (int i = 1; i < list.size(); i++) {
			if (e.isDisplayed()) {
				sel.selectByIndex(i);
				Creatlogfile(Date_Time + "," + Report + ",Pass");
			} else {
				Creatlogfile(Date_Time + "," + Report + ",Fail");
			}
		}
	}

	public void select_the_Drop_Down_one_values(String identifier, String locator,String Text, String Report) throws Exception {
		WebElement e = webElementId(identifier, locator);
		Select sel = new Select(e);
			if (e.isDisplayed()) {
				sel.selectByVisibleText(Text);
				Creatlogfile(Date_Time + "," + Report + ",Pass");
			} else {
				Creatlogfile(Date_Time + "," + Report + ",Fail");
		
		}
	}
	
	public void switch_to_new_window(String identifier, String locator, String Report, String V_identifier,
			String V_locator, String V_Report) throws Exception {
		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();
		// Perform the click operation that opens new window
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.click();
			Creatlogfile(Date_Time + "," + Report + ",Pass");
		} else {
			Creatlogfile(Date_Time + "," + Report + ",Fail");
		}
		Thread.sleep(25000);
		// Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		Thread.sleep(17000);
		//TimeUnit.MINUTES.sleep(1);
		// Perform the actions on new window
		WebElement V_e = webElementId(V_identifier, V_locator);
		if (V_e.isEnabled()) {
			Creatlogfile(Date_Time + "," + V_Report + ",Pass");
			System.out.println("Element Enabled");
		} else {

			Creatlogfile(Date_Time + "," + V_Report + ",Fail");
			System.out.println("Element is not Enabled");
		}
		// Close the new window, if that window no more required
		Thread.sleep(13000);
		driver.close();
		// Switch back to original browser (first window)
		driver.switchTo().window(winHandleBefore);

		// Continue with original browser (first window)
	}

	


//*******************************************************************
	   /* public void setUp(Scenario scenario) throws MalformedURLException {
	        //Set up the ChromeOptions object, which will store the capabilities for the Sauce run
	        ChromeOptions caps = new ChromeOptions();
	        caps.setCapability("version", "72.0");
	        caps.setCapability("platform", "Windows 10");
	        caps.setExperimentalOption("w3c", true);

	        //Create a map of capabilities called "sauce:options", which contain the info necessary to run on Sauce
	        // Labs, using the credentials stored in the environment variables. Also runs using the new W3C standard.
	        MutableCapabilities sauceOptions = new MutableCapabilities();
	        sauceOptions.setCapability("username", username);
	        sauceOptions.setCapability("accessKey", accesskey);
	        sauceOptions.setCapability("seleniumVersion", "3.141.59");
	        sauceOptions.setCapability("name", scenario.getName());

	        //Assign the Sauce Options to the base capabilities
	        caps.setCapability("sauce:options", sauceOptions);

	        //Create a new RemoteWebDriver, which will initialize the test execution on Sauce Labs servers
	        String SAUCE_REMOTE_URL = "https://ondemand.saucelabs.com/wd/hub";
	        driver = new RemoteWebDriver(new URL(SAUCE_REMOTE_URL), caps);
	        sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
	        wait = new WebDriverWait(driver, 10);

	        SauceREST sauceREST = new SauceREST(username, accesskey);
	        sauceUtils = new SauceUtils(sauceREST);
	    }

	    public void tearDown(Scenario scenario){
	        driver.quit();
	        sauceUtils.updateResults(!scenario.isFailed(), sessionId);
	    }*/
	
	
	
	// close
	public void closeBrowser(String Report) throws Exception {
		//driver.close();
		Creatlogfile(Date_Time + "," + Report + ",Pass");
		// screenRecorder.stop();
	}

	// Quit
	public void QuitObject(String Report) throws Exception {
		driver.quit();
		Creatlogfile(Date_Time + "," + Report + ",Pass");
	}
	/*//@AfterMethod(alwaysRun = true)
	   public static void cleanUpAfterTestMethod(ITestResult result) throws Exception {
		 Thread.sleep(13000);
		 ((JavascriptExecutor)driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
	        Thread.sleep(13000);
	        driver.quit();
	 }*/
	
}