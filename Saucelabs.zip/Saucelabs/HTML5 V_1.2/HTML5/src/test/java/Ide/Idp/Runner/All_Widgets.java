package Ide.Idp.Runner;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import LIB.Common;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(plugin = { "html:target/cucumber-html-report", "json:target/cucumber.json",
		"pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
		"junit:target/cucumber-results.xml" }, features = { "../HTML5/Featuresfiles/Login.feature",
				"../HTML5/Featuresfiles/Watch List.feature",
				"../HTML5/Featuresfiles/Chart.feature" ,"../HTML5/Featuresfiles/Options.feature"}, glue = "Ide.Idp.StepDef")

public class All_Widgets extends AbstractTestNGCucumberTests {
	public static WebDriver driver;
	public Common com = new Common();
	public All_Widgets() {
		driver = Common.driver;
	}
	@AfterMethod(alwaysRun = true)
	public void cleanUpAfterTestMethod(ITestResult result) throws IOException, InterruptedException {
		System.out.println("cleanUpAfterTestMethod");
		Thread.sleep(9000);
		 ((JavascriptExecutor)Common.driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
		 System.out.println("JavascriptExecutor");
	}
	
	@AfterSuite(alwaysRun = true)
	public void quit() throws Exception {
		System.out.println("quit");
		Thread.sleep(13000);
		//com.QuitObject("ILTC-00027,Login,Quit the Object");
	}
}
