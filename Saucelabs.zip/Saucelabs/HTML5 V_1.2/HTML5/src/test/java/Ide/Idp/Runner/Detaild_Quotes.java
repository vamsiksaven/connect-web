package Ide.Idp.Runner;

import java.io.*;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.saucelabs.saucerest.SauceREST;

import LIB.SauceUtils;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Detaild_Quotes {
	static WebDriver driver;
	static Actions act;

	public static final String USERNAME = "syed.wahabuddin";
	  public static final String ACCESS_KEY = "cba3622a-c943-4a48-91b8-39c37e5cfdd8";
	  public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";

	  public static String sessionId;
	  public static WebDriverWait wait;
	  public static SauceUtils sauceUtils;
	
	@Test
	public static void main() throws Exception {

		DesiredCapabilities caps = DesiredCapabilities.edge();
		caps.setCapability("platform", "Windows 10");
		caps.setCapability("browserVersion", "latest");
	      //caps.setExperimentalOption("w3c", true);

	      //Create a map of capabilities called "sauce:options", which contain the info necessary to run on Sauce
	      // Labs, using the credentials stored in the environment variables. Also runs using the new W3C standard.
	      MutableCapabilities sauceOptions = new MutableCapabilities();
	      sauceOptions.setCapability("username", USERNAME);
	      sauceOptions.setCapability("accessKey", ACCESS_KEY);
	      sauceOptions.setCapability("seleniumVersion", "3.141.59");
	      //sauceOptions.setCapability("name", scenario.getName());

	      //Assign the Sauce Options to the base capabilities
	      caps.setCapability("sauce:options", sauceOptions);

	      //Create a new RemoteWebDriver, which will initialize the test execution on Sauce Labs servers
	      String SAUCE_REMOTE_URL = "https://ondemand.saucelabs.com/wd/hub";
	      driver = new RemoteWebDriver(new URL(SAUCE_REMOTE_URL), caps);
	      sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
	      wait = new WebDriverWait(driver, 10);

	      SauceREST sauceREST = new SauceREST(USERNAME, ACCESS_KEY);
	      sauceUtils = new SauceUtils(sauceREST);
			
		// Result file

		//File file = new File("D:\\Test Results\\testdata.xlsx");
		File file = new File("./Detaild_Quotes.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet1 = workbook.getSheetAt(0);

		// loginpage log=new loginpage();
		//System.setProperty("webdriver.chromedriver", "C:\\Users\\vamsikrishnak\\robot framework\\chromedriver.exe");
		// System.setProperty("webdriver.gecko.driver", "C:\\Users\\vamsikrishnak\\robot
		// framework\\geckodriver.exe");
		
		//System.setProperty("webdriver.gecko.driver","D:\\QA_TheIce\\Firefox\\geckodriver.exe");
		//driver = new FirefoxDriver();
	//driver = new ChromeDriver();
		// driver = new FirefoxDriver();

		// Using properties file

		Properties obj = new Properties();
		FileInputStream objfile = new FileInputStream("../HTML5/Ide.Idp.Properties/Detaild_Quotes.properties");
				//System.getProperty("user.dir") + "\\src\\properties\\DQ.properties");
		
				
		obj.load(objfile);
		// for printing in excel
		for (int l = 1; l <= 28; l++) {
			for (int k = 1; k <= 28; k++) {
				// driver.get(obj.getProperty("https://connect-web.staging.dataservices.theice.com/connectweb/"));
				driver.get(obj.getProperty("URL"));
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Thread.sleep(2000);
				driver.findElement(By.xpath(obj.getProperty("username"))).click();
				Thread.sleep(2000);

				driver.findElement(By.xpath(obj.getProperty("username"))).sendKeys("QA_BMO2_DEHUIKONG@theice.com");
				Thread.sleep(2000);
				driver.findElement(By.xpath(obj.getProperty("password"))).click();
				System.out.println("username and password entered successfully");
				sheet1.getRow(k++).createCell(1).setCellValue("username and password entered successfully");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				// resultCell.setCellValue("PASS");

				Thread.sleep(2000);
				driver.findElement(By.xpath(obj.getProperty("password"))).sendKeys("Starts123");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("Submit"))).click();
				//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				//driver.manage().window().maximize();
				//driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);

				/*// Closing all opened tabs
				Actions act1 = new Actions(driver);
				act1.contextClick(driver.findElement(By.xpath(obj.getProperty("Rightclick_Close")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Thread.sleep(100);
				act1.contextClick(driver.findElement(By.xpath(obj.getProperty("Close_alltabs")))).perform();
				driver.findElement(By.xpath(obj.getProperty("Close_alltabs"))).click();
				Thread.sleep(100);
				System.out.println("Closed all opened tabs");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Checked whether Close Other Tabs option is working or not");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
*/
				// Clicking on + icon to add new widget
				//Thread.sleep(2000);
				//driver.findElement(By.xpath(obj.getProperty("Add_Widget"))).click();
				TimeUnit.MINUTES.sleep(1);

				// Clicking on DQ
				//Thread.sleep(5000);
				driver.findElement(By.xpath(obj.getProperty("DQ"))).click();
				Thread.sleep(1000);

				if (driver.findElement(By.xpath("//span[contains(text(),'Last Trade Time')]")) != null) {

					System.out.println("Detailed Quotes tab opened succesfully");
					sheet1.getRow(k++).createCell(1).setCellValue("Detailed Quotes tab opened succesfully");
					sheet1.getRow(l++).createCell(2).setCellValue("Pass");
					// resultCell.setCellValue("PASS");
				} else {
					System.out.println("Detailed Quotes tab did not opened");
					sheet1.getRow(k++).createCell(1).setCellValue("Detailed Quotes tab did not opened");
					sheet1.getRow(l++).createCell(2).setCellValue("Fail");
					// resultCell.setCellValue("FAIL");
				}

				// to click on symbol text box.

				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				// driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).clear();
				driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).clear();
				//driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).sendKeys(Keys.DELETE);
				Thread.sleep(2000);
				driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).sendKeys("IBM", Keys.ENTER);
				Thread.sleep(5000);

				// if(isElementPresent(By.xpath("//span[text()='IBM']")))
				if (driver.findElement(By.xpath(obj.getProperty("IBM"))) != null) {
					System.out.println("Entered IBM symbol");
					sheet1.getRow(k++).createCell(1).setCellValue(
							"Checked Symbol Lookup Drop down and Text Box in it . Also check filters in it like(All, Recent, Stock, ETF, Index, Fund, Future, Forex)");
					sheet1.getRow(l++).createCell(2).setCellValue("Pass");
					// resultCell.setCellValue("PASS");
				} else {
					System.out.println("Did not Entered IBM symbol");
					sheet1.getRow(k++).createCell(1).setCellValue("Entered IBM symbol");
					sheet1.getRow(l++).createCell(2).setCellValue("Fail");
					// resultCell.setCellValue("FAIL");
				}

				// DQ chart time intervals

				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				driver.findElement(By.xpath(obj.getProperty("ScaleCheckbox"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("1D"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("1M"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("3M"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("6M"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("1Y"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("5Y"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				System.out.println("Checked all time intervals");
				sheet1.getRow(k++).createCell(1).setCellValue("Checked all time intervals");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				// resultCell.setCellValue("PASS");

				// DQ right click Field.

				Actions act11 = new Actions(driver);
				act11.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Thread.sleep(100);
				act11.contextClick(driver.findElement(By.xpath(obj.getProperty("Fieldsbutton")))).perform();
				Thread.sleep(100);

				driver.findElement(By.xpath(obj.getProperty("Fieldsbutton"))).click();

				for (int i = 3; i <= 11; i++) {
					Actions act2 = new Actions(driver);
					act2.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(100);
					act2.contextClick(driver.findElement(By.xpath(obj.getProperty("Fieldsbutton")))).perform();
					Thread.sleep(3000);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(
							"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[" + i + "]/button"))
							.click();

				}
				Thread.sleep(1000);

				if (driver.getPageSource().contains("Exchange")) {
					System.out.println("Text is present");
					sheet1.getRow(k++).createCell(1).setCellValue("Text is present");
					sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				} else {
					System.out.println("Text is absent");
					sheet1.getRow(k++).createCell(1).setCellValue("Text is absent");
					sheet1.getRow(l++).createCell(2).setCellValue("Fail");

				}
				System.out.println("Checked all Fields");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Right click any where on the window and Choose Fields and choose Options in it");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				Thread.sleep(5000);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

				// DQ right click Font size.

				for (int i = 1; i <= 4; i++) {
					Thread.sleep(1000);

					Actions act3 = new Actions(driver);
					act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontsize1")))).perform();
					Thread.sleep(100);

					driver.findElement(By.xpath("//*[@id='container']/div//ul/li[5]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

					Thread.sleep(1000);

				}

				System.out.println("Checked Font size");
				sheet1.getRow(k++).createCell(1).setCellValue(
						"Right click any where on the window and Choose Font Size and choose Options in it.");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				Thread.sleep(1000);
				// Clear font size

				/*
				 * Actions act3=new Actions(driver);
				 * act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))
				 * ).perform(); driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 * act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontsize1"))))
				 * .perform(); Thread.sleep(100); driver.manage().timeouts().implicitlyWait(10,
				 * TimeUnit.SECONDS);
				 * driver.findElement(By.xpath(obj.getProperty("Clearfontsize"))).click();
				 * System.out.println("Checked Font size");
				 * sheet1.getRow(k++).createCell(1).setCellValue("Checked Font size");
				 * sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				 */

				// DQ right click Font Color.

				for (int i = 1; i <= 6; i++) {
					// log.right_click();
					Actions act = new Actions(driver);
					act.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(100);
					act.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontcolor1")))).perform();
					Thread.sleep(100);

					// right_click();

					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(" //*[@id='container']/div//ul/li[6]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(100);

				}
				Thread.sleep(1000);
				System.out.println("Checked Font color");
				sheet1.getRow(k++).createCell(1).setCellValue(
						"Right click any where on the window and Choose Font Color and choose Options in it.");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				// Clear font color

				/*
				 * Actions act=new Actions(driver);
				 * act.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1"))))
				 * .perform(); driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 * Thread.sleep(10);
				 * act.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontcolor1"))))
				 * .perform(); Thread.sleep(10); driver.manage().timeouts().implicitlyWait(10,
				 * TimeUnit.SECONDS);
				 * driver.findElement(By.xpath(obj.getProperty("Clearfontcolor"))).click();
				 * System.out.println("Checked Font color");
				 * sheet1.getRow(k++).createCell(1).setCellValue("Checked Font color");
				 * sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				 */

				// DQ Right-click Bold and Italic

				/*
				 * for(int i=5;i<=6;i++) { Actions act4=new Actions(driver);
				 * act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))
				 * ).perform(); driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 * Thread.sleep(10);
				 * act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Bold")))).
				 * perform(); Thread.sleep(10);
				 * 
				 * driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 * driver.findElement(By.xpath(
				 * "//*[@id='container']/div/div/div/div/div[5]/div/ul/li["+i+"]/button")).click
				 * (); driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				 * Thread.sleep(100); }
				 */

				Actions act4 = new Actions(driver);
				act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				// act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Bold")))).perform();
				driver.findElement(By.xpath(obj.getProperty("Bold"))).click();
				Thread.sleep(100);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				Actions act14 = new Actions(driver);
				act14.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				// act14.contextClick(driver.findElement(By.xpath(obj.getProperty("Italic")))).perform();
				driver.findElement(By.xpath(obj.getProperty("Italic"))).click();
				Thread.sleep(100);

				// act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Italic")))).perform();

				System.out.println("Checked Bold and Italic Fonts");
				sheet1.getRow(k++).createCell(1).setCellValue("Right click any where on the window and Choose Bolt");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				System.out.println("Checked Bold and Italic Fonts");
				sheet1.getRow(k++).createCell(1).setCellValue("Right click any where on the window and Choose Italic");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				Thread.sleep(1000);

				Actions act15 = new Actions(driver);
				act15.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				// act15.contextClick(driver.findElement(By.xpath(obj.getProperty("Clear")))).click();
				driver.findElement(By.xpath(obj.getProperty("Clear"))).click();
				Thread.sleep(100);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				sheet1.getRow(k++).createCell(1).setCellValue("Checked clear all styles");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				System.out.println("Checked clear all styles");

				// DQ Right-click Insert.

				for (int i = 1; i <= 2; i++) {

					Actions act5 = new Actions(driver);
					act5.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(100);
					act5.contextClick(driver.findElement(By.xpath(obj.getProperty("Insert")))).perform();
					Thread.sleep(100);

					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='container']/div//ul/li[10]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(100);
				}
				System.out.println("Checked insert option");
				sheet1.getRow(k++).createCell(1).setCellValue(
						" Right Click any where and go to Insert Choose Empty Cell Before or if not Choose Empty Cell After");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				// DQ Right-click Delete.

				for (int i = 1; i <= 2; i++) {
					Actions act6 = new Actions(driver);
					act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Delete")))).perform();
					Thread.sleep(100);

					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='container']/div//ul/li[11]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(1000);
				}
				System.out.println("Checked delete option");
				sheet1.getRow(k++).createCell(1).setCellValue(
						"Right click any where and check the Delete option for it(Selected Cell Content or Select Cell).");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				for (int i = 1; i <= 2; i++) {

					Actions act6 = new Actions(driver);
					act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Default")))).perform();
					Thread.sleep(100);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='container']/div//ul/li[15]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(1000);
				}
				System.out.println("Checked default option");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Right click any where and go to Defaults and test the two options.");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				// View
				int size=driver.findElements(By.xpath("//*[@id='container']/div//ul/li[3]/div/ul/li")).size();	
				for (int i = 1; i <= size; i++) {
					Thread.sleep(1000);

					Actions act3 = new Actions(driver);
					act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					act3.contextClick(driver.findElement(By.xpath(obj.getProperty("View")))).perform();
					Thread.sleep(100);
					driver.findElement(By.xpath("//*[@id='container']/div//ul/li[3]/div/ul/li[" + i + "]")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(obj.getProperty("Back"))).click();
					Thread.sleep(1000);

				}

				System.out.println("Checked View");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Right click any where and choose  View and choose Options in it.");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				Thread.sleep(1000);

				// Display Preferences

				// Widget Templetes
				int Widget_size=driver.findElements(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div/div")).size();
				for (int i = 1; i <Widget_size; i++) {
					Actions act8 = new Actions(driver);
					act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(obj.getProperty("Widget_Templete"))).click();
					// act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
					Thread.sleep(100);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(
							"/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div["+i+"]/div"))
							.click();
					// driver.findElement(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div["+i+"]")).click();
					Thread.sleep(10);
					// driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
					driver.findElement(By.xpath(obj.getProperty("Ok"))).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(1000);
				}
				if (driver.getPageSource().contains("Volume")) {
					System.out.println("Right click any where on the window and open Display Preferences");
					sheet1.getRow(k++).createCell(1).setCellValue("Text is present");
					sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				} else {
					System.out.println("Text is absent");
					sheet1.getRow(k++).createCell(1).setCellValue("Text is absent");
					sheet1.getRow(l++).createCell(2).setCellValue("Fail");
				}

				System.out.println("Checked Widget templetes option");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Checked all the Widget Templates against the Detailed Quote");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				// Fields
				for (int i = 1; i <= 6; i++) {
					Actions act8 = new Actions(driver);
					act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(obj.getProperty("Widget_Templete"))).click();
					driver.findElement(By.xpath(obj.getProperty("Fields"))).click();
					// act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
					driver.findElement(By.xpath("//label[contains(text(),'Show Short Field Names')]")).click();
					Thread.sleep(3000);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//					driver.findElement(By
//							.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div["
//									+ i + "]"))
//							.click();
					// /html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div[3]
					Thread.sleep(10);
					// driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
					driver.findElement(By.xpath(obj.getProperty("Ok"))).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(1000);
				}
				if (driver.getPageSource().contains("Volume")) {
					System.out.println("Text is present");
					sheet1.getRow(k++).createCell(1).setCellValue("Verifed Show Short Field Names  Check Box");
					sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				} else {
					System.out.println("Text is absent");
					sheet1.getRow(k++).createCell(1).setCellValue("Text is absent");
					sheet1.getRow(l++).createCell(2).setCellValue("Fail");
				}

				System.out.println("Checked fields option");
				sheet1.getRow(k++).createCell(1)
						.setCellValue("Checked all the Cell Templates against the Detailed Quote fields.");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				// Formatting
				for (int i = 1; i <= 5; i++) {
					Actions act8 = new Actions(driver);
					act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea3")))).perform();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath(obj.getProperty("Widget_Templete"))).click();
					driver.findElement(By.xpath(obj.getProperty("Formatting"))).click();
					// act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
					Thread.sleep(100);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(
							By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]"))
							.click();
					Thread.sleep(10);
					// driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
					driver.findElement(By.xpath(obj.getProperty("Ok"))).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					Thread.sleep(1000);
				}
				System.out.println("Checked formatting option");

				sheet1.getRow(k++).createCell(1).setCellValue("Verified Wrapped Cells Mode Check Box");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				sheet1.getRow(k++).createCell(1).setCellValue("Verified Show Column Separator  Check Box");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				sheet1.getRow(k++).createCell(1)
						.setCellValue("Verified Show Full Precision on non-trade data Check Box");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				sheet1.getRow(k++).createCell(1).setCellValue("Verified Show Full Precision on trade data Check Box");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				sheet1.getRow(k++).createCell(1).setCellValue("Verified Show Month Name(In Commodities) Check Box");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				// Testing Fields Customize

				Actions act8 = new Actions(driver);
				act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea3")))).perform();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Thread.sleep(100);
				act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Fieldsbutton")))).perform();
				Thread.sleep(100);
				driver.findElement(By.xpath(obj.getProperty("Customize"))).click();
				Thread.sleep(10);
				driver.findElement(By.xpath(obj.getProperty("New"))).click();
				driver.findElement(By.xpath(obj.getProperty("Enter_name"))).sendKeys("AuTest");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				act8.moveToElement(driver.findElement(By.xpath(obj.getProperty("Select_arrow")))).click().perform();
				//driver.findElement(By.xpath(obj.getProperty("Select_arrow"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Thread.sleep(100);
				WebElement element = driver.findElement(By.xpath(obj.getProperty("Save")));
				Actions action = new Actions(driver);
				action.moveToElement(element).click().perform();
				// driver.findElement(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[3]/div/div/button[1]")).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				// checking edit option
				WebElement element1 = driver.findElement(By.xpath(obj.getProperty("Edit")));
				Actions action1 = new Actions(driver);
				action1.moveToElement(element1).click().perform();
				// driver.findElement(By.xpath("//button[contains(text(),'Edit')]")).click();
				Thread.sleep(10);
				WebElement element2 = driver.findElement(By.xpath(obj.getProperty("Cancel")));
				Actions action2 = new Actions(driver);
				action2.moveToElement(element2).click().perform();
				// driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();

				// Checking delete option
				driver.findElement(By.xpath(obj.getProperty("Delete1"))).click();
				Thread.sleep(10);
				driver.findElement(By.xpath(obj.getProperty("No"))).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.findElement(By.xpath(obj.getProperty("Close"))).click();
				System.out.println("Checked Fields Customize along with new edit and delete options");
				sheet1.getRow(k++).createCell(1).setCellValue("Checked OK,Apply and cancel Buttons");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");

				// Symbol Linking
				for (int i = 1; i <= 2; i++) {
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//button[@class='pt-button pt-minimal']")).click();
					Thread.sleep(10);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='container']/div//div[5]/div/ul/li[" + i + "]/button"))
							.click();
					Thread.sleep(10);

				}
				System.out.println("Checked Symbol Linking");
				sheet1.getRow(k++).createCell(1).setCellValue("Checked Symbol Linking Drop Down");
				sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				// String
				// color=driver.findElement(By.xpath("//span[@class='pt-popover-target']//button[@class='pt-button
				// pt-minimal']")).getText();
				// System.out.println("Checked Symbol Linking is" + color);
				// String linkText =
				// driver.findElement(By.xpath(�//*[@id='container']/div//div[5]/div/ul/li["+i+"]/button�)).getAttribute(�innerText�);
				/*
				 * if(driver.getPageSource().contains("No Symbol Link")){
				 * System.out.println("No Symbol Link is present");
				 * sheet1.getRow(k++).createCell(1).setCellValue("No Symbol Link is present");
				 * sheet1.getRow(l++).createCell(2).setCellValue("Pass");
				 * 
				 * }else{ System.out.println("No Symbol Link is absent");
				 * sheet1.getRow(k++).createCell(1).setCellValue("No Symbol Link absent");
				 * sheet1.getRow(l++).createCell(2).setCellValue("Fail"); }
				 */
				for (int i = 4; i <= 10; i++) {
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//button[@class='pt-button pt-minimal']")).click();
					Thread.sleep(10);
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					driver.findElement(By.xpath("//*[@id='container']/div//div[5]/div/ul/li[" + i + "]/button"))
							.click();
					Thread.sleep(10);

				}

				//driver.close();
				
				// FileOutputStream fout =new FileOutputStream(new
				// File("D:\\testdata-result.xlsx"));
				FileOutputStream fout = new FileOutputStream(file);
				workbook.write(fout);
				//workbook.close();
				break;		
			}

		}
	}
	
	 @AfterMethod
		  public static void cleanUpAfterTestMethod(ITestResult result) throws Exception {
			   
			 ((JavascriptExecutor)driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
		        Thread.sleep(3000);
		        driver.quit();

		    }
	
}
