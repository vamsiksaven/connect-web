/*package Ide.Idp.StepDef;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.saucelabs.saucerest.SauceREST;

import LIB.SauceUtils;
import cucumber.api.Scenario;

import java.net.MalformedURLException;
import java.net.URL;
 
public class SampleSauceTest {
 
  public static final String USERNAME = "Saven777999";
  public static final String ACCESS_KEY = "7bf028a1-7f8f-4ab7-9a7e-d47282c71458";
  public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";
  public static WebDriver driver;
  
    public static String sessionId;
	public static WebDriverWait wait;
	public final String BASE_URL = "https://www.saucedemo.com";
	public static SauceUtils sauceUtils;
  
  
  public static void main(String[] args) throws Exception {
 
    DesiredCapabilities caps = DesiredCapabilities.chrome();
    caps.setCapability("platform", "Windows 10");
    caps.setCapability("version", "75.0");
 
    driver = new RemoteWebDriver(new URL(URL), caps);
    Thread.sleep(5000);
    driver.get("https://www.seleniumhq.org/");
    
    Thread.sleep(3000);

    driver.close();
    driver.quit();
	  
	  
	  setUp();
	  cleanUpAfterTestMethod(null);
	  
  }
	  
	// @AfterMethod
	  public static void cleanUpAfterTestMethod(ITestResult result) throws Exception {
		   
		 ((JavascriptExecutor)driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
	        Thread.sleep(3000);
	        driver.quit();
//	        Thread.sleep(3000);
//	        driver.close();
	    //}
   }
  
//@Test
  public static void setUp() throws MalformedURLException {  //Scenario scenario
      //Set up the ChromeOptions object, which will store the capabilities for the Sauce run
      ChromeOptions caps = new ChromeOptions();
      caps.setCapability("version", "72.0");
      caps.setCapability("platform", "Windows 10");
      caps.setExperimentalOption("w3c", true);

      //Create a map of capabilities called "sauce:options", which contain the info necessary to run on Sauce
      // Labs, using the credentials stored in the environment variables. Also runs using the new W3C standard.
      MutableCapabilities sauceOptions = new MutableCapabilities();
      sauceOptions.setCapability("username", USERNAME);
      sauceOptions.setCapability("accessKey", ACCESS_KEY);
      sauceOptions.setCapability("seleniumVersion", "3.141.59");
      //sauceOptions.setCapability("name", scenario.getName());

      //Assign the Sauce Options to the base capabilities
      caps.setCapability("sauce:options", sauceOptions);

      //Create a new RemoteWebDriver, which will initialize the test execution on Sauce Labs servers
      String SAUCE_REMOTE_URL = "https://ondemand.saucelabs.com/wd/hub";
      driver = new RemoteWebDriver(new URL(SAUCE_REMOTE_URL), caps);
      sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
      wait = new WebDriverWait(driver, 10);

      SauceREST sauceREST = new SauceREST(USERNAME, ACCESS_KEY);
      sauceUtils = new SauceUtils(sauceREST);
      
      driver.get("https://www.seleniumhq.org/");
  }

  public static void tearDown(Scenario scenario) throws Exception{
	  Thread.sleep(3000);
	  driver.quit();
	  Thread.sleep(3000);
      sauceUtils.updateResults(!scenario.isFailed(), sessionId);
      driver.close();
      
  }
















}




*/