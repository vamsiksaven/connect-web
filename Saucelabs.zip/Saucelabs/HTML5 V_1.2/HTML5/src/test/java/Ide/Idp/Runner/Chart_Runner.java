package Ide.Idp.Runner;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;

import LIB.Common;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(plugin = { "html:target/cucumber-html-report", "json:target/cucumber.json",
		"pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
		"junit:target/cucumber-results.xml" }, features = "../HTML5/Featuresfiles/Chart.feature", glue = "Ide.Idp.StepDef")
public class Chart_Runner extends AbstractTestNGCucumberTests {
	public static WebDriver driver;
	public Common com = new Common();
	public Chart_Runner() {
		driver = Common.driver;
	}
	
	 @AfterMethod
	  public static void cleanUpAfterTestMethod(ITestResult result) throws Exception {
		   
		 ((JavascriptExecutor)Common.driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
	        Thread.sleep(3000);
	        Common.driver.quit();

	    }
	
	/*@AfterMethod(alwaysRun = true)
	public void cleanUpAfterTestMethod(ITestResult result) throws IOException, InterruptedException {
		System.out.println("cleanUpAfterTestMethod");
		Thread.sleep(5000);
		 ((JavascriptExecutor)Common.driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
		 System.out.println("JavascriptExecutor");
	}
	
	@AfterSuite(alwaysRun = true)
	public void quit() throws Exception {
		System.out.println("quit");
		Thread.sleep(3000);
		com.QuitObject("ILTC-00027,Login,Quit the Object");
	}*/
	

}