package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LIB.Common;
//import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Forex {
	public Common com = new Common();
	public Forex F;
	public WebDriver driver;
	public String Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public Forex() {
		driver = Common.driver;
		com.sleepThread(10000);
	}
//	@When("^Click on right click on option in widget name$")
//	public void Right_click_on_widget() throws Exception {
//		com.sleepThread(3000);
//		
//		com.Rightclick("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/div[1]", "Right click on widget");
//		
//	}
	
	
	@Given("^Verify and click on Forex$")
	public void Verify_and_click_on_Forex() throws Exception {
		com.sleepThread(30000);
		String Forex = Common.readPropertyByForex().getProperty("Forex");
		com.verifyElementPresent("xpath",Forex, "ICATC-00001,Forex,Verify the Forex");
		//System.out.println(Forex);
		com.sleepThread(2000);
		//com.click("xpath",Forex,"ICATC-00002,Chart,Click on Forex");
	}
//	@And("^Click on Forex$")
//	public void Click_on_Forex() throws Exception {
//		String  Forex = Common.readPropertyByForex().getProperty("Forex");
//		com.sleepThread(12000);
//		com.click("xpath",Forex, "ICATC-00002,Chart,Click on Forex");
//	}
	@When("^Verify the Symbol Linking in Forex$")
	public void Verify_the_Symbol_Linking_in_Forex() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		//System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking,"ICATC-00003," + Widget_name + ",Verify the Symbol Linking in Forex");
	}

	@And("^Click on Symbol Linking in Forex$")
	public void click_on_Symbol_Linking_in_Forex() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.sleepThread(3000);
		com.click("xpath", Symbol_Linking, "ICATC-00004," + Widget_name + ",Click on Symbol Linking in Forex");
	}

	@And("^click on each Check Functionalities in Forex$")
	public void check_Functionalities_in_Forex() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		F=new Forex();
		int count = driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i <= 2; i++) {
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]",
					"ICATC-00005," + Widget_name + ",Verify the each Check Functionalities in Forex");
			com.click("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]",
					"ICATC-00006," + Widget_name + ",Click on each Check Functionalities in Forex");
			com.sleepThread(3000);
			F.click_on_Symbol_Linking_in_Forex();
		}
		F=new Forex();
		int count1 = driver
				.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+j+"]/button[1]",
					"ICATC-00005," + Widget_name + ",Verify the each Check Functionalities in Forex");
			com.sleepThread(2000);
			com.click("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+j+"]/button[1]",
					"ICATC-00006," + Widget_name + ",Click on each Check Functionalities in Forex");
			com.sleepThread(3000);
			F.click_on_Symbol_Linking_in_Forex();
		}
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]", "click on Link to all option" );
	}
	
//	@When("^Verify the spot rate drop down$")
//	public void Verify_the_spot_rate_drop_down() throws Exception {
//		com.sleepThread(2000);
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
//		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
//		com.verifyElementPresent("xpath",spotrate,"INTC-00010," + Widget_name +",Verify Spotrate dropdown");
// 
//	}
	@Then("^Click on spot rate drop down$")
	public void Click_on_spot_rate_drop_down() throws Exception {
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
		com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");

	}	
	
//	@And("^Click on each options in spot rate drop down$")
//	public void Click_on_each_options_in_spot_rate_drop_down() throws Exception
//	{
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
//		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]")).size();
//		System.out.println(size);
//		for (int i = 1; i <=size; i++) {
//			//String spotrate=Common.readPropertyByForex().getProperty("spotrate");
//			//com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");
//			com.verifyElementPresent("xpath","//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li["+i+"]","Verify each option under spotrate drop down");
//			com.sleepThread(2000);
//			com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li["+i+"]","Verify each option under spotrate drop down");
//			com.sleepThread(2000);						
//			com.click("xpath","//div[@class='css-y72j2n']","Click on Forex widget tab");
//			com.sleepThread(2000);			
//			
//			//com.click("xpath","//div[@class='css-y72j2n']","Click on Forex widget tab");
//		}
//		com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[1]","Click on spot rate 1st option");
//	}
	
	@And ("^Click on spotrate check box$")
	public void Click_on_spotrate_check_box() throws Exception {
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]", "Click on Spotrate check box");
		
	}
	@And ("^Click on 1 week forward check box$")
	public void Click_on_1_week_forward_check_box() throws Exception {
		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
		com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[2]/button[1]", "Click on 1 week forward check box");
	}
	@And ("^Click on 2 weeks forward check box$")
	public void Click_on_2_weeks_forward_check_box() throws Exception {
		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
		com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[3]/button[1]","Click on 2 weeks forward check box");
	}
	
	@And ("^Click on 1 month forward check box$")
	public void Click_on_1_month_forward_check_box() throws Exception {
		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
		com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[4]/button[1]", "Click on 1 month forward check box");
	}
	@And ("^Click on 2 months forward check box$")
	public void Click_on_2_months_forward_check_box() throws Exception {
		String spotrate=Common.readPropertyByForex().getProperty("spotrate");
		com.click("xpath",spotrate,"INTC-00010," +Widget_name+ ",Click on Spotrate drop down");
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[5]/button[1]", "Click on 2 months forward check box");
		com.sleepThread(2000);
		//com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]", "Click on Spotrate check box");
		//com.sleepThread(2000);
	}
	
	@When("^Right click on data box options$")
	public void Right_click_on_data_box_options() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String data_box=Common.readPropertyByForex().getProperty("data_box");
		com.Rightclick("xpath",data_box,"INTC-00010,"+Widget_name+"Right click on data box");
		com.sleepThread(2000);
	}
	@Then("^verify the View option in Forex$")
	public void verify_the_View_option_in_Forex() throws Exception
	{
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String View=Common.readPropertyByForex().getProperty("View");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath",View,"INTC-00010,"+Widget_name+",Verify View option");

	}
	
	@And("^Click on Chart options in spot rate drop down$")
	
	public void Click_on_chart_options_in_spot_rate_drop_down() throws Exception {
		com.sleepThread(2000);
		com.startAction();
		
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		//String View=Common.readPropertyByForex().getProperty("View");
		//String data_box=Common.readPropertyByForex().getProperty("data_box");
		//com.Rightclick("xpath",data_box,"INTC-00010,"+Widget_name+"Right click on data box");
		com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]/span[1]/span[1]/*[local-name()='svg'][1]","INTC-00010,"+Widget_name+"Verify View option");
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[2]/button[1]","Verify on Chart option under view side menu");
		com.sleepThread(2000);
		//com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[2]/button[1]","Click on Chart option under view side menu");
		//com.sleepThread(2000);
	    //com.Rightclick("xpath","//li[@class='css-k1a6dw']//div[@class='css-y72j2n']", "Right click on Chart widget");
	    //com.sleepThread(2000);
	    //com.click("xpath","//button[contains(text(),'Close Tab')]", "Click on Close Tab");
	    com.sleepThread(2000);
	    }
	
	@And("^Click on Detailed Quotes options in spot rate drop down$")
	
	public void Click_on_Detailed_Quotes_options_in_spot_rate_drop_down() throws Exception {
		com.sleepThread(2000);
		com.startAction();
		//String View=Common.readPropertyByForex().getProperty("View");
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		//String View=Common.readPropertyByForex().getProperty("");
		//String data_box=Common.readPropertyByForex().getProperty("data_box");
		//com.Rightclick("xpath",data_box,"INTC-00010,"+Widget_name+"Right click on data box");
		//com.click("xpath",View,"INTC-00010,"+Widget_name+"Verify View option");
		com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]/span[1]/span[1]/*[local-name()='svg'][1]","INTC-00010,"+Widget_name+"Verify View option");
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]","Verify on Detailed Quotes option under view side menu");
		com.sleepThread(2000);
		//com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li[1]/button[1]","Click on Detailed Quotes option under view side menu");
		//com.sleepThread(2000);
	    //com.Rightclick("xpath","//li[@class='css-1rm2l62']//div[@class='css-y72j2n']", "Right click on Detailed Quotes widget");
	    //.sleepThread(2000);
	    //com.click("xpath","//button[contains(text(),'Close Tab')]", "Click on Close Tab");
	    com.sleepThread(2000);
	    }
	
	@And("^Verify the Add to Symbol List option in Forex$")
	public void Verify_the_Add_to_Symbol_List_option_in_Forex() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Add_to_symol_list=Common.readPropertyByForex().getProperty("Add_to_symol_list");
		com.verifyElementPresent("xpath",Add_to_symol_list,"INTC-00010,"+Widget_name+",Verify Add to Symbol List");
	}
	
	

		
	@And("^Verify Show change indicator in forex$")
	public void Verify_Show_change_indicator_in_forex() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String data_box = Common.readPropertyByForex().getProperty("data_box");
		String  show_change_indicator= Common.readPropertyByForex().getProperty("show_change_indicator");
		com.Rightclick("xpath", data_box,"ICTC-00196," + Widget_name + ",Right click on data box option");
		com.verifyElementPresent("xpath",show_change_indicator,"Verifying show change indicator");
		
	}
		
	@And("^Click on show change indicator in Forex$")
	public void Click_on_show_change_indicator_in_Forex() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String show_change_indicator=Common.readPropertyByForex().getProperty("show_change_indicator");
		com.click("xpath",show_change_indicator,"INTC-00010,"+Widget_name+",Clikcing on show change indicator");

	}
	@And("^Click and verify defauilts in Forex$")
	public void Click_and_verify_defauilts_in_Forex() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Defaults=Common.readPropertyByForex().getProperty("Defaults");
		String data_box = Common.readPropertyByForex().getProperty("data_box");
		com.Rightclick("xpath", data_box,"ICTC-00196," + Widget_name + ",Right click on data box option");
		com.verifyElementPresent("xpath",Defaults,"INTC-00011" + Widget_name +",Verifying Defaults option");
		com.click("xpath",Defaults,"INTC-00012" + Widget_name +",clicking on Defaults option");

	}
	@And("^Click and verify Display preferences in Forex$")
	public void Click_and_verify_Display_preferences_in_Forex() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Display_Preference=Common.readPropertyByForex().getProperty("Display_Preference");
		String data_box = Common.readPropertyByForex().getProperty("data_box");
		com.Rightclick("xpath", data_box,"ICTC-00196," + Widget_name + ",Right click on data box option");
		com.verifyElementPresent("xpath",Display_Preference,"INTC-00012"+Widget_name+ ",Verifying Display Prefrence option");
		com.click("xpath",Display_Preference,"INTC-00010,"+Widget_name+",Clicking on Display Preference");
}
	
	@And("^Verify Display Preferences pop title in Forex$")
	public void Verify_Display_Preferences_pop_title_in_Forex() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_title = Common.readPropertyByForex().getProperty("Display_Preferences_pop_title");
		com.verifyElementPresent("xpath", Display_Preferences_pop_title,"IWLTC-00026,"+Widget_name+",Verify Display Preferences pop title");
	}

	@And("^Verify Display Preferences pop close icon in Forex$")
	public void Verify_Display_Preferences_pop_close_icon_in_Forex() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		//String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List().getProperty("Display_Preferences_pop_close_icon");
		String Close = Common.readPropertyByForex().getProperty("Close");
		com.verifyElementPresent("xpath", Close,"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
	}

	@And("^Verify Display Preferences pop save button in Forex$")
	public void Verify_Display_Preferences_pop_save_button_in_Forex() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save = Common.readPropertyByForex().getProperty("Save");
		com.verifyElementPresent("xpath", Save,"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop save button");
	}

	@And("^Verify Display Preferences pop Cancel button in Forex$")
	public void Verify_Display_Preferences_pop_Cancel_button_in_Forex() throws Exception {
		com.startAction();
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Cancel = Common.readPropertyByForex().getProperty("Cancel");
		com.verifyElementPresent("xpath", Cancel,"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
	}
	
	
		
	@And("^Verify the each Available options$")
	public void Verify_the_each_Available_options() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/button")).size();
		System.out.println(size);
		for (int i = 1; i <size; i++) {
			//String Display_Preference=Common.readPropertyByNews().getProperty("Display_Preference");
			//String data_box = Common.readPropertyByChart().getProperty("data_box");			
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/button["+i+"]",",Verify Each option in available section");
			com.sleepThread(3000);
//			F.Verify_Display_Preferences_pop_save_button_in_Forex();	
//			com.sleepThread(2000);
//			F.Right_click_on_data_box_options();
//			com.sleepThread(1000);
//			F.Click_and_verify_Display_preferences_in_Forex();
		}
		
	}
	@And("^Verify double Arrow right icon is working or not$")
	public void Verify_double_Arrow_right_icon_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[2]/button[1]/*[local-name()='svg'][1]","Verifying rightside facing arrow");
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[2]/button[2]/*[local-name()='svg'][1]","Verifying leftside facing arrow");

	}
	@And("^Verify double Arrow left icon is working or not$")
	public void Verify_double_Arrow_left_icon_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[3]/button[1]/*[local-name()='svg'][1]","Verifying upside facing arrow");
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[3]/button[2]/*[local-name()='svg'][1]","Verifying downside facing arrow");
		String Cancel = Common.readPropertyByForex().getProperty("Cancel");
		com.click("xpath", Cancel,"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
	}
	
	
	@When("^Verify the Edit button$")
	public void Verify_the_Edit_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]", "Verifying Edit option");
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]","Clikcing on Edit option");
		com.sleepThread(2000);
		com.startAction();
		String Display_Preferences_pop_title = Common.readPropertyByForex().getProperty("Display_Preferences_pop_title");
		com.verifyElementPresent("xpath", Display_Preferences_pop_title,"IWLTC-00026,"+Widget_name+",Verify Display Preferences pop title");
		}
	
	
}
