package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Research {
	public Common com = new Common();
	public WebDriver driver;
	public Research Rs;
	public String Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Research() {
		driver = Common.driver;
	}

	@Given("^Verify the Research$")
	public void Verify_the_chart() throws Exception {
		com.sleepThread(10000);
		String  Research= Common.readPropertyByResearch().getProperty("Research");
		com.verifyElementPresent("xpath",Research, "IRSTC-00001,Research,Verify the Research");
	}
	@And("^Click on Research$")
	public void Click_on_Chart() throws Exception {
		String   Research= Common.readPropertyByResearch().getProperty("Research");
		com.sleepThread(12000);
		com.click("xpath",Research, "IRSTC-00002,Research,Click on Research");
	}
	
	@When("^Verify the symbol lookup drop down$")
	public void Verify_the_symbol_lookup_drop_down() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String  symbol_lookup_drop_down= Common.readPropertyByResearch().getProperty("symbol_lookup_drop_down");
		com.verifyElementPresent("xpath",symbol_lookup_drop_down, "IRSTC-0003,Research,Verify the symbol lookup drop down");
	}
	@Then("^click on symbol lookup drop down icon$")
	public void click_on_symbol_lookup_drop_down_icon() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String symbol_lookup_drop_down_icon=Common.readPropertyByResearch().getProperty("symbol_lookup_drop_down_icon");
		com.click("xpath",symbol_lookup_drop_down_icon, "IRSTC-0004,Research,click on symbol lookup drop down icon");

	}
	@And("^Verify the title in display all companies pop$")
	public void Verify_the_title_in_display_all_companies_pop() throws Exception	
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String  title_in_display_all_companies_pop= Common.readPropertyByResearch().getProperty("title_in_display_all_companies_pop");
		com.verifyElementPresent("xpath",title_in_display_all_companies_pop, "IRSTC-0005,Research,Verify the title in display all companies pop");

	}
	@And("Verify the display all companies text is displayed or not in display all companies pop")
	public void Verify_the_display_all_companies_text_is_displayed_or_not_in_display_all_companies_pop() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String  display_all_companies_text= Common.readPropertyByResearch().getProperty("display_all_companies_text");
		com.verifyElementPresent("xpath",display_all_companies_text, "IRSTC-0006,Research,Verify the display all companies text is displayed or not in display all companies pop");

	}
	@And("^Check Close button is working or not in Symbol lookup dropdown$")
    public void click_on_close_icon_in_display_all_companies_pop() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String close_icon_in_display_all_companies_pop=Common.readPropertyByResearch().getProperty("close_icon_in_display_all_companies_pop");
		com.click("xpath",close_icon_in_display_all_companies_pop, "IRSTC-0007,Research,Check Close button is working or not in Symbol lookup dropdown");

	}
	@And("^Check Clear All button is working or not in Symbol lookup dropdown$")
	public void Click_on_clear_all_button_in_display_all_companies_pop() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String clear_all_button_in_display_all_companies_pop=Common.readPropertyByResearch().getProperty("clear_all_button_in_display_all_companies_pop");
		com.click("xpath",clear_all_button_in_display_all_companies_pop, "IRSTC-0008,Research,Check Clear All button is working or not in Symbol lookup dropdown");
	}
	@When("Click on Identifier Lookup icon an Identifier Lookup window will open")
	public void Click_on_Identifier_Lookup_icon_an_Identifier_Lookup_window_will_open() throws Exception {
		
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Identifier_Lookup_icon=Common.readPropertyByResearch().getProperty("Identifier_Lookup_icon");
		com.MouseOverToclickabl("xpath",Identifier_Lookup_icon,"IRSTC-0009,Research,Click on Identifier Lookup icon");
		String Identifier_Lookup_window_title=Common.readPropertyByResearch().getProperty("Identifier_Lookup_window_title");
		com.verifyText_Using_String("xpath",Identifier_Lookup_window_title," Identifier Lookup ","IRSTC-0010,Research,verify identifier Lookup window will open or not");
	}
	@Then("^Check Search box \"(.*?)\" is working or not$")
	public void Check_Search_box_is_working_or_not(String Search_name) throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Search_box_in_Identifier_Lookup_window=Common.readPropertyByResearch().getProperty("Search_box_in_Identifier_Lookup_window");
		com.sendKeys("xpath",Search_box_in_Identifier_Lookup_window,Search_name,"IRSTC-0011,Research,Enter IBM Symbol in search box");
		String Symbol_row=Common.readPropertyByResearch().getProperty("");
		com.verifyElementPresent("xpath",Symbol_row,"IRSTC-0012,Research,Verify the search data are showing or not");
	}
	@And("^Check all CATEGORIES options in Identifier lookup window$")
	public void Check_all_CATEGORIES_options_in_Identifier_lookup_window() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.sleepThread(3000);
		int size=driver.findElements(By.xpath("//*[contains(@class,'tf-options-pane-scroll-container')]/category-repeater/tf-options-pane-item")).size();
		System.out.println("all CATEGORIES options:"+size);
		try {
		for (int i = 1; i <=size; i++) {
		com.click("xpath","//*[contains(@class,'tf-options-pane-scroll-container')]/category-repeater["+i+"]/tf-options-pane-item","IRSTC-0013,Research,Check all CATEGORIES options in Identifier lookup window");	
		com.sleepThread(2000);
		String Results_Row=Common.readPropertyByResearch().getProperty("Results_Row");
		com.verifyElementPresent("xpath",Results_Row,"IRSTC-0014,Research,Verify the Results rows");			
		}}
		catch (Exception e) {
			System.out.println("Can`t displayed CATEGORIES rows");
		}
	}
	@And("^Click on Expand icon on Fixed Income in Categories Section is working or not$")
	public void Click_on_Expand_icon_on_Fixed_Income_in_Categories_Section_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Fixed_Income =Common.readPropertyByResearch().getProperty("Fixed_Income");
		com.verifyElementPresent("xpath",Fixed_Income,"IRSTC-0015,Research,Verify the text fixed income");
		com.sleepThread(4000);
		com.startAction();
		String Expand_icon=Common.readPropertyByResearch().getProperty("Expand_icon");
		com.MouseOverToclickabl("xpath",Expand_icon,"IRSTC-0016,Research,Click on Expand icon on Fixed Income");
		String Fixed_Income_icon_Corporate=Common.readPropertyByResearch().getProperty("Fixed_Income_icon_Corporate");
		com.click("xpath",Fixed_Income_icon_Corporate,"IRSTC-0017,Research,Click on Corporate option");
		String Results_Row=Common.readPropertyByResearch().getProperty("Results_Row");
		com.verifyElementPresent("xpath",Results_Row,"IRSTC-0018,Research,Verify the Results rows");	
	}
	@And("^Click on Expand icon on Indices in Categories Section is working or not$")
	public void Click_on_Expand_icon_on_Indices_in_Categories_Section_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Indices =Common.readPropertyByResearch().getProperty("Indices");
		com.verifyElementPresent("xpath",Indices,"IRSTC-0019,Research,Verify the text Indices");
		com.sleepThread(4000);
		com.startAction();
		String Expand_icon_Indices=Common.readPropertyByResearch().getProperty("Expand_icon_Indices");
		com.MouseOverToclickabl("xpath",Expand_icon_Indices,"IRSTC-0020,Research,Click on Expand icon on Fixed Income");
		int Size=driver.findElements(By.xpath("//*[contains(@class,'tf-options-pane-scroll-container')]/category-repeater/following::tf-options-pane-item[2]")).size();
		for (int i = 2; i <=Size; i++) {
		com.click("xpath","//*[contains(@class,'tf-options-pane-scroll-container')]/category-repeater["+i+"]/following::tf-options-pane-item[2]","IRSTC-0021,Research,Verify Indices in Categories Section is working or not");
		String Results_Row=Common.readPropertyByResearch().getProperty("Results_Row");
		com.verifyElementPresent("xpath",Results_Row,"IRSTC-0022,Research,Verify the Results rows");	
		}
	}
	@And("^Check Filters Drop down is working or not$")
	public void Check_Filters_Drop_down_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Filters_Drop_down=Common.readPropertyByResearch().getProperty("Filters_Drop_down");
		com.click("xpath", Filters_Drop_down, "IRSTC-0023,Research,Check Filters Drop down is working or not");
	}
	
	@And("^Chek Forward and backward buttons are working or not in Filters drop down$")
	public void Chek_Forward_and_backward_buttons_are_working_or_not_in_Filters_drop_down() throws Exception{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		int size=driver.findElements(By.xpath("//*[contains(@class,'es-rhp-top')]/aggregate/following::div[1]")).size();
		for (int i = 1; i < size; i++) {
			com.verifyElementPresent("xpath","//*[contains(@class,'es-rhp-top')]/aggregate["+i+"]/following::div[1]", "IRSTC-0024,Research,Verify filters options");
			com.sleepThread(2000);
			String Forward_buttons=Common.readPropertyByResearch().getProperty("Forward_buttons");
			com.click("xpath",Forward_buttons, "IRSTC-0025,Research,Click on forward button");
			com.sleepThread(2000);			
		}
		for (int j = 0; j < size; j++) {
			com.verifyElementPresent("xpath","//*[contains(@class,'es-rhp-top')]/aggregate["+j+"]/following::div[1]", "IRSTC-0026,Research,Verify filters options");
			String backward_buttons=Common.readPropertyByResearch().getProperty("backward_buttons");
			com.click("xpath",backward_buttons, "IRSTC-0027,Research,Click on backward buttons");
			com.sleepThread(2000);			
		}
	}
	@And("^Check Clear All Filter is working or not$")
	public void Check_Clear_All_Filter_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Select_filter=Common.readPropertyByResearch().getProperty("Select_filter");
		com.MouseOverToclickabl("xpath",Select_filter,"IRSTC-0028,Research,Select the filter option");
		String Selected_option=Common.readPropertyByResearch().getProperty("Selected_option");
		com.verifyElementPresent("xpath",Selected_option,"IRSTC-0029,Research,Verify the filter opton is showing or not");
		com.sleepThread(2000);
		String Clear_All_Filter=Common.readPropertyByResearch().getProperty("Clear_All_Filter");
		com.MouseOverToclickabl("xpath",Clear_All_Filter,"IRSTC-0030,Research,Check Clear All Filter is working or not");
		com.sleepThread(4000);
		com.verify_pop_closeing_or_not("xpath",Selected_option,"IRSTC-0031,Research,Verify the filter opton is clear all or not");
	}
	@And("^Check Reset filter is working or not$")
	public void Check_Reset_filter_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Select_filter=Common.readPropertyByResearch().getProperty("Select_filter");
		com.MouseOverToclickabl("xpath",Select_filter,"IRSTC-0032,Research,Select the filter option");
		String Selected_option=Common.readPropertyByResearch().getProperty("Selected_option");
		com.verifyElementPresent("xpath",Selected_option,"IRSTC-0033,Research,Verify the filter opton is showing or not");
		com.sleepThread(2000);
		String Reset_button=Common.readPropertyByResearch().getProperty("Reset_button");
		com.MouseOverToclickabl("xpath",Reset_button,"IRSTC-0034,Research,Check Reset filter is working or not");
		com.sleepThread(2000);
		com.verify_pop_closeing_or_not("xpath",Selected_option,"IRSTC-0035,Research,Verify the filter opton is clear all or not");
	}
	@And("^Check Help button is working or not$")
	public void Check_Help_button_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Help_icon=Common.readPropertyByResearch().getProperty("Help_icon");
		com.MouseOverToclickabl("xpath",Help_icon,"IRSTC-0036,Research,Check Help button is working or not");
		com.sleepThread(3000);
		com.handle_to_multiple_tabs("FactSet Login","IRSTC-0037,Research,Verify the tab is opning or not");
		com.sleepThread(5000);
	}
	@And("^Check Filters Drop down is working or not1$")
	public void Check_Filters_Drop_down_is_working_or_not1() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.sleepThread(5000);
		com.selectFrameById("frameID");
		String Filters_Drop_down=Common.readPropertyByResearch().getProperty("Filters_Drop_down");
		com.click("xpath", Filters_Drop_down, "IRSTC-0038,Research,Check Filters Drop down is working or not");
	}
	
	@And("^Select any name in relsuts field and click on Add ID button$")
	public void Select_any_name_in_relsuts_field_and_click_on_Add_ID_button() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.sleepThread(3000);
		com.startAction();
		String relsuts_field=Common.readPropertyByResearch().getProperty("relsuts_field");
		com.MouseOverToclickabl("xpath",relsuts_field,"IRSTC-0039,Research,Select any name in relsuts field and click on Add ID button");
		com.sleepThread(2000);
		String Add_id_button=Common.readPropertyByResearch().getProperty("Add_id_button");
		com.MouseOverToclickabl("xpath",Add_id_button,"IRSTC-0040,Research,Click on add id button");
		com.sleepThread(2000);
		String Added_in_Selected_List1=Common.readPropertyByResearch().getProperty("Added_in_Selected_List");
		String Added_in_Selected_List=driver.findElement(By.xpath(Added_in_Selected_List1)).getText();
		com.verifyText_Using_String("xpath", relsuts_field, Added_in_Selected_List,"IRSTC-0041,Research,Verify the Selected Symbol Should be Added in Selected List showing or not");
	}
	@And("^Selected Symbol Should be Added in Selected List$")
	public void Selected_Symbol_Should_be_Added_in_Selected_List() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Added_in_Selected_List=Common.readPropertyByResearch().getProperty("Added_in_Selected_List");
		com.verifyElementPresent("xpath", Added_in_Selected_List,"IRSTC-0042,Research,Selected Symbol Should be Added in Selected List");
	}
	@And("^Check Remove Icon is working or not in Selected name list$")
	public void Check_Remove_Icon_is_working_or_not_in_Selected_name_list() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Remove_Icon=Common.readPropertyByResearch().getProperty("Remove_Icon");
		com.MouseOverToclickabl("xpath",Remove_Icon,"IRSTC-0043,Research,Click on remove icon");
		com.sleepThread(2000);
		String Added_in_Selected_List=Common.readPropertyByResearch().getProperty("Added_in_Selected_List");
		com.verify_pop_closeing_or_not("xpath", Added_in_Selected_List,"IRSTC-0044,Research,Check Remove Icon is working or not in Selected name list");
	}
	@And("^Check Remove All icon is working or not$")
	public void Check_Remove_All_icon_is_working_or_not() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Remove_Icon_All=Common.readPropertyByResearch().getProperty("Remove_Icon_All");
		com.MouseOverToclickabl("xpath",Remove_Icon_All,"IRSTC-0045,Research,Click on remove all icon");
		com.sleepThread(2000);
		String Added_in_Selected_List=Common.readPropertyByResearch().getProperty("Added_in_Selected_List");
		com.verify_pop_closeing_or_not("xpath", Added_in_Selected_List,"IRSTC-0046,Research,Check Remove Icon is working or not in Selected name list");
	}
	@And("^Check ok button is working or not$")
	public void Check_ok_button_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Ok_button=Common.readPropertyByResearch().getProperty("Ok_button");
		com.startAction();
		com.MouseOverToElement("xpath",Ok_button,"IRSTC-0047,Research,Check ok button is working or not");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath",Ok_button,"IRSTC-0047,Research,Check ok button is working or not");
	}
	@And("^Check Cancel button is working or not$")
	public void Check_Cancel_button_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.sleepThread(4000);
		Common.zoomInZoomOut("90%");
		com.sleepThread(8000);
		String Cancel_button=Common.readPropertyByResearch().getProperty("Cancel_button");
		com.startAction();
		com.MouseOverToElement("xpath",Cancel_button,"IRSTC-0048,Research,Check Cancel button is working or not");
		com.MouseOverToclickabl("xpath",Cancel_button,"IRSTC-0048,Research,Check Cancel button is working or not");
		com.sleepThread(5000);
		String Remove_Icon_All=Common.readPropertyByResearch().getProperty("Remove_Icon_All");
		com.MouseOverToclickabl("xpath",Remove_Icon_All,"IRSTC-0045,Research,Click on remove all icon");
		com.sleepThread(5000);
		com.MouseOverkesys(Keys.ESCAPE,",Research,Click on escape button");
		com.sleepThread(5000);
		com.MouseOverkesys(Keys.ESCAPE,",Research,Click on escape button");
		//com.click("xpath",Cancel_button,"IRSTC-0048,Research,Check Cancel button is working or not");
	}
	@When("^Verify company research option$")
	public void Verify_company_research_option() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Company_Research=Common.readPropertyByResearch().getProperty("Company_Research");
		com.verifyElementPresent("xpath",Company_Research,"IRSTC-000,Research,Verify company research option");
	}
	@Then("^Click on company research option$")
	public void Click_on_company_research_option() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.sleepThread(20000);
		com.selectFrameById("frameID");
		String Company_Research=Common.readPropertyByResearch().getProperty("Company_Research");
		com.startAction();
		com.MouseOverToclickabl("xpath",Company_Research,"IRSTC-000,Research,Click on company research option");
		com.sleepThread(3000);
		//driver.switchTo().defaultContent();
	}
	@Then("^Click on company research$")
	public void Click_on_company_research() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Company_Research=Common.readPropertyByResearch().getProperty("Company_Research");
		com.startAction();
		com.MouseOverToclickabl("xpath",Company_Research,"IRSTC-000,Research,Click on company research option");
	}
	@When("^Verify Markets Research option$")
	public void Verify_Markets_Research_option() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Market_Research=Common.readPropertyByResearch().getProperty("Market_Research");
		com.verifyElementPresent("xpath",Market_Research,"IRSTC-000,Research,Verify Markets Research option");

	}
	@Then("^Click on Markets Research option$")
	public void Click_on_Markets_Research_option() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Market_Research=Common.readPropertyByResearch().getProperty("Market_Research");
		com.startAction();
		com.MouseOverToclickabl("xpath",Market_Research,"IRSTC-000,Research,Click on Markets Research option");
	}
	@When("^Verify All Research Options$")
	public void Verify_All_Research_Options() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String All_Research=Common.readPropertyByResearch().getProperty("All_Research");
		com.startAction();
		com.verifyElementPresent("xpath",All_Research,"IRSTC-000,Research,Verify All Research Options");

	}
	@Then("^Click on All Research Options$")
	public void Click_on_All_Research_Options() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String All_Research=Common.readPropertyByResearch().getProperty("All_Research");
		com.startAction();
		com.MouseOverToclickabl("xpath",All_Research,"IRSTC-000,Research,Click on All Research Options");
	}
	@And("^Verify Primary Check box is working or not$")
	public void Verify_Primary_Check_box_is_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Primary_checkbox=Common.readPropertyByResearch().getProperty("Primary_checkbox");
		com.click("xpath",Primary_checkbox,"IRSTC-000,Research,Verify Primary Check box is working or not");
		com.sleepThread(5000);
		try{
		com.sleepThread(10000);
		String slick_row_even=Common.readPropertyByResearch().getProperty("slick_row_even");
		com.click("xpath",slick_row_even,"IRSTC-000,Research,Verify slick data is displayed or not");
	    com.sleepThread(2000);
	    Verfiy_Collapse_Reading_pane_is_working_or_not();
	    com.sleepThread(2000);
	    Verfiy_Veiwer_option_is_working_or_not();
	    com.sleepThread(2000);
		com.selectFrameById("frameID");
		}catch(Exception t){
			com.sleepThread(3000);
			String No_Documents_Found=Common.readPropertyByResearch().getProperty("No_Documents_Found");
			com.verifyText_Using_String("xpath",No_Documents_Found,"No Documents Found",","+Widget_name+",Verify the No Documents Found massage is showing or not");

		}
	}
	
	@And("^Clcik on Calender icon drop down and verify all options are working or not$")
	public void Clcik_on_Calender_icon_drop_down_and_verify_all_options_are_working_or_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Calender_drop_down=Common.readPropertyByResearch().getProperty("Calender_drop_down");
		com.startAction();
		com.MouseOverToclickabl("xpath",Calender_drop_down,"IRSTC-000,Research,Verify Calender drop down options are working or not");
		String Start_date=Common.readPropertyByResearch().getProperty("Start_date");
		com.MouseOverToclickabl("xpath",Start_date,"IRSTC-000,Research,Click on any start date");
		com.sleepThread(2000);		
		String End_date=Common.readPropertyByResearch().getProperty("End_date");
		com.MouseOverToclickabl("xpath",End_date,"IRSTC-000,Research,Click on any end date");
		com.sleepThread(2000);
		String OK_button_in_Calender_drop_down=Common.readPropertyByResearch().getProperty("OK_button_in_Calender_drop_down");
		com.MouseOverToclickabl("xpath",OK_button_in_Calender_drop_down,"IRSTC-000,Research,Click on ok button");
		com.sleepThread(4000);
		try {
		com.sleepThread(10000);
		String slick_row_even=Common.readPropertyByResearch().getProperty("slick_row_even");
		com.verifyElementPresent("xpath",slick_row_even,"IRSTC-000,Research,Verify slick data is displayed or not");
		com.sleepThread(2000);
		Verfiy_Collapse_Reading_pane_is_working_or_not();
		com.sleepThread(2000);
		Verfiy_Veiwer_option_is_working_or_not();
		com.sleepThread(2000);
		com.selectFrameById("frameID");
	    }catch(Exception t){
		com.sleepThread(3000);
		String No_Documents_Found=Common.readPropertyByResearch().getProperty("No_Documents_Found");
		com.verifyText_Using_String("xpath",No_Documents_Found,"No Documents Found",","+Widget_name+",Verify the No Documents Found massage is showing or not");

	}
	}
	@And("^All Company Research drop down by selecting all options in it and check whether they are applying are not$")
	public void All_Company_Research_drop_down_by_selecting_all_options_in_it_and_check_whether_they_are_applying_are_not() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String All_Company_Research=Common.readPropertyByResearch().getProperty("All_Company_Research");
		com.click("xpath",All_Company_Research,"IRSTC-000,Research,Click on All company research drop down");
		com.sleepThread(2000);
		int size=driver.findElements(By.xpath("//*[contains(@class,'tf-menu-icon-gutter')]/span/tf-menu-item")).size();
		System.out.println("All Company Research drop down:"+size);
		for (int i = 1; i < size; i++) {
			try {
			com.startAction();
			com.MouseOverToclickabl("xpath","//*[contains(@class,'tf-menu-icon-gutter')]/span/tf-menu-item["+i+"]","All Company Research drop down by selecting all options");
			com.sleepThread(4000);
			}catch (Exception e) {
				System.out.println("Can`t dispalyed option");
			}			
			try {
				com.sleepThread(10000);
			String slick_row_even=Common.readPropertyByResearch().getProperty("slick_row_even");
			com.verifyElementPresent("xpath",slick_row_even,"IRSTC-000,Research,Verify slick data is displayed or not");
			com.sleepThread(2000);
			Verfiy_Collapse_Reading_pane_is_working_or_not();
			com.sleepThread(2000);
			Verfiy_Veiwer_option_is_working_or_not();
			com.selectFrameById("frameID");
			}catch(ArithmeticException t){
				com.sleepThread(2000);
				String No_Documents_Found=Common.readPropertyByResearch().getProperty("No_Documents_Found");
				com.verifyText_Using_String("xpath",No_Documents_Found,"No Documents Found",","+Widget_name+",Verify the No Documents Found massage is showing or not");
			}catch (Exception e) {
				System.out.println("No Documents Found massage is not showing or not");
			}
			
			com.sleepThread(2000);
			com.click("xpath",All_Company_Research,"IRSTC-000,Research,Click on All company research drop down");
			com.sleepThread(2000);
			}
	}
	@And("^Select the multiple option checkboxs in All Company Research drop down$")
	public void Select_the_multiple_option_checkboxs_in_All_Company_Research_drop_down() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		//com.sleepThread(5000);
		String All_Company_Research=Common.readPropertyByResearch().getProperty("All_Company_Research");
		//com.click("xpath",All_Company_Research,"IRSTC-000,Research,Click on All company research drop down");
		com.sleepThread(2000);
		com.startAction();
		String Multiple_in_All_Company_Research_drop_down=Common.readPropertyByResearch().getProperty("Multiple_in_All_Company_Research_drop_down");
		com.MouseOverToElement("xpath",Multiple_in_All_Company_Research_drop_down,"IRSTC-000,Research,Mouse over on multiple option");
		com.sleepThread(2000);
		List<WebElement> myElements = driver.findElements(By.xpath("//*[contains(@class,'tf-menu-dropdown')]//*[contains(@class,'tf-checklist-checkbox ng-pristine ng-untouched ng-valid ng-not-empty')]/span[1]"));
		System.out.println("multiple option checkboxs"+myElements.size());
		//for (int i=1;i<=myElements.size();i++) {
			myElements.get(2).click();
		//	System.out.println(i);
			com.startAction();
			String Ok_button_in_multiple=Common.readPropertyByResearch().getProperty("Ok_button_in_multiple");
			com.MouseOverToclickabl("xpath",Ok_button_in_multiple,"IRSTC-000,Research,Click on ok button in multiple option");
			com.sleepThread(4000);
			try {
				com.sleepThread(10000);
			String slick_row_even=Common.readPropertyByResearch().getProperty("slick_row_even");
			com.verifyElementPresent("xpath",slick_row_even,"IRSTC-000,Research,Verify slick data is displayed or not");
			com.sleepThread(2000);
			Verfiy_Collapse_Reading_pane_is_working_or_not();
			com.sleepThread(2000);
			Verfiy_Veiwer_option_is_working_or_not();
			com.sleepThread(2000);
			com.selectFrameById("frameID");
			}catch(Exception t){
				com.sleepThread(3000);
				String No_Documents_Found=Common.readPropertyByResearch().getProperty("No_Documents_Found");
				com.verifyText_Using_String("xpath",No_Documents_Found,"No Documents Found",","+Widget_name+",Verify the No Documents Found massage is showing or not");
			}
			com.sleepThread(2000);
			
			com.click("xpath",All_Company_Research,"IRSTC-000,Research,Click on All company research drop down");
			com.sleepThread(3000);	
			String Multiple_in_All_Company_Research_drop_down1=Common.readPropertyByResearch().getProperty("Multiple_in_All_Company_Research_drop_down1");
			com.MouseOverToElement("xpath",Multiple_in_All_Company_Research_drop_down1,"IRSTC-000,Research,Mouse over on multiple option");
			com.sleepThread(3000);
		}
//	}
	
	@When("^Verify Calender drop down options are working or not$")
	public void Click_on_today_dropdown() throws Exception	
	{	
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
	//.getText();
		String Today_Dropdown=Common.readPropertyByResearch().getProperty("Today_Dropdown");
		com.click("xpath",Today_Dropdown, "IRSTC-000,Research,Verify Calender drop down options are working or not");
	}
	@Then("^Select the each item in Calender dropdown$")
	public void Select_the_each_item_in_today_dropdown() throws Exception
	{
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		int size=driver.findElements(By.xpath("/html/body/tf-dropdown/ng-form/tf-dropdown-select-base-list/span/span/span/tf-daterange-shortcuts/tf-daterange-shortcut/tf-dropdown-select-item")).size();
		System.out.println("Size:"+size);
		for (int i = 1; i <=size; i++) {
		com.click("xpath","/html/body/tf-dropdown/ng-form/tf-dropdown-select-base-list/span/span/span/tf-daterange-shortcuts/tf-daterange-shortcut["+i+"]/tf-dropdown-select-item","IRSTC-00004,Research,Select the each item in Calender dropdown");	
		com.sleepThread(3000);
		Rs =new Research();
		Rs.Click_on_today_dropdown();		
		}
	}
	
	@And("^Keyword Search drop down by selecting all options in it and check whether they are appying are not")
	public void Keyword_Search_drop_down_by_selecting_all_options_in_it_and_check_whether_they_are_appying_are_not() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Keyword_Search_drop_down=Common.readPropertyByResearch().getProperty("Keyword_Search_drop_down");
		com.MouseOverToclickabl("xpath",Keyword_Search_drop_down,"IRSTC-000,Research,Click on Keyword Search drop down");
		com.sleepThread(3000);
		List<WebElement> myElements = driver.findElements(By.xpath("//*[contains(@class,'news-keyword-search-panel')]//tf-checkbox-control/following::span[2]"));
		System.out.println(myElements.size());
		//for (int i=1;i<myElements.size();i++) {
		myElements.get(2).click();
		com.sleepThread(2000);
		String Ok_button_in_Keyword_Search_drop_down=Common.readPropertyByResearch().getProperty("Ok_button_in_Keyword_Search_drop_down");
		com.MouseOverToclickabl("xpath",Ok_button_in_Keyword_Search_drop_down,"IRSTC-000,Research,Click on Ok button in Keyword Search drop down");
		com.sleepThread(4000);
		try {
			com.sleepThread(10000);
		String slick_row_even=Common.readPropertyByResearch().getProperty("slick_row_even");
		com.verifyElementPresent("xpath",slick_row_even,"IRSTC-000,Research,Verify slick data is displayed or not");
		com.sleepThread(2000);
		Verfiy_Collapse_Reading_pane_is_working_or_not();
		com.sleepThread(2000);
		Verfiy_Veiwer_option_is_working_or_not();
		com.sleepThread(5000);
		com.selectFrameById("frameID");
		}catch(ArithmeticException t){
			com.sleepThread(3000);
			String No_Documents_Found=Common.readPropertyByResearch().getProperty("No_Documents_Found");
			com.verifyText_Using_String("xpath",No_Documents_Found,"No Documents Found",","+Widget_name+",Verify the No Documents Found massage is showing or not");

		}
catch (Exception e) {
	System.out.println("No Documents Found massage is not showing");
	}
		com.MouseOverToclickabl("xpath",Keyword_Search_drop_down,"IRSTC-000,Research,Click on Keyword Search drop down");
		}
	//}
	@And("^Verfiy Contributor or Analyst drop down is working or not$")
	public void Verfiy_Contributor_or_Analyst_drop_down_is_working_or_not() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Contributor_or_Analyst_drop_down=Common.readPropertyByResearch().getProperty("Contributor_or_Analyst_drop_down");
		com.MouseOverToclickabl("xpath",Contributor_or_Analyst_drop_down,"IRSTC-000,Research,Click on Contributor or Analyst drop down");
		com.sleepThread(2000);
	}

	public void Verfiy_Collapse_Reading_pane_is_working_or_not() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String open_Reading_pane=Common.readPropertyByResearch().getProperty("open_Reading_pane");
		com.MouseOverToclickabl("xpath",open_Reading_pane,"IRSTC-000,Research,Click on open Reading pane is working or not");
		com.sleepThread(2000);
		String viewerContainer=Common.readPropertyByResearch().getProperty("viewerContainer");
		com.verify_pop_closeing_or_not("xpath",viewerContainer,"viewerContainer is collapsed or not");
		com.sleepThread(2000);
		String reading_pane_collapsed=Common.readPropertyByResearch().getProperty("reading_pane_collapsed");
		com.MouseOverToclickabl("xpath",reading_pane_collapsed,"IRSTC-000,Research,Click on Collapse Reading pane is working or not");
	}

	public void Verfiy_Veiwer_option_is_working_or_not() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		String Veiwer_option=Common.readPropertyByResearch().getProperty("Veiwer_option");
		com.MouseOverToclickabl("xpath",Veiwer_option,"IRSTC-000,Research,Verfiy Veiwer option is working or not");
		com.handle_to_multiple_tabs("Viewer","IRSTC-000,Research,Verify the tab is opning or not");
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@When("^Click on All Company Research dropdown$")
	public void Click_on_All_Company_Research_dropdown() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
					String All_Company_Research_dropdown=Common.readPropertyByResearch().getProperty("All_Company_Research_dropdown");
					com.click("xpath",All_Company_Research_dropdown, "IRSTC-00005,Research,Click on All Company Research dropdown");
	}
	@Then("^Select the each item in All Company Research dropdown$")
	public void Select_the_each_item_in_All_Company_Research_dropdown() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		int size=driver.findElements(By.xpath("/html/body/tf-dropdown/tf-menu/tf-menu-scroll-container/span/tf-menu-item/span")).size();
		for (int i = 1; i <size; i++) {
			com.click("xpath","/html/body/tf-dropdown/tf-menu/tf-menu-scroll-container/span/tf-menu-item["+i+"]/span","IRSTC-00006,Research,Select the each item in All Company Research dropdown");
			Rs =new Research();
			Rs.Click_on_All_Company_Research_dropdown();		
		}
	}
	@And("^Mouseover on Multiple option in All Company Research dropdown$")
	public void Mouseover_on_Multiple_option_in_ll_Company_Research_dropdown() throws Exception {
		//Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				//.getText();
		com.startAction();
		String Multiple_option_in_All_Company_Research_dropdown=Common.readPropertyByResearch().getProperty("Multiple_option_in_All_Company_Research_dropdown");
		com.MouseOverToElement("xpath",Multiple_option_in_All_Company_Research_dropdown, "IRSTC-00007,Research,Mouseover on Multiple option in All Company Research dropdown");
	}
	
	@Then("^Select the Frame Default$")
	private void Select_the_Frame_Default() {
		com.sleepThread(2000);
		//com.selectFrameDefault();
		driver.switchTo().defaultContent();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
