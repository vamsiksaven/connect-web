package Ide.Idp.StepDef;

import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;

//import javax.swing.plaf.synth.SynthSpinnerUI;
//import javax.xml.validation.Validator;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//import cucumber.api.java.en_scouse.An;
import cucumber.api.java.en_scouse.An;

public class Options {
	public Common com = new Common();
	public WebDriver driver;
	public Options Opt;
	public Chart C;
	public String Widget_name;

	// public String Widget_name1= Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Options() {
		driver = Common.driver;
	}

	@Given("^Verify the OPtions$")
	public void Verify_the_OPtions() throws Exception {
		com.sleepThread(12000);
		String Options = Common.readPropertyByoptions().getProperty("Options");
		System.out.println(Options);
		com.verifyElementPresent("xpath", Options, "IOTC-00001,Options,Verify the Options");

	}

	@And("^Click on Options$")
	public void Click_on_Options() throws Exception {
		String Options = Common.readPropertyByoptions().getProperty("Options");
		com.sleepThread(12000);
		com.click("xpath", Options, "IOTC-00002,Options,Click on Options");
		com.sleepThread(7000);
		String SymbolInput = Common.readPropertyByoptions().getProperty("SymbolInput");
		com.click("xpath", SymbolInput, "ITLC-34,Options,Click on Symbol input can be cleared or not");
		com.ClearTextField("xpath", SymbolInput, "ITLC-34,Options,Verify Symbol input can be cleared or not");
		com.sleepThread(4000);
		com.sendKeys("xpath", SymbolInput, "ICE", "ITLC-35,Options,Verify entering symbol input");
		com.sleepThread(3000);
		com.startAction();
		String Symboldropdown = Common.readPropertyByoptions().getProperty("Symboldropdown");
		com.sleepThread(7000);
		com.MouseOverToclickabl("xpath", Symboldropdown,
				"ITLC-36,Options,Verify data is displayed or not by clciking on dropdown");
	}

	@When("^Verify the Enter_symbol Drop Down in options$")
	public void Verify_the_Enter_symbol_Drop_Down() throws Exception {
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.sleepThread(1000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.verifyElementPresent("xpath", ICE_Drop_Down,
				"IOTC-00003," + Widget_name + ",Verify the Enter_symbol Drop Down");
	}

	@And("^Click on Enter_symbol Drop Down in options$")
	public void Click_on_ICE_Drop_Down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.startAction();
		com.MouseOverToclickabl("xpath", ICE_Drop_Down, "IOTC-00004," + Widget_name + ",Click on Enter_symbol Drop Down");
	}

	@And("^Enter_symbol the each list in options$")
	public void Enter_symbol_the_each_list() throws Exception {
		Opt = new Options();
		int size = driver.findElements(By.xpath("/html/body/div[3]/div/span/div/div/div[2]/div/div/span")).size();
		System.out.println("suggestion item " + size);
		for (int i = 2; i < size; i++) {
			System.out.println(i);
			com.startAction();
			// com.MouseOverToElement("xpath","/html/body/div[6]/div/span/div/div/div[2]/div/div["+i+"]/span/span","");
			String text = driver
					.findElement(By.xpath("/html/body/div[3]/div/span/div/div/div[2]/div/div[" + i + "]/span"))
					.getText();
			System.out.println("text" + text);
			com.MouseOverToclickabl("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div[" + i + "]/span",
					"IOTC-00005," + Widget_name + ",Click on_symbol the " + text + " list");
			driver.navigate().refresh();
			com.sleepThread(10000);
			try {
				com.sleepThread(9000);
				String Select_text = driver
						.findElement(By.xpath(
								"//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[1]/span[2]"))
						.getText();
				System.out.println("Select_text" + Select_text);
				if (Select_text.equals(text)) {
					com.Creatlogfile(Date_Time + "," + "IOTC-00006," + Widget_name + ",User selected symbol " + text
							+ " is chart header table dispalyed or not" + ",Pass");
				} else {
					com.Creatlogfile(Date_Time + "," + "IOTC-00006," + Widget_name + ",User selected symbol " + text
							+ " is chart header table dispalyed or not" + ",Fail");
				}
			} catch (Exception e) {
				com.Creatlogfile(Date_Time + "," + "IOTC-00006," + Widget_name
						+ ",User selected symbol data is not present" + ",Pass");
			}
			try {
				com.sleepThread(9000);
				String Input_text = driver.findElement(By.xpath(
						"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span[1]/div/span/div/input"))
						.getAttribute("value");
				System.out.println("Input_text" + Input_text);
				if (text.equals(Input_text)) {
					com.Creatlogfile(Date_Time + "," + "IOTC-0007," + Widget_name + ",User selected symbol "
							+ Input_text + " is symbol drop down is dispalyed or not" + ",Pass");
				} else {
					com.Creatlogfile(Date_Time + "," + "IOTC-0007," + Widget_name + ",User selected symbol "
							+ Input_text + " is symbol drop down is not dispalyed" + ",Fail");
				}
			} catch (Exception e) {
				com.Creatlogfile(Date_Time + "," + "IOTC-00006," + Widget_name
						+ ",User selected symbol data is not present" + ",Pass");
			}
			com.sleepThread(2000);
			Opt.Click_on_ICE_Drop_Down();
			
		}
	}

	@When("^Click on select strategy Dropdown$")
	public void Click_on_calls_and_puts_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Call_title_in_table = Common.readPropertyByoptions().getProperty("Call_title_in_table");
		com.verifyElementPresent("xpath", Call_title_in_table,
				"," + Widget_name + ",Call text showing or not in table");
		String puts_title_in_table = Common.readPropertyByoptions().getProperty("puts_title_in_table");
		com.verifyElementPresent("xpath", puts_title_in_table,
				"," + Widget_name + ",puts text showing or not in table");
		String select_strategy_Dropdown = Common.readPropertyByoptions().getProperty("select_strategy_Dropdown");
		com.click("xpath", select_strategy_Dropdown, "IOTC-0008," + Widget_name
				+ ",Check the Calls and Puts Dropdown is working or not. Also check Calls and Puts options under the dropdown");
	}

	@Then("^Verify the all options in select strategy Dropdown$")
	public void Verify_the_calls_and_puts_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li/button"))
				.size();
		for (int i = 1; i < size; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[" + i + "]/button",
					"IOTC-0009," + Widget_name + ",Verify the calls and puts Dropdown");
		}
	}

	@And("^Select the calls options$")
	public void Select_the_calls_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Call_options = Common.readPropertyByoptions().getProperty("Call_options");
		com.click("xpath", Call_options, "IOTC-00011," + Widget_name + ",Select the calls options");
	}

	@And("^Select the puts options$")
	public void Select_the_puts_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String cross_icon = Common.readPropertyByoptions().getProperty("cross_icon");
		com.verifyElementPresent("xpath", cross_icon,
				"," + Widget_name + ",Vrify the cross icon in sets drop down in options");
		com.click("xpath", cross_icon, "," + Widget_name + ",click on cross icon in sets drop down in options");
		com.sleepThread(2000);
		String select_strategy_Dropdown = Common.readPropertyByoptions().getProperty("select_strategy_Dropdown");
		com.click("xpath", select_strategy_Dropdown, "IOTC-0008," + Widget_name
				+ ",Check the Calls and Puts Dropdown is working or not. Also check Calls and Puts options under the dropdown");
		com.sleepThread(2000);
		String puts_options = Common.readPropertyByoptions().getProperty("puts_options");
		com.click("xpath", puts_options, "IOTC-00012," + Widget_name + ",Select the calls and puts options");
		com.sleepThread(3000);
		driver.navigate().refresh();
		com.sleepThread(9000);
	}

	@When("^Pre defined Column Sets Drop Down in options$")
	public void Pre_defined_Column_Sets_Drop_Down_in_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		com.startAction();
		String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Drop_Down");
//		com.MouseOverToElement("xpath", Pre_defined_Column_Sets_Drop_Down,
//				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
//		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
		com.sleepThread(2000);
		com.click("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
//		com.sleepThread(2000);
	}
	@When("^Pre defined Column Sets Drop Down in options1$")
	public void Pre_defined_Column_Sets_Drop_Down_in_options1() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		com.startAction();
		String Pre_defined_Column_Sets_Drop_Down1 = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Drop_Down1");
		com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down1,
				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
		com.sleepThread(2000);
	}
	@And("^Verify and Click on Custom Column Sets and Predefined Column Sets in options$")
	public void Verify_and_Click_on_Custom_Column_Sets_and_Predefined_Column_Sets_in_options() throws Exception {
		Opt = new Options();
		int Predefined = driver.findElements(By.xpath(
				"/html/body/div[7]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Predefined:" + Predefined);
		for (int j = 2; j <=Predefined; j++) {
			try {
			com.sleepThread(2000);
			com.startAction();
			com.verifyElementPresent("xpath",
					"/html/body/div[7]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div",
					"IOTC-00014," + Widget_name + ",Verify the Custom Column Sets and Predefined Column Sets");
			com.MouseOverToclickabl("xpath",
					"/html/body/div[7]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div",
					"IOTC-00015," + Widget_name + ",Click on Custom Column Sets and Predefined Column Sets");
			//Opt.Pre_defined_Column_Sets_Drop_Down_in_options();
			int size_calls=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]")).size();
			System.out.println("size_calls:"+size_calls);
			for (int i = 1; i <=size_calls; i++) {
				com.startAction();
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div["+i+"]",","+ Widget_name +",Options,Click on ");
				String Biddropdown = Common.readPropertyByoptions().getProperty("Biddropdown");
				String BestFitBid = Common.readPropertyByoptions().getProperty("BestFitBid");
				com.sleepThread(6000);
				com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
				com.sleepThread(3000);
				// com.waitUntilElementPresent(BestFitBid);
				com.MouseOverToElement("xpath", BestFitBid, "ILTC-00028,Options,Mouse hover on Best Fit Bid");
				com.click("xpath", BestFitBid, "ILTC-00028,Options,Click on Best Fit Bid");
				com.sleepThread(3000);
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]",","+ Widget_name +",Options,Click on ");
				com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
				com.sleepThread(5000);
				String BestFitAllColums = Common.readPropertyByoptions().getProperty("BestFitAllColums");
				com.sleepThread(5000);
				com.waitUntilElementPresent(BestFitAllColums);
				com.MouseOverToElement("xpath", BestFitAllColums, "ILTC-00028,Options,Mouse hover on Best Fit All Columns");
				com.click("xpath", BestFitAllColums, "ILTC-00028,Options,Click on Best Fit All Columns");

				
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div["+i+"]",","+ Widget_name +",Options,Click on ");
				com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
				com.sleepThread(5000);
				String ViewDefinition = Common.readPropertyByoptions().getProperty("ViewDefinition");
				com.sleepThread(5000);
				com.waitUntilElementPresent(ViewDefinition);
				com.MouseOverToElement("xpath", ViewDefinition, "ILTC-00028,Options,Mouse hover on View Definition");
				com.click("xpath", ViewDefinition, "ILTC-00028,Options,Click on View Definition");

			}
			
			int size_puts=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[2]")).size();
			System.out.println("size_puts:"+size_puts);
			for (int i = 1; i <=size_puts; i++) {
				com.startAction();
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div["+i+"]",","+ Widget_name +",Options,Click on ");
				String Biddropdown = Common.readPropertyByoptions().getProperty("Biddropdown");
				String BestFitBid = Common.readPropertyByoptions().getProperty("BestFitBid");
				com.sleepThread(6000);
				com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
				com.sleepThread(3000);
				// com.waitUntilElementPresent(BestFitBid);
				com.MouseOverToElement("xpath", BestFitBid, "ILTC-00028,Options,Mouse hover on Best Fit Bid");
				com.click("xpath", BestFitBid, "ILTC-00028,Options,Click on Best Fit Bid");
				com.sleepThread(3000);
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div["+i+"]",","+ Widget_name +",Options,Click on ");
				String BestFitAllColums = Common.readPropertyByoptions().getProperty("BestFitAllColums");
				com.sleepThread(5000);
				com.waitUntilElementPresent(BestFitAllColums);
				com.MouseOverToElement("xpath", BestFitAllColums, "ILTC-00028,Options,Mouse hover on Best Fit All Columns");
				com.click("xpath", BestFitAllColums, "ILTC-00028,Options,Click on Best Fit All Columns");
				
				com.sleepThread(3000);
				com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div["+i+"]",","+ Widget_name +",Options,Click on ");
				com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
				com.sleepThread(5000);
				String ViewDefinition = Common.readPropertyByoptions().getProperty("ViewDefinition");
				com.sleepThread(5000);
				//com.waitUntilElementPresent(ViewDefinition);
				com.MouseOverToElement("xpath", ViewDefinition, "ILTC-00028,Options,Mouse hover on View Definition");
				com.click("xpath", ViewDefinition, "ILTC-00028,Options,Click on View Definition");

			}
			com.sleepThread(5000);
			String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByoptions()
					.getProperty("Pre_defined_Column_Sets_Drop_Down");
			com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down,
					"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
			com.click("xpath", Pre_defined_Column_Sets_Drop_Down,
					"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
			}catch (Exception e) {
				// TODO: handle exception
			System.out.println("can`t be find"+j);
			}
			}
	}

	@And("^Click on New...Pre defined Column Sets Drop Down in options$")
	public void Click_on_New_Pre_defined_Column_Sets_Drop_Down_in_options() throws Exception {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_New_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_New_button");
		com.startAction();
		String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Drop_Down");
		com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
		com.click("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IOTC-00013," + Widget_name + ",Click on Pre defined Column Sets Drop Down in options");
		com.sleepThread(2000);
		com.click("xpath", Pre_defined_Column_Sets_New_button,
				"IOTC-00016," + Widget_name + ",Click on New...Pre defined Column Sets Drop Down");
	}

	@And("^Verify Add column set title in options$")
	public void Verify_Add_column_set_title_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_title,
				"IOTC-00017," + Widget_name + ",Verify Add column set title");
	}

	@And("^Verify save button in Add column set in options$")
	public void Verify_save_button_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button,
				"IOTC-00018," + Widget_name + ",Verify save button in Add column set");
	}

	@And("^Verify cancel button in Add column set in options$")
	public void Verify_cancel_button_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button,
				"IOTC-00019," + Widget_name + ",Verify cancel button in Add column set");
	}

	@And("^Verify close icon in Add column set in options$")
	public void Verify_close_icon_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon,
				"IOTC-00020," + Widget_name + ",Verify close icon in Add column set");
	}

	@And("^Click on cancel button in Add column set in options$")
	public void Click_on_cancel_button_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button,
				"IOTC-00021," + Widget_name + ",Click on cancel button in Add column set");
	}

	@When("^Click on Save Column Set Pre defined Column Sets Drop Down in options$")
	public void Click_on_Save_Column_Set_Pre_defined_Column_Sets_Drop_Down_in_options() throws Exception {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_Save_column_set = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set,
				"IOTC-00023," + Widget_name + ",Click on Save Column Set Pre defined Column Sets Drop Down");
	}

	@And("^Click on close icon in Add column set pop in options$")
	public void Click_on_close_icon_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon,
				"IOTC-00024," + Widget_name + ",Click on close icon in Add column set pop");
	}

	@And("^Verify name text box in Add column set pop in options$")
	public void Verify_name_text_box_in_Add_column_set_pop_in_options() throws Exception {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Add_Column_Set_name_text_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_name_text_box,
				"IOTC-00025," + Widget_name + ",Verify name text box in Add column set pop");
	}

	@And("^Verify Available Columns title in Add column set pop in options$")
	public void Verify_Available_Columns_title_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title,
				"IOTC-00026," + Widget_name + ",Verify Available Columns title in Add column set pop");
	}

	@And("^Verify Search box Available Columns title below in Add column set pop in options$")
	public void Verify_Search_box_Available_Columns_title_below_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box,
				"IOTC-00027," + Widget_name + ",Verify Search box Available Columns title below in Add column set pop");
	}

	@And("^Verify Selected Columns title in Add column set in options$")
	public void Verify_Selected_Columns_title_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title,
				"IOTC-00028," + Widget_name + ",Verify Selected Columns title in Add column set");
	}

	@And("^Verify Search box Selected Columns title below in Add column set pop in options$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Add_column_set_pop_in_options() throws Exception {

		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box,
				"IOTC-00029," + Widget_name + ",Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box");
	}

	@And("Verify Set this column set as default checkbox in Add column set pop in options")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Add_column_set_pop_in_options() throws Exception {
		com.sleepThread(3000);
		String Pre_defined_Column_Sets_Add_Column_Set_checkbox = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_checkbox,
				"IOTC-00030," + Widget_name + ",Verify Set this column set as default checkbox in Add column set pop");
	}

	@And("^Verify Available Columns Each list in Add column set pop in options$")
	public void Verify_Available_Columns_Each_list_in_Add_column_set_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("Available_Columns_list:" + Available_Columns_list);

		/*
		 * for(int i=1; i<=Available_Columns_list; i++){ com.sleepThread(5000);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); System.out.println(i); int
		 * sublist=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li/div[1]/span[2]/div")).size();
		 * System.out.println(sublist+"****************"); for (int j = 1; j <=sublist;
		 * j++) { com.sleepThread(5000); System.out.println("loppnumber"+j);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.sleepThread(5000);
		 * String Pre_defined_Column_Sets_Add_Column_Set_arrow_right=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_right"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_right); } int
		 * Selected_Columns_list=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"
		 * )).size(); System.out.println(Selected_Columns_list); for (int k = 1; k
		 * <=Selected_Columns_list; k++) { com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.sleepThread(2000); String
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_left"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left); } }
		 */
		int i = 1;
		while (i < 2) {
			com.sleepThread(5000);
			com.verifyElementPresent("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"," + Widget_name + ",Verify Available Columns Each list in Add column set pop");
			com.click("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"," + Widget_name + ",Click on Available Columns Each list in Add column set pop");
			System.out.println(i);
			int sublist = driver.findElements(
					By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println("sublist:" + sublist);

			int j = 1;
			while (j <= 10) {

				com.sleepThread(5000);
				System.out.println("loppnumber" + j);
				String text = driver.findElement(
						By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
						.getText();
				System.out.println("text=" + text);
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
						"," + Widget_name + ",Verify the Available '" + text + "' sub list in Add column set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
						"," + Widget_name + ",Click on Available '" + text + "' sub list in Add column set pop");
				com.sleepThread(5000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByoptions()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right,
						"," + Widget_name + ",Click on Pre defined Column Sets Add Column Set arrow right");
				j++;
				/*
				 * int t = 1; while (t < 10) {
				 * 
				 * com.sleepThread(5000); System.out.println("loppnumber" + j); String text1 =
				 * driver.findElement( By.xpath(
				 * "/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
				 * + i + "]/div[2]/div/ul/li[1]/div[1]/span[2]/div")) .getText();
				 * System.out.println("text=" + text1); com.verifyElementPresent("xpath",
				 * "/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
				 * + i + "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
				 * ","+Widget_name+",Verify the Available '"
				 * +text1+"' sub list in Add column set pop"); com.click("xpath",
				 * "/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
				 * + i + "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
				 * ","+Widget_name+",Click on Available '"
				 * +text1+"' sub list in Add column set pop"); com.sleepThread(5000); String
				 * Pre_defined_Column_Sets_Add_Column_Set_arrow_right1 =
				 * Common.readPropertyByoptions()
				 * .getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				 * com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right1, ","+
				 * Widget_name+",Click on Pre defined Column Sets Add Column Set arrow right_1"
				 * ); j++; }
				 */
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button/div"))
					.size();
			System.out.println("Selected Columns list" + Selected_Columns_list);
			int k = 1;
			while (k <= 2) {
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button[" + k
								+ "]/div",
						"," + Widget_name + ",Verify the Selected Columns list");
				com.click("xpath", "/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button["
						+ k + "]/div", "," + Widget_name + ",Click on Selected Columns list");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByoptions()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left,
						"," + Widget_name + ",Click on Pre defined Column Sets Add Column Set arrow left");
				k++;
			}
			i++;
		}
	}

	@And("^Verify double Arrow right icon in Add column set pop in options$")
	public void Verify_double_Arrow_right_icon_in_Add_column_set_pop_in_options() throws Exception {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right,
				"IOTC-00031," + Widget_name + ",Verify double Arrow right icon in Add column set pop");
	}

	@And("^Verify double Arrow left icon in Add column set pop in options$")
	public void Verify_double_Arrow_left_icon_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left,
				"IOTC-00032," + Widget_name + ",Verify double Arrow left icon in Add column set pop");
	}

	@And("^Verify down arrow default disable or not in Add column set pop in options$")
	public void Verify_down_arrow_default_disable_or_not_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_down_arrow = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_down_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_down_arrow,
				"IOTC-00033," + Widget_name + ",Verify down arrow default disable or not in Add column set pop");
	}

	@And("^Verify up arrow default disable or not in Add column set pop in options$")
	public void Verify_up_arrow_default_disable_or_not_in_Add_column_set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_up_arrow = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_up_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_up_arrow,
				"IOTC-00034," + Widget_name + ",Verify up arrow default disable or not in Add column set pop");
	}

	@And("^Click on save button in Add column set in options$")
	public void Click_on_save_button_in_Add_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button,
				"IOTC-00035," + Widget_name + ",Click on save button in Add column set in options");
	}

	@And("^Verify Save Column Set title in options$")
	public void Verify_Save_Column_Set_title_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_title,
				"IOTC-00036," + Widget_name + ",Verify Save Column Set title in options");
	}

	@And("^Verify save button in Save Column Set in options$")
	public void Verify_save_button_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_save_button,
				"IOTC-00037," + Widget_name + ",Verify save button in Save Column Set in options");
	}

	@And("^Verify cancel button in Save Column Set in options$")
	public void Verify_cancel_button_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button,
				"IOTC-00038," + Widget_name + ",Verify cancel button in Save Column Set in options");
	}

	@And("^Verify close icon in Save Column Set in options$")
	public void Verify_close_icon_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon,
				"IOTC-00039," + Widget_name + ",Verify close icon in Save Column Set in options");
	}

	@And("^Click on cancel button in Save Column Set in options$")
	public void Click_on_cancel_button_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button,
				"IOTC-00040," + Widget_name + ",Click on cancel button in Save Column Set in options");
	}

	@And("^Click on close icon in Save Column Set pop in options$")
	public void Click_on_close_icon_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon,
				"IOTC-00041," + Widget_name + ",Click on close icon in Save Column Set pop in options");
	}

	@And("^Verify name text box in Save Column Set pop in options$")
	public void Verify_name_text_box_in_Save_Column_Set_pop_in_options() throws Exception {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Save_Column_Set_name_text_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_Column_Set_name_text_box,
				"IOTC-00042," + Widget_name + ",Verify name text box in Save Column Set pop in options");
	}

	@And("^Verify Available Columns title in Save Column Set pop in options$")
	public void Verify_Available_Columns_title_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_title,
				"IOTC-00043," + Widget_name + ",Verify Available Columns title in Save Column Set pop in options");
	}

	@And("^Verify Search box Available Columns title below in Save Column Set pop in options$")
	public void Verify_Search_box_Available_Columns_title_below_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box,
				"IOTC-00044," + Widget_name
						+ ",Verify Search box Available Columns title below in Save Column Set pop in options");
	}

	@And("^Verify Selected Columns title in Save Column Set in options$")
	public void Verify_Selected_Columns_title_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title,
				"IOTC-00045," + Widget_name + ",Verify Selected Columns title in Save Column Set in options");
	}

	@And("^Verify Search box Selected Columns title below in Save Column Set pop in options$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box,
				"IOTC-00046," + Widget_name
						+ ",Verify Search box Selected Columns title below in Save Column Set pop in options");
	}

	@And("Verify Set this column set as default checkbox in Save Column Set pop in options")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_checkbox = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_checkbox, "IOTC-00047," + Widget_name
				+ ",Verify Set this column set as default checkbox in Save Column Set pop in options");
	}

	@And("^Verify Available Columns Each list in Save Column Set pop in options$")
	public void Verify_Available_Columns_Each_list_in_Save_Column_Set_pop_in_options() throws Exception {
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("Available_Columns_list" + Available_Columns_list);

		for (int i = 1; i <= 2; i++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"," + Widget_name + ",Verify Available Columns Each list in Save Column Set pop");
			com.click("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"," + Widget_name + ",Verify Available Columns Each list in Save Column Set pop");
			int sublist = driver.findElements(By.xpath(
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println("sublist:" + sublist);
			for (int j = 1; j <= 2; j++) {
				com.sleepThread(2000);
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div",
						"," + Widget_name + ",Verify Sublist Available Columns Each list in Save Column Set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[\"+i+\"]/div[2]/div/ul/li[\"+j+\"]/div[1]/span[2]/div",
						"," + Widget_name + ",Click on Sublist Available Columns Each list in Save Column Set pop");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByoptions()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right,
						"," + Widget_name + ",Click on Pre defined Column Sets Add Column Set arrow right");
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button/div"))
					.size();
			System.out.println("Selected_Columns_list" + Selected_Columns_list);
			for (int k = 1; k <= 2; k++) {
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button[" + k
								+ "]/div",

						"," + Widget_name + ",Verify Available Columns Each list in Save Column Set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button[" + k
								+ "]/div",
						"," + Widget_name + ",Click on Available Columns Each list in Save Column Set pop");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByoptions()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left,
						"," + Widget_name + ",Click on Pre defined Column Sets Add Column Set arrow left");
			}
		}
	}

	@And("^Verify double Arrow right icon in Save Column Set pop in options$")
	public void Verify_double_Arrow_right_icon_in_Save_Column_Set_pop_in_options() throws Exception {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_right = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_right,
				"IOTC-00048," + Widget_name + ",Verify double Arrow right icon in Save Column Set pop in options");
	}

	@And("^Verify double Arrow left icon in Save Column Set pop in options$")
	public void Verify_double_Arrow_left_icon_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_left = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_left,
				"IOTC-00049," + Widget_name + ",Verify double Arrow left icon in Save Column Set pop in options");
	}

	@And("^Verify down arrow default disable or not in Save Column Set pop in options$")
	public void Verify_down_arrow_default_disable_or_not_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_down_arrow = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_down_arrow");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_down_arrow, "IOTC-00050,"
				+ Widget_name + ",Verify down arrow default disable or not in Save Column Set pop in options");
	}

	@And("^Verify up arrow default disable or not in Save Column Set pop in options$")
	public void Verify_up_arrow_default_disable_or_not_in_Save_Column_Set_pop_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_up_arrow = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_up_arrow");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_up_arrow, "IOTC-00051," + Widget_name
				+ ",Verify up arrow default disable or not in Save Column Set pop in options");
	}

	@And("^Click on save button in Save Column Set in options$")
	public void Click_on_save_button_in_Save_Column_Set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_save_button,
				"IOTC-00052," + Widget_name + ",Click on save button in Save Column Set in options");
	}

	@When("^Click on Manage column set Pre defined Column Sets Drop Down in options$")
	public void Click_on_Manage_column_set_Pre_defined_Column_Sets_Drop_Down_in_options() throws Exception {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_Manage_column_set = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set, "IOTC-00053," + Widget_name
				+ ",Click on Manage column set Pre defined Column Sets Drop Down in options");
	}

	@And("^Verify Manage column set title in options$")
	public void Verify_Manage_column_set_title_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_title = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_title");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_title,
				"IOTC-00054," + Widget_name + ",Verify Manage column set title in options");
	}

	@And("^Verify close icon in Manage column set in options$")
	public void Verify_close_icon_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon,
				"IOTC-00055," + Widget_name + ",Verify close icon in Manage column set in options");
	}

	@And("^Verify cancel button in Manage column set in options$")
	public void Verify_cancel_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button,
				"IOTC-00056," + Widget_name + ",Verify cancel button in Manage column set in options");
	}

	@And("^Verify Edit button in Manage column set in options$")
	public void Verify_Edit_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_Edit_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Edit_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Edit_button,
				"IOTC-00057," + Widget_name + ",Verify Edit button in Manage column set in options");
	}

	@And("^Verify Copy button in Manage column set in options$")
	public void Verify_Copy_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_Copy_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Copy_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Copy_button,
				"IOTC-00056," + Widget_name + ",Verify Copy button in Manage column set in options");
	}

	@And("^Verify Delete button in Manage column set in options$")
	public void Verify_Delete_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_Delete_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Delete_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Delete_button,
				"IOTC-00057," + Widget_name + ",Verify Delete button in Manage column set in options");
	}

	@And("^Verify New button in Manage column set in options$")
	public void Verify_New_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_New_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_New_button");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_New_button,
				"IOTC-00058," + Widget_name + ",Verify New button in Manage column set in options");
	}

	@And("^click on close icon in Manage column set in options$")
	public void click_on_close_icon_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon,
				"IOTC-00059," + Widget_name + ",click on close icon in Manage column set in options");
	}

	@And("^click on cancel button in Manage column set in options$")
	public void click_on_cancel_button_in_Manage_column_set_in_options() throws Exception {
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByoptions()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button,
				"IOTC-00060," + Widget_name + ",click on cancel button in Manage column set in options");
	}

	@When("^Click on Display_Preferences$")
	public void Click_on_Display_Preferences() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(6000);
		String Display_Preferences = Common.readPropertyByoptions().getProperty("Display_Preferences");
		com.MouseOverToclickabl("xpath", Display_Preferences, "," + Widget_name + ",Click on Display_Preferences");
	}

	@When("^Check Instrument Preference Radio buttons are working or not Equities and Futures$")
	public void Check_Instrument_Preference_Radio_buttons_are_working_or_not_Equities_and_Futures() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int size = driver
				.findElements(
						By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div/fieldset[1]/label/div/label"))
				.size();
		System.out.println("Preference Radio buttons" + size);
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div/fieldset[1]/label/div/label[" + i + "]",
					"IOTC-00061," + Widget_name
							+ ",Check Instrument Preference Radio buttons are working or not Equities and Futures");
			com.sleepThread(2000);
			Opt = new Options();
			Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
			com.sleepThread(2000);
			Opt.Click_on_ICE_Drop_Down();
			com.sleepThread(8000);
			Opt.Enter_symbol_the_each_list();
			System.out.println("Preference Radio buttons" + i);
			com.startAction();
			String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
			com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
			com.sleepThread(2000);
			Opt = new Options();
			Opt.Click_on_Display_Preferences();
		}

	}

	@Then("^Check Auto Refresh On_Off option is working or not$")
	public void Check_Auto_Refresh_On_Off_option_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		  com.startAction();
		// String Right_click=Common.readPropertyByoptions().getProperty("Right_click");
		// com.Rightclick("xpath",Right_click,"Right clicked on options data");
		  com.sleepThread(5000);
		// Opt=new Options();
		// Opt.Click_on_Display_Preferences();
		String Auto_Refresh = Common.readPropertyByoptions().getProperty("Auto_Refresh");
		com.MouseOverToclickabl("xpath", Auto_Refresh,
				"IOTC-00062," + Widget_name + ",Check Auto Refresh Off option is working or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Auto_Refresh, "," + Widget_name + ",Check Auto Refresh On option is working or not");
		// com.sleepThread(2000);
		// com.click("xpath",Auto_Refresh, "IOTC-00062,"+Widget_name+",Check Auto
		// Refresh Off option is working or not");
	}

	@And("^Check Auto Refresh Drop down is working or not$")
	public void Check_Auto_Refresh_Drop_down_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		String Auto_Refresh_Drop_down = Common.readPropertyByoptions().getProperty("Auto_Refresh_Drop_down");
		com.startAction();
		com.MouseOverToElement("xpath", Auto_Refresh_Drop_down, "," + Widget_name + ",Mouse over on Auto Refresh Drop down");
		com.select_the_Drop_Down_values("xpath", Auto_Refresh_Drop_down,
				"IOTC-00063," + Widget_name + ",Check Auto Refresh Drop down is working or not");
	}

	@And("Check Security Details On_OFF option is working or not in Additional Information Pass")
	public void Check_Security_Details_On_OFF_option_is_working_or_not_in_Additional_Information_Pass()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Security_Details_On_OFF_option = Common.readPropertyByoptions()
				.getProperty("Security_Details_On_OFF_option");
		com.click("xpath", Security_Details_On_OFF_option, "IOTC-00064," + Widget_name
				+ ",Check Security Details OFF option is working or not in Additional Information Pass");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.sleepThread(2000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(4000);
		String Security_Details_scale = Common.readPropertyByoptions().getProperty("Security_Details_scale");
		com.verifyElementPresent("xpath", Security_Details_scale,
				"," + Widget_name + ",Security details scale Headings or not");
		com.click("xpath", Security_Details_On_OFF_option, "," + Widget_name
				+ ",Check Security Details On option is working or not in Additional Information Pass");
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Security_Details_scale,
				"," + Widget_name + ",Security details scale showing or not");

	}

	@And("^Check Options Details On_Off option is working or not in Additional Information Pass$")
	public void Check_Options_Details_On_Off_option_is_working_or_not_in_Additional_Information_Pass()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		String Options_Details_On_Off_option = Common.readPropertyByoptions()
				.getProperty("Options_Details_On_Off_option");
		com.click("xpath", Options_Details_On_Off_option, "," + Widget_name
				+ ",Check Options Details On_Off option is working or not in Additional Information Pass");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.sleepThread(2000);
		String Options_Details_scale = Common.readPropertyByoptions().getProperty("Options_Details_scale");
		com.verifyElementPresent("xpath", Options_Details_scale,
				"," + Widget_name + ",Options details scale Headings or not");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);

		com.click("xpath", Options_Details_On_Off_option, "," + Widget_name
				+ ",Check Options Details On_Off option is working or not in Additional Information Pass");
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Options_Details_scale,
				"," + Widget_name + ",Options details scale showing or not");

	}

	@And("^Check Mirror Columns options is working or not in Table layout$")
	public void Check_Mirror_Columns_options_is_working_or_not_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		String Mirror_Columns_options = Common.readPropertyByoptions().getProperty("Mirror_Columns_options");
		com.verifyElementPresent("xpath", Mirror_Columns_options,
				"IOTC-00066," + Widget_name + ",Check Mirror Columns options is working or not in Table layout");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		String Mirror_Simple_colimns = Common.readPropertyByoptions().getProperty("Mirror_Simple_colimns");
		com.verifyElementPresent("xpath", Mirror_Simple_colimns,
				"," + Widget_name + ",Vrify the Mirror option simple colims");
	}

	@And("^Check Simple  Columns options is working or not in Table layout$")
	public void Check_Simple_Columns_options_is_working_or_not_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		String Simple_Columns_options = Common.readPropertyByoptions().getProperty("Simple_Columns_options");
		com.verifyElementPresent("xpath", Simple_Columns_options,
				"IOTC-00067," + Widget_name + ",Check Simple  Columns options is working or not in Table layout");
		com.click("xpath", Simple_Columns_options,
				"," + Widget_name + ",select the Simple  Columns options is working or not in Table layout");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.sleepThread(3000);
		String Simple_colimns = Common.readPropertyByoptions().getProperty("Simple_colimns");
		com.verifyElementPresent("xpath", Simple_colimns, "," + Widget_name + ",Vrify the simple colims");
	}

	@And("^Check Put_Call Headings On_Off option is working or not in Table layout$")
	public void Check_Put_Call_Headings_On_Off_option_is_working_or_not_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		com.startAction();
		com.KeyEvent(KeyEvent.VK_DOWN);
		String Put_Call_Headings_On_Off_option = Common.readPropertyByoptions()
				.getProperty("Put_Call_Headings_On_Off_option");
		com.sleepThread(2000);
		com.click("xpath", Put_Call_Headings_On_Off_option,
				"IOTC-00068," + Widget_name + ",Check Put_Call Headings Off option is working or not in Table layout");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		String Simple_colimns = Common.readPropertyByoptions().getProperty("Simple_colimns");
		com.verifyElementPresent("xpath", Simple_colimns, "," + Widget_name + ",Vrify the simple colims");
		String Call_title_in_table = Common.readPropertyByoptions().getProperty("Call_title_in_table");
		com.verifyElementPresent("xpath", Call_title_in_table,
				"," + Widget_name + ",Call text Heading or not in table");
		// String
		// puts_title_in_table=Common.readPropertyByoptions().getProperty("puts_title_in_table");
		// com.verifyElementPresent("xpath",puts_title_in_table,","+Widget_name+",puts
		// text Heading or not in table");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		com.click("xpath", Put_Call_Headings_On_Off_option,
				"," + Widget_name + ",Check Put_Call Headings On option is working or not in Table layout");
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.verifyElementPresent("xpath", Simple_colimns, "," + Widget_name + ",Vrify the simple colims");
		com.verifyElementPresent("xpath", Call_title_in_table,
				"," + Widget_name + ",Call text showing or not in table");
		// com.verifyElementPresent("xpath",puts_title_in_table,","+Widget_name+",puts
		// text showing or not in table");
	}

	@And("^Check Expiration Headings On_Off option is working or not in Table layout$")
	public void Check_Expiration_Headings_On_Off_option_is_working_or_not_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		com.KeyEvent(KeyEvent.VK_DOWN);
		String Expiration_Headings_On_Off_option = Common.readPropertyByoptions()
				.getProperty("Expiration_Headings_On_Off_option");
		com.click("xpath", Expiration_Headings_On_Off_option, "IOTC-00069," + Widget_name
				+ ",Check Expiration Headings Off option is working or not in Table layout");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		String Date_expiration = Common.readPropertyByoptions().getProperty("Date_expiration");
		com.verifyElementPresent("xpath", Date_expiration, "," + Widget_name + ",Date expiration heading or not");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(2000);
		com.KeyEvent(KeyEvent.VK_DOWN);
		com.click("xpath", Expiration_Headings_On_Off_option,
				"," + Widget_name + ",Check Expiration Headings On option is working or not in Table layout");
		Opt.Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout();
		com.verifyElementPresent("xpath", Date_expiration, "," + Widget_name + ",Date expiration showing or not");
	}

	@And("^Check Symbol Column On_Off option is working or not in Table layout$")
	public void Check_Symbol_Column_On_Off_option_is_working_or_not_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		Opt = new Options();
		Opt.Click_on_Display_Preferences();
		com.sleepThread(5000);
		com.KeyEvent(KeyEvent.VK_DOWN);
		String Symbol_Column_On_Off_option = Common.readPropertyByoptions().getProperty("Symbol_Column_On_Off_option");
		com.click("xpath", Symbol_Column_On_Off_option,
				"IOTC-00065," + Widget_name + ",Check Symbol Column Off option is working or not in Table layout");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Column_On_Off_option,
				"," + Widget_name + ",Check Symbol Column On option is working or not in Table layout");
	}

	@And("^Check symbol Column Dropdown is working or not Ticker and Description in Table layout$")
	public void Check_symbol_Column_Dropdown_is_working_or_not_Ticker_and_Description_in_Table_layout()
			throws Exception {
		String symbol_Column_Dropdown = Common.readPropertyByoptions().getProperty("symbol_Column_Dropdown");
		com.select_the_Drop_Down_values("xpath", symbol_Column_Dropdown, "IOTC-00066," + Widget_name
				+ ",Check symbol Column Dropdown is working or not Ticker and Description in Table layout");
	}

	@And("^Verify OK button So that the changes has to be applied in Table layout$")
	public void Verify_OK_Button_So_that_the_changes_has_to_be_applied_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String OK_button = Common.readPropertyByoptions().getProperty("OK_button");
		com.MouseOverToclickabl("xpath", OK_button, "IOTC-00067," + Widget_name
				+ ",Verify OK button So that the changes has to be applied in Table layout");
	}

	@And("^Verify Cancel button So that the changes has to be Cancled in Table layout$")
	public void Cancel_Verify_Cancel_Button_So_that_the_changes_has_to_be_Cancled_in_Table_layout() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Cancel_button = Common.readPropertyByoptions().getProperty("Cancel_button");
		com.click("xpath", Cancel_button, "IOTC-00068," + Widget_name
				+ ",Verify Cancel button So that the changes has to be Cancled in Table layout");
	}

	@When("^Verify the strikes drop down$")
	public void Verify_the_strikes_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String strikes_drop_down = Common.readPropertyByoptions().getProperty("strikes_drop_down");
		com.verifyElementPresent("xpath", strikes_drop_down,
				"IOTC-00069," + Widget_name + ",Verify the strikes drop down");
	}

	@Then("^Click on strikes drop down$")
	public void Click_on_strikes_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String strikes_drop_down = Common.readPropertyByoptions().getProperty("strikes_drop_down");
		com.click("xpath", strikes_drop_down, "IOTC-00070," + Widget_name + ",Click on strikes drop down");
	}

	@And("^Verify the all fields in strikes drop down$")
	public void Verify_the_all_fields_in_strikes_drop_down() throws Exception {
		com.startAction();
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[1]/button"))
				.size();
		System.out.println("all fields: " + size);
		for (int i = 1; i < size; i++) {
			com.sleepThread(3000);
			com.MouseOverToclickabl("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[" + i + "]/button",
					"IOTC-00071," + Widget_name + ",Verify the all fields in strikes drop down");
			String Fields_cross_icon = Common.readPropertyByoptions().getProperty("Fields_cross_icon");
			com.click("xpath", Fields_cross_icon, "," + Widget_name + ",click on fields cross icon");
			Opt = new Options();
			Opt.Click_on_strikes_drop_down();

		}
	}

	@And("^Click on all fields cross icon$")
	public void Click_on_all_fields_cross_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String All_Fields_cross_icon = Common.readPropertyByoptions().getProperty("All_Fields_cross_icon");
		com.click("xpath", All_Fields_cross_icon, "," + Widget_name + ",Click on all fields cross icon");
	}

	@And("^Select Strikes Drop Down and select any strikes so that we can see only selected strike prices$")
	public void Select_Strikes_Drop_Down_and_select_any_strikes_so_that_we_can_see_only_selected_strike_prices()
			throws Exception {
		com.startAction();
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Strikes_option = Common.readPropertyByoptions().getProperty("Strikes_option");
		com.MouseOverToElement("xpath", Strikes_option, "," + Widget_name + ",Mouse over on strikes option");
		com.sleepThread(4000);
		int Size = driver
				.findElements(
						By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li/button/label"))
				.size();
		System.out.println("Strikes_text :" + Size);

		for (int i = 25; i < 28; i++) {
			com.sleepThread(4000);
			String Strikes_text = driver.findElement(By.xpath(
					"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li[" + i + "]/button/label"))
					.getText();
			System.out.println("Strikes_text:" + Strikes_text);
			com.click("xpath",
					"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li[" + i + "]/button/label",
					"," + Widget_name + ",Select on strikes value");
			// String
			// Strikes_value_in_table=Common.readPropertyByoptions().getProperty("Strikes_value_in_table");
			// com.MouseOverToElement("xpath",Strikes_value_in_table,",,Mouse over on
			// strikes value in table");
			com.sleepThread(2000);
			//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[7]/div[1]")).click();
			try {
				com.sleepThread(2000);
				System.out.println("*****************");
				String Strikes_value = driver.findElement(By.xpath(
						"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[7]/div[1]"))
						.getText();
				System.out.println("Strikes_value:" + Strikes_value);
				System.out.println("---------------");

				String Strikes_replace = Strikes_value.replace(Strikes_value + ".00", "");

				if (Strikes_text.equals(Strikes_replace)) {
					com.Creatlogfile(Date_Time + "," + "," + Widget_name + ",Strikes option value " + Strikes_text
							+ " and Strike column value " + Strikes_value + " equals or not" + ",Pass");

				} else {
					com.Creatlogfile(Date_Time + "," + "," + Widget_name + ",Strikes option value " + Strikes_text
							+ " and Strike column value " + Strikes_value + " equals or not" + ",Fail");
				}
			} catch (Exception t) {
				com.Creatlogfile(
						Date_Time + "," + "," + Widget_name + ",Thare is no Related Strikes option value" + ",Pass");
			}
			com.sleepThread(5000);
			String Close_icon_in_Strikes_drop_down = Common.readPropertyByoptions().getProperty("Close_icon_in_Strikes_drop_down");
     		com.click("xpath", Close_icon_in_Strikes_drop_down, ",Options,Click on close icon in strikes drop down");
     		com.sleepThread(2000);
     		Opt = new Options();
			Opt.Click_on_strikes_drop_down();
			com.sleepThread(3000);
			com.MouseOverToElement("xpath", Strikes_option, "," + Widget_name + ",Mouse over on strikes option");
			com.sleepThread(3000);
			/*
			 * com.click("xpath",
			 * "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li["+i+
			 * "]/button/label",","+Widget_name+",Select on strikes value");
			 * com.sleepThread(2000); Opt=new Options(); Opt.Click_on_strikes_drop_down();
			 * com.sleepThread(2000); com.MouseOverToElement("xpath",Strikes_option,","+
			 * Widget_name+",Mouse over on strikes option"); com.sleepThread(2000);
			 */
		}

		//com.click("xpath", "Close_icon_in_Strikes_drop_down", "," + Widget_name + ",Click on close icon in strikes drop down");
		//com.sleepThread(5000);
		//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[7]/div[1]")).click();
	}

	@And("^click on Move Region Into a New Window option in options$")
	public void click_on_Move_Region_Into_a_New_Window_option() throws Exception {
		com.startAction();
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Move_Region_Into_a_New_Window = Common.readPropertyByChart()
				.getProperty("Move_Region_Into_a_New_Window");
		System.out.println(Move_Region_Into_a_New_Window);
		com.MouseOverToElement("xpath", Move_Region_Into_a_New_Window, ",Options,ouse over on move region");
		com.sleepThread(2000);
		String New_Window = Common.readPropertyByChart().getProperty("New_Window");
		com.MouseOverToElement("xpath", New_Window, ",Options,ouse over on New Window");
		com.sleepThread(6000);
		String New_window_widget_name = Common.readPropertyByChart().getProperty("New_window_widget_name");
		com.switch_to_new_window("xpath", New_Window,
				"," + Widget_name + ",click on Move Region Into a New Window option", "xpath", New_window_widget_name,
				",Options,Switch to New Window verify the widget tab");
		com.sleepThread(2000);
		com.click("xpath", "//*[contains(text(),'Options')]", ",Options,Click on Chart widget");
		com.sleepThread(2000);
	}

	@And("^Clicked on All Expirations option in dropdown$")
	public void Clicked_on_All_Expirations_option_in_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Filter_Dropdown = Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		// Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		com.click("xpath", Filter_Dropdown, ","+Widget_name +",clicked on Filter dropdown");
		com.sleepThread(2000);

		String All_Expirations = Common.readPropertyByoptions().getProperty("All_Expirations");
		// Next=Common.readPropertyByoptions().getProperty("Next");
		com.click("xpath", All_Expirations, "," + Widget_name + ",clicked on All Expirations");
		com.sleepThread(2000);
	}

	@And("^Click on next option in dropdown$")
	public void Click_on_next_option_in_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Filter_Dropdown = Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		// Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		com.click("xpath", Filter_Dropdown, "," + Widget_name + ",clicked on Filter dropdown");
		com.sleepThread(2000);

		String Next = Common.readPropertyByoptions().getProperty("A_Next");
		// Next=Common.readPropertyByoptions().getProperty("Next");
		com.mouseovercontextClick("xpath", Next, "," + Widget_name + ",mouse hover on Next dropdown");
		com.sleepThread(2000);
		int size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[2]/div/ul/li/button"))
				.size();
		System.out.println("Next" + size);
		for (int i = 1; i < size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[2]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",clicking on next submenus");
			com.sleepThread(2000);
			com.startAction();
			// Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
			com.click("xpath", Filter_Dropdown, "," + Widget_name + ",clicked on Filter dropdown");
			com.sleepThread(2000);
			// Next=Common.readPropertyByoptions().getProperty("Next");
			com.mouseovercontextClick("xpath", Next, "," + Widget_name + ",mouse hover on Next dropdown");
			com.sleepThread(2000);

		}
		com.click("xpath", Filter_Dropdown, ",,clicked on Filter dropdown");
		com.sleepThread(2000);
		System.out.println("Checked filters next dropdown");
	}

	@When("^Clicked on Weekly option in dropdown$")
	public void Clicked_on_Weekly_option_in_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Filter_Dropdown = Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		// //Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		// com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
		com.sleepThread(2000);
		String Weekly = Common.readPropertyByoptions().getProperty("A_Weekly");
		com.mouseovercontextClick("xpath", Weekly, "mouse hover on Weekly dropdown");
		com.sleepThread(2000);
		int Size = driver.findElements(By.xpath(
				"//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li"))
				.size();
		System.out.println("Weekly" + Size);
		for (int i = 1; i <= Size; i++) {
			com.click("xpath",
					"//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li["
							+ i + "]",
					"," + Widget_name + ",clicking on next submenus");
			com.sleepThread(2000);
			com.startAction();
			// Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
			com.click("xpath", Filter_Dropdown, "," + Widget_name + ",clicked on Filter dropdown");
			com.sleepThread(2000);
			com.mouseovercontextClick("xpath", Weekly, "," + Widget_name + ",mouse hover on Weekly dropdown");
			com.sleepThread(2000);
		}
		System.out.println("Checked filters weekly dropdown");
	}

	@When("^Clicked on monthly option in dropdown$")
	public void Clicked_on_monthly_option_in_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		com.startAction();
		String Filter_Dropdown = Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		com.click("xpath", Filter_Dropdown, "clicked on Filter dropdown");
		com.sleepThread(2000);
		String Monthly = Common.readPropertyByoptions().getProperty("A_Monthly");
		com.MouseOverToElement("xpath", Monthly, "," + Widget_name + ",mouse hover on Monthly dropdown");
		com.sleepThread(2000);
		int Size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[3]/div/ul/li/button"))
				.size();
		System.out.println("monthly" + Size);
		for (int i = 1; i < Size; i++) {
			com.MouseOverToclickabl("xpath",
					"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[3]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",clicking on monthly submenus");
			com.sleepThread(3000);
			String Out_Area = Common.readPropertyByoptions().getProperty("Out_Area");
			com.click("xpath", Out_Area, "," + Widget_name + ",clicking on outside submenus");
			com.startAction();

			com.click("xpath", Filter_Dropdown, "," + Widget_name + ",clicked on Filter dropdown");
			com.sleepThread(2000);

			com.mouseovercontextClick("xpath", Monthly, "," + Widget_name + ",mouse hover on Monthly dropdown");
			com.sleepThread(2000);
		}

		// System.out.println("Checked filters monthly dropdown");
		// com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
		// com.sleepThread(2000);
		// System.out.println("Checked filters next dropdown");
	}

	@When("^Clicked on specific dates option in dropdown$")
	public void Clicked_on_specific_dates_option_in_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Filter_Dropdown = Common.readPropertyByoptions().getProperty("Filter_Dropdown");
		// com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
		com.sleepThread(2000);
		String Specific_Dates = Common.readPropertyByoptions().getProperty("Specific_Dates");
		// String
		// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
		com.MouseOverToElement("xpath", Specific_Dates, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);
		int Size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li/button"))
				.size();
		System.out.println("Specific_Dates :" + Size);
		for (int i = 2; i < Size; i++) {
			com.MouseOverToclickabl("xpath",
					"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",clicking on specific_datessubmenus");
			com.sleepThread(3000);
			String Out_Area = Common.readPropertyByoptions().getProperty("Out_Area");
			com.click("xpath", Out_Area, "," + Widget_name + ",clicking on outside submenus");
			com.startAction();
			// String
			// Filter_Dropdown=Common.readPropertyByoptions().getProperty("Filter_Dropdown");
			com.click("xpath", Filter_Dropdown, "," + Widget_name + ",clicked on Filter dropdown");
			com.sleepThread(2000);
			// String
			// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
			com.MouseOverToElement("xpath", Specific_Dates,
					"," + Widget_name + ",mouse hover on Specific_Dates dropdown");
			com.sleepThread(2000);
		}

		System.out.println(
				"Tested Filters option by selecting different Specific dates Also Checked options like Next, Weekly, Monthly options are working as intended.");

	}

	@When("^Clicked on Refresh button$")
	// Options
	public void Clicked_on_Refresh_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Refresh = Common.readPropertyByoptions().getProperty("Refresh");
		com.click("xpath", Refresh, "," + Widget_name + ",clicked on refersh button");
		com.sleepThread(2000);

		String Strike = Common.readPropertyByoptions().getProperty("Strike");
		// com.click("xpath",Strike,"clicked on strike button");
		com.sleepThread(2000);
		System.out.println("Tested Refresh button  it is functioning as intended");
	}

	// Right click
	@Then("^clicked on view chart and other widgets$")
	// Options
	public void clicked_on_view_chart_and_other_widgest() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(8000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		String View = Common.readPropertyByoptions().getProperty("View");
		// String
		// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
		com.mouseovercontextClick("xpath", View, "," + Widget_name + ",mouse hover on view");
		com.sleepThread(2000);
		int size = driver.findElements(By.xpath("//*[@id='container']/div//div[6]/div/ul/li[1]/div/ul/li/button"))
				.size();
		System.out.println("view chart"+size);
		for (int i = 1; i < size; i++) {
			
			String view_suboptions = driver
					.findElement(By.xpath("//*[@id='container']/div//div[6]/div/ul/li[1]/div/ul/li[" + i + "]/button"))
					.getText();
			com.click("xpath", "//*[@id='container']/div//div[6]/div/ul/li[1]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",clicking on specific_datessubmenus");

			String openwidget = driver.findElement(By.xpath("//li[@class='css-1eeqky1']")).getText();
			try {
				view_suboptions.equals(openwidget);
				com.Creatlogfile(Date_Time + "," + "," + Widget_name
						+ ",Clickable wiget and open widget is equals or not" + ",Pass");

			} catch (Exception t) {
				com.Creatlogfile(Date_Time + "," + "," + Widget_name
						+ ",Clickable wiget and open widget is equals or not" + ",Fail");
			}

			Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
					.getText();
			com.sleepThread(3000);
			com.startAction();
			String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
			com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
			com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");

			com.sleepThread(3000);
			String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
			com.MouseOverToclickabl("xpath", Close_Tab,
					"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
			com.sleepThread(2000);
			
			com.startAction();
			com.sleepThread(5000);
			driver.navigate().refresh();
			com.sleepThread(9000);
			//String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
			com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
			com.sleepThread(2000);
			//String View = Common.readPropertyByoptions().getProperty("View");
			// String
			// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
			com.mouseovercontextClick("xpath", View, "," + Widget_name + ",mouse hover on view");
			com.sleepThread(2000);

		}

	}
/*	@Then("^clicked on view chart and other widgets$")
	// Options
	public void clicked_on_view_chart_and_other_widgest() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div//div[5]/div/ul/li[1]/div/ul/li/button"))
				.size();
		System.out.println("view chart"+size);
		for (int i = 1; i < size; i++) {
			
			String view_suboptions = driver
					.findElement(By.xpath("//*[@id='container']/div//div[5]/div/ul/li[1]/div/ul/li[" + i + "]/button"))
					.getText();
			com.click("xpath", "//*[@id='container']/div//div[5]/div/ul/li[1]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",clicking on specific_datessubmenus");

			String openwidget = driver.findElement(By.xpath("//*[@id='7']/div[2]/div[1]/ul/li[2]/div")).getText();
			try {
				view_suboptions.equals(openwidget);
				com.Creatlogfile(Date_Time + "," + "," + Widget_name
						+ ",Clickable wiget and open widget is equals or not" + ",Pass");

			} catch (Exception t) {
				com.Creatlogfile(Date_Time + "," + "," + Widget_name
						+ ",Clickable wiget and open widget is equals or not" + ",Fail");
			}

			Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
					.getText();
			com.sleepThread(3000);
			com.startAction();
			String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
			com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
			com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");

			com.sleepThread(2000);
			String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
			com.click("xpath", Close_Tab,
					"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
			com.sleepThread(2000);

		}

	}*/

	@And("^Clicked on insert column$")
	// Options
	public void Clicked_on_insert_column() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(19000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(3000);

		String Insert = Common.readPropertyByoptions().getProperty("Insert");
		com.MouseOverToElement("xpath", Insert, "," + Widget_name + ",inserting new row");
		com.MouseOverToclickabl("xpath", Insert, "," + Widget_name + ",inserting new row");
		com.sleepThread(1000);

		// String
		// Insert_Column=Common.readPropertyByoptions().getProperty("Insert_Column");
		// com.click("xpath",Insert_Column,"inserting new row");
		com.sleepThread(1000);

		String Add_Column_Ok = Common.readPropertyByoptions().getProperty("Add_Column_Ok");
		com.click("xpath", Add_Column_Ok, "," + Widget_name + ",click on add column save button");

		System.out.println("Checked insert option");

	}

	@And("^verify the Add Columns pop title$")
	public void verify_the_Add_Columns_pop_title() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Insert = Common.readPropertyByoptions().getProperty("Insert");
		com.MouseOverToElement("xpath", Insert, "," + Widget_name + ",inserting new row");
		com.MouseOverToclickabl("xpath", Insert, "," + Widget_name + ",inserting new row");
		com.sleepThread(1000);
		String Add_column_pop_title = Common.readPropertyByoptions().getProperty("Add_column_pop_title");
		com.verifyElementPresent("xpath", Add_column_pop_title,
				"," + Widget_name + ",verify the Add Columns pop title");
	}

	@And("^Add the new insert column$")
	public void Add_the_new_insert_column() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Select_frist_column_in_add_column_pop = Common.readPropertyByoptions()
				.getProperty("Select_frist_column_in_add_column_pop");
		com.verifyElementPresent("xpath", Select_frist_column_in_add_column_pop,
				"," + Widget_name + ",Add the new insert column");

	}

	@And("^verify the cancel button in Add Columns pop$")
	public void verify_the_cancel_button_in_Add_Columns_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Insert_Add_columns_pop_Cancel_button = Common.readPropertyByoptions()
				.getProperty("Insert_Add_columns_pop_Cancel_button");
		com.verifyElementPresent("xpath", Insert_Add_columns_pop_Cancel_button,
				"," + Widget_name + ",verify the cancel button in Add Columns pop");
	}

	@And("^Verify the ok button in Add Columns pop$")
	public void Verify_the_ok_button_in_Add_Columns_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_Column_Ok = Common.readPropertyByoptions().getProperty("Add_Column_Ok");
		com.verifyElementPresent("xpath", Add_Column_Ok,
				"," + Widget_name + ",Verify the ok button in Add Columns pop");
	}

	@And("^Click on ok button in Add Columns pop$")
	public void Click_on_ok_button_in_Add_Columns_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_Column_Ok = Common.readPropertyByoptions().getProperty("Add_Column_Ok");
		com.click("xpath", Add_Column_Ok, "," + Widget_name + ",Click on ok button in Add Columns pop");

	}

	@And("^verify the cross icon in Add Columns pop$")
	public void verify_the_cross_icon_in_Add_Columns_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_Column_Cross_icon = Common.readPropertyByoptions().getProperty("Add_Column_Cross_icon");
		com.verifyElementPresent("xpath", Add_Column_Cross_icon,
				"," + Widget_name + ",verify the cross icon in Add Columns pop");
		// com.click("xpath",Add_Column_Cross_icon, "," + Widget_name +",Click on cross
		// icon in Add Columns pop");
	}

	@And("^Clicked on Delete Inserted columns$")
	// Options
	public void Clicked_on_Delete_Inserted_columns() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);

		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Delete_column = Common.readPropertyByoptions().getProperty("Delete_column");
		com.click("xpath", Delete_column, "," + Widget_name + ",Deleting inserted rows");

		System.out.println("Checked delete option");

	}

	@And("^Clicked on Copy as text$")
	// Options
	public void Clicked_on_Copy_as_text() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);

		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Edit = Common.readPropertyByoptions().getProperty("R_Edit");
		com.mouseovercontextClick("xpath", Edit, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);

		String Copy_As_Text = Common.readPropertyByoptions().getProperty("Copy_As_Text");
		com.click("xpath", Copy_As_Text, "," + Widget_name + ",clicking on Copy As Text");

		System.out.println("Checked copy as text option");
	}

	@And("^Clicked on select all$")
	// Options
	public void Clicked_on_select_all() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);

		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Edit = Common.readPropertyByoptions().getProperty("R_Edit");
		com.mouseovercontextClick("xpath", Edit, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);

		String Select_All = Common.readPropertyByoptions().getProperty("Select_All");
		com.click("xpath", Select_All, "," + Widget_name + ",clicking on select all");

		System.out.println("Checked select all options");
	}

	/*
	 * @And("^Clicked on clear selection$") //Options public void
	 * Clicked_on_clear_selection() throws Exception { com.startAction();
	 * com.sleepThread(1000);
	 * 
	 * String Right_click=Common.readPropertyByoptions().getProperty("Right_click");
	 * com.Rightclick("xpath",Right_click,"Right clicked on options data");
	 * com.sleepThread(2000);
	 * 
	 * String Edit=Common.readPropertyByoptions().getProperty("R_Edit");
	 * com.mouseovercontextClick("xpath",
	 * Edit,"mouse hover on Specific_Dates dropdown"); com.sleepThread(2000);
	 * 
	 * String
	 * Clear_Selection=Common.readPropertyByoptions().getProperty("Clear_Selection")
	 * ; com.click("xpath",Clear_Selection,"clicking on clear selection");
	 * 
	 * System.out.println("Checked clear option"); }
	 */

	@And("^Clicked on best fit$")
	// Options
	public void Clicked_on_best_fit() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);

		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Edit = Common.readPropertyByoptions().getProperty("R_Edit");
		com.mouseovercontextClick("xpath", Edit, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);

		String Best_Fit_Symbol = Common.readPropertyByoptions().getProperty("Best_Fit_Symbol");
		com.click("xpath", Best_Fit_Symbol, "," + Widget_name + ",clicking on Copy As Text");

		System.out.println("Checked best fit option");
	}

	@And("^Clicked on best fit all columns$")
	// Options
	public void Clicked_on_best_fit_all_columns() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);

		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);

		String Edit = Common.readPropertyByoptions().getProperty("R_Edit");
		com.mouseovercontextClick("xpath", Edit, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);

		String Best_Fit_All_Columns = Common.readPropertyByoptions().getProperty("Best_Fit_All_Columns");
		com.click("xpath", Best_Fit_All_Columns, "," + Widget_name + ",clicking on best fit all");

		System.out.println("Checked best fit all columns option");

	}

	@And("^Clicked on Show Selected Option Symbol Details$")
	// Options
	public void Clicked_on_Show_Selected_Option_Symbol_Details() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		String Show_Selected_Option_Symbol_Details = Common.readPropertyByoptions()
				.getProperty("Show_Selected_Option_Symbol_Details");
		// String
		// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
		com.click("xpath", Show_Selected_Option_Symbol_Details,
				"," + Widget_name + ",Show Selected Option Symbol Details");
		com.sleepThread(2000);

		String Verify_Show_Selected_Option_Symbol_Details = Common.readPropertyByoptions()
				.getProperty("Verify_Show_Selected_Option_Symbol_Details");
		if (Verify_Show_Selected_Option_Symbol_Details != null) {
			System.out.println("Show Selected Option Symbol Details is working");

		} else {
			System.out.println("Show Selected Option Symbol Details is not working");
		}
		System.out.println(
				"Checked whether the Underlying Symbol Details and Show Selected Option Symbol Details were working or not");

	}

	@And("^clicked on save option properties as default$")
	public void clicked_on_save_option_properties_as_defaulty() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		String Defaults = Common.readPropertyByoptions().getProperty("Defaults");
		// String
		// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
		com.mouseovercontextClick("xpath", Defaults, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);
		com.click("xpath", "//*[contains(text(),'Save Options Properties as Default')]",
				"," + Widget_name + ",clicking on Default Save Options Properties as Default");
		com.sleepThread(1000);
	}
	@And("^Verify the title Question pop in save option properties as default$")
	public void Verify_the_title_Question_pop_in_save_option_properties_as_default() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Question_pop = Common.readPropertyByoptions().getProperty("Question_pop");
		com.verifyElementPresent("xpath",Question_pop,","+ Widget_name +",Verify the title Question pop in save option properties as default");
	}
	@And("^Verify the Close icon in Question pop in save option properties as default$")
	public void Verify_the_Close_icon_in_Question_pop_in_save_option_properties_as_default() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String  Close_icon_in_Question_pop= Common.readPropertyByoptions().getProperty("Close_icon_in_Question_pop");
		com.verifyElementPresent("xpath",Close_icon_in_Question_pop,","+ Widget_name +",Verify the Close icon in Question pop in save option properties as default");
	}
	@And("^Verify the Yes button in Question pop in save option properties as default$")
	public void Verify_the_Yes_button_in_Question_pop_in_save_option_properties_as_default() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String  Yes_button_in_Question_pop= Common.readPropertyByoptions().getProperty("Yes_button_in_Question_pop");
		com.verifyElementPresent("xpath",Yes_button_in_Question_pop,","+ Widget_name +",Verify the Yes button in Question pop in save option properties as default");
	}
	@And("^Verify the NO button in Question pop in save option properties as default$")
	public void Verify_the_NO_button_in_Question_pop_in_save_option_properties_as_default() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String  No_button_in_Question_pop= Common.readPropertyByoptions().getProperty("No_button_in_Question_pop");
		com.verifyElementPresent("xpath",No_button_in_Question_pop,","+ Widget_name +",Verify the NO button in Question pop in save option properties as default");
	}
	@And("^Click on Close icon in Question pop in save option properties as default$")
	public void Click_on_Close_icon_in_Question_pop_in_save_option_properties_as_default() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String  Close_icon_in_Question_pop= Common.readPropertyByoptions().getProperty("Close_icon_in_Question_pop");
		com.click("xpath",Close_icon_in_Question_pop,","+ Widget_name +",Click on Close icon in Question pop in save option properties as default");
	}
	@And("^Click on NO button in Question pop in save option properties as default$")
	public void Click_on_NO_button_in_Question_pop_in_save_option_properties_as_default() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String  No_button_in_Question_pop= Common.readPropertyByoptions().getProperty("No_button_in_Question_pop");
		com.click("xpath",No_button_in_Question_pop,","+ Widget_name +",Click on NO button in Question pop in save option properties as default");
	}
	@And("^Click on Yes button in Question pop in save option properties as default$")
	public void Click_on_Yes_button_in_Question_pop_in_save_option_properties_as_default() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String  Yes_button_in_Question_pop= Common.readPropertyByoptions().getProperty("Yes_button_in_Question_pop");
		com.click("xpath",Yes_button_in_Question_pop,","+ Widget_name +",Click on Yes button in Question pop in save option properties as default");
		com.sleepThread(1000);
		String  Ok_button_in_Question_pop= Common.readPropertyByoptions().getProperty("Ok_button_in_Question_pop");
		com.click("xpath",Ok_button_in_Question_pop,","+ Widget_name +",Click on ok button");
	}
	
	
	@And("^clicking on Apply Default Properties to the Options$")
	public void clicking_on_Apply_Default_Properties_to_the_Options() throws Exception {
		String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
		com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		// String
		// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
		String Defaults = Common.readPropertyByoptions().getProperty("Defaults");
		com.mouseovercontextClick("xpath", Defaults, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
		com.sleepThread(2000);
		com.click("xpath", "//*[contains(text(),'Apply Default Properties to the Options')]",
				"," + Widget_name + ",clicking on Apply Default Properties to the Options");
		System.out.println("Checked defaults");
	}
	
	
	
	
	
	
	
	
	
	// ***************************************************************

	// Verify column set
	@Given("^Click on the default column set$")
	public void click_on_the_default_column_set() throws Exception {
		com.sleepThread(10000);
		com.startAction();
		String columnsetdropdown = Common.readPropertyByoptions().getProperty("columnsetdropdown");
		// com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", columnsetdropdown, "ILTC-00029,Options,Click on column set dropdown");
		// com.waitUntilElementPresent(columnsetdropdown);
		// com.startAction();
		// com.MouseOverToElement("xpath", columnsetdropdown, "ILTC-00030,Options,Click
		// on New column set dropdown");
	}

	@Then("^select the column set for which you want to get results$")
	public void select_the_column_set_for_which_you_want_to_get_results() throws Throwable {
		String Defaultcolumnset = Common.readPropertyByoptions().getProperty("Defaultcolumnset");
		com.sleepThread(2000);
		com.click("xpath", Defaultcolumnset, "ILTC-00030,Options,Click on Default column set");
	}

	@Then("^Verify the columns whether they are from column set or not$")
	public void verify_the_columns_whether_they_are_from_column_set_or_not() throws Throwable {
		String Ask = Common.readPropertyByoptions().getProperty("Ask");
		String Bid = Common.readPropertyByoptions().getProperty("Bid");
		String Last = Common.readPropertyByoptions().getProperty("Last");
		String Netchange = Common.readPropertyByoptions().getProperty("Netchange");
		String OpenInterest = Common.readPropertyByoptions().getProperty("OpenInterest");
		com.sleepThread(5000);
		String Asktext = "Ask";
		String Bidtext = "Bid";
		String Lasttext = "Last";
		String netchangetext = "Net Change";
		String Openinteresrtext = "Open Interest";
		com.verifyText("xpath", Bid, Bidtext, "ILTC-00030,Options,Verify Bid text column of Default column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Ask, Asktext, "ILTC-00030,Options,Verify Ask text column of Deafult column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Last, Lasttext, "ILTC-00030,Options,Verify Last text column of Deafult column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Netchange, netchangetext,
				"ILTC-00030,Options,Verify Net Change text column of Deafult column set and Deafult columns set verified");
		com.sleepThread(5000);
		com.verifyText("xpath", OpenInterest, Openinteresrtext,
				"ILTC-00030,Options,Verify open Interest text column of Deafult column set");
	}

	// Duplicate column set
	@Given("^Click on default column set and select New$")
	public void click_on_default_column_set_and_select_New() throws Throwable {
		String columnsetdropdown = Common.readPropertyByoptions().getProperty("columnsetdropdown");
		String NewColumnset = Common.readPropertyByoptions().getProperty("NewColumnset");
		com.sleepThread(6000);
		com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on Default column set");
		com.sleepThread(5000);
		// com.waitUntilElementPresent(NewColumnset);
		// com.startAction();
		// com.MouseOverToElement("xpath", NewColumnset, "ILTC-00030,Options,Click on
		// New column set dropdown");
		com.click("xpath", NewColumnset, "ILTC-00030,Options,Click on New column set dropdown");
	}

	@Then("^Enter Name \"([^\"]*)\" of column set$")
	public void enter_Name_of_column_set(String Name) throws Throwable {
		String Nameinput = Common.readPropertyByoptions().getProperty("Nameinput");
		com.sleepThread(3000);
		com.sendKeys("xpath", Nameinput, Name, "ITLC-31,Options,Enter the name for column set");
	}

	@Then("^Select available columns and click right arrow$")
	public void select_available_columns_and_click_right_arrow() throws Throwable {
		String Optionsavailablecolumns = Common.readPropertyByoptions().getProperty("Optionsavailablecolumns");
		String OptionTypecolumn = Common.readPropertyByoptions().getProperty("OptionTypecolumn");
		String Strikecolumn = Common.readPropertyByoptions().getProperty("Strikecolumn");
		String rightarrow = Common.readPropertyByoptions().getProperty("rightarrow");
		com.sleepThread(5000);
		com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
		com.sleepThread(3000);
		com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
		com.sleepThread(4000);
		com.startAction();
		com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
		com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
		com.sleepThread(3000);
		com.click("xpath", Strikecolumn, "ITLC-35,Options,click on Strike in options");
		com.sleepThread(4000);
		com.startAction();
		com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
		com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
	}

	@Then("^click on save and again click on default$")
	public void click_on_save_and_again_click_on_default() throws Throwable {
		String savecolumnset = Common.readPropertyByoptions().getProperty("savecolumnset");
		String columnsetdropdown = Common.readPropertyByoptions().getProperty("columnsetdropdown");
		com.sleepThread(5000);
		com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set");
		com.sleepThread(5000);
		com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on default column set");
	}

	@Then("^Click on New and enter the SameName \"([^\"]*)\"$")
	public void click_on_New_and_enter_the_SameName(String SameName) throws Throwable {
		String NewColumnset = Common.readPropertyByoptions().getProperty("NewColumnset");
		String Nameinput = Common.readPropertyByoptions().getProperty("Nameinput");
		com.sleepThread(5000);
		com.click("xpath", NewColumnset, "ILTC-00029,Options,Click on New column set");
		com.sendKeys("xpath", Nameinput, SameName, "ITLC-35,Options,Verify entering symbol input");
	}

	@Then("^Add available columns by clicking on right arrow$")
	public void add_available_columns_by_clicking_on_right_arrow() throws Throwable {
		String Optionsavailablecolumns = Common.readPropertyByoptions().getProperty("Optionsavailablecolumns");
		String OptionTypecolumn = Common.readPropertyByoptions().getProperty("OptionTypecolumn");
		String underlyingsymbol = Common.readPropertyByoptions().getProperty("underlyingsymbol");
		String rightarrow = Common.readPropertyByoptions().getProperty("rightarrow");
		com.sleepThread(3000);
		com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
		com.sleepThread(3000);
		com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
		com.sleepThread(4000);
		com.startAction();
		com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
		com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
		com.sleepThread(3000);
		com.click("xpath", underlyingsymbol, "ITLC-35,Options,click on underlyingsymbol in options");
		com.sleepThread(4000);
		com.startAction();
		com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
		com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
	}

	@Then("^click on save and duplicate column set should not be added and click on cancel after verification$")
	public void click_on_save_and_duplicate_column_set_should_not_be_added() throws Throwable {
		String savecolumnset = Common.readPropertyByoptions().getProperty("savecolumnset");
		String cancelcolumnset = Common.readPropertyByoptions().getProperty("cancelcolumnset");
		com.sleepThread(5000);
		com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set and colum set not added");
		com.sleepThread(9000);
		com.click("xpath", cancelcolumnset, "ILTC-00029,Options,Click on cancel column set");
	}

	// Edit columnset
	@Given("^Click on columnset dropdown and then click on manage column set$")
	public void click_on_columnset_dropdown_and_then_click_on_manage_column_set() throws Throwable {
		String columnsetdropdown = Common.readPropertyByoptions().getProperty("columnsetdropdown");
		String Managecolumnset = Common.readPropertyByoptions().getProperty("Managecolumnset");
		com.sleepThread(5000);
		com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on Columnset");
		com.sleepThread(4000);
		com.click("xpath", Managecolumnset, "ILTC-00029,Options,Click on Manage column set");
	}

	@Then("^Select the column set that has to be edited and click on edit$")
	public void select_the_column_set_that_has_to_be_edited_and_click_on_edit() throws Throwable {
		String Customcolumnset = Common.readPropertyByoptions().getProperty("Customcolumnset");
		String Editcolumnset = Common.readPropertyByoptions().getProperty("Editcolumnset");
		com.sleepThread(5000);
		com.click("xpath", Customcolumnset, "ILTC-00029,Options,Click on custom Column set");
		com.sleepThread(4000);
		com.click("xpath", Editcolumnset, "ILTC-00029,Options,Click on Edit column set");
	}

	@Then("^clear the Name field and enter the New Name \"([^\"]*)\"$")
	public void clear_the_Name_field_and_enter_the_New_Name(String Name) throws Throwable {
		String EditNameinputcolumnset = Common.readPropertyByoptions().getProperty("EditNameinputcolumnset");
		// com.sleepThread(5000);
		// com.ClearTextField("xpath", EditNameinput, "ILTC-00029,Options,Clear name of
		// column set");
		com.sleepThread(4000);
		com.sendKeys("xpath", EditNameinputcolumnset, Name, "ITLC-35,Options,Verify entering Name input");
	}

	@Then("^Click on Save and verify the columnset name$")
	public void click_on_Save_and_verify_the_columnset_name() throws Throwable {
		String Editsavecolumnset = Common.readPropertyByoptions().getProperty("Editsavecolumnset1");
		String Editedcustomcolumnset = Common.readPropertyByoptions().getProperty("Editedcustomcolumnset1");
		String closecolumnset = Common.readPropertyByoptions().getProperty("closecolumnset");
		com.sleepThread(5000);
		com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
		com.sleepThread(4000);
		com.waitUntilElementPresent(Editedcustomcolumnset);
		String text = "WXYZINDI";
		com.verifyText("xpath", Editedcustomcolumnset, text, "ITLC-00029,Options, Verify Edited column set name");
		// com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on cancel column
		// set");
	}

	// Copy colum set
	@Given("^Select the column set that has to be copied and Click on copy column set$")
	public void select_the_column_set_that_has_to_be_copied_and_Click_on_copy_column_set() throws Throwable {
		String Customcolumnset = Common.readPropertyByoptions().getProperty("Customcolumnset");
		String Copycolumnset = Common.readPropertyByoptions().getProperty("Copycolumnset1");
		com.sleepThread(5000);
		com.click("xpath", Customcolumnset, "ILTC-00029,Options,Click on custom Column set");
		com.sleepThread(4000);
		com.click("xpath", Copycolumnset, "ILTC-00029,Options,Click on Copy column set");
	}

	@Then("^Clear the name and enter the new column set Name \"([^\"]*)\" and add column$")
	public void clear_the_name_and_enter_the_new_column_set_Name(String Name) throws Throwable {
		String EditNameinput = Common.readPropertyByoptions().getProperty("EditNameinput1");
		String OptiontypeSN = Common.readPropertyByoptions().getProperty("OptiontypeSN1");
		String rightarrowincopy = Common.readPropertyByoptions().getProperty("rightarrowincopy1");
		String Optionscolumnsincopy = Common.readPropertyByoptions().getProperty("Optionscolumnsincopy1");
		com.sleepThread(5000);
		com.ClearTextField("xpath", EditNameinput, "ILTC-00029,Options,Clear name of column set");
		com.sleepThread(4000);
		com.sendKeys("xpath", EditNameinput, Name, "ITLC-35,Options,Verify entering Name input");
		com.sleepThread(3000);
		com.click("xpath", Optionscolumnsincopy, "ITLC-32,Options,click on options in available columns");
		com.sleepThread(3000);
		com.click("xpath", OptiontypeSN, "ITLC-35,Options,click on optiontypeSN in options");
		com.sleepThread(4000);
		com.startAction();
		com.MouseOverToElement("xpath", rightarrowincopy, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
		com.click("xpath", rightarrowincopy, "ITLC-35,Options,click on rightarrow to add columns");
	}

	@Then("^Click on save and verify the copied column set name$")
	public void click_on_save_and_verify_the_column_set_name() throws Throwable {
		String Editsavecolumnset = Common.readPropertyByoptions().getProperty("Editsavecolumnset1");
		String Copiedcustomcolumnset = Common.readPropertyByoptions().getProperty("Copiedcustomcolumnset1");
		String closecolumnset = Common.readPropertyByoptions().getProperty("closecolumnset");
		com.sleepThread(5000);
		com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
		com.sleepThread(4000);
		com.waitUntilElementPresent(Copiedcustomcolumnset);
		String text = "LON";
		com.verifyText("xpath", Copiedcustomcolumnset, text, "ITLC-00029,Options, Verify Copied column set name");
	}

	// Delete column set
	@Given("^Click on delete and then click on Confirmatio ok button$")
	public void click_on_delete_and_then_click_on_Confirmatio_ok_button() throws Throwable {
		com.startAction();
		String Deletecolumnset = Common.readPropertyByoptions().getProperty("Deletecolumnset1");
		String Columnsetdeleteconfirmation = Common.readPropertyByoptions().getProperty("Columnsetdeleteconfirmation1");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Deletecolumnset, "ILTC-00029,Options,Click on Delete Column set");
		com.sleepThread(4000);
		com.click("xpath", Columnsetdeleteconfirmation, "ILTC-00029,Options,Click on Delete Confirmation");
	}

	@Then("^Verify whether the column set is deleted or not$")
	public void verify_whether_the_column_set_is_deleted_or_not() throws Throwable {
		String Deltedcolumnset = Common.readPropertyByoptions().getProperty("Deltedcolumnset1");
		String closecolumnset = Common.readPropertyByoptions().getProperty("closecolumnset1");
		com.sleepThread(4000);
		com.waitUntilElementPresent(Deltedcolumnset);
		String text = "LON";
		com.verifyText("xpath", Deltedcolumnset, text, "ITLC-00029,Options, Verify Deleted column set name");
		com.sleepThread(4000);
		com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on Close");
	}

	@And("^Click on All column set list$")
	public void Click_on_All_colum_set_list() throws Throwable
	{
		Opt=new Options();		
		Opt.click_on_columnset_dropdown_and_then_click_on_manage_column_set();
		com.sleepThread(4000);
		String closecolumnset = Common.readPropertyByoptions().getProperty("closecolumnset1");
		int size=driver.findElements(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div")).size();
		System.out.println("Click on All column set list:"+size);		
		for (int i =1; i < size; i++) {
			com.click("xpath","/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div",",Options,Click on All column set list");
			Opt.click_on_delete_and_then_click_on_Confirmatio_ok_button();		
		}
		com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on Close");
	}
	
	// verify definition
	@Given("^Click on Bid and select Best Fit Bid$")
	public void Click_on_Bid_and_select_BestFitBid() throws Exception {
		String Bid = Common.readPropertyByoptions().getProperty("Bid");
		String Biddropdown = Common.readPropertyByoptions().getProperty("Biddropdown");
		String BestFitBid = Common.readPropertyByoptions().getProperty("BestFitBid");
		com.sleepThread(6000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		// com.waitUntilElementPresent(BestFitBid);
		com.startAction();
		com.MouseOverToElement("xpath", BestFitBid, "ILTC-00028,Options,Mouse hover on Best Fit Bid");
		com.click("xpath", BestFitBid, "ILTC-00028,Options,Click on Best Fit Bid");
	}

	@Then("^Click on Bid and select Best Fit All columns$")
	public void Click_0n_Bid_and_select_BestFitAllColumns() throws Exception {
		String Bid = Common.readPropertyByoptions().getProperty("Bid");
		String Biddropdown = Common.readPropertyByoptions().getProperty("Biddropdown");
		String BestFitAllColums = Common.readPropertyByoptions().getProperty("BestFitAllColums");
		com.sleepThread(5000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.sleepThread(2000);
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		com.waitUntilElementPresent(BestFitAllColums);
		com.startAction();
		com.MouseOverToElement("xpath", BestFitAllColums, "ILTC-00028,Options,Mouse hover on Best Fit All Columns");
		com.click("xpath", BestFitAllColums, "ILTC-00028,Options,Click on Best Fit All Columns");
	}

	@Then("^Click on Bid and select View Definiton$")
	public void Click_0n_Bid_and_select_ViewDeifinition() throws Exception {
		String Bid = Common.readPropertyByoptions().getProperty("Bid");
		String Biddropdown = Common.readPropertyByoptions().getProperty("Biddropdown");
		String ViewDefinition = Common.readPropertyByoptions().getProperty("ViewDefinition");
		com.sleepThread(5000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		com.waitUntilElementPresent(ViewDefinition);
		com.startAction();
		com.MouseOverToElement("xpath", ViewDefinition, "ILTC-00028,Options,Mouse hover on View Definition");
		com.click("xpath", ViewDefinition, "ILTC-00028,Options,Click on View Definition");

	}

	@Then("^Verify Bid definition$")
	public void verify_bid_definition() throws Exception {
		String BidDefiniton = Common.readPropertyByoptions().getProperty("BidDefiniton");
		com.sleepThread(4000);
		// com.waitUntilElementPresent(BidDefiniton);
		String text = "Bid price (highest available buying price)";
		com.verifyText_Using_String("xpath",BidDefiniton,text, "ITLC-00029,Options, Verify Bid Definition");
	}

	// Symbol Verification
	@Given("^Clear the existing symbol and enter the symbol \"([^\"]*)\" for which you want to get result$")
	public void clear_the_existing_symbol_and_enter_the_symbol_for_which_you_want_to_get_result(String symbol)
			throws Throwable {
		String SymbolInput = Common.readPropertyByoptions().getProperty("SymbolInput");
		com.sleepThread(7000);
		com.waitUntilElementPresent(SymbolInput);
		com.ClearTextField("xpath", SymbolInput, "ITLC-34,Options,Verify Symbol input can be cleared or not");
		com.sleepThread(3000);
		com.sendKeys("xpath", SymbolInput, symbol, "ITLC-35,Options,Verify entering symbol input");
	}

	@Then("^Select the symbol from dropdown and the output should be displayed$")
	public void select_the_symbol_from_dropdown_and_the_output_should_be_displayed() throws Throwable {
		com.startAction();
		String Symboldropdown = Common.readPropertyByoptions().getProperty("Symboldropdown");
		com.sleepThread(6000);
		com.MouseOverToclickabl("xpath", Symboldropdown,
				"ITLC-36,Options,Verify data is displayed or not by clciking on dropdown");
	}

	@Then("^verify whether the input symbol data is being displayed or not$")
	public void verify_whether_the_input_symbol_data_is_being_displayed_or_not() throws Throwable {
		String Icesymbol = Common.readPropertyByoptions().getProperty("Icesymbol");
		com.sleepThread(6000);
		String symboltext = "ICE";
		com.verifyText("xpath", Icesymbol, symboltext, "ITLC-00029,Options, User should get ICE symbol data");
	}

	@When("^verify the call symbol name and year and month and strike value and date$")
	public void verify_the_symbol_name_and_year_and_month_and_strike_value_and_date() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		Opt = new Options();
		String Verfy_ICE_Drop_Down = Common.readPropertyByoptions().getProperty("Verfy_ICE_Drop_Down");
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.click("xpath", Verfy_ICE_Drop_Down, "IOTC-00004," + Widget_name + ",Click on Enter_symbol Drop Down");
		com.sleepThread(2000);
		// Get symbol name
		int size = driver.findElements(By.xpath("/html/body/div[3]/div/span/div/div/div[2]/div/div/span")).size();
		System.out.println("Symbol suggestion items " + size);
		for (int i = 2; i < size; i++) {
			System.out.println(i);
			com.sleepThread(2000);
			com.startAction();
			// com.MouseOverToElement("xpath","/html/body/div[6]/div/span/div/div/div[2]/div/div["+i+"]/span/span","");
			String text = driver
					.findElement(By.xpath("/html/body/div[3]/div/span/div/div/div[2]/div/div[" + i + "]/span"))
					.getText();
			System.out.println("text: " + text);
			com.MouseOverToclickabl("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div[" + i + "]/span",
					"IOTC-00005," + Widget_name + ",Click on_symbol the " + text + " list");
			String Symbol_Input_text = driver.findElement(By.xpath("//*[@class='pt-input']")).getAttribute("value");
			driver.navigate().refresh();
			com.sleepThread(10000);
			//Symbol name xpath
			try{
				driver.findElement(By.xpath("//*[@class='d-optionsDQCellValue']")).isDisplayed(); 
				
			String All_Expirations_drop_down = Common.readPropertyByoptions().getProperty("All_Expirations_drop_down");
			com.click("xpath", All_Expirations_drop_down, "," + Widget_name + ",Click on all expirations");
			com.sleepThread(6000);			
			com.startAction();
			String Specific_Dates_drop_down = Common.readPropertyByoptions().getProperty("Specific_Dates_drop_down");
			
			com.MouseOverToElement("xpath", Specific_Dates_drop_down,
					"," + Widget_name + ",Mouseover on specific dates option");
			Thread.sleep(4000);
			int sd_size = driver
					.findElements(
							By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[6]/div/ul/li/button/label"))
					.size();
			System.out.println("SD_Size: " + sd_size);
			for (int j = 2; j < sd_size; j++) {				
				int number=3;				
				if(number==j) {					
					String Specific_Date = driver.findElement(By.xpath(
							"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[6]/div/ul/li[" + j + "]/button/label"))
							.getText();
					System.out.println("Specific_Date:"+Specific_Date);
					com.click("xpath",
							"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[6]/div/ul/li[" + j + "]/button/label",
							"," + Widget_name + ",Click on specific date");
					Thread.sleep(2000);	
				
				// com.click("xpath","//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[1]/div/div/div/div[1]/div[1]/div[1]/div",","+Widget_name+",click
				// on call manu");
				// driver.findElement(By.xpath("//*[@id=\"5\"]/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[1]/div/div/div/div[1]/div[1]/div[1]/div")).click();
				
					
				String month_and_Year_text = Specific_Date.replace(" (W)","");
				System.out.println("month_and_Year_text:"+month_and_Year_text);
					
					
				String Year = com.getLastCharacters(month_and_Year_text, 2);
				System.out.println("Year:" + Year);
				String Zero_with_Date = month_and_Year_text.substring(0, 2);
				System.out.println("Date:" + Zero_with_Date);

				StringBuffer Date_trim = new StringBuffer(Zero_with_Date);
				System.out.println(Date_trim);

				String one_value = Date_trim.substring(0, 1);
				System.out.println("Date:" + one_value);
				if (one_value.equals("0")) {
					System.out.println("value of Zero :" + one_value);
					int start = 0;
					int end = 1;
					StringBuffer Date = Date_trim.replace(start, end, "");
					System.out.println(Date);
					Thread.sleep(1000);
					String month_and_Year = month_and_Year_text.replace(Zero_with_Date + "-", "");
					System.out.println(month_and_Year);					
					String month = month_and_Year.replace("-" + Year, "");
					System.out.println(month);
					String month_name = com.call_months(month);
					Thread.sleep(6000);
					
					System.out.println("********Test*****");
					int Symbol_size = driver.findElements(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[1]/div[1]/div[1]"))
							.size();
					System.out.println("Symbol_size:" + Symbol_size);
					for (int k = 2; k <= Symbol_size; k++) {
						String Strilke = driver.findElement(By.xpath(
								"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]"))
								.getText();
						System.out.println(Strilke);
						System.out.println("********Date: " + Date);
						System.out.println("O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D"
								+ Date + "");
						com.verifyText_Using_String("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ "","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date
										+ "");
						com.sleepThread(2000);
						//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]")).sendKeys(Keys.DOWN);

					}

				} else //if (one_value.equals("1")) 
				{
					System.out.println("value of one :" + one_value);
					int start = 0;
					int end = 0;
					StringBuffer Date = Date_trim.replace(start, end, "");
					System.out.println("Date:"+Date);
					Thread.sleep(1000);

					String month_and_Year = month_and_Year_text.replace(Zero_with_Date + "-", "");
					System.out.println("month_and_Year:"+month_and_Year);					
					String month = month_and_Year.replace("-" + Year, "");
					System.out.println("month:"+month);
					String month_name = com.call_months(month);

					int Symbol_size = driver.findElements(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[1]/div[1]/div[1]"))
							.size();
					System.out.println("Symbol_size:" + Symbol_size);
					for (int k = 2; k <= Symbol_size; k++) {
						String Strilke = driver.findElement(By.xpath(
								"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]"))
								.getText();
						System.out.println("Strilke:"+Strilke);
						System.out.println("O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D");
						String verifyText = driver.findElement(By.xpath(
								"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]"))
								.getText();
						com.verifyText_Using_String("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ "","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ ","+verifyText);
						com.sleepThread(2000);
						//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]")).sendKeys(Keys.DOWN);
					}

				}

				/*
				 * String month_and_Year=Specific_Date.replace(Zero_with_Date+"-","");
				 * System.out.println(month_and_Year);
				 * 
				 * String month=month_and_Year.replace("-"+Year,""); System.out.println(month);
				 * String month_name=com.call_months(month);
				 * 
				 * int Symbol_size=driver.findElements(By.xpath(
				 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div/div[1]/div[1]/div"
				 * )).size(); System.out.println("Symbol_size:"+Symbol_size); for (int k = 1; k
				 * <=Symbol_size; k++) { String Strilke=driver.findElement(By.xpath(
				 * "//*[@id=\"5\"]/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div["
				 * +k+"]/div[1]/div[7]/div")).getText(); System.out.println(Strilke);
				 * System.out.println("O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
				 * "D"); com.verifyText_Using_String("xpath",
				 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div["
				 * +k+"]/div[1]/div[1]/div","O:"+Symbol_Input_text+" "+Year+""+month_name+""+
				 * Strilke+"D"+Date+"","O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
				 * "D"+Date+""); com.sleepThread(2000); }
				 */
				/*
				 * String Symbol_data=driver.findElement(By.xpath(
				 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div[1]/div[1]/div[1]/div"
				 * )).getText(); System.out.println(Symbol_data);
				 * System.out.println("O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
				 * "D"+Date+"");
				 * 
				 * 
				 * if(Symbol_data.equals("O:"+Symbol_Input_text+" "+Year+""+month_name+""+
				 * Strilke+"D"+Date+"")) { System.out.println("symbol data is mach"); } else {
				 * System.out.println("symbol data is not mach"); }
				 */
				com.sleepThread(9000);
				String All_Expirations_drop_down_date_close_icon = Common.readPropertyByoptions()
						.getProperty("All_Expirations_drop_down_date_close_icon");
				com.click("xpath", All_Expirations_drop_down_date_close_icon,
						"," + Widget_name + ",All expirations drop down date close icon");
				com.sleepThread(5000);
				com.click("xpath", All_Expirations_drop_down, ",Options,Click on all expirations");
				com.sleepThread(2000);
				com.startAction();
				com.MouseOverToElement("xpath", Specific_Dates_drop_down,
						"," + Widget_name + ",Mouseover on specific dates option");
				Thread.sleep(2000);
				// com.click("xpath","//*[contains(@class,'pt-overlay pt-overlay-open
				// pt-overlay-inline')]/span/div/div/div[2]/ul/li["+j+"]",","+Widget_name+",Deselect
				// the previous selected specific date");
		
				
			}
			else {
				
				String Specific_Date = driver.findElement(By.xpath(
						"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[6]/div/ul/li[" + j + "]/button/label"))
						.getText();
				System.out.println(Specific_Date);
				com.click("xpath",
						"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[6]/div/ul/li[" + j + "]/button/label",
						"," + Widget_name + ",Click on specific date");
				Thread.sleep(2000);	
				String month_and_Year_text = Specific_Date.replace(" (W)","");
				System.out.println("month_and_Year_text:"+month_and_Year_text);

			// com.click("xpath","//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[1]/div/div/div/div[1]/div[1]/div[1]/div",","+Widget_name+",click
			// on call manu");
			// driver.findElement(By.xpath("//*[@id=\"5\"]/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[1]/div/div/div/div[1]/div[1]/div[1]/div")).click();
			String Year = com.getLastCharacters(month_and_Year_text, 2);
			System.out.println("Year" + Year);
			String Zero_with_Date = month_and_Year_text.substring(0, 2);
			System.out.println("Date" + Zero_with_Date);

			StringBuffer Date_trim = new StringBuffer(Zero_with_Date);
			System.out.println(Date_trim);

			String one_value = Date_trim.substring(0, 1);
			System.out.println("Date:" + one_value);
			if (one_value.equals("0")) {
				System.out.println("value of Zero :" + one_value);
				int start = 0;
				int end = 1;
				StringBuffer Date = Date_trim.replace(start, end, "");
				System.out.println(Date);
				Thread.sleep(1000);

				String month_and_Year = month_and_Year_text.replace(Zero_with_Date + "-", "");
				System.out.println(month_and_Year);

				String month = month_and_Year.replace("-" + Year, "");
				System.out.println(month);
				String month_name = com.call_months(month);
				Thread.sleep(6000);
				
				System.out.println("********Test*****");
				int Symbol_size = driver.findElements(By.xpath(
						"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[1]/div[1]/div[1]"))
						.size();
				System.out.println("Symbol_size:" + Symbol_size);
				for (int k = 2; k <= Symbol_size; k++) {
					String Strilke = driver.findElement(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]"))
							.getText();
					System.out.println(Strilke);
					System.out.println("********Date: " + Date);
					System.out.println("O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D"
							+ Date + "");
					String verifyText = driver.findElement(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]"))
							.getText();
					com.verifyText_Using_String("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ "","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date
									+ ","+verifyText);
					com.sleepThread(2000);
					//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]")).sendKeys(Keys.DOWN);

				}

			} else //if (one_value.equals("1")) 
			{
				System.out.println("value of one :" + one_value);
				int start = 0;
				int end = 0;
				StringBuffer Date = Date_trim.replace(start, end, "");
				System.out.println(Date);
				Thread.sleep(1000);

				String month_and_Year = month_and_Year_text.replace(Zero_with_Date + "-", "");
				System.out.println(month_and_Year);

				String month = month_and_Year.replace("-" + Year, "");
				System.out.println(month);
				String month_name = com.call_months(month);

				int Symbol_size = driver.findElements(By.xpath(
						"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div[1]/div[1]/div[1]"))
						.size();
				System.out.println("Symbol_size:" + Symbol_size);
				for (int k = 2; k <= Symbol_size; k++) {
					String Strilke = driver.findElement(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]"))
							.getText();
					System.out.println("Strilke:"+Strilke);
					System.out.println("O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D");
					String verifyText = driver.findElement(By.xpath(
							"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]"))
							.getText();
					com.verifyText_Using_String("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[1]/div[1]","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ "","O:" + Symbol_Input_text + " " + Year + "" + month_name + "" + Strilke + "D" + Date+ ","+verifyText);
					com.sleepThread(2000);
					//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div[1]/div[7]/div[1]")).sendKeys(Keys.DOWN);
				}

			}

			/*
			 * String month_and_Year=Specific_Date.replace(Zero_with_Date+"-","");
			 * System.out.println(month_and_Year);
			 * 
			 * String month=month_and_Year.replace("-"+Year,""); System.out.println(month);
			 * String month_name=com.call_months(month);
			 * 
			 * int Symbol_size=driver.findElements(By.xpath(
			 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div/div[1]/div[1]/div"
			 * )).size(); System.out.println("Symbol_size:"+Symbol_size); for (int k = 1; k
			 * <=Symbol_size; k++) { String Strilke=driver.findElement(By.xpath(
			 * "//*[@id=\"5\"]/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div["
			 * +k+"]/div[1]/div[7]/div")).getText(); System.out.println(Strilke);
			 * System.out.println("O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
			 * "D"); com.verifyText_Using_String("xpath",
			 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div["
			 * +k+"]/div[1]/div[1]/div","O:"+Symbol_Input_text+" "+Year+""+month_name+""+
			 * Strilke+"D"+Date+"","O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
			 * "D"+Date+""); com.sleepThread(2000); }
			 */
			/*
			 * String Symbol_data=driver.findElement(By.xpath(
			 * "//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/div[2]/div[1]/div/div/div/div[1]/div[1]/div[1]/div"
			 * )).getText(); System.out.println(Symbol_data);
			 * System.out.println("O:"+Symbol_Input_text+" "+Year+""+month_name+""+Strilke+
			 * "D"+Date+"");
			 * 
			 * 
			 * if(Symbol_data.equals("O:"+Symbol_Input_text+" "+Year+""+month_name+""+
			 * Strilke+"D"+Date+"")) { System.out.println("symbol data is mach"); } else {
			 * System.out.println("symbol data is not mach"); }
			 */
			com.sleepThread(9000);
			String All_Expirations_drop_down_date_close_icon = Common.readPropertyByoptions()
					.getProperty("All_Expirations_drop_down_date_close_icon");
			com.click("xpath", All_Expirations_drop_down_date_close_icon,
					"," + Widget_name + ",All expirations drop down date close icon");
			com.sleepThread(5000);
			com.click("xpath", All_Expirations_drop_down, ",Options,Click on all expirations");
			com.sleepThread(2000);
			com.startAction();
			com.MouseOverToElement("xpath", Specific_Dates_drop_down,
					"," + Widget_name + ",Mouseover on specific dates option");
			Thread.sleep(2000);
			// com.click("xpath","//*[contains(@class,'pt-overlay pt-overlay-open
			// pt-overlay-inline')]/span/div/div/div[2]/ul/li["+j+"]",","+Widget_name+",Deselect
			// the previous selected specific date");
					
			}
				}	
			}
			
			catch(Exception t){
					System.out.println("Data is Not displayed");
				}
			String Symbol_ICE_Drop_Down = Common.readPropertyByoptions().getProperty("Symbol_ICE_Drop_Down");
			com.sleepThread(3000);
			com.click("xpath", Symbol_ICE_Drop_Down, "," + Widget_name + ",Click on Enter_symbol Drop Down");
		}
	}
	@And("^Enter the Symbol \"([^\"]*)\"$")
	public void Enter_the_Symbol(String symbol_name)throws Exception {
	String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
	com.click("xpath",ICE_Drop_Down,"," + Widget_name + ",Click on Enter");
	com.sleepThread(2000);
	//com.sendKeys_fOR_Keybord("xpath",ICE_Drop_Down,Keys.CONTROL.valueOf("a"), "," + Widget_name + ",Click on Enter");
	//com.sleepThread(2000);
	com.sendKeys_fOR_Keybord("xpath",ICE_Drop_Down,Keys.DELETE, "," + Widget_name + ",Click on Enter");
	com.sleepThread(2000);
	com.ClearTextField("xpath", ICE_Drop_Down, "," + Widget_name + ",Clear the text in symbol text box");
	com.sleepThread(3000);
	com.sendKeys("xpath",ICE_Drop_Down,symbol_name, "," + Widget_name + ",Enter the Symbol");
	com.sleepThread(2000);
	com.sendKeys_fOR_Keybord("xpath",ICE_Drop_Down,Keys.ENTER, "," + Widget_name + ",Click on Enter");
	com.sleepThread(6000);
	driver.navigate().refresh();
	com.sleepThread(9000);
	}
	
	
	
	
	



}


