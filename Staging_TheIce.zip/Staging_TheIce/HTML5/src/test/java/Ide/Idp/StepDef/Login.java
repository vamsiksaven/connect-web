package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
//import org.testng.annotations.AfterMethod;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en_scouse.An;
import gherkin.lexer.Th;

public class Login {

	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public Login l;
	public GraphicsConfiguration gc;

	public Login() {
		driver = Common.driver;
		login = Common.readPropertyByLogin().getProperty("Login_button");
	}

	// Verify_the_ligin_page_Logo
	@Given("^I have open the browser$")
	public void open_browser() throws Exception {
		String Browser = Common.readPropertyByLogin().getProperty("Browser");
		// com.startRecording();
		com.Setup(Browser,"ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// 
		//https://connect-web.qa.dataservices.theice.com
		//https://connect-web.staging.dataservices.theice.com
		com.maximiseBrowser();

	}

	@When("^Verify the logo$")
	public void Verify_the_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByLogin().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Login,Verify the logo");

	}

	// @Verify_the_login_page
	@And("^Verify Username field$")
	public void Verify_username_field() throws Exception {
		String un = Common.readPropertyByLogin().getProperty("User_name");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", un, "ILTC-00003,Login,Verify Username field");

	}

	@And("^Verify password field$")
	public void Verify_password_field() throws Exception {
		String Pwd = Common.readPropertyByLogin().getProperty("Passwod");
		com.verifyElementPresent("xpath", Pwd, "ILTC-00004,Login,Verify password field");

	}

	@And("^Verify Remember me link$")
	public void Verify_Remember_me() throws Exception {
		com.sleepThread(3000);
		String Remember_me = Common.readPropertyByLogin().getProperty("Remember_me");
		com.verifyElementPresent("xpath", Remember_me, "ILTC-00005,Login,Verify Remember me link");

	}

	@And("^Verify Forgot Password link$")
	public void Verify_Forgot_Password() throws Exception {
		String Forgot_Password_link = Common.readPropertyByLogin().getProperty("Forgot_Password_link");
		com.verifyElementPresent("xpath", Forgot_Password_link, "ILTC-00006,Login,Verify Forgot Password link");

	}

	@And("^Verify Change link$")
	public void Verify_Change() throws Exception {
		String Change_Password = Common.readPropertyByLogin().getProperty("Change_Password");
		com.verifyElementPresent("xpath", Change_Password, "ILTC-00007,Login,Verify Change link");
	}

	@And("^Verify Terms & Conditions of Use link$")
	public void Verify_Terms() throws Exception {
		String Terms = Common.readPropertyByLogin().getProperty("Terms");
		com.verifyElementPresent("xpath", Terms, "ILTC-00008,Login,Verify Terms & Conditions of Use link");
	}

	@And("^Verify Privacy Policy$")
	public void Verify_Privacy_Policy() throws Exception {
		String Privacy_Policy = Common.readPropertyByLogin().getProperty("Privacy_Policy");
		com.verifyElementPresent("xpath", Privacy_Policy, "ILTC-00009,Login,Verify Privacy Policy");
	}

	@And("^Verify login button$")
	public void Verify_login_button() throws Exception {
		String Login_button = Common.readPropertyByLogin().getProperty("Login_button");
		com.verifyElementPresent("xpath", Login_button, "ILTC-00010,Login,Verify login button");
	}

	@When("^verify password link$")
	public void verify_password_link() throws Exception {
		String pwd_link = Common.readPropertyByLogin().getProperty("Password_Link");
		com.verifyElementPresent("xpath", pwd_link, "ILTC-00011,Login,verify password link");
	}

	@And("^click on password link$")
	public void click_on_password_link() throws Exception {
		String Forgot_Password_link = Common.readPropertyByLogin().getProperty("Forgot_Password_link");
		com.click("xpath", Forgot_Password_link, "ILTC-00012,Login,Click on password link");
	}

	@And("^verify next page is navegating or not$")
	public void verify_next_page() throws Exception {
		com.sleepThread(6000);
		String forgot_password_title = Common.readPropertyByLogin().getProperty("forgot_password_title");
		com.verifyElementPresent("xpath", forgot_password_title, "ILTC-00013,Login,verify next page is navegating or not");

	}

	@When("^verify text box$")
	public void verify_text_box() throws Exception {
		String text_box = Common.readPropertyByLogin().getProperty("f_p_Email_pwd_text_box");
		com.verifyElementPresent("xpath", text_box, "ILTC-00014,Login,verify text box");
	}

	@And("^verify submit$")
	public void verify_submit() throws Exception {
		String submit = Common.readPropertyByLogin().getProperty("f_p_send_mail");
		com.verifyElementPresent("xpath", submit, "ILTC-00015,Login,verify submit");
	}

	@And("^verify captcha$")
	public void verify_captcha() throws Exception {	
		com.sleepThread(5000);
		String captcha = Common.readPropertyByLogin().getProperty("f_p_Captcha");
		com.verifyElementPresent("xpath", captcha, "ILTC-00016,Login,verify captcha");
	}

	@When("^verify validation message$")
	public void verify_validation_message() throws Exception {
		com.sleepThread(3000);
		String v_messag = Common.readPropertyByLogin().getProperty("f_p_Email_Add_req_msg");
		com.verifyElementPresent("xpath", v_messag, "ILTC-00017,Login,verify validation message");
	}

	@And("^Click on submit$")
	public void Click_on_submit() throws Exception {
		String submit = Common.readPropertyByLogin().getProperty("f_p_send_mail");
		com.click("xpath", submit, "ILTC-00018,Login,Click on submit");
	}

	@When("^Click on back link$")
	public void cluick_on_back() throws Exception {
		com.sleepThread(5000);
		String back = Common.readPropertyByLogin().getProperty("forgot_pwd_back");
		com.click("xpath", back, "ILTC-00019,Login,Click on back link");
	}
	
	@When("^Click on change password link$")
	public void Click_on_change_password_link() throws Exception
	{
		String Change_Password = Common.readPropertyByLogin().getProperty("Change_Password");
		com.click("xpath", Change_Password, ",Login,Click on change password link");

	}
	@Then("^Verify the change password title$")
	public void Verify_the_change_password_title() throws Exception
	{
		String  change_password_title= Common.readPropertyByLogin().getProperty("change_password_title");
		com.verifyElementPresent("xpath",change_password_title, ",Login,Verify the change password title");

	}
	@And("^Verify the user id text box$")
	public void Verify_the_user_id_text_box() throws Exception
	{
		String  user_id_text_box_in_Change_Password= Common.readPropertyByLogin().getProperty("user_id_text_box_in_Change_Password");
		com.verifyElementPresent("xpath",user_id_text_box_in_Change_Password , ",Login,Verify the user id text box");

	}
	@And("^Verify the old password text box$")
	public void Verify_the_old_password_text_box() throws Exception {
		String  old_password_text_box= Common.readPropertyByLogin().getProperty("old_password_text_box");
		com.verifyElementPresent("xpath",old_password_text_box , ",Login,Verify the old password text box");

	}
	
	@And("^Verify the new password text box$")
	public void Verify_the_new_password_text_box() throws Exception {
		String  new_password_text_box= Common.readPropertyByLogin().getProperty("new_password_text_box");
		com.verifyElementPresent("xpath",new_password_text_box ,",Login,Verify the new password text box");

	}
	@And("^Verify the new password confirm text box$")
	public void Verify_the_new_password_confirm_text_box() throws Exception
	{
		String  new_password_confirm_text_box= Common.readPropertyByLogin().getProperty("new_password_confirm_text_box");
		com.verifyElementPresent("xpath",new_password_confirm_text_box, ",Login,Verify the new password confirm text box");

	}
	@And("^Verify the show password link$")
	public void Verify_the_show_password_link() throws Exception
	{
		String  show_password_link= Common.readPropertyByLogin().getProperty("show_password_link");
		com.verifyElementPresent("xpath",show_password_link, ",Login,Verify the show password link");

	}
	@And("^Verify the change password button$")
	public void Verify_the_change_password_button() throws Exception
	{
		String  change_password_button= Common.readPropertyByLogin().getProperty("change_password_button");
		com.verifyElementPresent("xpath",change_password_button ,",Login,Verify the change password button");

	}
	@And("^Verify the back button$")
	public void Verify_the_back_button() throws Exception
	{
		String  back_button_in_Change_Password= Common.readPropertyByLogin().getProperty("back_button_in_Change_Password");
		com.verifyElementPresent("xpath",back_button_in_Change_Password,",Login,Verify the back button");

	}
	@And("^Click on change password button$")
	public void Click_on_change_password_button() throws Exception
	{	com.startAction();
		String  change_password_button= Common.readPropertyByLogin().getProperty("change_password_button");
		com.MouseOverToclickabl("xpath",change_password_button,",Login,Click on change password button");

	}
	@And("^Verify the alert in change password page$")
	public void Verify_the_alert_in_change_password_page()
	{	
		com.sleepThread(2000);
		com.handling_alerts_accecpt();
	}
	@And("^Click on back button$")
	public void Click_on_back_button() throws Exception {
		String  back_button_in_Change_Password= Common.readPropertyByLogin().getProperty("back_button_in_Change_Password");
		com.click("xpath",back_button_in_Change_Password,",Login,Click on back button");

	}
	
	@And("^click on Remember me link$")
	public void click_on_Remember_me_link() throws Exception {
		String Rem_link = Common.readPropertyByLogin().getProperty("Remember_me");
		com.click("xpath", Rem_link, "ILTC-00020,Login,click on Remember me link");
	}

	@When("^username and password are saving or not$")
	public void username_and_password_are_saving_or_not() throws Exception {
		com.verify_text_box_text("xpath", un, "vamsi.kamatam@theice.com",
				"ILTC-00021,Login,username are saving or not");
		com.verify_text_box_text("xpath", Pws, "Starts123", "ILTC-00022,Login,password are saving or not");
	}

	// correct_username_and_correct_password
	@SuppressWarnings("deprecation")
	@Given("^Login with IDE IDP credentials Username \"(.*?)\" and Password \"(.*?)\"$")
	public void Login_with_IDE_IDP_credentials_Username_and_Password(String Username, String Password)
			throws Exception {
		un = Common.readPropertyByLogin().getProperty("User_name");
		Pws = Common.readPropertyByLogin().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(4000);
		com.click("xpath",un,",Login,Click on user name");
		com.sleepThread(4000);
		com.sendKeys("xpath",un, Username,
				"ILTC-00023,Login,Enter the correct username and are given in associated text fields");
		com.sleepThread(1000);
		com.click("xpath", un,",Login,Click on user name");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Login,Enter the correct password are given in associated text fields");
	}

	@Then("^Click on login button$")
	public void login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Login,Click on login button");
		TimeUnit.MINUTES.sleep(1);
		// com.stopRecording();
		String launch_menu=Common.readPropertyByLogin().getProperty("launch_menu");
		com.verifyElementPresent("xpath",launch_menu, ",Login,Verify the launch_menu bar");
		//TimeUnit.MINUTES.sleep(1);
		//driver.navigate().refresh();
	}
	@And("^Click on username menu in right side$")
	public void Click_on_username_menu_in_right_side() throws Exception {
		String Login_user_name=Common.readPropertyByLogin().getProperty("Login_user_name");
		com.sleepThread(5000);
		com.startAction();
		com.MouseOverToclickabl("xpath",Login_user_name,"ILTC-00026,Login,Click on username menu in right side");
	}
	@And("^Click on logout option$")
	public void Click_on_logout_option() throws Exception
	{
		String Logout=Common.readPropertyByLogin().getProperty("Logout");
		com.click("xpath",Logout,"ILTC-00027,Login,Click on logout option");
		TimeUnit.MINUTES.sleep(1);
	}


	@And("^Close the Browser$")
	public void Close_the_Browser() throws Exception {
		com.closeBrowser("ILTC-00028,Login,Close the Browser");
	}

	@And("^Quit the Object$")
	public void Quit_the_Object(ITestResult result) throws Exception {
		com.QuitObject("ILTC-00029,Login,Quit the Object");
	}

	
	
	//****************************************************************
	@When("^Check whether Opne new page window is opened or not$")
	public void Check_whether_Opne_new_page_window_is_opened_or_not() throws Exception {		
		String File=Common.readPropertyByLogin().getProperty("File");
		String Open_new_page=Common.readPropertyByLogin().getProperty("Open_new_page");
		com.click("xpath",File,"ILTC-000,Login,Click on file button");
		com.startAction();
		com.MouseOverToclickabl("xpath",Open_new_page,"ILTC-000,Login,Click on open new page option");
		com.sleepThread(2000);
		String Page_2=Common.readPropertyByLogin().getProperty("Page_2");
		com.verifyElementPresent("xpath",Page_2,"ILTC-000,Login,Verify the page 2 is created or not");		
		com.Rightclick("xpath",Page_2,"ILTC-000,Login,Right click on page_2 button");
		com.sleepThread(2000);
		String Delete_Page=Common.readPropertyByLogin().getProperty("Delete_Page");
		com.MouseOverToclickabl("xpath",Delete_Page,"ILTC-000,Login,Click on delete page option");
		l=new Login();
		l.Veriy_the_delete_page_button();
	}
	
	@When("^Verfiy Add a Page is adding or not$")
	public void Verfiy_Add_a_Page_is_adding_or_not() throws Exception
	{
		com.startAction();
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		String Add_Page=Common.readPropertyByLogin().getProperty("Add_Page");
		com.sleepThread(2000);
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.MouseOverToclickabl("xpath",Add_Page,"ILTC-000,Login,Click on Add Page option");
		com.sleepThread(2000);
		String Page_2=Common.readPropertyByLogin().getProperty("Page_2");
		com.verifyElementPresent("xpath",Page_2,"Verify the page 2 is created or not");		
		com.Rightclick("xpath",Page_2,"ILTC-000,Login,Right click on page_2 button");
		com.sleepThread(2000);
		String Delete_Page=Common.readPropertyByLogin().getProperty("Delete_Page");
		com.MouseOverToclickabl("xpath",Delete_Page,"ILTC-000,Login,Click on delete page option");
		l=new Login();
		l.Veriy_the_delete_page_button();
	}

	@Then("^Verfiy Rename a Page is working or not$")
	public void Verfiy_Rename_a_Page_is_working_or_not() throws Exception {		
		com.startAction();
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Rename_Page=Common.readPropertyByLogin().getProperty("Rename_Page");
		com.MouseOverToclickabl("xpath",Rename_Page,"ILTC-000,Login,Click on Rename Page file button");
		com.sleepThread(4000);
		//com.ClearTextField("xpath",Page_1,"ILTC-000,Login,Clear the text in page 1 button");
		String page_text=driver.findElement(By.xpath(Page_1)).getText();
		System.out.println(page_text);
		System.out.println("page text"+page_text.length());
		for (int i =1; i <=page_text.length(); i++) {
			//com.sendKeys_fOR_Keybord("xpath",Page_1, Keys.BACK_SPACE,"ILTC-000,Login,Clear the text in page 1 button");			
			com.sleepThread(2000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_BACK_SPACE);
			robot.keyRelease(KeyEvent.VK_BACK_SPACE);			
			System.out.println(i);
		}
		
		com.sleepThread(1000);
		com.sendKeys("xpath",Page_1,"Chart","ILTC-000,Login,Enter the text in page 1 field");		
		com.verifyText_Using_String("xpath",Page_1,"Chart","ILTC-000,Login,verify the page name is changing or not");
	}
	@And("^verify Copy a Page is working or not$")
	public void verify_Copy_a_Page_is_working_or_not() throws Exception
	{
		com.startAction();
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Copy_Page=Common.readPropertyByLogin().getProperty("Copy_Page");
		com.MouseOverToclickabl("xpath",Copy_Page,"ILTC-000,Login,Click on Copy Page file button");
		com.sleepThread(2000);
		String Page_2=Common.readPropertyByLogin().getProperty("Page_2");
		com.verifyElementPresent("xpath",Page_2,"ILTC-000,Login,Verify the Copy Page is created or not");
		l=new Login();
		l.Verfiy_Delete_Page_is_working_or_not();
		l.Veriy_the_delete_page_button();
	}
	@And("^Check Whether Move page to New window is opening in new window or not$")
	public void Check_Whether_Move_page_to_New_window_is_opening_in_new_window_or_not() throws Exception
	{
		com.startAction();
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Move_Page_to_New_Window=Common.readPropertyByLogin().getProperty("Move_Page_to_New_Window");
		String Principal_Region=Common.readPropertyByLogin().getProperty("Principal_Region");
		com.sleepThread(2000);
		com.switch_to_new_window("xpath", Move_Page_to_New_Window, "ILTC-000,Login,Click on Move Page to New Window", "xpath",
				Principal_Region, ",Login,Switch to New Window verify the widget tab");
		String Add_page_icon=Common.readPropertyByLogin().getProperty("Add_page_icon");
		com.MouseOverToclickabl("xpath",Add_page_icon,"ILTC-000,Login,Click on add page icon");	
		com.sleepThread(2000);
	}
	@And("^Verfiy Delete Page is working or not$")
	public void Verfiy_Delete_Page_is_working_or_not() throws Exception
	{ 
		com.startAction();		
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Delete_Page=Common.readPropertyByLogin().getProperty("Delete_Page");
		com.MouseOverToclickabl("xpath",Delete_Page,"ILTC-000,Login,Click on Delete Page file button");
		com.sleepThread(2000);
		String Delete_page_pop_title=Common.readPropertyByLogin().getProperty("Delete_page_pop_title");
		com.verifyElementPresent("xpath", Delete_page_pop_title,"ILTC-000,Login,Delete page pop is opning or not");
	}
	@And("^Veriy the close icon$")
	public void Veriy_the_close_icon() throws Exception
	{
		com.startAction();
		String close_icon=Common.readPropertyByLogin().getProperty("close_icon");
		com.MouseOverToclickabl("xpath",close_icon,"ILTC-000,Login,Click on close icon");
	}
	@And("^Veriy the cancel button$")
	public void Veriy_the_cancel_button() throws Exception {
		com.startAction();
		String cancel_button=Common.readPropertyByLogin().getProperty("cancel_button");
		com.MouseOverToclickabl("xpath",cancel_button,"ILTC-000,Login,Click on cancel button");

	}
	@And("^Veriy the delete page button$")
	public void Veriy_the_delete_page_button() throws Exception
	{
		com.startAction();
		String Delete_page_pop_delete_button=Common.readPropertyByLogin().getProperty("Delete_page_pop_delete_button");
		com.MouseOverToElement("xpath",Delete_page_pop_delete_button,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath",Delete_page_pop_delete_button,"ILTC-000,Login,Right click on page_1 button");

	}
	 
	@And("^Click on Reorder Page a new pop up window will open$")
	public void Click_on_Reorder_Page_a_new_pop_up_window_will_open() throws Exception
	{
		com.startAction();
		String Add_page_icon=Common.readPropertyByLogin().getProperty("Add_page_icon");
		com.MouseOverToclickabl("xpath",Add_page_icon,"ILTC-000,Login,Click on add page icon");	
		com.sleepThread(2000);
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Reorder_Page=Common.readPropertyByLogin().getProperty("Reorder_Page");
		com.MouseOverToclickabl("xpath",Reorder_Page,"ILTC-000,Login,Right click on Reorder Page button");
		com.sleepThread(2000);
		String Reorder_Page_pop_title=Common.readPropertyByLogin().getProperty("Reorder_Page_pop_title");
		com.verifyElementPresent("xpath",Reorder_Page_pop_title,"ILTC-000,Login,Reorder Page pop is opning or not");
	}
	@And("^Change the Order of the page by Selecting page name with Mouse point$")
	public void Change_the_Order_of_the_page_by_Selecting_page_name_with_Mouse_point() throws Exception {
		com.startAction();
		String Selecting_page_1=Common.readPropertyByLogin().getProperty("Selecting_page_1");
		String Selecting_page_2=Common.readPropertyByLogin().getProperty("Selecting_page_2");		
		com.dragAndDrop("xpath",Selecting_page_1, "xpath",Selecting_page_2, "ILTC-000,Login,");
	}
	
	@And("^Click on Update Order button is working or not$")
	public void Click_on_Update_Order_button_is_working_or_not() throws Exception
	{
		com.startAction();
		com.sleepThread(2000);
		String Update_Order=Common.readPropertyByLogin().getProperty("Update_Order");
		com.MouseOverToclickabl("xpath",Update_Order,"Update Order button is enabled or not");
	}
	@And("^Verify Cancel button is working or not$")
	public void Verify_Cancel_button_is_working_or_not() throws Exception
	
	{
		String cancel_button=Common.readPropertyByLogin().getProperty("cancel_button");
		com.click("xpath",cancel_button,"ILTC-000,Login,Click on cancel button");
	}
	@And("^Verify Close icon is working or not$")
	public void Verify_Close_icon_is_working_or_not() throws Exception {
		
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on page_1 button");
		com.sleepThread(2000);
		String Reorder_Page=Common.readPropertyByLogin().getProperty("Reorder_Page");
		com.MouseOverToclickabl("xpath",Reorder_Page,"ILTC-000,Login,Right click on Reorder Page button");
		com.sleepThread(2000);
		String close_icon=Common.readPropertyByLogin().getProperty("close_icon");
		com.click("xpath",close_icon,"ILTC-000,Login,Click on close icon");

	}
	@And("^verfiy Change color by selecting color in arrow button drop down list selected color is applying or not to page name$")
	public void Verfiy_Selecting_color_arrow() throws Exception {
		com.startAction();
		String Page_1=Common.readPropertyByLogin().getProperty("Page_1");
		com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on Page_1r Page button");
		com.sleepThread(2000);
		String Change_Color=Common.readPropertyByLogin().getProperty("Change_Color");
		com.MouseOverToclickabl("xpath",Change_Color,"ILTC-000,Login,Click on ChangColor file button");
		int size=driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[10]/div/ul/li")).size();
		for (int i =3; i <size; i++) {
			com.MouseOverToclickabl("xpath","//*[@id='container']/div/div/div/div/div[6]/div/ul/li[10]/div/ul/li["+i+"]","ILTC-000,Login,Select the each color");
			com.Rightclick("xpath",Page_1,"ILTC-000,Login,Right click on Page_1 Page button");
			com.sleepThread(2000);
			com.MouseOverToclickabl("xpath",Change_Color,"ILTC-000,Login,Click on ChangColor file button");
		}
		l=new Login();
		String Delete_Page=Common.readPropertyByLogin().getProperty("Delete_Page");
		com.MouseOverToclickabl("xpath",Delete_Page,"ILTC-000,Login,Click on Delete Page file button");
		com.sleepThread(2000);
		l.Veriy_the_delete_page_button();
	}
	
	
	
	
	
	
	
	
}
