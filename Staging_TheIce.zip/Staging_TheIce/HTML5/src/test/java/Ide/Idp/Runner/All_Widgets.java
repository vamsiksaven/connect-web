
package Ide.Idp.Runner;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(plugin = { "html:target/cucumber-html-report", "json:target/cucumber.json",
		"pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
		"junit:target/cucumber-results.xml" }, features = { 
				"../HTML5/Featuresfiles/Login.feature",				
				"../HTML5/Featuresfiles/Chart.feature",							
				"../HTML5/Featuresfiles/CNBC.feature",				
				"../HTML5/Featuresfiles/News.feature",
				"../HTML5/Featuresfiles/DetailedQuotes.feature",
				"../HTML5/Featuresfiles/Fundaments.feature",
				"../HTML5/Featuresfiles/Estimates.feature",
				"../HTML5/Featuresfiles/Research.feature",				
				"../HTML5/Featuresfiles/Watch List.feature",
				"../HTML5/Featuresfiles/Options.feature",
				"../HTML5/Featuresfiles/Ownership.feature",
				"../HTML5/Featuresfiles/Z_Global_Preferences.feature"
				}, glue = "Ide.Idp.StepDef")
public class All_Widgets extends AbstractTestNGCucumberTests {
}


//	
//	
/*



*/
//	
//
//
//
//		