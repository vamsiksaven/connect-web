package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ownership {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
public ownership() {
	driver = Common.driver;		
}

@Given("^Clicked on Ownership widget\\.$")
public void clicked_on_Ownership_Widget() throws Throwable {
	Thread.sleep(2000);
	com.startAction();
	//Clicking on + icon to add new widget
    String Add_Widget=Common.readPropertyByOwnership().getProperty("Add_Widget");     
    //com.MouseOverToclickabl("xpath",Add_Widget,"clicked on + icon");
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    com.click("xpath",Add_Widget,"clicked on + icon");
    Thread.sleep(200);
    
  	//Clicking on ownership 		        		      		        
    String Ownership=Common.readPropertyByOwnership().getProperty("Ownership");
    com.click("xpath",Ownership,"Clicked on Ownership widget");
    Thread.sleep(6000);
    System.out.println("Clicked on Ownership widget");    
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
}
@Given("^Clicked on Ownership widget1$")
public void Clicked_on_Ownership_widget1() throws Exception
{
	//Clicking on ownership 		        		      		        
    String Ownership=Common.readPropertyByOwnership().getProperty("Ownership");
    com.click("xpath",Ownership,"Clicked on Ownership widget");
    Thread.sleep(6000);
    System.out.println("Clicked on Ownership widget");    
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	
}

@Given("^Clicked on Company_reports and its sub options\\.$")
public void clicked_on_Company_reports_and_its_suboptions() throws Throwable {
	com.selectFrameById("frameID");
    String FDsymbolbox=Common.readPropertyByOwnership().getProperty("FDsymbolbox");
//  com.sendKeys("xpath", FDsymbolbox, Keys.CONTROL + "a", "clear text");
  com.sendKeys("xpath", FDsymbolbox, "ICE", "Enter symbol");
  com.sendKeys_fOR_Keybord("xpath", FDsymbolbox, Keys.ENTER , "Enter symbol");   
  Thread.sleep(2000);
  //System.out.println("entered symbol");
  //driver.navigate().refresh();    
  //Thread.sleep(2000);       
  driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);	
	for (int i = 2; i <= 13; i++) {
		
		Thread.sleep(1000);
		com.startAction();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		com.click("xpath","/html/body/div[3]/div[1]/div/div/div[3]/div[1]/div/div/ul/li/ul/li[1]/ul/li["+i+"]/div[2]","clicking on company reports and its sub options");
		Thread.sleep(5000);
		
	}
	
}
		
@Given("^Clicked on Holder_reports and its sub options\\.$")
public void Clicked_on_Holder_reports_and_its_sub_options() throws Throwable {
		
		for (int i = 1; i <= 8; i++) {
			
			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			com.click("xpath","//*[@id='tf-nav-pane-group-gen273']/ul/li["+i+"]/div[2]","clicking on company reports and its sub options");
			Thread.sleep(5000);
			
		}
	
	
}


@Given("^Clicked on Symbol_lookup and its sub options\\.$")
public void Clicked_on_Symbol_lookup_and_its_sub_options() throws Throwable {

	//Clicking on Symbol lookup 		        		      		        
    String Symbol_lookup=Common.readPropertyByOwnership().getProperty("Symbol_lookup");
    com.click("xpath",Symbol_lookup,"Clicked on Symbol_lookup");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup");
   //Clicking on Symbol lookup_dropdown
    String Symbol_lookup_dropdown=Common.readPropertyByOwnership().getProperty("Symbol_lookup_dropdown");
    com.click("xpath",Symbol_lookup_dropdown,"Clicked on Symbol_lookup_dropdown");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup_dropdown");
    
    //Clicking on equity
    String Symbol_lookup_equity=Common.readPropertyByOwnership().getProperty("Symbol_lookup_equity");
    com.click("xpath",Symbol_lookup_equity,"Clicked on Symbol_lookup equity");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup equity");
    
    //Clicking on clear all and close
    String Symbol_lookup_clear_all=Common.readPropertyByOwnership().getProperty("Symbol_lookup_clear_all");
    com.click("xpath",Symbol_lookup_clear_all,"Clicked on Symbol_lookup_clear_all");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup_clear_all");
    Thread.sleep(6000);
                                                   
    //String Symbol_lookup_close=Common.readPropertyByOwnership().getProperty("Symbol_lookup_close");                                          
    //com.click("xpath",Symbol_lookup_close,"Clicked on Symbol_lookup_close");
    
}
       
    @Given("^Clicked on Institutions_dropdown and its sub options\\.$")
    public void clicked_on_Institutions_dropdown_and_its_sub_options() throws Throwable {
       
    	
    	com.click("xpath","/html/body/div[3]/div[1]/div/div/div[3]/div[1]/div/div/ul/li/ul/li[1]/ul/li[5]/div[2]","clicking on company reports");
    	
    	//Clicking on Institutions_dropdown button
        String Institutions_dropdown_button=Common.readPropertyByOwnership().getProperty("Institutions_dropdown_button");
        //com.click("xpath",Institutions_dropdown_button,"Clicked on Institutions_dropdown");
        Thread.sleep(60);
        System.out.println("Clicked on Institutions_dropdown_button");
        
        //Clicking on Institutions_dropdown sub options
        
        for (int i = 1; i <= 5; i++) {
        	
        	com.click("xpath",Institutions_dropdown_button,"Clicked on Institutions_dropdown");
        	Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			com.click("xpath","/html/body/div[6]/div/ul/li["+i+"]","clicking on Institutions_dropdown sub options");
			Thread.sleep(5000);
        	
        }
        }
        
        

    @Given("^Clicked on Currency_dropdown and its sub options\\.$")
    public void clicked_on_Currency_dropdown_and_its_sub_options() throws Throwable {
    	
    	//Clicking on Currency_dropdown_button
        String Currency_dropdown_button=Common.readPropertyByOwnership().getProperty("Currency_dropdown_button");
        //com.click("xpath",Currency_dropdown_button,"Clicked on Currency_dropdown");
        Thread.sleep(60);
        System.out.println("Clicked on Currency_dropdown_button");
        
        //Clicking on Institutions_dropdown sub options
        
        for (int i = 1; i <= 10; i++) {
        	
        	Thread.sleep(1000);
        	com.click("xpath",Currency_dropdown_button,"Clicked on Currency_dropdown");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			com.click("xpath","/html/body/div[6]/div/ul/li["+i+"]","clicking on Institutions_dropdown sub options");
			Thread.sleep(5000);
        	
        }
       
        
    }

    @Given("^Clicked on Identifier_lookup and its sub options\\.$")
    public void clicked_on_Identifier_lookup_and_its_sub_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
    	//Clicking on Symbol lookup 		        		      		        
        String Identifier_lookup=Common.readPropertyByOwnership().getProperty("Identifier_lookup");
        com.click("xpath",Identifier_lookup,"Clicked on Identifier_lookup");
        Thread.sleep(6000);
        System.out.println("Clicked on Symbol_lookup");
       //Clicking on Symbol lookup_dropdown
        String Identifier_symbol_lookup=Common.readPropertyByOwnership().getProperty("Identifier_symbol_lookup");
        com.click("xpath",Identifier_symbol_lookup,"Clicked on Identifier_symbol_lookup");
        Thread.sleep(6000);
        System.out.println("Clicked on Identifier_symbol_lookup");
        
        //Clicking category and its sub options
        for(int i=1;i<5;i++) {
        	
        	
        }
        System.out.println("Clicked on category and its sub options");
        //com.selectFrameById("frameID");
        //Clicking on clear all and close
        String Identifier_Clear_all=Common.readPropertyByOwnership().getProperty("Identifier_Clear_all");
        com.click("xpath",Identifier_Clear_all,"Clicked on Identifier_Clear_all");
        Thread.sleep(6000);
        System.out.println("Clicked on Identifier_Clear_all");
        Thread.sleep(6000);
                                                       
        String Identifier_cancel=Common.readPropertyByOwnership().getProperty("Identifier_cancel");                                          
        com.click("xpath",Identifier_cancel,"Clicked on Identifier_cancel");
    	
    	
        
    }
	
}



