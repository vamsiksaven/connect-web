package Ide.Idp.StepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Watch_List {
	public Common com = new Common();
	public Watch_List wl;
	public WebDriver driver;
	public String Widget_name;

	public Watch_List() {
		driver = Common.driver;
	}
	@Given("^Verify the Watch List$")
	public void Verify_the_Watch_List() throws Exception {
		com.sleepThread(12000);
		String whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		System.out.println(whatch_list);		
		com.verifyElementPresent("xpath", whatch_list, "IWLTC-00001,Watch List,Verify the Watch List");
	}

	@And("^Click on Watch List$")
	public void Click_on_Watch_List() throws Exception {
		com.sleepThread(12000);		
		String whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		com.click("xpath", whatch_list, "IWLTC-00002,Watch List,Click on Watch List");
	}

	@When("^Verify the Symbol Linking$")
	public void Verify_the_Symbol_Linking() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking, "IWLTC-00003,"+Widget_name+",Verify the Symbol Linking");
	}

	@And("^Click on Symbol Linking$")
	public void click_on_Symbol_Linking() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
	}

	@And("^click on each Check Functionalities$")
	public void check_Functionalities() throws Exception {
		wl = new Watch_List();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
					"IWLTC-00005,"+Widget_name+",Verify on each Check Functionalities");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
					"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}

		/*
		 * com.verifyElementPresent("xpath",
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+i+"]/button/label"
		 * ); String t=driver.findElement(By.xpath(
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[\"+i+\"]/button/label"
		 * )).getText(); System.out.println(t+"****************");
		 * com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+
		 * i+"]/button/label"); com.sleepThread(3000);
		 */

		wl = new Watch_List();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
					"IWLTC-00006,"+Widget_name+",Verify on each Check Functionalities");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
					"IWLTC-00007,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}
	}

	@When("^Click on my wath lists Drop Down$")
	public void Click_on_my_wath_lists_Drop_Down() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String my_wath_list = Common.readPropertyByWatch_List().getProperty("my_wath_lists_Drop_Down");
		com.verifyElementPresent("xpath", my_wath_list, "IWLTC-00008,"+Widget_name+",Verify on my wath lists Drop Down");
		com.click("xpath", my_wath_list, "IWLTC-00009,"+Widget_name+",Click on my wath lists Drop Down");
		com.sleepThread(3000);
	}

	@When("^Right click on each symbol$")
	public void Right_click_on_each_symbol() throws Exception {
		com.startAction();
		com.sleepThread(9000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
		//com.click("xpath", Right_click_on_symbol, "IWLTC-00010,"+Widget_name+",click on symbol row");
		com.sleepThread(2000);
		com.Rightclick("xpath", Right_click_on_symbol, "IWLTC-00010,"+Widget_name+",Right click on each symbol");
	}

	@And("^Verify view button$")
	public void Verify_view_button() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String View = Common.readPropertyByWatch_List().getProperty("View");
		com.startAction();
		com.MouseOverToElement("xpath", View, "IWLTC-00011,"+Widget_name+",Mouseover on view button");
		com.verifyElementPresent("xpath", View, "IWLTC-00012,"+Widget_name+",Verify view button");
	}

	@And("^Click on submenus in view option in Watch List$")
	public void Click_on_submenus_in_view_option() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		//String Rightclick_view_option = Common.readPropertyByWatch_List().getProperty("Rightclick_view_option");
		//com.MouseOverToElement("xpath", Rightclick_view_option, "Chart,mouse over on view option");
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[1]/div/ul/li"))
				.size();
		System.out.println("View:"+size);
		for (int i = 1; i <= size; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[1]/div/ul/li[" + i + "]",							   
					"ICTC-00223,"+Widget_name+",Click on submenus in view option");
			com.sleepThread(2000);
			com.startAction();
			String second_widget = Common.readPropertyByChart().getProperty("second_widget");
			com.Rightclick("xpath", second_widget, ",Watch List,Right click on open the new widget name");
			com.sleepThread(1000);
			String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
			com.click("xpath", Close_Tab, ",Watch List,Click on Close Tab and verify the tab is closeing or not");
			com.sleepThread(2000);	
			wl=new Watch_List();
			wl.Right_click_on_each_symbol();
			wl.Verify_view_button();
		}
	}
	@And("^verify Detailed Quotes button$")
	public void verify_Detailed_Quotes_button() throws Exception {

		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Detailed_Quotes = Common.readPropertyByWatch_List().getProperty("Detailed_Quotes");
		com.startAction();
		com.MouseOverToElement("xpath", Detailed_Quotes, "IWLTC-00013,"+Widget_name+",Mouse over on Detailed Quotes button");
		com.verifyElementPresent("xpath", Detailed_Quotes, "IWLTC-00014,"+Widget_name+",verify Detailed Quotes button");
		// com.click("xpath", Detailed_Quotes);
	}

	@And("^verify Chart button$")
	public void verify_Chart_button() throws Exception {
		com.sleepThread(2000);
		// wl=new Watch_List();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Chart = Common.readPropertyByWatch_List().getProperty("Chart");
		com.startAction();
		com.MouseOverToElement("xpath", Chart, "IWLTC-00015,"+Widget_name+",Mouse over on chart button");
		com.verifyElementPresent("xpath", Chart, "IWLTC-00016,"+Widget_name+",verify Chart button");
	}

	@And("^verify Insert column$")
	public void verify_Insert_column() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Insert_column = Common.readPropertyByWatch_List().getProperty("Insert_column");
		com.startAction();
		com.MouseOverToElement("xpath", Insert_column, "IWLTC-00017,"+Widget_name+",Mouse over on Insert column");
		com.verifyElementPresent("xpath", Insert_column, "IWLTC-00018,"+Widget_name+",verify Insert column");
	}

	@And("^Delete selected column$")
	public void Delete_selected_column() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Delete_selected_column = Common.readPropertyByWatch_List().getProperty("Delete_selected_column");
		com.startAction();
		com.MouseOverToElement("xpath", Delete_selected_column,
				"IWLTC-00019,"+Widget_name+",Mouser over on Delete selected column");
		com.verifyElementPresent("xpath", Delete_selected_column, "IWLTC-00020,"+Widget_name+",Delete selected column");
	}

	@And("^verify Edit$")
	public void verify_Edit() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Edit = Common.readPropertyByWatch_List().getProperty("Edit");
		com.startAction();
		com.MouseOverToElement("xpath", Edit, "IWLTC-00021,"+Widget_name+",Mouser over on Edit Option");
		com.verifyElementPresent("xpath", Edit, "IWLTC-00022,"+Widget_name+",verify Edit");
	}

	@And("^verify Display Preferences$")
	public void verify_Display_Preferences() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
		com.Rightclick("xpath", Right_click_on_symbol, "," + Widget_name + ",Right clicked on options data");
		com.sleepThread(2000);
		String Display_Preferences = Common.readPropertyByWatch_List().getProperty("Display_Preferences");
		com.startAction();
		com.MouseOverToElement("xpath", Display_Preferences,
				"IWLTC-00023,"+Widget_name+",Mouser over on Display Preferences");
		com.verifyElementPresent("xpath", Display_Preferences, "IWLTC-00024,"+Widget_name+",verify Display Preferences");
	}

	@And("^Click Display Preferences$")
	public void Click_Display_Preferences() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences = Common.readPropertyByWatch_List().getProperty("Display_Preferences");
		com.startAction();
		com.MouseOverToclickabl("xpath", Display_Preferences,
				"IWLTC-00025,"+Widget_name+",Mouser over to click on Display Preferences");
	}

	@And("^Verify Display Preferences pop title$")
	public void Verify_Display_Preferences_pop_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_title");
		com.verifyElementPresent("xpath", Display_Preferences_pop_title,
				"IWLTC-00026,"+Widget_name+",Verify Display Preferences pop title");
	}

	@And("^Verify Display Preferences pop close icon$")
	public void Verify_Display_Preferences_pop_close_icon() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_close_icon");
		com.verifyElementPresent("xpath", Display_Preferences_pop_close_icon,
				"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
	}

	@And("^Verify Display Preferences pop ok button$")
	public void Verify_Display_Preferences_pop_ok_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_ok = Common.readPropertyByWatch_List().getProperty("Display_Preferences_pop_ok");
		com.verifyElementPresent("xpath", Display_Preferences_pop_ok,
				"IWLTC-00028,"+Widget_name+",Verify Display Preferences pop ok button");
	}

	@And("^Verify Display Preferences pop Apply button$")
	public void Verify_Display_Preferences_pop_Apply_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Apply");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Apply,
				"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
	}

	@And("^Verify Display Preferences pop Cancel button$")
	public void Verify_Display_Preferences_pop_Cancel_button() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Cancel");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Cancel,
				"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
	}

	@And("^Verify Display Preferences pop Auto sort check box$")
	public void Verify_Display_Preferences_pop_Auto_sort_check_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Auto_sort = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Auto_sort,
				"IWLTC-00031,"+Widget_name+",Verify Display Preferences pop Auto sort check box");
	}

	@And("^Click on Auto sort check box$")
	public void Click_on_Auto_sort_check_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Auto_sort = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort");
		com.click("xpath", Display_Preferences_pop_Auto_sort, "IWLTC-00031,"+Widget_name+",Click on Auto sort check box");
	}

	@And("^Verify Display Preferences pop Auto sort text box$")
	public void Verify_Display_Preferences_pop_Auto_sort_text_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Auto_sort_text_box = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort_text_box");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Auto_sort_text_box,
				"IWLTC-00032,"+Widget_name+",Verify Display Preferences pop Auto sort text box");
	}

	@And("^Verify Display Preferences pop symbol field$")
	public void Verify_Display_Preferences_pop_symbol_field() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Symbol_Field = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Symbol_Field");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Symbol_Field,
				"IWLTC-00033,"+Widget_name+",Verify Display Preferences pop symbol field");
	}

	@And("^Click on symbol field$")
	public void Click_on_symbol_field() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Symbol_Field = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Symbol_Field");
		com.click("xpath", Display_Preferences_pop_Symbol_Field, "IWLTC-00034,"+Widget_name+",Click on symbol field");
	}

	@And("^Verify and Click on All check box$")
	public void Verify_and_Click_on_All_check_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int li = driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < li; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"IWLTC-00035,"+Widget_name+",Verify the All check box");
			com.click("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"IWLTC-00036,"+Widget_name+",Click on All check box");
		}
	}

	@And("^Click on formatting$")
	public void Click_on_formatting() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_formatting = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_formatting");
		com.click("xpath", Display_Preferences_pop_formatting, "IWLTC-00037,"+Widget_name+",Click on formatting");
	}

	@And("^Verify and Click on All check box in formatting$")
	public void Verify_and_Click_on_All_check_box_in_formatting() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int li = driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < li; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"IWLTC-00038,"+Widget_name+",Verify the All check box in formatting");
			com.click("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"IWLTC-00039,"+Widget_name+",Click on All check box in formatting");
		}
	}

	/*
	 * public void d() { String d =
	 * Common.readPropertyByWatch_List().getProperty("Symdol"); com.startAction();
	 * com.double_click_an_element("xpath", d); }
	 */

	@And("^Verify and Click on My watch lists and Server Watch Lists$")
	public void Verify_and_Click_on_My_watch_lists_and_Server_Watch_Lists() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		wl = new Watch_List();
		int count = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
				.size();

		int mylist = driver.findElements(By.xpath(
				"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[3]/div"))
				.size();
		System.out.println("mylist:" + mylist);
		int Serverlist = driver.findElements(By.xpath(
				"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Serverlist:" + Serverlist);
		for (int i = 2; i < mylist; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[" + i
							+ "]/div[1]/span[3]/div",
					"IWLTC-00040,"+Widget_name+",Verify the My watch lists");
			com.click("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li["
					+ i + "]/div[1]/span[2]/div", "IWLTC-00041,"+Widget_name+",Click on My watch lists");
			wl.Click_on_my_wath_lists_Drop_Down();
		}
		for (int j = 1; j <= Serverlist; j++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div",
					"IWLTC-00042,"+Widget_name+",Verify the Server Watch Lists");
			com.click("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li["
					+ j + "]/div[1]/span[2]/div", "IWLTC-00043,"+Widget_name+",Click on Server Watch Lists");
			com.sleepThread(6000);
			/*
			 * wl.Right_click_on_each_symbol(); com.sleepThread(3000);
			 * wl.Verify_view_button(); com.sleepThread(3000); wl.verify_Insert_column();
			 * wl.Delete_selected_column(); wl.verify_Edit();
			 * wl.verify_Display_Preferences(); wl.d();
			 * 
			 * wl.verify_Detailed_Quotes_button(); com.sleepThread(3000);
			 * wl.verify_Chart_button();
			 */
			wl.Click_on_my_wath_lists_Drop_Down();

		}
	}

	@When("^Click on New...$")
	public void Click_on_New() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String my_wath_new = Common.readPropertyByWatch_List().getProperty("my_wath_list_New");
		com.click("xpath", my_wath_new, "IWLTC-00044,"+Widget_name+",Click on New...");
	}

	@And("^Verify Add New Symbol List title$")
	public void Verify_Add_New_Symbol_List_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String symbol_list_title = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_title");
		com.verifyElementPresent("xpath", symbol_list_title, "IWLTC-00044,"+Widget_name+",Verify Add New Symbol List title");
	}

	@And("^Verify text box$")
	public void Verify_text_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String text_box = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_texbox");
		com.verifyElementPresent("xpath", text_box, "IWLTC-00045,"+Widget_name+",Verify text box");
	}

	@And("^Verify ok button$")
	public void Verify_ok_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.verifyElementPresent("xpath", ok, "IWLTC-00046,"+Widget_name+",Verify ok button");
	}

	@And("^Verify cancel button$")
	public void Verify_cancel_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_cancel");
		com.verifyElementPresent("xpath", cancel, "IWLTC-00047,"+Widget_name+",Verify cancel button");
		com.sleepThread(3000);
	}

	@And("^Verify close icon$")
	public void Verify_close_icon() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", close, "IWLTC-00048,"+Widget_name+",Verify close icon");
		com.sleepThread(3000);
	}

	@And("^Click on cancel button$")
	public void Click_on_cancel_button() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_cancel");
		com.click("xpath", cancel, "IWLTC-00049,"+Widget_name+",Click on cancel button");
	}

	@And("^Click on close icon$")
	public void Click_on_close_icon() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.click("xpath", close, "IWLTC-00050,"+Widget_name+",Click on close icon");
	}

	@And("^Enter the Symbol list name \"(.*?)\"$")
	public void Enter_symbol_list_name(String Test) throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String symbol_list_name = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_texbox");
		com.sendKeys("xpath", symbol_list_name, Test, "IWLTC-00051,"+Widget_name+",Enter the Symbol list name");
	}

	@And("^click on ok button$")
	public void click_on_ok_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.click("xpath", ok, "IWLTC-00052,"+Widget_name+",click on ok button");
		com.sleepThread(3000);
	}

	@When("^Click on Save as...$")
	public void Click_on_save_as() throws Exception {
		com.sleepThread(2000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_as = Common.readPropertyByWatch_List().getProperty("my_wath_list_save_as");
		com.MouseOverToclickabl("xpath", Save_as, "IWLTC-00053,"+Widget_name+",Click on Save as...");
	}

	@And("^Verify Save Symbol List as title$")
	public void Verify_Save_Symbol_List_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_symbol_list_title = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_title");
		com.verifyElementPresent("xpath", Save_symbol_list_title,
				"IWLTC-00054,"+Widget_name+",Verify Save Symbol List as title");
	}

	@And("^Verify text box in save sysmbol list pop$")
	public void Verify_text_box_in_save_sysmbol_list() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String save_text_box = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_texbox");
		com.verifyElementPresent("xpath", save_text_box,
				"IWLTC-00055,"+Widget_name+",Verify text box in save sysmbol list pop");
	}

	@And("^Verify ok button in save sysmbol list pop$")
	public void Verify_ok_button_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String ok = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_ok");
		com.verifyElementPresent("xpath", ok, "IWLTC-00056,"+Widget_name+",Verify ok button in save sysmbol list pop");
	}

	@And("^Verify cancel button in save sysmbol list pop$")
	public void Verify_cancel_button_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_cancel");
		com.verifyElementPresent("xpath", cancel,
				"IWLTC-00057,"+Widget_name+",Verify cancel button in save sysmbol list pop");
	}

	@And("^Verify close icon in save sysmbol list pop$")
	public void Verify_close_icon_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", close, "IWLTC-00058,"+Widget_name+",Verify close icon in save sysmbol list pop");
	}

	@And("^Click on cancel button in save sysmbol list pop$")
	public void Click_on_cancel_button_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_cancel");
		com.click("xpath", cancel, "IWLTC-00059,"+Widget_name+",Click on cancel button in save sysmbol list pop");
		com.sleepThread(3000);
	}

	@And("^Click on close icon in save sysmbol list pop$")
	public void Click_on_close_icon_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.click("xpath", close, "IWLTC-00060,"+Widget_name+",Click on close icon in save sysmbol list pop");
		com.sleepThread(3000);
	}

	@And("^Enter the Symbol list name \"(.*?)\" in save sysmbol list pop$")
	public void Enter_save_symbol_list_name(String For_Test) throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String symbol_list_name = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_texbox");
		com.sendKeys("xpath", symbol_list_name, For_Test,
				"IWLTC-00061,"+Widget_name+",Enter the Symbol list name in save sysmbol list pop");
	}

	@And("^click on ok button in save sysmbol list pop$")
	public void click_on_ok_button_in_save_sysmbol_list_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.click("xpath", ok, "IWLTC-00062,"+Widget_name+",click on ok button in save sysmbol list pop");
		com.sleepThread(3000);
	}

	@When("^Click on Import from file...$")
	public void Click_on_Import_from_file() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_file = Common.readPropertyByWatch_List().getProperty("my_wath_list_Import_from_file");
		com.click("xpath", Import_file, "IWLTC-00063,"+Widget_name+",Click on Import from file...");
	}

	@And("^Verify Import from file title$")
	public void Verify_Import_from_file_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_title = Common.readPropertyByWatch_List().getProperty("Import_from_file_title");
		com.verifyElementPresent("xpath", Import_from_file_title,
				"IWLTC-00064,"+Widget_name+",Verify Import from file title");
	}

	@And("^Verify Select file in Import from file pop$")
	public void Verify_Select_file() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_browse = Common.readPropertyByWatch_List().getProperty("Import_from_file_browse");
		com.verifyElementPresent("xpath", Import_from_file_browse,
				"IWLTC-00065,"+Widget_name+",Verify Select file in Import from file pop");
	}

	@And("^Verify ok button in Import from file pop$")
	public void Verify_ok_buttom() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_ok = Common.readPropertyByWatch_List().getProperty("Import_from_file_ok");
		com.verifyElementPresent("xpath", Import_from_file_ok,
				"IWLTC-00066,"+Widget_name+",Verify ok button in Import from file pop");
	}

	@And("^Verify cancel button in Import from file pop$")
	public void Verify_cancel_button_Import_from_file() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.verifyElementPresent("xpath", Import_from_file_cancel,
				"IWLTC-00067,"+Widget_name+",Verify cancel button in Import from file pop");
	}

	@And("^Verify close icon in Import from file pop$")
	public void Verify_close_icon_Import_from_file() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Import_from_file_close_icon");
		com.verifyElementPresent("xpath", Import_from_file_close_icon,
				"IWLTC-00068,"+Widget_name+",Verify close icon in Import from file pop");
	}

	@And("^Click on close icon in Import from file pop$")
	public void Click_on_close_icon_in_Import_from_file() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Import_from_file_close_icon");
		com.click("xpath", Import_from_file_close_icon,
				"IWLTC-00069,"+Widget_name+",Click on close icon in Import from file pop");
	}

	@And("^Click on cancel button in Import from file pop$")
	public void Click_on_cancel_button_in_Import_from_file_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.click("xpath", Import_from_file_cancel,
				"IWLTC-00070,"+Widget_name+",Click on cancel button in Import from file pop");
	}

	@And("^Select file in Import from file pop$")
	public void Select_file_in_Import_from_file_pop() {

	}

	@And("^click on ok button in Import from file pop$")
	public void click_on_ok_button_in_Import_from_file_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.click("xpath", Import_from_file_cancel,
				"IWLTC-00071,"+Widget_name+",click on ok button in Import from file pop");
	}

	@When("^Click on Manage watchlists...$")
	public void Click_on_Manage_watchlists() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String my_wath_list_Manage_watchlists = Common.readPropertyByWatch_List()
				.getProperty("my_wath_list_Manage_watchlists");
		com.click("xpath", my_wath_list_Manage_watchlists, "IWLTC-00072,"+Widget_name+",Click on Manage watchlists...");
	}

	@And("^Verify Watch List title$")
	public void Verify_Watch_List_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_title = Common.readPropertyByWatch_List().getProperty("Manage_watchlists_title");
		com.verifyElementPresent("xpath", Manage_watchlists_title, "IWLTC-00073,"+Widget_name+",Verify Watch List title");
	}

	@And("^Verify close icon in Manage watchlists pop$")
	public void Verify_close_icon_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_close_icon,
				"IWLTC-00074,"+Widget_name+",Verify close icon in Manage watchlists pop");
	}

	@And("^Verify New button in Manage watchlists pop$")
	public void Verify_New_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_new_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_new_button");
		com.verifyElementPresent("xpath", Manage_watchlists_new_button,
				"IWLTC-00075,"+Widget_name+",Verify New button in Manage watchlists pop");
	}

	@And("^Verify Import button in Manage watchlists pop$")
	public void Verify_Import_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_import_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_import_button");
		com.verifyElementPresent("xpath", Manage_watchlists_import_button,
				"IWLTC-00076,"+Widget_name+",Verify Import button in Manage watchlists pop");
	}

	@And("^Verify Export button in Manage watchlists pop$")
	public void Verify_Export_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Export_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Export_button");
		com.verifyElementPresent("xpath", Manage_watchlists_Export_button,
				"IWLTC-00077,"+Widget_name+",Verify Export button in Manage watchlists pop");
	}

	@And("^Verify cancel button in Manage watchlists pop$")
	public void Verify_cancel_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_cancel_button");
		com.verifyElementPresent("xpath", Manage_watchlists_cancel_button,
				"IWLTC-00078,"+Widget_name+",Verify cancel button in Manage watchlists pop");
	}

	@And("^Click on close icon in Manage watchlists pop$")
	public void Click_on_close_icon_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_close_icon");
		com.click("xpath", Manage_watchlists_close_icon,
				"IWLTC-00079,"+Widget_name+",Click on close icon in Manage watchlists pop");
	}

	@And("^Click on cancel button in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_cancel_button");
		com.click("xpath", Manage_watchlists_cancel_button,
				"IWLTC-00080,"+Widget_name+",Click on cancel button in Manage watchlists pop");
		com.sleepThread(3000);
	}

	@When("^Click on New button in Manage watchlists pop$")
	public void Click_on_New_button_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_new_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_new_button");
		com.click("xpath", Manage_watchlists_new_button,
				"IWLTC-00081,"+Widget_name+",Click on New button in Manage watchlists pop");
	}

	@And("^Verify Add New Symbol List title in Manage watchlists pop$")
	public void Verify_Add_New_Symbol_List_title_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_title,
				"IWLTC-00081,"+Widget_name+",Verify Add New Symbol List title in Manage watchlists pop");
	}

	@And("^Verify text box Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_text_box_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_texbox = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_texbox");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_texbox,
				"IWLTC-00082,"+Widget_name+",Verify text box Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify ok button Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_ok_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_ok,
				"IWLTC-00083,"+Widget_name+",Verify ok button Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify cancel button Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_cancel_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_cancel,
				"IWLTC-00084,"+Widget_name+",Verify cancel button Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify close icon Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_close_icon,
				"IWLTC-00085,"+Widget_name+",Verify close icon Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on cancel button Add New Symbol List pop in Manage watchlists pop$")
	public void Click_on_cancel_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_cancel");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_cancel,
				"IWLTC-00086,"+Widget_name+",Click on cancel button Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on close icon Add New Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_close_icon");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_close_icon,
				"IWLTC-00087,"+Widget_name+",Click on close icon Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^Enter the Symbol list name \"(.*?)\" Add New Symbol List pop in Manage watchlists pop$")
	public void Enter_the_Symbol_list_name_Add_New_Symbol_List_pop_in_Manage_watchlists_pop(String test)
			throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_texbox = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_texbox");
		com.sendKeys("xpath", Manage_watchlists_Add_New_Symbol_List_texbox, test,
				"IWLTC-00088,"+Widget_name+",Enter the Symbol list name in Add New Symbol List pop in Manage watchlists pop");
	}

	@And("^click on ok button Add New Symbol List pop in Manage watchlists pop$")
	public void click_on_ok_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Add_New_Symbol_List_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_ok");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_ok,
				"IWLTC-00089,"+Widget_name+",click on ok button Add New Symbol List pop in Manage watchlists pop");
	}

	@When("^Click on Import button in Manage watchlists pop$")
	public void Click_on_Import_button_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Import_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Import_button");
		com.click("xpath", Manage_watchlists_Import_button,
				"IWLTC-00090,"+Widget_name+",Click on Import button in Manage watchlists pop");
	}

	@And("^Verify Import from file title in Manage watchlists pop$")
	public void Verify_Import_from_file_title_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_title,
				"IWLTC-00091,"+Widget_name+",Verify Import from file title in Manage watchlists pop");
	}

	@And("^Verify Select file in Import from file pop in Manage watchlists pop$")
	public void Verify_Select_file_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_browse = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_browse");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_browse,
				"IWLTC-00092,"+Widget_name+",Verify Select file in Import from file pop in Manage watchlists pop");
	}

	@And("^Verify ok button in Import from file pop in Manage watchlists pop$")
	public void Verify_ok_button_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_ok,
				"IWLTC-00093,"+Widget_name+",Verify ok button in Import from file pop in Manage watchlists pop");
	}

	@And("^Verify cancel button in Import from file pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_cancel,
				"IWLTC-00094,"+Widget_name+",Verify cancel button in Import from file pop in Manage watchlists pop");
	}

	@And("^Verify close icon in Import from file pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_close_icon,
				"IWLTC-00095,"+Widget_name+",Verify close icon in Import from file pop in Manage watchlists pop");
	}

	@And("^Click on close icon in Import from file pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_close_icon");
		com.click("xpath", Manage_watchlists_Load_from_file_close_icon,
				"IWLTC-00096,"+Widget_name+",Click on close icon in Import from file pop in Manage watchlists pop");
	}

	@And("^Click on cancel button in Import from file pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_cancel");
		com.click("xpath", Manage_watchlists_Load_from_file_cancel,
				"IWLTC-00097,"+Widget_name+",Click on cancel button in Import from file pop in Manage watchlists pop");
	}

	@And("^Select file in Import from file pop in Manage watchlists pop$")
	public void Select_file_in_Import_from_file_pop_in_Manage_watchlists_pop() {

	}

	@And("^click on ok button in Import from file pop in Manage watchlists pop$")
	public void click_on_ok_button_in_Import_from_file_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Load_from_file_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_ok");
		com.click("xpath", Manage_watchlists_Load_from_file_ok,
				"IWLTC-00098,"+Widget_name+",click on ok button in Import from file pop in Manage watchlists pop");
	}

	@And("^Click on Frist label in Manage watchlists pop$")
	public void Click_on_Frist_label_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_label");
		com.click("xpath", Manage_watchlists_frist_label,
				"IWLTC-00099,"+Widget_name+",Click on Frist label in Manage watchlists pop");
	}

	@And("^Verify Save Symbol List as label in Manage watchlists pop$")
	public void Verify_Save_Symbol_List_as_label_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label,
				"IWLTC-00100,"+Widget_name+",Verify Save Symbol List as label in Manage watchlists pop");
	}

	@When("^Click on Save Symbol List as label in Manage watchlists pop$")
	public void Click_on_Save_Symbol_List_as_label_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		String Manage_watchlists_frist_save_as_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label");
		com.click("xpath", Manage_watchlists_frist_save_as_label,
				"IWLTC-00101,"+Widget_name+",Click on Save Symbol List as label in Manage watchlists pop");
	}

	@And("^Verify Save Symbol List as title in Manage watchlists pop$")
	public void Verify_Save_Symbol_List_title_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_title,
				"IWLTC-00102,"+Widget_name+",Verify Save Symbol List as title in Manage watchlists pop");
	}

	@And("^Verify text box in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_text_box_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_text_box");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_text_box,
				"IWLTC-00103,"+Widget_name+",Verify text box in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Verify ok button in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_ok_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_ok,
				"IWLTC-00104,"+Widget_name+",Verify ok button in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Verify cancel button in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_Cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Cancel_button");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_Cancel_button,
				"IWLTC-00105,"+Widget_name+",Verify cancel button in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Verify close icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_close_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_Close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_Close_icon,
				"IWLTC-00106,"+Widget_name+",Verify close icon in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Click on cancel button in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_Cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Cancel_button");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_Cancel_button,
				"IWLTC-00107,"+Widget_name+",Click on cancel button in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(3000);
	}

	@And("^Click on close icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_Close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Close_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_Close_icon,
				"IWLTC-00108,"+Widget_name+",Click on close icon in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(3000);
	}

	@And("^Enter the Symbol list name \"(.*?)\" in save sysmbol list pop in Manage watchlists pop$")
	public void Enter_save_symbol_list_name_in_Manage_watchlists_pop(String For_Test) throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_text_box");
		com.sendKeys("xpath", Manage_watchlists_frist_save_as_label_pop_text_box, For_Test,
				"IWLTC-00109,"+Widget_name+",Enter the Symbol list name in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^click on ok button in save sysmbol list pop in Manage watchlists pop$")
	public void click_on_ok_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_ok");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_ok,
				"IWLTC-00110,"+Widget_name+",click on ok button in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(3000);
	}

	@When("^Verify Edit icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Edit_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Edit_name = Common.readPropertyByWatch_List()
				.getProperty("Edit_name");
		com.MouseOverToclickabl("xpath", Edit_name,
				"IWLTC-00111,"+Widget_name+",Mouse over on Edit name");
		String Manage_watchlists_frist_save_as_label_Edit_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Edit_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Edit_icon,
				"IWLTC-00111,"+Widget_name+",Verify Edit icon in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Click on Edit icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_Edit_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Edit_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Edit_icon");
		com.MouseOverToElement("xpath", Manage_watchlists_frist_save_as_label_Edit_icon,
				"IWLTC-00112,"+Widget_name+",Mouse over on Edit icon in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(2000);		
				com.MouseOverToclickabl("xpath", Manage_watchlists_frist_save_as_label_Edit_icon,
				"IWLTC-00112,"+Widget_name+",Click on Edit icon in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(2000);
	}

	@And("^Verify Rename Symbol List title in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Rename_Symbol_List_title_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title,
				"IWLTC-00113,"+Widget_name+",Verify Rename Symbol List title in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Verify text box in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_text_box_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title,
				"IWLTC-00114,"+Widget_name+",Verify text box in Rename Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify ok button in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_ok_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok,
				"IWLTC-00115,"+Widget_name+",Verify ok button in Rename Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify cancel button in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel,
				"IWLTC-00116,"+Widget_name+",Verify cancel button in Rename Symbol List pop in Manage watchlists pop");

	}

	@And("^Verify close icon in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon = Common
				.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon,
				"IWLTC-00117,"+Widget_name+",Verify close icon in Rename Symbol List pop in Manage watchlists pop");
	}

	@Then("^Clear the Symbol List name or not in Rename Symbol List pop in Manage watchlists pop$")
	public void Clear_the_Symbol_List_name_or_not_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop()
			throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box");
		com.ClearTextField("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box,
				"IWLTC-00118,"+Widget_name+",Clear the Symbol List name or not in Rename Symbol List pop in Manage watchlists pop");
		com.sleepThread(2000);
	}

	@And("^Enter the Rename \"(.*?)\" in Rename Symbol List pop in Manage watchlists pop$")
	public void Enter_the_Rename_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop(String Test_For) throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box");
		com.sendKeys("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box, Test_For,
				"IWLTC-00119,"+Widget_name+",Enter the Rename in Rename Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on ok button in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_ok_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok,
				"IWLTC-00120,"+Widget_name+",Click on ok button in Rename Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on cancel button in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel,
				"IWLTC-00121,"+Widget_name+",Click on cancel button in Rename Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on close icon in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon = Common
				.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon,
				"IWLTC-00122,"+Widget_name+",Click on close icon in Rename Symbol List pop in Manage watchlists pop");
	}

	@Then("^Verify Delete icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Delete_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Delete_icon,
				"IWLTC-00123,"+Widget_name+",Verify Delete icon in save sysmbol list pop in Manage watchlists pop");
	}

	@And("^Click on Delete icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_frist_save_as_label_Delete_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Delete_icon,
				"IWLTC-00124,"+Widget_name+",Click on Delete icon in save sysmbol list pop in Manage watchlists pop");
	}
	
	@And("^Delete on all created my watch list$")
	public void Delete_on_all_created_my_watch_list() throws Exception {
		
		com.startAction();
		int size=driver.findElements(By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[3]/div")).size();
		System.out.println("Delete on all created my watch list:"+size);
		for (int i =1; i <size; i++) {
			com.startAction();
			int value=size-i;
			com.MouseOverToclickabl("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li["+value+"]/div[1]/span[3]/div",",,Delete on all created my watch list");
			com.sleepThread(3000);
			wl=new Watch_List();
			wl.Click_on_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop();
			com.sleepThread(3000);
			wl.Click_on_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop();
			com.sleepThread(3000);
		}
		
		com.MouseOverToclickabl("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[3]/div",",,Delete on all created my watch list");
		com.sleepThread(3000);
		wl=new Watch_List();
		wl.Click_on_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop();
		com.sleepThread(3000);
		wl.Click_on_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop();
		com.sleepThread(3000);
	
	}
	
	@And("^Verify Remove Symbol List title in Manage watchlists pop$")
	public void Verify_Remove_Symbol_List_title_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_title,
				"IWLTC-00125,"+Widget_name+",Verify Remove Symbol List title in Manage watchlists pop");
	}

	@And("^Verify massage is showing or not in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_massage_is_showing_or_not_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_massage = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_massage");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_massage,
				"IWLTC-00126,"+Widget_name+",Verify massage is showing or not in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify Yes button in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes,
				"IWLTC-00127,"+Widget_name+",Verify Yes button in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify No button in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_No_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_No = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_No");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_No,
				"IWLTC-00128,"+Widget_name+",Verify No button in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Verify close icon in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon,
				"IWLTC-00129,"+Widget_name+",Verify close icon in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on close icon in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon,
				"IWLTC-00130,"+Widget_name+",Click on close icon in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on Yes button in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes,
				"IWLTC-00131,"+Widget_name+",Click on Yes button in Remove Symbol List pop in Manage watchlists pop");
	}

	@And("^Click on No button in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_No_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_No = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_No");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_No,
				"IWLTC-00132,"+Widget_name+",Click on No button in Remove Symbol List pop in Manage watchlists pop");
	}

	@When("^Pre defined Column Sets Drop Down$")
	public void Pre_defined_Column_Sets_Drop_Down() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Drop_Down");
		com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IWLTC-00133,"+Widget_name+",Pre defined Column Sets Drop Down");
		com.click("xpath", Pre_defined_Column_Sets_Drop_Down,
				"IWLTC-00133,"+Widget_name+",Pre defined Column Sets Drop Down");
	}
	
	@When("^Pre defined Column Sets Drop Down1$")
	public void Pre_defined_Column_Sets_Drop_Down1() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
	com.startAction();
	String Pre_defined_Column_Sets_Drop_Down1 = Common.readPropertyByWatch_List()
			.getProperty("Pre_defined_Column_Sets_Drop_Down1");
	com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down1,
			"IWLTC-00133,"+Widget_name+",Pre defined Column Sets Drop Down");
	
	}
	@And("^Verify and Click on Custom Column Sets and Predefined Column Sets$")
	public void Verify_and_Click_on_Custom_Column_Sets_and_Predefined_Column_Sets() throws Exception {
		wl = new Watch_List();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(3000);
		int Predefined = driver.findElements(By.xpath(
				"/html/body/div[5]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Predefined:" + Predefined);
		for (int j = 2; j <= Predefined; j++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[5]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div",
					"IWLTC-00134,"+Widget_name+",Verify the Custom Column Sets and Predefined Column Sets");
			com.click("xpath",
					"/html/body/div[5]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div",
					"IWLTC-00135,"+Widget_name+",Click on Custom Column Sets and Predefined Column Sets");
			com.sleepThread(2000);
			com.startAction();
			String Pre_defined_Column_Sets_Drop_Down1 = Common.readPropertyByWatch_List()
					.getProperty("Pre_defined_Column_Sets_Drop_Down1");
			com.MouseOverToclickabl("xpath", Pre_defined_Column_Sets_Drop_Down1,
					"IWLTC-00133,"+Widget_name+",Pre defined Column Sets Drop Down");
		}
	}

	@And("^Click on New...Pre defined Column Sets Drop Down$")
	public void Click_on_New_Pre_defined_Column_Sets_Drop_Down() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_New_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_New_button");
		com.click("xpath", Pre_defined_Column_Sets_New_button,
				"IWLTC-00136,"+Widget_name+",Click on New...Pre defined Column Sets Drop Down");

	}

	@And("^Verify Add column set title$")
	public void Verify_Add_column_set_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_title,
				"IWLTC-00137,"+Widget_name+",Verify Add column set title");
	}

	@And("^Verify save button in Add column set$")
	public void Verify_save_button_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button,
				"IWLTC-00138,"+Widget_name+",Verify save button in Add column set");
	}

	@And("^Verify cancel button in Add column set$")
	public void Verify_cancel_button_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button,
				"IWLTC-00139,"+Widget_name+",Verify cancel button in Add column set");
	}

	@And("^Verify close icon in Add column set$")
	public void Verify_close_icon_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon,
				"IWLTC-00140,"+Widget_name+",Verify close icon in Add column set");
	}

	@And("^Click on cancel button in Add column set$")
	public void Click_on_cancel_button_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button,
				"IWLTC-00141,"+Widget_name+",Click on cancel button in Add column set");
	}

	@And("^Click on close icon in Add column set pop$")
	public void Click_on_close_icon_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon,
				"IWLTC-00142,"+Widget_name+",Click on close icon in Add column set pop");
	}

	@And("^Verify name text box in Add column set pop$")
	public void Verify_name_text_box_in_Add_column_set_pop() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_name_text_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_name_text_box,
				"IWLTC-00143,"+Widget_name+",Verify name text box in Add column set pop");
	}

	@And("^Verify Available Columns title in Add column set pop$")
	public void Verify_Available_Columns_title_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title,
				"IWLTC-00144,"+Widget_name+",Verify Available Columns title in Add column set pop");
	}

	@And("^Verify Search box Available Columns title below in Add column set pop$")
	public void Verify_Search_box_Available_Columns_title_below_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box,
				"IWLTC-00145,"+Widget_name+",Verify Search box Available Columns title below in Add column set pop");
	}

	@And("^Verify Selected Columns title in Add column set$")
	public void Verify_Selected_Columns_title_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title,
				"IWLTC-00146,"+Widget_name+",Verify Selected Columns title in Add column set");
	}

	@And("^Verify Search box Selected Columns title below in Add column set pop$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box,
				"IWLTC-00147,"+Widget_name+",Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box");
	}

	@And("Verify Set this column set as default checkbox in Add column set pop")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_checkbox = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_checkbox,
				"IWLTC-00148,"+Widget_name+",Verify Set this column set as default checkbox in Add column set pop");
	}

	@And("^Verify Available Columns Each list in Add column set pop$")
	public void Verify_Available_Columns_Each_list_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("Available_Columns_list:" + Available_Columns_list);

		/*
		 * for(int i=1; i<=Available_Columns_list; i++){ com.sleepThread(5000);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); System.out.println(i); int
		 * sublist=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li/div[1]/span[2]/div")).size();
		 * System.out.println(sublist+"****************"); for (int j = 1; j <=sublist;
		 * j++) { com.sleepThread(5000); System.out.println("loppnumber"+j);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.sleepThread(5000);
		 * String Pre_defined_Column_Sets_Add_Column_Set_arrow_right=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_right"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_right); } int
		 * Selected_Columns_list=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"
		 * )).size(); System.out.println(Selected_Columns_list); for (int k = 1; k
		 * <=Selected_Columns_list; k++) { com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.sleepThread(2000); String
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_left"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left); } }
		 */
		int i = 1;
		while (i <2) {
			com.sleepThread(5000);
			com.verifyElementPresent("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"IWLTC-00149,"+Widget_name+",Verify Available Columns Each list in Add column set pop");
			com.click("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"IWLTC-00150,"+Widget_name+",Click on Available Columns Each list in Add column set pop");
			System.out.println(i);
			int sublist = driver.findElements(
					By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println("sublist:" + sublist);

			int j = 1;
			while (j < 10) {

				com.sleepThread(5000);
				System.out.println("loppnumber" + j);
				String text = driver.findElement(
						By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
					.getText();
				System.out.println("text=" + text);
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
						"IWLTC-00151,"+Widget_name+",Verify the Available Each sub list in Add column set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
						"IWLTC-00152,"+Widget_name+",Click on Available Each sub list in Add column set pop");
				com.sleepThread(5000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right,
						"IWLTC-00153,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow right");
				j++;
				int t = 1;
				while (t < 10) {

					com.sleepThread(5000);
					System.out.println("loppnumber" + j);
					String text1 = driver.findElement(
							By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
									+ i + "]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
							.getText();
					System.out.println("text=" + text1);
					com.verifyElementPresent("xpath",
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
									+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
							"IWLTC-00151,"+Widget_name+",Verify the Available Each sub list in Add column set pop");
					com.click("xpath",
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
									+ "]/div[2]/div/ul/li[1]/div[1]/span[2]/div",
							"IWLTC-00152,"+Widget_name+",Click on Available Each sub list in Add column set pop");
					com.sleepThread(5000);
					String Pre_defined_Column_Sets_Add_Column_Set_arrow_right1 = Common.readPropertyByWatch_List()
							.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
					com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right1,
							"IWLTC-00154,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow right_1");
					j++;
				}
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"))
					.size();
			System.out.println("Selected Columns list" + Selected_Columns_list);
			int k = 1;
			while (k <=2) {
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button[" + k
								+ "]/div",
						"IWLTC-00155,"+Widget_name+",Verify the Selected Columns list");
				com.click("xpath", "/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
						+ k + "]/div", "IWLTC-00156,"+Widget_name+",Click on Selected Columns list");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left,
						"IWLTC-00157,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow left");
				k++;
			}
			i++;
		}
	}

	@And("^Verify double Arrow right icon in Add column set pop$")
	public void Verify_double_Arrow_right_icon_in_Add_column_set_pop() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right,
				"IWLTC-00158,"+Widget_name+",Verify double Arrow right icon in Add column set pop");
	}

	@And("^Verify double Arrow left icon in Add column set pop$")
	public void Verify_double_Arrow_left_icon_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left,
				"IWLTC-00159,"+Widget_name+",Verify double Arrow left icon in Add column set pop");
	}

	@And("^Verify down arrow default disable or not in Add column set pop$")
	public void Verify_down_arrow_default_disable_or_not_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_down_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_down_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_down_arrow,
				"IWLTC-00160,"+Widget_name+",Verify down arrow default disable or not in Add column set pop");
	}

	@And("^Verify up arrow default disable or not in Add column set pop$")
	public void Verify_up_arrow_default_disable_or_not_in_Add_column_set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_up_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_up_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_up_arrow,
				"IWLTC-00161,"+Widget_name+",Verify up arrow default disable or not in Add column set pop");
	}

	@And("^Click on save button in Add column set$")
	public void Click_on_save_button_in_Add_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button,
				"IWLTC-00162,"+Widget_name+",Click on save button in Add column set");
	}

	@When("^Click on Save Column Set Pre defined Column Sets Drop Down$")
	public void Click_on_Save_Column_Set_Pre_defined_Column_Sets_Drop_Down() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set,
				"IWLTC-00163,"+Widget_name+",Click on Save Column Set Pre defined Column Sets Drop Down");
	}

	@And("^Verify Save Column Set title$")
	public void Verify_Save_Column_Set_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_title,
				"IWLTC-00164,"+Widget_name+",Verify Save Column Set title");
	}

	@And("^Verify save button in Save Column Set$")
	public void Verify_save_button_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_save_button,
				"IWLTC-00165,"+Widget_name+",Verify save button in Save Column Set");
	}

	@And("^Verify cancel button in Save Column Set$")
	public void Verify_cancel_button_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button,
				"IWLTC-00166,"+Widget_name+",Verify cancel button in Save Column Set");
	}

	@And("^Verify close icon in Save Column Set$")
	public void Verify_close_icon_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon,
				"IWLTC-00167,"+Widget_name+",Verify close icon in Save Column Set");
	}

	@And("^Click on cancel button in Save Column Set$")
	public void Click_on_cancel_button_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button,
				"IWLTC-00168,"+Widget_name+",Click on cancel button in Save Column Set");
	}

	// *****************************************************************************************************************

	@And("^Click on close icon in Save Column Set pop$")
	public void Click_on_close_icon_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon,
				"IWLTC-00169,"+Widget_name+",Click on close icon in Save Column Set pop");
	}

	@And("^Verify name text box in Save Column Set pop$")
	public void Verify_name_text_box_in_Save_Column_Set_pop() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Add_Column_Set_name_text_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_name_text_box,
				"IWLTC-00170,"+Widget_name+",Verify name text box in Save Column Set pop");
	}

	@And("^Verify Available Columns title in Save Column Set pop$")
	public void Verify_Available_Columns_title_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_title,
				"IWLTC-00171,"+Widget_name+",Verify Available Columns title in Save Column Set pop");
	}

	@And("^Verify Search box Available Columns title below in Save Column Set pop$")
	public void Verify_Search_box_Available_Columns_title_below_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box,
				"IWLTC-00172,"+Widget_name+",Verify Search box Available Columns title below in Save Column Set pop");
	}

	@And("^Verify Selected Columns title in Save Column Set$")
	public void Verify_Selected_Columns_title_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title,
				"IWLTC-00173,"+Widget_name+",Verify Selected Columns title in Save Column Set");
	}

	@And("^Verify Search box Selected Columns title below in Save Column Set pop$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box,
				"IWLTC-00174,"+Widget_name+",Verify Search box Selected Columns title below in Save Column Set pop");
	}

	@And("Verify Set this column set as default checkbox in Save Column Set pop")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_checkbox = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_checkbox,
				"IWLTC-00175,"+Widget_name+",Verify Set this column set as default checkbox in Save Column Set pop");
	}

	@And("^Verify Available Columns Each list in Save Column Set pop$")
	public void Verify_Available_Columns_Each_list_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("" + Available_Columns_list);

		for (int i = 1; i <= 2; i++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"IWLTC-00175,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
			com.click("xpath",
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"IWLTC-00176,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
			int sublist = driver.findElements(By.xpath(
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println("sublist:" + sublist);
			for (int j = 1; j <= 2; j++) {
				com.sleepThread(2000);
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div",
						"IWLTC-00177,"+Widget_name+",Verify Sublist Available Columns Each list in Save Column Set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[\"+i+\"]/div[2]/div/ul/li[\"+j+\"]/div[1]/span[2]/div",
						"IWLTC-00178,"+Widget_name+",Click on Sublist Available Columns Each list in Save Column Set pop");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right,
						"IWLTC-00179,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow right");
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"))
					.size();
			System.out.println(Selected_Columns_list);
			for (int k = 1; k <= 2; k++) {
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button["+k+"]/div",
								
						"IWLTC-00180,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/span/div/div[3]/div/button["+k+"]/div",
						"IWLTC-00181,"+Widget_name+",Click on Available Columns Each list in Save Column Set pop");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left,
						"IWLTC-00182,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow left");
			}
		}
	}

	@And("^Verify double Arrow right icon in Save Column Set pop$")
	public void Verify_double_Arrow_right_icon_in_Save_Column_Set_pop() throws Exception {
		com.sleepThread(5000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_right = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_right,
				"IWLTC-00183,"+Widget_name+",Verify double Arrow right icon in Save Column Set pop");
	}

	@And("^Verify double Arrow left icon in Save Column Set pop$")
	public void Verify_double_Arrow_left_icon_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_left = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_left,
				"IWLTC-00184,"+Widget_name+",Verify double Arrow left icon in Save Column Set pop");
	}

	@And("^Verify down arrow default disable or not in Save Column Set pop$")
	public void Verify_down_arrow_default_disable_or_not_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_down_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_down_arrow");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_down_arrow,
				"IWLTC-00185,"+Widget_name+",Verify down arrow default disable or not in Save Column Set pop");
	}

	@And("^Verify up arrow default disable or not in Save Column Set pop$")
	public void Verify_up_arrow_default_disable_or_not_in_Save_Column_Set_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_up_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_up_arrow");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_up_arrow,
				"IWLTC-00186,"+Widget_name+",Verify up arrow default disable or not in Save Column Set pop");
	}

	@And("^Click on save button in Save Column Set$")
	public void Click_on_save_button_in_Save_Column_Set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_save_button,
				"IWLTC-00187,"+Widget_name+",Click on save button in Save Column Set");
	}

	@When("^Click on Manage column set Pre defined Column Sets Drop Down$")
	public void Click_on_Manage_column_set_Pre_defined_Column_Sets_Drop_Down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set,
				"IWLTC-00188,"+Widget_name+",Click on Manage column set Pre defined Column Sets Drop Down");
	}

	@And("^Verify Manage column set title$")
	public void Verify_Manage_column_set_title() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_title");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_title,
				"IWLTC-00189,"+Widget_name+",Verify Manage column set title");
	}

	@And("^Verify close icon in Manage column set$")
	public void Verify_close_icon_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon,
				"IWLTC-00190,"+Widget_name+",Verify close icon in Manage column set");
	}

	@And("^Verify cancel button in Manage column set$")
	public void Verify_cancel_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button,
				"IWLTC-00191,"+Widget_name+",Verify cancel button in Manage column set");
	}

	@And("^Verify Edit button in Manage column set$")
	public void Verify_Edit_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_Edit_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Edit_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Edit_button,
				"IWLTC-00192,"+Widget_name+",Verify Edit button in Manage column set");
	}

	@And("^Verify Copy button in Manage column set$")
	public void Verify_Copy_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_Copy_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Copy_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Copy_button,
				"IWLTC-00193,"+Widget_name+",Verify Copy button in Manage column set");
	}

	@And("^Verify Delete button in Manage column set$")
	public void Verify_Delete_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_Delete_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Delete_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Manage_column_set_Delete_button,
				"IWLTC-00194,"+Widget_name+",Verify Delete button in Manage column set");
	}

	@And("^Verify New button in Manage column set$")
	public void Verify_New_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_New_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_New_button");
		com.verifyElementEnabled("xpath", Pre_defined_Column_Sets_Manage_column_set_New_button,
				"IWLTC-00195,"+Widget_name+",Verify New button in Manage column set");
	}

	@And("^click on close icon in Manage column set$")
	public void click_on_close_icon_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon,
				"IWLTC-00196,"+Widget_name+",click on close icon in Manage column set");
	}

	@And("^click on cancel button in Manage column set$")
	public void click_on_cancel_button_in_Manage_column_set() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button,
				"IWLTC-00197,"+Widget_name+",click on cancel button in Manage column set");
	}

	@And("^Verify and Click on Show Symbol as Description check box$")
	public void Verify_and_Click_on_Show_Symbol_as_Description_check_box() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Show_Symbol_as_Description_check_box=Common.readPropertyByWatch_List().getProperty("Show_Symbol_as_Description_check_box");
		com.verifyElementPresent("xpath",Show_Symbol_as_Description_check_box,					
				"IWLTC-00197,"+Widget_name+",Verify the Show Symbol as Description check box");
		com.click("xpath",Show_Symbol_as_Description_check_box,
				",Watch List,Click on Show Symbol as Description check box");
	}

	@And("^unselect the click Action check box Drop down Options is disabled or not$")
	public void unselect_the_click_Action_check_box_Drop_down_Options_is_disabled_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String click_Action_check_box = Common.readPropertyByWatch_List().getProperty("click_Action_check_box");
		com.verifyElementisSelected("xpath", click_Action_check_box,
				"IWLTC-00198,"+Widget_name+",unselect the click Action check box Drop down Options is disabled or not");
		String click_Action_Drop_down = Common.readPropertyByWatch_List().getProperty("click_Action_Drop_down");
		com.verifyElementPresent("xpath", click_Action_Drop_down,
				",Watch List,click Action check box Drop down Options is disabled or not");
	}

	@And("^Selelct the click Action check box Drop down Options is enable or not$")
	public void Selelct_the_click_Action_check_box_Drop_down_Options_is_enable_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String click_Action_check_box = Common.readPropertyByWatch_List().getProperty("click_Action_check_box");
		com.verifyElementisSelected("xpath", click_Action_check_box,
				"IWLTC-00199,"+Widget_name+",Selelct the click Action check box Drop down Options is enable or not");
		String click_Action_Drop_down = Common.readPropertyByWatch_List().getProperty("click_Action_Drop_down");
		com.verifyElementPresent("xpath", click_Action_Drop_down,
				",Watch List,click Action check box Drop down Options is enable or not");
	}

	@And("^Check Whether Click Action Drop down Options are working or not$")
	public void Check_Whether_Click_Action_Drop_down_Options_are_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String click_Action_Drop_down = Common.readPropertyByWatch_List().getProperty("click_Action_Drop_down");
		com.select_the_Drop_Down_values("xpath", click_Action_Drop_down,
				"IWLTC-00200,"+Widget_name+",Check Whether Click Action Drop down Options are working or not");
	}

	@And("^unselect the Double click Action check box Drop down Options is disabled or not$")
	public void unselect_the_Double_click_Action_check_box_Drop_down_Options_is_disabled_or_not() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Double_Click_Action_check_box_Drop_down = Common.readPropertyByWatch_List()
				.getProperty("Double_Click_Action_check_box_Drop_down");
		com.verifyElementdisable("xpath", Double_Click_Action_check_box_Drop_down,
				"IWLTC-00201,"+Widget_name+",unselect the Double click Action check box Drop down Options is disabled or not");
	}

	@And("^Selelct the Double Click Action check box Drop down Options is enable or not$")
	public void Selelct_the_Double_Click_Action_check_box_Drop_down_Options_is_enable_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Double_click_Action_check_box = Common.readPropertyByWatch_List()
				.getProperty("Double_click_Action_check_box");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Double_click_Action_check_box,
				"IWLTC-00202,"+Widget_name+",Selelct the Double Click Action check box Drop down Options is enable or not");
		com.sleepThread(2000);
		com.click("xpath", Double_click_Action_check_box,
				"IWLTC-00202,"+Widget_name+",Selelct the Double Click Action check box Drop down Options is enable or not");
		String Double_Click_Action_check_box_Drop_down = Common.readPropertyByWatch_List()
				.getProperty("Double_Click_Action_check_box_Drop_down");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Double_Click_Action_check_box_Drop_down,
				",Watch List,Double Click Action check box Drop down Options is enable or not");
	}

	@And("^Check Whether Double Click Action Drop down Options are working or not$")
	public void Check_Whether_Double_Click_Action_Drop_down_Optionsvare_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Double_Click_Action_check_box_Drop_down = Common.readPropertyByWatch_List()
				.getProperty("Double_Click_Action_check_box_Drop_down");
		com.select_the_Drop_Down_values("xpath", Double_Click_Action_check_box_Drop_down,
				"IWLTC-00203,"+Widget_name+",Check Whether Double Click Action Drop down Options are working or not");
	}

	@And("^Check Whether Show52_weeks high/low Indicatiors checkbox option is working or not$")
	public void Check_Whether_Show52_weeks_high_low_Indicatiors_checkbox_option_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Show52_weeks = Common.readPropertyByWatch_List().getProperty("Show52_weeks");
		com.verifyElementisSelected("xpath", Show52_weeks,
				"IWLTC-00204,"+Widget_name+",Check Whether Show52_weeks high low Indicatiors checkbox option is working or not");
	}

	@And("^Check Whether Active Indicator Colors are applying are not$")
	public void Check_Whether_Active_Indicator_Colors_are_applying_are_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Active_Indicator_Colors = Common.readPropertyByWatch_List().getProperty("Active_Indicator_Colors");
		com.click("xpath", Active_Indicator_Colors,
				"IWLTC-00205,"+Widget_name+",Check Whether Active Indicator Colors are applying are not");
		String More_colors = Common.readPropertyByWatch_List().getProperty("More_colors");
		com.verifyElementPresent("xpath", More_colors,
				",Watch List,More colors is showing or not in Active Indicator Colors");
	}

	@And("^Check Whether Sync Field Column Widths in Summary mode Check box is working or not$")
	public void Check_Whether_Sync_Field_Column_Widths_in_Summary_mode_Check_box_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sync_field_column = Common.readPropertyByWatch_List().getProperty("Sync_field_column");
		com.verifyElementPresent("xpath", Sync_field_column,
				"IWLTC-00206,"+Widget_name+",Check Whether Sync Field Column Widths in Summary mode Check box is working or not");
	}

	@And("^Check Whether Show Full Precision on Non-Trade data Check box is working or not$")
	public void Check_Whether_Show_Full_Precision_on_Non_Trade_data_Check_box_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Show_Full_Precision_non_trade = Common.readPropertyByWatch_List()
				.getProperty("Show_Full_Precision_non_trade");
		com.click("xpath", Show_Full_Precision_non_trade,
				"IWLTC-00207,"+Widget_name+",Check Whether Show Full Precision on Non-Trade data Check box is working or not");
	}

	@And("^Check Whether Show Full Precision on Trade data Check box is working or not$")
	public void Check_Whether_Show_Full_Precision_on_Trade_data_Check_box_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Show_Full_Precision_trade = Common.readPropertyByWatch_List().getProperty("Show_Full_Precision_trade");
		com.click("xpath", Show_Full_Precision_trade,
				"IWLTC-00208,"+Widget_name+",Check Whether Show Full Precision on Trade data Check box is working or not");
	}

	@And("^Check Whether Best Fit Check box is working or not$")
	public void Check_Whether_Best_Fit_Check_box_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Best_fit = Common.readPropertyByWatch_List().getProperty("Best_fit");
		com.verifyElementPresent("xpath", Best_fit,
				"IWLTC-00209,"+Widget_name+",Check Whether Best Fit Check box is working or not");
	}

	@Then("^Cancle button is clickable or not in Display Preferences pop$")
	public void Click_on_Cancle_button_So_that_the_changes_has_to_be_Cancled() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Apply");
		com.click("xpath", Display_Preferences_pop_Apply,
				"IWLTC-00210,"+Widget_name+",Click on Cancle button So that the changes has to be Cancled");
	}

	@And("^Click on52 Week indicator$")
	public void Click_on52_Week_indicator() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Week_indicator = Common.readPropertyByWatch_List().getProperty("Week_indicator");
		com.click("xpath", Week_indicator, "IWLTC-00211,"+Widget_name+",Click on52 Week indicator");
	}

	@Then("^Click on OK button So that the changes has to be applied$")
	public void Click_on_OK_button_So_that_the_changes_has_to_be_applied() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_ok = Common.readPropertyByWatch_List().getProperty("Display_Preferences_pop_ok");
		com.click("xpath", Display_Preferences_pop_ok,
				"IWLTC-00212,"+Widget_name+",Click on OK button So that the changes has to be applied");
		com.sleepThread(3000);

	}

	@Then("^Click on Apply button So that the changes has to be applied$")
	public void Click_on_Apply_button_So_that_the_changes_has_to_be_applied() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences_pop_Apply1 = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Apply1");
		com.click("xpath", Display_Preferences_pop_Apply1,
				"IWLTC-00213,"+Widget_name+",Verify Display Preferences pop Apply button");

	}

	@And("^verify the All edit options$")
	public void verify_the_All_edit_options() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		com.startAction();
		int size = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li"))
				.size();
		System.out.println("Edit"+size);
		for (int i = 1; i <= size; i++) {
			try {
			com.MouseOverToElement("xpath",
					"//*[@id='conta"
					+ "iner']/div/div/div/div/div[6]/div/ul/li[5]/div/ul/li[" + i + "]",
					"IWLTC-00214,"+Widget_name+",verify the All edit options");
			wl=new Watch_List();
			wl.verify_Edit();
			}catch (Exception e) {
				System.out.println("Empty li");
			}
		}
	}

	@And("^Prin option is disabled or not$")
	public void Prin_option_is_disabled_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_Preferences = Common.readPropertyByWatch_List().getProperty("Display_Preferences");
		com.verifyElementPresent("xpath", Display_Preferences, "IWLTC-00215,"+Widget_name+",Prin option is disabled or not");
	}

	@When("^Check whether fields drop down option is working or not$")
	public void Check_whether_fields_drop_down_option_is_working_or_not() throws Exception {
		com.sleepThread(8000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Time_column = Common.readPropertyByWatch_List().getProperty("Time_column");
		com.MouseOverToElement("xpath", Time_column, ",Watch List,Mouseover on Column name");
		com.sleepThread(8000);
		String fields_drop_down_option = Common.readPropertyByWatch_List().getProperty("fields_drop_down_option");
		com.click("xpath", fields_drop_down_option,
				"IWLTC-00216,"+Widget_name+",Check whether fields drop down option is working or not");
	}

	@Then("Check Whether Sort ascending option is working or not")
	public void Check_Whether_Sort_ascending_option_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_ascending_option = Common.readPropertyByWatch_List().getProperty("Sort_ascending_option");
		com.verifyElementPresent("xpath", Sort_ascending_option,
				",Watch List,mouser on Sort ascending option is working or not");
//		com.click("xpath", Sort_ascending_option,
//				"IWLTC-00217,"+Widget_name+",Check Whether Sort ascending option is working or not");

	}

	@And("^Check whether Sort descending option is working or not$")
	public void Check_whether_Sort_descending_option_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_descending_option = Common.readPropertyByWatch_List().getProperty("Sort_descending_option");
		com.verifyElementPresent("xpath", Sort_descending_option,
				",Watch List,mouser on Sort descending option is working or not");
//		com.click("xpath", Sort_descending_option,
//				"IWLTC-00218,"+Widget_name+",Check whether Sort descending option is working or not");

	}

	@And("Check whether Add New Column option is working or not")
	public void Check_whether_Add_New_Column_option_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Add_New_Column_option = Common.readPropertyByWatch_List().getProperty("Add_New_Column_option");
		com.verifyElementPresent("xpath", Add_New_Column_option,
				"IWLTC-00219,"+Widget_name+",Check whether Add New Column option is working or not");
		String Add_to_colume = Common.readPropertyByWatch_List().getProperty("Add_to_colume");
		//com.MouseOverToElement("xpath", Add_to_colume, ",Watch List,Mouse over on Add column name");
		com.verifyElementPresent("xpath", Add_to_colume, ",Watch List,Click on Add column name");
	}

	@And("^Check whether Remove This Column option is working or not$")
	public void Check_whether_Remove_This_Column_option_is_working_or_not() throws Exception {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Remove_This_Column_option = Common.readPropertyByWatch_List().getProperty("Remove_This_Column_option");
		com.verifyElementPresent("xpath", Remove_This_Column_option,
				"IWLTC-00220,"+Widget_name+",Check whether Remove This Column option is working or not");
	}

	@And("^Check Whether View Definiton option is working or not$")
	public void Check_Whether_View_Definiton_option_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String View_Definiton_option = Common.readPropertyByWatch_List().getProperty("View_Definiton_option");
		com.verifyElementPresent("xpath", View_Definiton_option,
				"IWLTC-00221,"+Widget_name+",Check Whether View Definiton option is working or not");
//		String View_Definiton = Common.readPropertyByWatch_List().getProperty("View_Definiton");
//		com.verifyElementPresent("xpath", View_Definiton, "View Definiton option is working or not");
		wl = new Watch_List();		
		wl.Click_on_my_wath_lists_Drop_Down();
		com.sleepThread(3000);
		String Server_Watch_Lists = Common.readPropertyByWatch_List().getProperty("Server_Watch_Lists");
		com.click("xpath",Server_Watch_Lists, "IWLTC-00043,"+Widget_name+",Click on Server Watch Lists");
		com.sleepThread(3000);
	}

	@And("^Click on Close Other Tabs all taba is closing or not in watch list$")
	public void Click_on_Close_Other_Tabs() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Launch_menu_widget1 = Common.readPropertyByChart().getProperty("Launch_menu_widget1");
		com.click("xpath", Launch_menu_widget1, ",Watch List,Click on first widget in Launch menu");
		String add_tab = Common.readPropertyByChart().getProperty("add_tab");
		com.click("xpath", add_tab, ",Watch List,Click on Add tab opning Launch menu or not");
		com.sleepThread(2000);
		String whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		com.click("xpath", whatch_list, ",Watch List,Click on second widget in Launch menu");
		Chart C = new Chart();
		C.Click_on_right_click_on_option_in_widget_name();
		com.sleepThread(1000);
		String Close_Other_Tabs = Common.readPropertyByChart().getProperty("Close_Other_Tabs");
		com.click("xpath", Close_Other_Tabs, "ICTC-00222,"+Widget_name+",Click on Close Other Tabs all taba is closing or not");
		com.sleepThread(1000);
		com.verifyElementPresent("xpath", add_tab, ","+Widget_name+",all tabs is closing or not");
		com.sleepThread(3000);
		wl=new Watch_List();
		wl.Click_on_Watch_List();
	}
	
	
	
	//*************************07_19_2019********************************
	  //Column set
	   @Then("^Click on default column set$")
	   public void click_on_default_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			com.sleepThread(7000);
			com.startAction();
			com.MouseOverToElement("xpath", Columnsetdropdown, "ILTC-00029,"+Widget_name+",Mouse hover on column set dropdown");
			com.click("xpath", Columnsetdropdown, "ILTC-00029,"+Widget_name+",Click on column set dropdown");			
	   }

	   @Then("^select the column set for which you want to get desired results$")
	   public void select_the_column_set_for_which_you_want_to_get_desired_results() throws Throwable {
		    String Defaultdropdown = Common.readPropertyByWatch_List().getProperty("Defaultdropdown");
			com.sleepThread(3000);
			com.startAction();
			com.MouseOverToElement("xpath", Defaultdropdown, "ILTC-00030,"+Widget_name+",Mouse hover on Default column set");
			com.click("xpath", Defaultdropdown, "ILTC-00030,"+Widget_name+",Click on Default column set");
	   }

	   @Then("^Verify the columns whether they are from selected column set or not$")
	   public void verify_the_columns_whether_they_are_from_selected_column_set_or_not() throws Throwable {
		    String Time = Common.readPropertyByWatch_List().getProperty("Timecolumnset");
			String Last = Common.readPropertyByWatch_List().getProperty("Lastcolumnset");
			String Date = Common.readPropertyByWatch_List().getProperty("Datecolumnset");
			String Open = Common.readPropertyByWatch_List().getProperty("Opencolumnset");
			String High = Common.readPropertyByWatch_List().getProperty("Highcolumnset");
			String NetChange = Common.readPropertyByWatch_List().getProperty("Netchangecolumnset");
			String Percentagechange = Common.readPropertyByWatch_List().getProperty("Percentagechangecolumnset");
			com.sleepThread(5000);
			String Timetext = "Time";
			String Lasttext = "Last";
			String Datetext = "Date";
			String Opentext = "Open";
			String Hightext = "High";
			String netchangetext = "Net Change";
			String Percentagechangetext = "% Change";
			com.verifyText("xpath", Time, Timetext, "ILTC-00030,"+Widget_name+",Verify Time text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Last, Lasttext, "ILTC-00030,"+Widget_name+",Verify Last text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Date, Datetext, "ILTC-00030,"+Widget_name+",Verify Date text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Open, Opentext, "ILTC-00030,"+Widget_name+",Verify Open Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", High, Hightext, "ILTC-00030,"+Widget_name+",Verify High Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", NetChange, netchangetext, "ILTC-00030,"+Widget_name+",Verify Net Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Percentagechange, Percentagechangetext, "ILTC-00030,"+Widget_name+",Verify % Change text column of Selected Watch List and Selected columns set is verified");
	   }
	   
	   //Duplicate column set
	   @Given("^Click on the default column set and select New$")
	   public void click_on_the_default_column_set_and_select_New() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			String Newdropdown = Common.readPropertyByWatch_List().getProperty("Newdropdown");
			com.sleepThread(6000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,"+Widget_name+",Click on Default column set");
			com.sleepThread(5000);
			//com.waitUntilElementPresent(NewColumnset);
			com.startAction();
			com.MouseOverToElement("xpath", Newdropdown, "ILTC-00030,"+Widget_name+",Click on New column set dropdown");
			com.click("xpath", Newdropdown, "ILTC-00030,"+Widget_name+",Click on New column set dropdown");
	   }

	   @Then("^Enter Name \"([^\"]*)\" of new column set$")
	   public void enter_Name_of_new_column_set(String Name) throws Throwable {
		    String Nameinput = Common.readPropertyByWatch_List().getProperty("Nameinput");
			com.sleepThread(3000);
			com.sendKeys("xpath", Nameinput, Name, "ITLC-31,"+Widget_name+",Enter the name for column set");
	   }

	   @Then("^Select the available columns and click right arrow$")
	   public void select_the_available_columns_and_click_right_arrow() throws Throwable {
		    String Optionsavailablecolumns = Common.readPropertyByWatch_List().getProperty("Optionsavailablecolumns");
			String OptionTypecolumn = Common.readPropertyByWatch_List().getProperty("Optiontype");
			String Strikecolumn = Common.readPropertyByWatch_List().getProperty("Strike");
			String rightarrow = Common.readPropertyByWatch_List().getProperty("rightarrow");
			com.sleepThread(5000);
			com.click("xpath", Optionsavailablecolumns, "ITLC-32,"+Widget_name+",click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", OptionTypecolumn, "ITLC-35,"+Widget_name+",click on optiontype in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,"+Widget_name+",Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,"+Widget_name+",click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", Strikecolumn, "ITLC-35,"+Widget_name+",click on Strike in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,"+Widget_name+",Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,"+Widget_name+",click on rightarrow to add columns");		
	   }

	   @Then("^click on save and again click on default dropdown$")
	   public void click_on_save_and_again_click_on_default_dropdown() throws Throwable {
		    String savecolumnset = Common.readPropertyByWatch_List().getProperty("Savecolumnset");
			String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			com.sleepThread(5000);
			com.click("xpath", savecolumnset, "ILTC-00029,"+Widget_name+",Click on Save column set");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,"+Widget_name+",Click on default column set");
	   }

	   @Then("^Click on New and enter the Same Name \"([^\"]*)\"$")
	   public void click_on_New_and_enter_the_Same_Name(String Name) throws Throwable {
		    String Newdropdown = Common.readPropertyByWatch_List().getProperty("Newdropdown");
			String Nameinput = Common.readPropertyByWatch_List().getProperty("Nameinput");
			com.sleepThread(5000);
			com.click("xpath", Newdropdown, "ILTC-00029,"+Widget_name+",Click on New column set");
			com.sendKeys("xpath", Nameinput, Name, "ITLC-35,"+Widget_name+",Verify entering symbol input");
	   }

	   @Then("^Add available columns by clicking on the right arrow$")
	   public void add_available_columns_by_clicking_on_the_right_arrow() throws Throwable {
		    String Optionsavailablecolumns = Common.readPropertyByWatch_List().getProperty("Optionsavailablecolumns");
			String OptionTypecolumn = Common.readPropertyByWatch_List().getProperty("Optiontype");
			String underlyingsymbol = Common.readPropertyByWatch_List().getProperty("underlyingsymbol");
			String rightarrow = Common.readPropertyByWatch_List().getProperty("rightarrow");
			com.sleepThread(3000);
			com.click("xpath", Optionsavailablecolumns, "ITLC-32,"+Widget_name+",click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", OptionTypecolumn, "ITLC-35,"+Widget_name+",click on optiontype in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath",rightarrow, "ITLC-35,"+Widget_name+",Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,"+Widget_name+",click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", underlyingsymbol, "ITLC-35,"+Widget_name+",click on underlyingsymbol in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,"+Widget_name+",Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,"+Widget_name+",click on rightarrow to add columns");
	   }

	   @Then("^click on the save and duplicate column set should not be added and click on cancel after verification$")
	   public void click_on_the_save_and_duplicate_column_set_should_not_be_added_and_click_on_cancel_after_verification() throws Throwable {
		    String Savecolumnset = Common.readPropertyByWatch_List().getProperty("Savecolumnset");
			String cancelcolumnset = Common.readPropertyByWatch_List().getProperty("cancelcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Savecolumnset, "ILTC-00029,"+Widget_name+",Click on Save column set and colum set not added");
			com.sleepThread(9000);
			com.click("xpath", cancelcolumnset, "ILTC-00029,"+Widget_name+",Click on cancel column set");
	   }
	   
	   //Editing column set
	   @Given("^Click on the columnset dropdown and then click on manage column set$")
	   public void click_on_the_columnset_dropdown_and_then_click_on_manage_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			String Managecolumnset = Common.readPropertyByWatch_List().getProperty("Managecolumnsset");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,"+Widget_name+",Click on Columnset");
			com.sleepThread(4000);
			com.click("xpath",Managecolumnset, "ILTC-00029,"+Widget_name+",Click on Manage column set"); 
	   }

	   @Then("^Select the column set that needs to be edited and click on edit$")
	   public void select_the_column_set_that_needs_to_be_edited_and_click_on_edit() throws Throwable {
		    String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String Editcolumnset = Common.readPropertyByWatch_List().getProperty("Editcolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnset, "ILTC-00029,"+Widget_name+",Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", Editcolumnset, "ILTC-00029,"+Widget_name+",Click on Edit column set");
	   }

	   @Then("^clear Name field and enter the New Name \"([^\"]*)\"$")
	   public void clear_Name_field_and_enter_the_New_Name(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByWatch_List().getProperty("Editnameinput");
			com.sleepThread(5000);
			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,"+Widget_name+",Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,"+Widget_name+",Verify entering Name input");
	   }

	   @Then("^Click on Save and verify columnset name$")
	   public void click_on_Save_and_verify_columnset_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByWatch_List().getProperty("Editsavecolumnset");
			String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,"+Widget_name+",Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(customcolumnset);
			String text ="Testcolumnset1";
			com.verifyText("xpath", customcolumnset, text, "ITLC-00029,"+Widget_name+", Verify Edited column set name");
			//com.click("xpath", closecolumnset, "ILTC-00029,"+Widget_name+",Click on cancel column set");
	   }

	   //Copy column set
	   @Given("^Select the column set that needs to be copied and Click on copy column set$")
	   public void select_the_column_set_that_needs_to_be_copied_and_Click_on_copy_column_set() throws Throwable {
		    String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String copycolumnset = Common.readPropertyByWatch_List().getProperty("copycolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnset, "ILTC-00029,"+Widget_name+",Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", copycolumnset, "ILTC-00029,"+Widget_name+",Click on Copy column set");
	   }

	   @Then("^Clear the name and enter new column set Name \"([^\"]*)\" and add column$")
	   public void clear_the_name_and_enter_new_column_set_Name_and_add_column(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByWatch_List().getProperty("Editnameinput");
		    String Optionscolumnsforcopy = Common.readPropertyByWatch_List().getProperty("Optionscolumnsforcopy");
			String Optiontypesn = Common.readPropertyByWatch_List().getProperty("optiontypesnsforcopy");
			String rightarrowforcopy = Common.readPropertyByWatch_List().getProperty("rightarrowforcopy");
			com.sleepThread(5000);
			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,"+Widget_name+",Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,"+Widget_name+",Verify entering Name input");
			com.sleepThread(3000);
			com.click("xpath", Optionscolumnsforcopy, "ITLC-32,"+Widget_name+",click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", Optiontypesn, "ITLC-35,"+Widget_name+",click on optiontypeSN in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrowforcopy, "ITLC-35,"+Widget_name+",Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrowforcopy, "ITLC-35,"+Widget_name+",click on rightarrow to add columns");
	   }

	   @Then("^Click on save and verify copied column set name$")
	   public void click_on_save_and_verify_copied_column_set_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByWatch_List().getProperty("Editsavecolumnset");
			String Copiedcustomcolumnset = Common.readPropertyByWatch_List().getProperty("Copiedcustomcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,"+Widget_name+",Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(Copiedcustomcolumnset);
			String text ="Test";
			com.verifyText("xpath", Copiedcustomcolumnset, text, "ITLC-00029,"+Widget_name+", Verify Copied column set name");
	   }
	   
	   //Delete column set
	   @Given("^Click on delete button and then click on Confirmation ok button$")
	   public void click_on_delete_button_and_then_click_on_Confirmation_ok_button() throws Throwable {
		    String Deletecolumnset = Common.readPropertyByWatch_List().getProperty("Deletecolumnset");
			String Deleteconfirmationcolumnset = Common.readPropertyByWatch_List().getProperty("Deleteconfirmationcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Deletecolumnset, "ILTC-00029,"+Widget_name+",Click on Delete Column set");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", Deleteconfirmationcolumnset, "ILTC-00029,"+Widget_name+",Mouse hover on Delete Confirmation");
			com.click("xpath", Deleteconfirmationcolumnset, "ILTC-00029,"+Widget_name+",Click on Delete Confirmation");
	   }

	   @Then("^Verify whether column set is deleted or not$")
	   public void verify_whether_column_set_is_deleted_or_not() throws Throwable {
		    String Deltedcolumnset = Common.readPropertyByWatch_List().getProperty("Deletedcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(4000);
			com.waitUntilElementPresent(Deltedcolumnset);
			String text ="Test";
			com.verifyText("xpath", Deltedcolumnset, text, "ITLC-00029,"+Widget_name+", Verify Deleted column set name");
//			com.sleepThread(4000);
//			com.click("xpath", closecolumnset, "ILTC-00029,"+Widget_name+",Click on Close");
	   }
	   
	   @And("^Delete all created column set list$")
	   public void Delete_all_created_column_set_list() throws Throwable
	   {
		   String column_set_list=Common.readPropertyByWatch_List().getProperty("column_set_list");
		   com.MouseOverToclickabl("xpath",column_set_list, ",,Delete all created column set list");
		   com.sleepThread(3000);
		   wl=new Watch_List();
		   wl.click_on_delete_button_and_then_click_on_Confirmation_ok_button();
		   
		   com.sleepThread(4000);
		   String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
		   com.click("xpath", closecolumnset, "ILTC-00029,"+Widget_name+",Click on Close");
 	   }
	   
 //Watch List dropdown
	@Given("^Click on the watch list dropdown$")
	public void click_on_the_watch_list_dropdown() throws Exception {
		String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		//com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,"+Widget_name+",Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on watch list dropdown");
	}

	@Then("^select the watch List for which you want to get results$")
	public void select_the_watch_List_for_which_you_want_to_get_results() throws Exception {
		String WatchList = Common.readPropertyByWatch_List().getProperty("WatchList");
		com.sleepThread(5000);
		//com.waitUntilElementPresent(WatchList);
		com.startAction();
		com.MouseOverToElement("xpath", WatchList, "ILTC-00030,"+Widget_name+",Mouse hover on watch list");
		com.click("xpath", WatchList, "ILTC-00030,"+Widget_name+",Click on WatchList");
	}

	@Then("^Verify the columns whether they belong to watch list or not$")
	public void verify_the_columns_whether_they_belong_to_watch_list_or_not() throws Exception {
		String Time = Common.readPropertyByWatch_List().getProperty("Time");
		String Last = Common.readPropertyByWatch_List().getProperty("Last");
		String Date = Common.readPropertyByWatch_List().getProperty("Date");
		String Open = Common.readPropertyByWatch_List().getProperty("Open");
		String High = Common.readPropertyByWatch_List().getProperty("High");
		String NetChange = Common.readPropertyByWatch_List().getProperty("NetChange");
		String Percentagechange = Common.readPropertyByWatch_List().getProperty("Percentagechange");
		com.sleepThread(5000);
		String Timetext = "Time";
		String Lasttext = "Last";
		String Datetext = "Date";
		String Opentext = "Open";
		String Hightext = "High";
		String netchangetext = "Net Change";
		String Percentagechangetext = "% Change";
		com.verifyText("xpath", Time, Timetext, "ILTC-00030,"+Widget_name+",Verify Time text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Last, Lasttext, "ILTC-00030,"+Widget_name+",Verify Last text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Date, Datetext, "ILTC-00030,"+Widget_name+",Verify Date text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Open, Opentext, "ILTC-00030,"+Widget_name+",Verify Open Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", High, Hightext, "ILTC-00030,"+Widget_name+",Verify High Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", NetChange, netchangetext, "ILTC-00030,"+Widget_name+",Verify Net Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Percentagechange, Percentagechangetext, "ILTC-00030,"+Widget_name+",Verify % Change text column of Selected Watch List and Selected Watch List verified");
	}
	
	//Adding new symbol list and verifying

 @Given("^Click on Watch List dropdown$")
 public void click_on_Watch_List_dropdown() throws Throwable {
 	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,"+Widget_name+",Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on watch list dropdown");
 }

 @Then("^Click on New in the dropdown$")
 public void click_on_New_in_the_dropdown() throws Throwable {
 	String Newwatchlist = Common.readPropertyByWatch_List().getProperty("Newwatchlist");
		com.sleepThread(4000);			
		com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", Newwatchlist, "ILTC-00030,"+Widget_name+",Mouse hiver on New");
		com.click("xpath", Newwatchlist, "ILTC-00029,"+Widget_name+",Click on New");
 }

 @Then("^Enter Symbol List Name \"([^\"]*)\" and click on Ok$")
 public void enter_Symbol_List_Name_and_click_on_Ok(String Name) throws Throwable {
 	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
 	String newsymbollistok = Common.readPropertyByWatch_List().getProperty("newsymbollistok");
 	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Symbol List Name");
		com.click("xpath", newsymbollistok, "ILTC-00029,"+Widget_name+",Click on Ok");
		
 }

 @Then("^Click on Wtachlist dropdown and Verify the Added Symbol List from dropdown$")
 public void verify_the_Added_Symbol_List_from_dropdown() throws Throwable {
	 String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
 	String NewlyAddedsymbollist = Common.readPropertyByWatch_List().getProperty("NewlyAddedsymbollist");
 	com.sleepThread(3000);
 	com.click("xpath",Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on Watch List Dropdown");
 	com.sleepThread(3000);
 	String symbollisttext = "Test";
		com.verifyText("xpath",NewlyAddedsymbollist, symbollisttext, "ILTC-00030,"+Widget_name+",Verify Newly Added Symbol List");
 }
 
 //Adding symbols to the newly added watch list
 @Given("^Click on newly added watch list$")
 public void click_on_newly_added_watch_list() throws Throwable {
 	String NewlyAddedsymbollist = Common.readPropertyByWatch_List().getProperty("NewlyAddedsymbollist");
		com.sleepThread(4000);			
		//com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", NewlyAddedsymbollist, "ILTC-00030,"+Widget_name+",Mouse hover on Newly Added symbol list");
		com.click("xpath", NewlyAddedsymbollist, "ILTC-00029,"+Widget_name+",Click on Newly Added Symbol List");
 }

 @Then("^Double click on Enter symbol and select the symbol$")
 public void double_click_on_Enter_symbol_and_select_the_symbol() throws Throwable {
 	String Symbolinput = Common.readPropertyByWatch_List().getProperty("Symbolinput");
 	String Symbolinputdropdown = Common.readPropertyByWatch_List().getProperty("Symbolinputdropdown");
 	com.sleepThread(4000);
		com.double_click_on_element("xpath", Symbolinput, "ILTC-00029,"+Widget_name+",Double Click on Symbol Input");
		com.sleepThread(4000);
		com.click("xpath", Symbolinputdropdown, "ILTC-00029,"+Widget_name+",Select the symbol input");   
 }

 @Then("^Verify whether symbol is added or not$")
 public void verify_whether_symbol_is_added_or_not() throws Throwable {
 	String Symbolinput = Common.readPropertyByWatch_List().getProperty("Symbolinput");
 	com.sleepThread(4000);
 	String symbollisttext = "AAPL";
		com.verifyText("xpath", Symbolinput, symbollisttext, "ILTC-00030,"+Widget_name+",Verify Newly Added Symbol");
 }
 
 //Duplicate symbol list
 @Given("^Click on the WatchList Dropdown$")
 public void click_on_Watch_List_Dropdown() throws Throwable {
 	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,"+Widget_name+",Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on watch list dropdown");
 }

 @Then("^Click on New dropdown$")
 public void click_on_New_dropdown() throws Throwable {
 	String Newwatchlist = Common.readPropertyByWatch_List().getProperty("Newwatchlist");
		com.sleepThread(4000);			
		com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", Newwatchlist, "ILTC-00030,"+Widget_name+",Mouse hover on New");
		com.click("xpath", Newwatchlist, "ILTC-00029,"+Widget_name+",Click on New");
 }

 @Then("^Enter same symbol list Name \"([^\"]*)\" and click on Ok$")
 public void enter_same_symbol_list_Name_and_click_on_Ok(String Name) throws Throwable {
 	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
 	String newsymbollistok = Common.readPropertyByWatch_List().getProperty("newsymbollistok");
 	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the existing Symbol List Name");
		com.click("xpath", newsymbollistok, "ILTC-00029,"+Widget_name+",Click on Ok");
 }

 @Then("^User should not be able to add so click on cancel$")
 public void user_should_not_be_able_to_add_and_click_on_cancel() throws Throwable {
 	String CancelSymbolList = Common.readPropertyByWatch_List().getProperty("CancelSymbolList");
 	com.sleepThread(3000);
		com.click("xpath", CancelSymbolList, "ILTC-00029,"+Widget_name+",User not able to add duplicate list so Click on Cancel");
 }
 
 //Save As Symbol List
 @Given("^Click on the WatchList Dropdown and click on save as$")
 public void click_on_the_WatchList_Dropdown_and_click_on_save_as() throws Throwable {
 	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
 	String SaveAs = Common.readPropertyByWatch_List().getProperty("SaveAs");
 	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", SaveAs, "ILTC-00029,"+Widget_name+",Click on Save As");
 }

 @Then("^Enter symbol list Name \"([^\"]*)\" and click on Ok$")
 public void enter_symbol_list_Name_and_click_on_Ok(String Name) throws Throwable {
 	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
 	String SaveAsOk = Common.readPropertyByWatch_List().getProperty("SaveAsOk");
 	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Save As Symbol List Name");
		com.click("xpath", SaveAsOk, "ILTC-00029,"+Widget_name+",Click on Save As Ok");
 }

 @Then("^Verify the added symbol list$")
 public void verify_the_added_symbol_list() throws Throwable {
 	String SaveAsverification = Common.readPropertyByWatch_List().getProperty("SaveAsverification");
 	com.sleepThread(4000);
 	String symboltext = "AAPL";
		com.verifyText("xpath", SaveAsverification, symboltext, "ILTC-00030,"+Widget_name+",Verify Newly Added Save As Symbol");
 }
 
 //Duplicate symbol list using Save As
 @Given("^Click on watch List dropdown and click Save As$")
 public void click_on_watch_List_dropdown_and_click_Save_As() throws Throwable {
 	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
 	String SaveAs = Common.readPropertyByWatch_List().getProperty("SaveAs");
 	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", SaveAs, "ILTC-00029,"+Widget_name+",Click on Save As for duplicate symbol list");
 }

 @Then("^Enter the exisitng Symbol List Name \"([^\"]*)\" and click on Ok$")
 public void enter_the_exisitng_Symbol_List_Name_and_click_on_Ok(String Name) throws Throwable {
 	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
 	String SaveAsOk = Common.readPropertyByWatch_List().getProperty("SaveAsOk");
 	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Save As Symbol List Name for duplicate symbol list");
		com.click("xpath", SaveAsOk, "ILTC-00029,"+Widget_name+",Click on Save As Ok");
 }

 @Then("^User should not be able to add using Save As and click on Cancel$")
 public void user_should_not_be_able_to_add_using_Save_As_and_click_on_Cancel() throws Throwable {
 	String CancelSymbolList = Common.readPropertyByWatch_List().getProperty("CancelSymbolList");
 	com.startAction();
 	com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", CancelSymbolList, "ILTC-00029,"+Widget_name+",User not able to add duplicate symbol list using Save As so Click on Cancel");
 }
 @When("^Click on Manage watchlists$")
 public void Click_on_Manage_watchlists_my_watch_lists() throws Exception
 {
	 Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
	 com.sleepThread(3000);	
	 String my_wath_list_Manage_watchlists1 = Common.readPropertyByWatch_List()
				.getProperty("my_wath_list_Manage_watchlists1");
		com.click("xpath", my_wath_list_Manage_watchlists1, ","+Widget_name+",Click on Manage watchlists...");
 }
 
 @And("^Delete the All crated my watch lists$")
 public void Delete_the_All_crated_my_watch_lists() throws Exception
 {
	 com.startAction();
		int size=driver.findElements(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[3]/div")).size();
		System.out.println("Delete on all created my watch list:"+size);
		for (int i =1; i <size; i++) {
			com.startAction();
			int value=size-i;
			com.MouseOverToclickabl("xpath","/html/body/div[7]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li["+value+"]/div[1]/span[3]/div",",,Delete on all created my watch list");
			com.sleepThread(3000);
			wl=new Watch_List();
			String Manage_watchlists_frist_save_as_label_Delete_icon1 = Common.readPropertyByWatch_List()
					.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon1");
			com.click("xpath", Manage_watchlists_frist_save_as_label_Delete_icon1,
					","+Widget_name+",Click on Delete icon in save sysmbol list pop in Manage watchlists pop");
			com.sleepThread(3000);
			String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1 = Common.readPropertyByWatch_List()
					.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1");
			com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1,
					","+Widget_name+",Click on Yes button in Remove Symbol List pop in Manage watchlists pop");
			com.sleepThread(3000);
		}
		
		com.MouseOverToclickabl("xpath","/html/body/div[7]/div/span/div[2]/div/div[2]/div/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[3]/div",",,Delete on all created my watch list");
		com.sleepThread(3000);
		wl=new Watch_List();
		String Manage_watchlists_frist_save_as_label_Delete_icon1 = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon1");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Delete_icon1,
				","+Widget_name+",Click on Delete icon in save sysmbol list pop in Manage watchlists pop");
		com.sleepThread(3000);
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1 = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes1,
				","+Widget_name+",Click on Yes button in Remove Symbol List pop in Manage watchlists pop");
		com.sleepThread(3000);
		String Manage_watchlists_cancel_button1 = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_cancel_button1");
		com.click("xpath", Manage_watchlists_cancel_button1,
				","+Widget_name+",Click on cancel button in Manage watchlists pop");
		com.sleepThread(3000);
 }
 
 //Adding new column
 @Given("^Mouse Hover and click on Time$")
 public void mouse_Hover_and_click_on_Time() throws Throwable {
 	String Time = Common.readPropertyByWatch_List().getProperty("Time");
 	String Timedropdown = Common.readPropertyByWatch_List().getProperty("Timedropdown");
 	com.sleepThread(5000);
 	com.startAction();
		com.MouseOverToElement("xpath", Time,
				"ILTC-00023,WatchList,Mouse hover on Time column");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", Timedropdown, "ILTC-00029,"+Widget_name+",Click on Time column");
 }

 @Then("^Mouse hover on Add new column and click on column that you want to add$")
 public void mouse_hover_on_Add_new_column_and_click_on_column_that_you_want_to_add() throws Throwable {
 	String Addnewcolumn = Common.readPropertyByWatch_List().getProperty("Addnewcolumn");
 	String SelectingBid = Common.readPropertyByWatch_List().getProperty("SelectingBid");
 	com.sleepThread(3000);
 	com.startAction();
		com.MouseOverToElement("xpath", Addnewcolumn,
				"ILTC-00023,WatchList,Mouse hover on Add New column");
		com.click("xpath", SelectingBid, "ILTC-00029,"+Widget_name+",Click on Bid to Add as column");
 }

 @Then("^Verify the newly added column$")
 public void verify_the_newly_added_column() throws Throwable {
 	String Bid = Common.readPropertyByWatch_List().getProperty("Bid");
 	com.sleepThread(4000);
 	String columntext = "Bid";
		com.verifyText("xpath", Bid, columntext, "ILTC-00030,"+Widget_name+",Verify Newly Added column");
 }
 
 //Removing column
 @Given("^Mouse hover and click on column you want to delete$")
 public void mouse_hover_and_click_on_column_you_want_to_delete() throws Throwable {
 	String Bid = Common.readPropertyByWatch_List().getProperty("Bid");
 	String Columndropdown = Common.readPropertyByWatch_List().getProperty("Columndropdown");
 	com.sleepThread(3000);
 	com.startAction();
		com.MouseOverToElement("xpath", Bid,
				"ILTC-00023,WatchList,Mouse hover on column that has to be deleted");
		com.click("xpath", Columndropdown, "ILTC-00029,"+Widget_name+",Click on column that has to be deleted");
 }

 @Then("^Click on Remove This column and verify column is removed or not$")
 public void click_on_Remove_This_column_and_verify_column_is_removed_or_not() throws Throwable {
 	String Removethiscolumn = Common.readPropertyByWatch_List().getProperty("Removethiscolumn");
 	String Last = Common.readPropertyByWatch_List().getProperty("Last");
 	com.sleepThread(4000);
		com.click("xpath", Removethiscolumn, "ILTC-00029,"+Widget_name+",Click on Remove This column");
		com.sleepThread(4000);
 	String columntext = "Last";
		com.verifyText("xpath", Last, columntext, "ILTC-00030,"+Widget_name+",Verify Column is deleted or not");
 }
 
 //View Definition and verification
 @Given("^Mouse Hover on Time and click on Time$")
 public void mouse_Hover_on_Time_and_click_on_Time() throws Throwable {
 	String Time = Common.readPropertyByWatch_List().getProperty("Time");
 	String Timedropdown = Common.readPropertyByWatch_List().getProperty("Timedropdown");
 	com.sleepThread(5000);
 	com.startAction();
		com.MouseOverToElement("xpath", Time,
				"ILTC-00023,WatchList,Mouse hover on Time column");
		com.click("xpath", Timedropdown, "ILTC-00029,"+Widget_name+",Click on Time column for View Definition");
 }

 @Then("^Click on View Definiton and verify the definition$")
 public void click_on_View_Definiton_and_verify_the_definition() throws Throwable {
 	String ViewDefinition = Common.readPropertyByWatch_List().getProperty("ViewDefinition");
 	String Verifydefinition = Common.readPropertyByWatch_List().getProperty("Verifydefinition");
 	com.sleepThread(4000);
		com.click("xpath", ViewDefinition, "ILTC-00029,"+Widget_name+",Click on View Definition for column");
		com.sleepThread(4000);
 	String definitiontext = "Time of the last update (Includes Bids / Asks)";
	com.verifyText("xpath", Verifydefinition, definitiontext, "ILTC-00030,"+Widget_name+",Verify Column definition");
 }
 
 //Import from file
 @Given("^Click on watch List dropdown and click on Import from file$")
 public void click_on_watch_List_dropdown_and_click_on_Import_from_file() throws Throwable {
 	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
 	String importfromfile = Common.readPropertyByWatch_List().getProperty("importfromfile");
 	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,"+Widget_name+",Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", importfromfile, "ILTC-00029,"+Widget_name+",Click on Import from file");
 }

 @Then("^Select file to upload and click on Ok$")
 public void select_file_to_upload_and_click_on_Ok() throws Throwable {
 	String BrowseFile = Common.readPropertyByWatch_List().getProperty("BrowseFile");
 	String FileUploadOk = Common.readPropertyByWatch_List().getProperty("FileUploadOk");
 	com.sleepThread(4000);
 	String Fileupload = "D:\\QA_TheIce\\HTML5\\SYMBOLS";
 	//com.sendKeys("xpath", BrowseFile, Fileupload, "ND-00060,Widgets,Upload file to import");
 	com.click("xpath", BrowseFile, "ILTC-00029,"+Widget_name+",Click on Select file to upload");
 	com.sleepThread(8000);
 	com.upload_file(Fileupload);
 	com.sleepThread(7000);
 	com.click("xpath", FileUploadOk, "ILTC-00029,"+Widget_name+",Click on Ok to upload file");
 }

@Then("^Verify Imported File$")
public void verify_imported_file() throws Exception{
	   String Importedsymbol = Common.readPropertyByWatch_List().getProperty("Importedsymbol");
	   com.sleepThread(5000);
	   String symboltext = "SYMBOLS";
	   com.verifyText("xpath", Importedsymbol, symboltext, "ILTC-00030,"+Widget_name+",Verify imported symbol file");
	   String AAPL ="AAPL";
	   com.sleepThread(8000);
	   String input_AAPL=Common.readPropertyByWatch_List().getProperty("AAPL");
	   com.verifyText("xpath",input_AAPL,AAPL, ","+Widget_name+",Verify imported symbol names");
}
//**************************
@And("^clicked on save option properties as default in Watch list$")
public void clicked_on_save_option_properties_as_defaulty() throws Exception {
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	com.startAction();
//	com.sleepThread(1000);
//	String Right_click = Common.readPropertyByoptions().getProperty("Right_click");
//	com.Rightclick("xpath", Right_click, "," + Widget_name + ",Right clicked on options data");
	com.sleepThread(2000);
	String Defaults_option = Common.readPropertyByWatch_List().getProperty("Defaults_option");
	// String
	// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
	com.mouseovercontextClick("xpath", Defaults_option, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
	com.sleepThread(2000);
	String Save_Watch_List_Properties_as_Default = Common.readPropertyByWatch_List().getProperty("Save_Watch_List_Properties_as_Default");
	com.click("xpath",Save_Watch_List_Properties_as_Default,
			"," + Widget_name + ",clicking on Default Save Options Properties as Default");
	com.sleepThread(1000);
}
@And("^Verify the title Question pop in save option properties as default in Watch list$")
public void Verify_the_title_Question_pop_in_save_option_properties_as_default() throws Exception
{
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String Question_pop = Common.readPropertyByWatch_List().getProperty("Question_pop");
	com.verifyElementPresent("xpath",Question_pop,","+ Widget_name +",Verify the title Question pop in save option properties as default");
}
@And("^Verify the Close icon in Question pop in save option properties as default in Watch list$")
public void Verify_the_Close_icon_in_Question_pop_in_save_option_properties_as_default() throws Exception
{
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String  Close_icon_in_Question_pop= Common.readPropertyByWatch_List().getProperty("Close_icon_in_Question_pop");
	com.verifyElementPresent("xpath",Close_icon_in_Question_pop,","+ Widget_name +",Verify the Close icon in Question pop in save option properties as default");
}
@And("^Verify the Yes button in Question pop in save option properties as default in Watch list$")
public void Verify_the_Yes_button_in_Question_pop_in_save_option_properties_as_default() throws Exception
{
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String  Yes_button_in_Question_pop= Common.readPropertyByWatch_List().getProperty("Yes_button_in_Question_pop");
	com.verifyElementPresent("xpath",Yes_button_in_Question_pop,","+ Widget_name +",Verify the Yes button in Question pop in save option properties as default");
}
@And("^Verify the NO button in Question pop in save option properties as default in Watch list$")
public void Verify_the_NO_button_in_Question_pop_in_save_option_properties_as_default() throws Exception
{
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String  No_button_in_Question_pop= Common.readPropertyByWatch_List().getProperty("No_button_in_Question_pop");
	com.verifyElementPresent("xpath",No_button_in_Question_pop,","+ Widget_name +",Verify the NO button in Question pop in save option properties as default");
}
@And("^Click on Close icon in Question pop in save option properties as default in Watch list$")
public void Click_on_Close_icon_in_Question_pop_in_save_option_properties_as_default() throws Exception
{
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	com.startAction();
	String  Close_icon_in_Question_pop= Common.readPropertyByWatch_List().getProperty("Close_icon_in_Question_pop");
	com.click("xpath",Close_icon_in_Question_pop,","+ Widget_name +",Click on Close icon in Question pop in save option properties as default");
	com.startAction();
	com.sleepThread(3000);
	String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
	com.Rightclick("xpath", Right_click_on_symbol, "," + Widget_name + ",Right clicked on options data");
}
@And("^Click on NO button in Question pop in save option properties as default in Watch list$")
public void Click_on_NO_button_in_Question_pop_in_save_option_properties_as_default() throws Exception {
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String  No_button_in_Question_pop= Common.readPropertyByWatch_List().getProperty("No_button_in_Question_pop");
	com.click("xpath",No_button_in_Question_pop,","+ Widget_name +",Click on NO button in Question pop in save option properties as default");
	com.startAction();
	com.sleepThread(3000);
	String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
	com.Rightclick("xpath", Right_click_on_symbol, "," + Widget_name + ",Right clicked on options data");
}
@And("^Click on Yes button in Question pop in save option properties as default in Watch list$")
public void Click_on_Yes_button_in_Question_pop_in_save_option_properties_as_default() throws Exception {
	Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
			.getText();
	String  Yes_button_in_Question_pop= Common.readPropertyByWatch_List().getProperty("Yes_button_in_Question_pop");
	com.click("xpath",Yes_button_in_Question_pop,","+ Widget_name +",Click on Yes button in Question pop in save option properties as default");
	com.click("xpath","/html/body/div[6]/div/span/div[2]/div/div[3]/div/div/button",","+ Widget_name +",Click on ok button");
		
}
@And("^clicking on Apply Default Properties to the Options in Watch list$")
public void clicking_on_Apply_Default_Properties_to_the_Options() throws Exception {
	String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
	com.Rightclick("xpath", Right_click_on_symbol, "," + Widget_name + ",Right clicked on options data");
	com.sleepThread(2000);
	// String
	// Specific_Dates=Common.readPropertyByoptions().getProperty("Specific_Dates");
	String Defaults_option = Common.readPropertyByWatch_List().getProperty("Defaults_option");
	com.mouseovercontextClick("xpath", Defaults_option, "," + Widget_name + ",mouse hover on Specific_Dates dropdown");
	com.sleepThread(2000);
	String Apply_Default_Properties_to_the_Watch_List = Common.readPropertyByWatch_List().getProperty("Apply_Default_Properties_to_the_Watch_List");
	com.click("xpath", Apply_Default_Properties_to_the_Watch_List,
			"," + Widget_name + ",clicking on Apply Default Properties to the Options");
	System.out.println("Checked defaults");
}




@And("^Symbol Linking working for all widgets$")
public void Symbol_Linking_working_for_all_widgets() throws Exception {
	
	
	wl = new Watch_List();
	Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
	String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
	com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
	int count = driver
			.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
	System.out.println(count);
	com.sleepThread(2000);

	for (int i = 1; i < 2; i++) {
		com.verifyElementPresent("xpath",
				"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00005,"+Widget_name+",Verify on each Check Functionalities");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
		wl.Click_on_my_wath_lists_Drop_Down();
		com.sleepThread(2000);
		com.click("xpath","/html/body/div[5]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li[1]/div[1]/span[2]/div","");
		com.sleepThread(4000);
		com.startAction();
		String Add_tab=Common.readPropertyByWatch_List().getProperty("Add_tab");
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		String  Chart = Common.readPropertyByChart().getProperty("Chart");
		com.sleepThread(4000);
		com.click("xpath",Chart, "ICTC-00002,Chart,Click on Chart");
		com.sleepThread(3000);
		String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(4000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
	    String watchlist_tab=Common.readPropertyByWatch_List().getProperty("watchlist_tab");
	    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);		
		int size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_size:"+size);
		for (int k = 1; k <=size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname);
			String second_widget=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			String symbol_name=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname,","+ watchlist_symbolname+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
		String watchlist_symbolname1=Common.readPropertyByWatch_List().getProperty("watchlist_symbolname");
		String watchlist_symbolname=driver.findElement(By.xpath(watchlist_symbolname1)).getText();
		//System.out.println("watchlist_symbolname:"+watchlist_symbolname);
		String second_widget=Common.readPropertyByWatch_List().getProperty("second_widget");
		//com.click("xpath",second_widget,",,Click on second widget tab");		
		String symbol_name=Common.readPropertyByWatch_List().getProperty("symbol_name");
		//com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");		
		com.sleepThread(3000);
		//String second_widget=Common.readPropertyByWatch_List().getProperty("second_widget");
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String DetailedQuotes = Common.readPropertyByDetailedQuotes().getProperty("DetailedQuotes");
		com.click("xpath", DetailedQuotes, "IDQTC-00002,Detailed Quotes,Click on Detailed Quotes");
		com.sleepThread(3000);
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(2000);		    
	    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
			int D_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
			System.out.println("symbol_D_size:"+D_size);
			for (int k = 1; k <=D_size; k++) {
				com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
				String watchlist_symbolname_D=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
				System.out.println("watchlist_symbolname:"+watchlist_symbolname_D);
				//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
				com.click("xpath",second_widget,",,Click on second widget tab");		
				//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
				com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_D,","+ watchlist_symbolname_D+"");
				com.sleepThread(3000);
			    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
				com.sleepThread(3000);
			}
			
			
			/*System.out.println("DetailedQuotes_symbolname:"+watchlist_symbolname);
			com.click("xpath",second_widget,",,Click on second widget tab");		
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String Fundamentals = Common.readPropertyByFundamentals().getProperty("Fundamentals");
		com.click("xpath", Fundamentals,"IWLTC-0000,"+Widget_name+",Clicked on Fundamentals widget");
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
		com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);
		int F_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_F_size:"+F_size);
		for (int k = 1; k <=F_size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname_F=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname_F);
			//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_F,","+ watchlist_symbolname_F+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
		/*System.out.println("Fundamentals_symbolname:"+watchlist_symbolname);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String Options = Common.readPropertyByoptions().getProperty("Options");
		com.click("xpath", Options, "IOTC-00002,Options,Click on Options");
		com.sleepThread(2000);
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
		com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);
		int O_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_O_size:"+O_size);
		for (int k = 1; k <=O_size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname_O=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname_O);
			//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_O,","+ watchlist_symbolname_O+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
				
		/*System.out.println("Options_symbolname:"+watchlist_symbolname);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(3000);
		wl.click_on_Symbol_Linking();
	}
	wl = new Watch_List();
	int count1 = driver
			.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
	System.out.println(count1);

	com.sleepThread(2000);

	for (int j = 4; j <= 10; j++) {
		com.verifyElementPresent("xpath",
				"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Verify on each Check Functionalities");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00007,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(4000);
		com.startAction();
		String Add_tab=Common.readPropertyByWatch_List().getProperty("Add_tab");
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		String  Chart = Common.readPropertyByChart().getProperty("Chart");
		com.sleepThread(4000);
		com.click("xpath",Chart, "ICTC-00002,Chart,Click on Chart");
		com.sleepThread(3000);
		String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(4000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
	    String watchlist_tab=Common.readPropertyByWatch_List().getProperty("watchlist_tab");
	    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);		
		int size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_size:"+size);
		for (int k = 1; k <=size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname);
			String second_widget=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			String symbol_name=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname,","+ watchlist_symbolname+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
		String watchlist_symbolname1=Common.readPropertyByWatch_List().getProperty("watchlist_symbolname");
		String watchlist_symbolname=driver.findElement(By.xpath(watchlist_symbolname1)).getText();
		//System.out.println("watchlist_symbolname:"+watchlist_symbolname);
		String second_widget=Common.readPropertyByWatch_List().getProperty("second_widget");
		//com.click("xpath",second_widget,",,Click on second widget tab");		
		String symbol_name=Common.readPropertyByWatch_List().getProperty("symbol_name");
		//com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");		
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String DetailedQuotes = Common.readPropertyByDetailedQuotes().getProperty("DetailedQuotes");
		com.click("xpath", DetailedQuotes, "IDQTC-00002,Detailed Quotes,Click on Detailed Quotes");
		com.sleepThread(3000);
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(2000);		    
	    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
			int D_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
			System.out.println("symbol_D_size:"+D_size);
			for (int k = 1; k <=D_size; k++) {
				com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
				String watchlist_symbolname_D=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
				System.out.println("watchlist_symbolname:"+watchlist_symbolname_D);
				//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
				com.click("xpath",second_widget,",,Click on second widget tab");		
				//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
				com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_D,","+ watchlist_symbolname_D+"");
				com.sleepThread(3000);
			    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
				com.sleepThread(3000);
			}
			
			
			/*System.out.println("DetailedQuotes_symbolname:"+watchlist_symbolname);
			com.click("xpath",second_widget,",,Click on second widget tab");		
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String Fundamentals = Common.readPropertyByFundamentals().getProperty("Fundamentals");
		com.click("xpath", Fundamentals,"IWLTC-0000,"+Widget_name+",Clicked on Fundamentals widget");
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
		com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);
		int F_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_F_size:"+F_size);
		for (int k = 1; k <=F_size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname_F=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname_F);
			//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_F,","+ watchlist_symbolname_F+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
		/*System.out.println("Fundamentals_symbolname:"+watchlist_symbolname);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath",Add_tab,"IWLTC-0000,"+Widget_name+",Click on add tab button");
		com.sleepThread(3000);
		String Options = Common.readPropertyByoptions().getProperty("Options");
		com.click("xpath", Options, "IOTC-00002,Options,Click on Options");
		com.sleepThread(2000);
		com.click("xpath",Widget_tab, "ICTC-00002,Chart,Click on widget tab");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking, "IWLTC-00004,"+Widget_name+",Click on Symbol Linking");
		com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
				"IWLTC-00006,"+Widget_name+",Click on each Check Functionalities");
		com.sleepThread(3000);
		com.click("xpath",watchlist_tab,",,Click on watchlist tab");
		com.sleepThread(3000);
		int O_size=driver.findElements(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div/div/div/div[1]")).size();
		System.out.println("symbol_O_size:"+O_size);
		for (int k = 1; k <=O_size; k++) {
			com.click("xpath","//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]","IWLTC-0000,"+Widget_name+",Click on each symbol");
			String watchlist_symbolname_O=driver.findElement(By.xpath("//*[contains(@class,'ice-grid-cnt ice-grid-vbox noselect')]/div[2]/div[1]/div[1]/div[1]/div[1]/div["+k+"]/div/div/div[1]")).getText();
			System.out.println("watchlist_symbolname:"+watchlist_symbolname_O);
			//String second_widget_D=Common.readPropertyByWatch_List().getProperty("second_widget");
			com.click("xpath",second_widget,",,Click on second widget tab");		
			//String symbol_name_D=Common.readPropertyByWatch_List().getProperty("symbol_name");
			com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname_O,","+ watchlist_symbolname_O+"");
			com.sleepThread(3000);
		    com.click("xpath",watchlist_tab,",,Click on watchlist tab");
			com.sleepThread(3000);
		}
				
		/*System.out.println("Options_symbolname:"+watchlist_symbolname);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		com.verify_text_box_text("xpath",symbol_name, watchlist_symbolname, "");*/
		com.sleepThread(3000);
		com.click("xpath",second_widget,",,Click on second widget tab");		
		//String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
		com.sleepThread(1000);
		//String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(3000);
		wl.click_on_Symbol_Linking();
	}
	
			
}










}

	
	
	
	
	
	
	
