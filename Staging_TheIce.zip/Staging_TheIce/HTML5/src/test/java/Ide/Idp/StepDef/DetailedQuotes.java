package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DetailedQuotes {
	
	private static String Widget_name = null;
	public Common com = new Common();
	public DetailedQuotes DQ;
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public DetailedQuotes() {
		driver = Common.driver;
		login = Common.readPropertyByDetailedQuotes().getProperty("Login_button");
	}
	
	// Verify_the_login_page_Logo
	@Given("^open browser$")
	public void open_the_web_browser() throws Throwable {
		com.Setup("Chrome", "ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// https://ida-idp.qa.market-q.com/ida-idp/
		com.maximiseBrowser();
	}

	@When("^Verify ice portal logo$")
	public void verify_the_ice_portal_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByDetailedQuotes().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Login,Verify the logo");
	}
    
	//Login
	@Given("^Login with the IDE IDP credentials of the Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void login_with_the_IDE_IDP_credentials_of_ICE_Username_and_Password(String Username, String Password) throws Throwable {
		un = Common.readPropertyByDetailedQuotes().getProperty("User_name");
		Pws = Common.readPropertyByDetailedQuotes().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(5000);
		com.sendKeys("xpath", un, Username,
				"ILTC-00023,Login,Enter the correct username and are given in associated text fields");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Login,Enter the correct password are given in associated text fields");
	}

	@Then("^Click the user login button$")
	public void click_on_the_user_login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Login,Click on login button");
		TimeUnit.MINUTES.sleep(3);
		// com.stopRecording();
	}
	
	//Verify and click on Detailed Quotes
	@Given("^Verify the Detailed Quotes$")
	public void Verify_the_Detailed_Quotes() throws Exception {
		com.sleepThread(12000);
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String DetailedQuotes = Common.readPropertyByDetailedQuotes().getProperty("DetailedQuotes");
		System.out.println(DetailedQuotes);		
		com.verifyElementPresent("xpath", DetailedQuotes, "IDQTC-00001,Detailed Quotes,Verify the Detailed Quotes");
	}

	@And("^Click on Detailed Quotes$")
	public void Click_on_Watch_List() throws Exception {
		com.sleepThread(12000);	
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String DetailedQuotes = Common.readPropertyByDetailedQuotes().getProperty("DetailedQuotes");
		com.click("xpath", DetailedQuotes, "IDQTC-00002,Detailed Quotes,Click on Detailed Quotes");
	}
	
	//Symbol Linking verification
	@When("^Verify the Symbol Linking in detailed quotes$")
	public void Verify_the_Symbol_Linking_in_detailed_quotes() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByDetailedQuotes().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking, "IDQTC-00003,"+Widget_name+",Verify the Symbol Linking");
	}

	@And("^Click on Symbol Linking in detailed quotes$")
	public void click_on_Symbol_Linking_in_detailed_quotes() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Symbol_Linking = Common.readPropertyByDetailedQuotes().getProperty("Symbol_Linking");
		com.click("xpath", Symbol_Linking, "IDQTC-00004,"+Widget_name+",Click on Symbol Linking");
	}

	@And("^click on each Check Functionalities in symbol linking$")
	public void check_Functionalities_in_symbol_linking() throws Exception {
		DQ = new DetailedQuotes();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		int count = driver
				.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li/button[1]")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li[" + i + "]/button[1]",
					"IDQTC-00005,"+Widget_name+",Verify on each Check Functionalities");
			com.sleepThread(1000);
			com.click("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li[" + i + "]/button[1]",
					"IDQTC-00006,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			DQ.click_on_Symbol_Linking_in_detailed_quotes();
		}

		/*
		 * com.verifyElementPresent("xpath",
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+i+"]/button/label"
		 * ); String t=driver.findElement(By.xpath(
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[\"+i+\"]/button/label"
		 * )).getText(); System.out.println(t+"****************");
		 * com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+
		 * i+"]/button/label"); com.sleepThread(3000);
		 */

		DQ = new DetailedQuotes();
		int count1 = driver
				.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li/button[1]")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li[" + j + "]/button[1]",
					"IDQTC-00005,"+Widget_name+",Verify on each Check Functionalities");
			com.sleepThread(1000);
			com.click("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/ul[1]/li[" + j + "]/button[1]",
					"IDQTC-00006,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			DQ.click_on_Symbol_Linking_in_detailed_quotes();
		}
	}

	//Symbol verification
	@Given("^Click on the symbol input and clear the input field$")
	public void click_on_the_symbol_and_clear_the_inout_field() throws Throwable {
		com.sleepThread(4000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Symbolinput = Common.readPropertyByDetailedQuotes().getProperty("Symbolinput");
		com.click("xpath", Symbolinput, "IDQTC-00007,"+Widget_name+",Click on Symbol Input");
		com.sleepThread(2000);
		com.ClearTextField("xpath", Symbolinput, "IDQTC-00008,"+Widget_name+",Clear symbol input");
	}

	@Then("^Enter the symbol \"([^\"]*)\" and select it from the dropdown$")
	public void enter_the_symbol_and_select_it_from_the_dropdown(String symbol) throws Throwable {
		com.sleepThread(4000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Symbolinput = Common.readPropertyByDetailedQuotes().getProperty("Symbolinput");
		String symbolinputdropdown = Common.readPropertyByDetailedQuotes().getProperty("symbolinputdropdown");
		com.sendKeys("xpath", Symbolinput, symbol, "IDQTC-00009,"+Widget_name+",Enter symbol");
		com.sleepThread(2000);
		com.click("xpath",symbolinputdropdown, "IDQTC-00010,"+Widget_name+",Click on Symbol Input Dropdown");
	    
	}

	@Then("^Verify the symbol entered$")
	public void verify_the_symbol_entered() throws Throwable {
		com.sleepThread(4000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String IBM = Common.readPropertyByDetailedQuotes().getProperty("IBM");
		com.sleepThread(9000);
		String Symbolname = "IBM";
		try{
		com.verifyText("xpath", IBM, Symbolname, "IDQTC-00011,"+Widget_name+",Verify the symbol name");
		}catch(Exception t){
			com.sleepThread(9000);
			com.verifyElementPresent("xpath",IBM,"IDQTC-00011,"+Widget_name+",Verify the symbol name");
		}
		}
	
	@Then("^Click on different DQ chart time intervals$")
	public void Click_on_different_chart_time_intervals() throws Throwable {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String ScaleCheckbox = Common.readPropertyByDetailedQuotes().getProperty("ScaleCheckbox");
		String One_D = Common.readPropertyByDetailedQuotes().getProperty("1D");
		String One_M = Common.readPropertyByDetailedQuotes().getProperty("1M");
		String Three_M = Common.readPropertyByDetailedQuotes().getProperty("3M");
		String Six_M = Common.readPropertyByDetailedQuotes().getProperty("6M");
		String One_Y = Common.readPropertyByDetailedQuotes().getProperty("1Y");
		String Five_Y = Common.readPropertyByDetailedQuotes().getProperty("5Y");
		com.sleepThread(3000);
		com.click("xpath", ScaleCheckbox, "IDQTC-00012,"+Widget_name+",Click on Scale CheckBox");
		com.sleepThread(3000);
		com.click("xpath", One_D, "IDQTC-00013,"+Widget_name+",Click on 1D");
		com.sleepThread(3000);
		com.click("xpath", One_M, "IDQTC-00014,"+Widget_name+",Click on 1M");
		com.sleepThread(3000);
		com.click("xpath", Three_M, "IDQTC-00015,"+Widget_name+",Click on 3M");
		com.sleepThread(3000);
		com.click("xpath", Six_M, "IDQTC-00016,"+Widget_name+",Click on 6M");
		com.sleepThread(3000);
		com.click("xpath", One_Y, "IDQTC-00017,"+Widget_name+",Click on 1Y");
		com.sleepThread(3000);
		com.click("xpath", Five_Y, "IDQTC-00018,"+Widget_name+",Click on 6Y");
	}
	
	//Verifying Fields and its options
	@Given("^Right click on the window and hover on fields and click on each options in the fields$")
	public void right_click_on_the_window_and_hover_on_fields() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Fields = Common.readPropertyByDetailedQuotes().getProperty("Fields");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00019,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Fields, "IDQTC-00020,"+Widget_name+",Mouse hover on fields");
		com.sleepThread(1000);
		for (int i = 3; i <= 11; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[" + i + "]/button",
					"IDQTC-00021,"+Widget_name+",Click on each fields optons");
			com.sleepThread(3000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00019,"+Widget_name+", Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Fields, "IDQTC-00020,"+Widget_name+",Mouse hover on fields");
            com.sleepThread(1000);
		}
	}
	
	//Verifying New Option
//	@Given("^Righ click on window and hover on fields$")
//	public void righ_click_on_window_and_hover_on_fields() throws Throwable {
//	    
//	}

	@Given("^Click on Customize$")
	public void click_on_Customize() throws Throwable {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Customize = Common.readPropertyByDetailedQuotes().getProperty("Customize");
		com.sleepThread(1000);
		com.click("xpath", Customize, "IDQTC-00021,"+Widget_name+",Click On Customize");
	}

	@Then("^Click on New and enter the name of field \"([^\\\"]*)\"$")
	public void click_on_New_and_enter_the_name_of_field(String field) throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String New = Common.readPropertyByDetailedQuotes().getProperty("New");
		String Enter_name = Common.readPropertyByDetailedQuotes().getProperty("Enter_name");
		com.sleepThread(1000);
		com.click("xpath", New, "IDQTC-00022,"+Widget_name+",Click On New");
		com.sleepThread(3000);
		com.sendKeys("xpath", Enter_name, field, "IDQTC-00023,"+Widget_name+",Enter the name of column set");
	}

	@Then("^Click on arrow to add all the columns$")
	public void click_on_arrow_to_add_all_the_columns() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Select_arrow = Common.readPropertyByDetailedQuotes().getProperty("Select_arrow");
		String AddAllcolumns = Common.readPropertyByDetailedQuotes().getProperty("AddAllcolumns");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Select_arrow, "IDQTC-00024,"+Widget_name+",Mouse hover On Arrow to add columns");
		com.sleepThread(2000);
		com.click("xpath", Select_arrow, "IDQTC-00025,"+Widget_name+",Click On Arrow to add columns");
	}

	@Then("^Click on save and verify the added column set$")
	public void click_on_save_and_verify_the_added_column_set() throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String customcolumnset = Common.readPropertyByDetailedQuotes().getProperty("customcolumnset");
		com.sleepThread(1000);
		com.click("xpath", Save, "IDQTC-00026,"+Widget_name+",Click On Save");
		com.sleepThread(3000);
		String newcustomcolumnset = "Autest";
		com.verifyText("xpath", customcolumnset, newcustomcolumnset, "IDQTC-00026,"+Widget_name+",Verify newly added column set");
	}
	
	//Verifying Edit column set
	@Given("^Click on Edit$")
	public void click_on_Edit_and_clear_the_name_input() throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Edit = Common.readPropertyByDetailedQuotes().getProperty("Edit");
		com.sleepThread(2000);
		com.click("xpath", Edit, "IDQTC-00027,"+Widget_name+",Click On Edit");
//		com.sleepThread(3000);
//	    com.ClearTextField("xpath", Enter_name, "IDQTC-00028,"+Widget_name+",Clear name input for edit");
	}

	@Given("^Enter the name of field \"([^\"]*)\"$")
	public void enter_the_name_of_field(String field) throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Enter_name = Common.readPropertyByDetailedQuotes().getProperty("Enter_name");
		com.sendKeys("xpath", Enter_name, field, "IDQTC-00029,"+Widget_name+",Enter the Name for edit column set");
	}

	@Then("^Click on save and verify the Edited column set$")
	public void click_on_save_and_verify_the_Edited_column_set() throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String Editedcustomcolumnset = Common.readPropertyByDetailedQuotes().getProperty("Editedcustomcolumnset");
		com.sleepThread(2000);
		com.click("xpath", Save, "IDQTC-00030,"+Widget_name+",Click On Save for Edit");
		com.sleepThread(3000);
		String editedcolumnset = "Autest1";
		com.verifyText("xpath", Editedcustomcolumnset, editedcolumnset, "IDQTC-00031,"+Widget_name+",Verify newly edited column set");
	}

	//Verify Copied column set
	@Given("^Click on Copy and enter the columnset name \"([^\\\"]*)\"$")
	public void click_on_Copy_and_enter_the_columnset_name(String name) throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Copy = Common.readPropertyByDetailedQuotes().getProperty("Copy");
		String Enter_name = Common.readPropertyByDetailedQuotes().getProperty("Enter_name");
		com.sleepThread(2000);
		com.click("xpath", Copy, "IDQTC-00032,"+Widget_name+",Click On Copy");
		com.sleepThread(3000);
	    com.sendKeys("xpath", Enter_name, name, "IDQTC-00033,"+Widget_name+",Enter the name for copying column set");
	}

	@Then("^Select the column to remove and click on back arrow$")
	public void select_the_column_to_remove_and_click_on_back_arrow() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String columntoremove = Common.readPropertyByDetailedQuotes().getProperty("columntoremove");
		String removecolumarrow = Common.readPropertyByDetailedQuotes().getProperty("removecolumarrow");
		String removecolumn = Common.readPropertyByDetailedQuotes().getProperty("removecolumn");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", columntoremove, "IDQTC-00034,"+Widget_name+",Mouse hover On Column to remove");
		com.sleepThread(1000);
		com.click("xpath", columntoremove, "IDQTC-00035,"+Widget_name+",Click On Column to remove");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", removecolumarrow, "IDQTC-00036,"+Widget_name+",Mouse hover On back arrow");
		com.sleepThread(2000);
		com.click("xpath", removecolumarrow, "IDQTC-00037,"+Widget_name+",Click On back arrow to remove");
	}

	@Then("^Click on save and verify the copied column set$")
	public void click_on_save_and_verify_the_copied_column_set() throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String copiedcolumnsset = Common.readPropertyByDetailedQuotes().getProperty("copiedcolumnsset");
		com.sleepThread(2000);
		com.click("xpath", Save, "IDQTC-00038,"+Widget_name+",Click On Save for copy");
		com.sleepThread(3000);
		String copiedcolumnset = "CopyAutest";
		com.verifyText("xpath", copiedcolumnsset, copiedcolumnset, "IDQTC-00039,"+Widget_name+",Verify newly copied column set");  
	}
	
	//Verify Delete option
	@Given("^Click on Delete and then click on Yes$")
	public void click_on_Delete_and_then_click_on_Yes() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Delete = Common.readPropertyByDetailedQuotes().getProperty("Delete");
		String Yes = Common.readPropertyByDetailedQuotes().getProperty("Yes");
		com.sleepThread(2000);
		com.click("xpath", Delete, "IDQTC-00040,"+Widget_name+",Click On Delete columnset");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Yes, "IDQTC-00041,"+Widget_name+",Mouse hover On Yes");
		com.sleepThread(1000);
		com.click("xpath", Yes, "IDQTC-00042,"+Widget_name+",Click On Yes");
	}

	@Then("^Verify the deleted column set and click on close$")
	public void verify_the_deleted_column_set() throws Throwable {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String copiedcolumnsset = Common.readPropertyByDetailedQuotes().getProperty("copiedcolumnsset");
		String Close = Common.readPropertyByDetailedQuotes().getProperty("Close");
		com.sleepThread(1000);
		String deletedtext = "Autest1";
		com.verifyTextnotdisplaying("xpath", copiedcolumnsset, deletedtext, "IDQTC-00043,"+Widget_name+",Verify Column set deleted or not");
	    com.sleepThread(2000);
	    com.click("xpath", Close, "IDQTC-00044,"+Widget_name+",Click On Close");   
	}
	
	//Verify save As option
	@Given("^Right click on widget and click on close tab$")
	public void right_click_on_widget_and_click_on_close_tab() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Widget_name = Common.readPropertyByDetailedQuotes().getProperty("Widget_name");
		String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Widget_name, "IDQTC-00045,"+Widget_name+",Mouse hover on detailed quotes");
		com.sleepThread(1000);
		com.Rightclick("xpath", Widget_name, "IDQTC-00046,"+Widget_name+",right click On detailed quotes");
		com.sleepThread(1000);
		com.click("xpath", Closetab, "IDQTC-00047,"+Widget_name+",click On close tab");
	}

	@Then("^Click on Detailed Quotes and right click on window$")
	public void click_on_Detailed_Quotes_and_right_click_on_window() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String DetailedQuotes = Common.readPropertyByDetailedQuotes().getProperty("DetailedQuotes");
		com.sleepThread(2000);
		com.click("xpath", DetailedQuotes, "IDQTC-00048,Detailed Quotes,click On detailed quotes");
		com.sleepThread(5000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00049,Detailed Quotes,right click On detailed quotes");	
	}
	
	@Then("^Hover on fields and click on CopyAuTest$")
	public void Hover_on_fields_and_click_on_copyautest() throws Throwable {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Fields = Common.readPropertyByDetailedQuotes().getProperty("Fields");
		String CopyAuTest = Common.readPropertyByDetailedQuotes().getProperty("CopyAuTest");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Fields, "IDQTC-00050,"+Widget_name+",Mouse hover on fields");
		com.sleepThread(1000);
		com.click("xpath", CopyAuTest, "IDQTC-00051,"+Widget_name+",click On CopyAuTest");
	}

	@Then("^Right click and Hover on fields and click on Save As$")
	public void right_click_and_hover_on_fields_and_click_on_Save_As() throws Throwable {
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Fields = Common.readPropertyByDetailedQuotes().getProperty("Fields");
		String Save_as = Common.readPropertyByDetailedQuotes().getProperty("Save_as");
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		com.sleepThread(5000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00049,Detailed Quotes,right click On detailed quotes");	
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Fields, "IDQTC-00050,"+Widget_name+",Mouse hover on fields");
		com.sleepThread(1000);
		com.click("xpath", Save_as, "IDQTC-00051,"+Widget_name+",click On Save As..");
	}

	@Then("^Enter the name \"([^\"]*)\" and click on save$")
	public void enter_the_name_and_click_on_price_and_volume(String name) throws Throwable {
		com.startAction();
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Enter_name = Common.readPropertyByDetailedQuotes().getProperty("Enter_name");
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String Priceandvolume = Common.readPropertyByDetailedQuotes().getProperty("Priceandvolume");
		com.sleepThread(1000);
		com.sendKeys("xpath", Enter_name, name, "IDQTC-00052,"+Widget_name+",Enter the name for save as..");
		com.sleepThread(3000);
		com.click("xpath", Save, "IDQTC-00058,"+Widget_name+",Click on Save for save as..");
		com.sleepThread(2000);
//		com.MouseOverToElement("xpath", Priceandvolume, "IDQTC-00053,"+Widget_name+",Mouse hover on price and volume");
//		com.sleepThread(3000);
//		com.click("xpath", Priceandvolume, "IDQTC-00054,"+Widget_name+",Click on price and volume");	    
	}

	@Then("^Click on Ask size column and click on arrow to add$")
	public void click_on_Ask_size_column_and_click_on_arrow_to_add() throws Throwable {
		com.startAction();
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String AskSize = Common.readPropertyByDetailedQuotes().getProperty("AskSize");
		String Addcolumnarrow = Common.readPropertyByDetailedQuotes().getProperty("Addcolumnarrow");
		com.sleepThread(1000);
		com.click("xpath", AskSize, "IDQTC-00055,"+Widget_name+",Click on Ask Size");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Addcolumnarrow, "IDQTC-00056,"+Widget_name+",Mouse hover on Add Arrow");
		com.sleepThread(1000);
		com.click("xpath", Addcolumnarrow, "IDQTC-00057,"+Widget_name+",Click on Add column arrow");
	}

	@Then("^click on save$")
	public void click_on_save_and_right_click_on_window() throws Throwable {
		com.startAction();
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		com.sleepThread(1000);
		com.click("xpath", Save, "IDQTC-00058,"+Widget_name+",Click on Save for save as..");
		com.sleepThread(2000);
	}


	
	//Verifying View and its options
	@Given("^Right click on window and verify view option$")
	public void right_click_on_window_and_verify_view_option() throws Throwable {
		com.startAction();
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String View = Common.readPropertyByDetailedQuotes().getProperty("View");
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00059,"+Widget_name+",Right click on window for view");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", View, "IDQTC-00060,"+Widget_name+",Verify whether view is present or not");
	}

	@Then("^Click on sub menus in view option and verify each option$")
	public void click_on_sub_menus_in_view_option_and_verify_each_option() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String View = Common.readPropertyByDetailedQuotes().getProperty("View");
		com.MouseOverToElement("xpath", View, "IDQTC-00061,"+Widget_name+",mouse over on view option");
		int size = driver.findElements(By.xpath("//*[@id='container']/div//ul/li[3]/div/ul/li"))
				.size();
		System.out.println(size);
		com.sleepThread(2000);
		for (int i = 1; i <= 3; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id='container']/div//ul/li[3]/div/ul/li[" + i + "]",
					"IDQTC-00062,Charts,Click on submenus in view option");
			com.sleepThread(3000);
			String second_widget = Common.readPropertyByDetailedQuotes().getProperty("second_widget");
			String widgetname = driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("second_widget"))).getText();
			com.verifyText("xpath", second_widget, widgetname, "ICTC-00063,"+Widget_name+",Verify " + widgetname + " widget name");
			com.sleepThread(3000);
			com.Rightclick("xpath", second_widget, "ICTC-00064,"+Widget_name+",Right click on new widget name");
			com.sleepThread(3000);
			String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
			com.click("xpath", Closetab, "ICTC-00065,"+Widget_name+",Click on Close Tab and verify the tab is closing or not");
			com.sleepThread(5000);
			String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
			com.Rightclick("xpath", Rightclick,
					"ICTC-00066,Charts,Right click on window");
			com.MouseOverToElement("xpath", View, "ICTC-00067,"+Widget_name+",mouse over on view option");
			com.sleepThread(3000);
       
		}
		com.sleepThread(4000);
		com.click("xpath", View, "ICTC-00068,"+Widget_name+",Click on View");
	}
	
	//Verify Font size and its option
	@Given("^Right click on the window and hover on font size and click on each options in the Font size$")
	public void click_on_sub_menus_in_Font_Size_option_and_verify_each_option() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Fontsize = Common.readPropertyByDetailedQuotes().getProperty("Fontsize");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00069,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Fontsize, "IDQTC-00070,"+Widget_name+",Mouse hover on font size");
		com.sleepThread(1000);
		for (int i = 1; i <= 4; i++) {
			com.click("xpath", "//*[@id='container']/div//ul/li[5]/div/ul/li[" + i + "]",
					"IDQTC-00071,"+Widget_name+",Click on each font size optons");
			com.sleepThread(3000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00072,"+Widget_name+", Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Fontsize, "IDQTC-00073,"+Widget_name+",Mouse hover on font size");
            com.sleepThread(1000);
		}
		com.click("xpath", Fontsize, "IDQTC-00074,"+Widget_name+",Click on font size");
	}
	
	//Verify Font color and its option
	@Given("^Right click on the window and hover on font color and click on each options in the Font color$")
	public void click_on_sub_menus_in_Font_color_option_and_verify_each_option() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Fontcolor = Common.readPropertyByDetailedQuotes().getProperty("Fontcolor");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00075,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Fontcolor, "IDQTC-00076,"+Widget_name+",Mouse hover on font color");
		com.sleepThread(1000);
		for (int i = 1; i <= 6; i++) {
			com.click("xpath", "//*[@id='container']/div//ul/li[6]/div/ul/li[" + i + "]",
					"IDQTC-00077,"+Widget_name+",Click on each font size optons");
			com.sleepThread(3000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00078,"+Widget_name+", Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Fontcolor, "IDQTC-00079,"+Widget_name+",Mouse hover on font color");
            com.sleepThread(1000);
		}
		com.click("xpath", Fontcolor, "IDQTC-00080,"+Widget_name+",Click on font color");
	}
	
	//Verify bold and italic, clear cell styles options
	@Given("^Right click on the window and verify bold is present or not$")
	public void right_click_on_the_window_and_verify_bold_is_present_or_not() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Bold = Common.readPropertyByDetailedQuotes().getProperty("Bold");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00081,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Bold, "IDQTC-00082,"+Widget_name+",verify bold option");
	}

	@Then("^Click on Bold$")
	public void click_on_Bold() throws Throwable {
		com.sleepThread(4000);;
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Bold = Common.readPropertyByDetailedQuotes().getProperty("Bold");
		com.sleepThread(1000);
		com.click("xpath", Bold, "IDQTC-00083,"+Widget_name+", click on bold");
	}

	@Then("^Right click on window and verify italic is present or not$")
	public void right_click_on_window_and_verify_italic_is_present_or_not() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Italic = Common.readPropertyByDetailedQuotes().getProperty("Italic");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00084,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Italic, "IDQTC-00085,"+Widget_name+",verify italic option");
	}

	@Then("^Click on Italic$")
	public void click_on_Italic() throws Throwable {
		com.sleepThread(4000);;
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Italic = Common.readPropertyByDetailedQuotes().getProperty("Italic");
		com.sleepThread(1000);
		com.click("xpath", Italic, "IDQTC-00086,"+Widget_name+", click on Italic");
	}
	
	@Then("^Right click on window and verify Clear cell styles is present or not$")
	public void right_click_on_window_and_verify_clear_cell_styles_is_present_or_not() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String ClearCellStyles = Common.readPropertyByDetailedQuotes().getProperty("ClearCellStyles");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00087,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", ClearCellStyles, "IDQTC-00088,"+Widget_name+",verify Clear CellS tyles option");
	}

	@Then("^Click on Clear Cell Styles$")
	public void click_on_clear_cell_styles() throws Throwable {
		com.sleepThread(4000);;
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String ClearCellStyles = Common.readPropertyByDetailedQuotes().getProperty("ClearCellStyles");
		com.sleepThread(1000);
		com.click("xpath", ClearCellStyles, "IDQTC-00089,"+Widget_name+", click on Clear Cell Styles");
	}
	
	//Verify Insert and its option
	@Given("^Right click on the window and hover on Insert and click on each options in the Insert$")
	public void click_on_sub_menus_in_insert_option_and_verify_each_option() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Insert = Common.readPropertyByDetailedQuotes().getProperty("Insert");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00090,"+Widget_name+", Right click on window");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Insert, "IDQTC-00091,"+Widget_name+",Mouse hover on Insert");
		com.sleepThread(2000);
		for (int i = 1; i <= 2; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[10]/div/ul/li[" + i + "]",
					"IDQTC-00021,"+Widget_name+",Click on each insert options");
			com.sleepThread(4000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00092,"+Widget_name+", Right click on window");
			com.sleepThread(3000);
			com.MouseOverToElement("xpath", Insert, "IDQTC-00093,"+Widget_name+",Mouse hover on Insert");
            com.sleepThread(2000);
		}
		com.click("xpath", Insert, "IDQTC-00094,"+Widget_name+",Click on Insert");
	}
	
	//Verify Delete and its option
	@Given("^Right click on the window and hover on Delete and click on each options in the Delete$")
	public void click_on_sub_menus_in_delete_option_and_verify_each_option() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Delete1 = Common.readPropertyByDetailedQuotes().getProperty("Delete1");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00095,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Delete1, "IDQTC-00096,"+Widget_name+",Mouse hover on Delete");
		com.sleepThread(1000);
		for (int i = 1; i <= 2; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id='container']/div//ul/li[11]/div/ul/li[" + i + "]",
					"IDQTC-00097,"+Widget_name+",Click on each font size optons");
			com.sleepThread(3000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00098,"+Widget_name+", Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Delete1, "IDQTC-00099,"+Widget_name+",Mouse hover on Delete");
            com.sleepThread(1000);
		}
		com.click("xpath", Delete1, "IDQTC-00100,"+Widget_name+",Click on Delete");
	}
	
	//Verify Default and its option
//	@Given("^Right click on the window and hover on Default and click on each options in the Default$")
//	public void click_on_sub_menus_in_default_option_and_verify_each_option() throws Throwable {
//		com.sleepThread(4000);
//		com.startAction();
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
//		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
//		String Default = Common.readPropertyByDetailedQuotes().getProperty("Default");
//		String Overwriteyes = Common.readPropertyByDetailedQuotes().getProperty("Overwriteyes");
//		com.sleepThread(1000);
//		com.Rightclick("xpath", Rightclick, "IDQTC-00101,"+Widget_name+", Right click on window");
//		com.sleepThread(2000);
//		com.MouseOverToElement("xpath", Default, "IDQTC-00102,"+Widget_name+",Mouse hover on Default");
//		com.sleepThread(1000);
//		for (int i = 1; i <= 2; i++) {
//			com.MouseOverToclickabl("xpath", "//*[@id='container']/div//ul/li[15]/div/ul/li[" + i + "]",
//					"IDQTC-00021,"+Widget_name+",Click on each font size optons");
//			com.sleepThread(3000);
//			com.Rightclick("xpath", Rightclick, "IDQTC-00103,"+Widget_name+", Right click on window");
//			com.sleepThread(2000);
//			com.MouseOverToElement("xpath", Default, "IDQTC-00104,"+Widget_name+",Mouse hover on Default");
//            com.sleepThread(1000);
//		}
////		com.click("xpath", Overwriteyes, "IDQTC-00104,"+Widget_name+",Click on overwrite Yes");
////		com.sleepThread(2000);
////		com.click("xpath", Overwriteyes, "IDQTC-00104,"+Widget_name+",Click on overwrite Ok");
////		com.sleepThread(2000);
//		com.click("xpath", Default, "IDQTC-00105,"+Widget_name+",Click on Default");
//	}
	
	@Given("^Right click and Hover on defaults and click on Save default properties to the detailed quotes$")
	public void hover_on_defaults_and_click_on_Save_default_properties_to_the_detailed_quotes() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Default = Common.readPropertyByDetailedQuotes().getProperty("Default");
		String Overwriteyes = Common.readPropertyByDetailedQuotes().getProperty("Overwriteyes");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00101,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Default, "IDQTC-00102,"+Widget_name+",Mouse hover on Default");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", "//*[@id='container']/div//ul/li[15]/div/ul/li[2]",
				"IDQTC-00021,"+Widget_name+",Click on Save default properties");
		com.sleepThread(2000);
		com.click("xpath", Overwriteyes, "IDQTC-00104,"+Widget_name+",Click on overwrite Yes");
		com.sleepThread(2000);
		com.click("xpath", Overwriteyes, "IDQTC-00104,"+Widget_name+",Click on overwrite Ok");
		com.sleepThread(2000);
	}

	@Then("^Right click and Hover on defaults and click on Apply default properties to the detailed quotes$")
	public void hover_on_defaults_and_click_on_Apply_default_properties_to_the_detailed_quotes() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Default = Common.readPropertyByDetailedQuotes().getProperty("Default");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00101,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Default, "IDQTC-00102,"+Widget_name+",Mouse hover on Default");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", "//*[@id='container']/div//ul/li[15]/div/ul/li[1]",
				"IDQTC-00021,"+Widget_name+",Click on Apply default properties");
		com.sleepThread(2000);
	}
	
	//Verify widget template and its options
	@Given("^Right click and Click on display preferences and verify widget templates is present or not$")
	public void click_on_display_preferences_and_verify_widget_templates_is_present_or_not() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Display_preferences = Common.readPropertyByDetailedQuotes().getProperty("Display_preferences");
		String Widget_Templete = Common.readPropertyByDetailedQuotes().getProperty("Widget_Templete");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IDQTC-00106,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.click("xpath", Display_preferences, "IDQTC-00107,"+Widget_name+", Click on display preferences");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Widget_Templete, "IDQTC-00108,"+Widget_name+",verify widget template is present or not");
	}

	@Then("^Verify all the templates in the widget template$")
	public void verify_all_the_templates_in_the_widget_template() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String Display_preferences = Common.readPropertyByDetailedQuotes().getProperty("Display_preferences");
		com.sleepThread(3000);
		//int Widget_size=driver.findElements(By.xpath("//div[contains(@class,'d-dq-template-dialog ')]")).size();
		int Widget_size=driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div")).size();
		System.out.println(Widget_size);
		com.sleepThread(1000);
		for (int i = 1; i <=Widget_size ; i++) {
			com.MouseOverToclickabl("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div["+i+"]",
					"IDQTC-00109,"+Widget_name+",Click on each fields optons");
			//com.MouseOverToclickabl("xpath", "//div[contains(@class,'d-dq-template-dialog ')]", "IDQTC-00021,"+Widget_name+",Click on each fields optons");
			com.sleepThread(3000);
			com.click("xpath", Save, "IDQTC-00110,"+Widget_name+", click on save");
			com.sleepThread(2000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00111,"+Widget_name+",Right click on window");
            com.sleepThread(2000);
            com.click("xpath", Display_preferences, "IDQTC-00112,"+Widget_name+",click on display preferences");
            com.sleepThread(4000);
            //driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div["+i+"]")).sendKeys(Keys.DOWN);
            //com.sleepThread(3000);
		}
		
	}
	
	//Verifying fields
	@Given("^Verify fields is present or not and click on fields$")
	public void verify_fields_is_present_or_not_click_fields() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String fields_displaypreference = Common.readPropertyByDetailedQuotes().getProperty("fields_displaypreference");
		com.sleepThread(5000);
		com.verifyElementPresent("xpath", fields_displaypreference, "IDQTC-00113,"+Widget_name+",verify fields is present or not");
		com.sleepThread(3000);
		com.click("xpath", fields_displaypreference, "IDQTC-00114,"+Widget_name+", Click on fields");
	}

	@Then("^Verify show short field names in fields$")
	public void verify_show_short_field_names_in_fields() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String showshortfieldnames = Common.readPropertyByDetailedQuotes().getProperty("showshortfieldnames");
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", showshortfieldnames, "IDQTC-00115,"+Widget_name+",Click on show short field names");
		com.sleepThread(3000);
		com.click("xpath", Save, "IDQTC-00116,"+Widget_name+",Click on save");
	}

	@Then("^Verify cell templates in the fields$")
	public void verify_cell_templates_in_the_fields() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByDetailedQuotes().getProperty("Rightclick");
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String fields_displaypreference = Common.readPropertyByDetailedQuotes().getProperty("fields_displaypreference");
		String Display_preferences = Common.readPropertyByDetailedQuotes().getProperty("Display_preferences");
		com.Rightclick("xpath", Rightclick, "IDQTC-00117,"+Widget_name+",Right click for display preference");
		com.sleepThread(3000);
		com.click("xpath", Display_preferences, "IDQTC-00118,"+Widget_name+",click on display preference");
		com.sleepThread(3000);
		com.click("xpath", fields_displaypreference, "IDQTC-00119,"+Widget_name+",click on fields in display preference");
		int celltemplate_size=driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div")).size();
		System.out.println(celltemplate_size);
		com.sleepThread(2000);
		for (int i = 1; i <= 6; i++) {
			com.click("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div["
					+ i + "]",
					"IDQTC-00120,"+Widget_name+",Click on each fields options");
			com.sleepThread(3000);
			com.click("xpath", Save, "IDQTC-00019,"+Widget_name+", click on save");
			com.sleepThread(2000);
			com.Rightclick("xpath", Rightclick, "IDQTC-00020,"+Widget_name+",Right click on window");
            com.sleepThread(2000);
            com.click("xpath", Display_preferences, "IDQTC-00020,"+Widget_name+",click on display preferences");
            com.sleepThread(3000);
            com.click("xpath", fields_displaypreference, "IDQTC-00020,"+Widget_name+",click on fields in display preference");
            com.sleepThread(3000);
	    }

	}	
	
	//Verify formatting
	@Given("^Verify formatting is present or not and click on formatting$")
	public void verify_formatting_is_present_or_not_and_click_on_formatting() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Formatting = Common.readPropertyByDetailedQuotes().getProperty("Formatting");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", Formatting, "IDQTC-00121,"+Widget_name+",Click on formatting");  
	}

	@Then("^Verify options in formatting$")
	public void verify_options_in_formatting() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick2 = Common.readPropertyByDetailedQuotes().getProperty("Rightclick2");
		String Save = Common.readPropertyByDetailedQuotes().getProperty("Save");
		String Formatting = Common.readPropertyByDetailedQuotes().getProperty("Formatting");
		String Display_preferences = Common.readPropertyByDetailedQuotes().getProperty("Display_preferences");
		int formatting_size=driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label")).size();
		System.out.println(formatting_size);
		com.sleepThread(2000);
		for (int i = 1; i <= 5; i++) {
			com.click("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"IDQTC-00122,"+Widget_name+",Click on each fields options");
			com.sleepThread(3000);
			com.click("xpath", Save, "IDQTC-00123,"+Widget_name+", click on save");
			com.sleepThread(2000);
			com.Rightclick("xpath", Rightclick2, "IDQTC-00124,"+Widget_name+",Right click on window");
            com.sleepThread(2000);
            com.click("xpath", Display_preferences, "IDQTC-00125,"+Widget_name+",click on display preferences");
            com.sleepThread(3000);
            com.click("xpath", Formatting, "IDQTC-00126,"+Widget_name+",click on formatting in display preference");
            com.sleepThread(3000);
	   }
	}
	
	@Then("^Verify cancel in display preferences$")
	public void verify_cancel_in_display_preferences() throws Throwable {
		com.sleepThread(4000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Cancel = Common.readPropertyByDetailedQuotes().getProperty("Cancel");
		com.sleepThread(1000);
		com.click("xpath", Cancel, "IDQTC-00127,"+Widget_name+",Click on cancel in display preferences"); 
	}
	@When("^Right click for display preference$")
	public void Right_click_for_display_preference() throws Exception
	{
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("Widget_name"))).getText();
		String Rightclick1 = Common.readPropertyByDetailedQuotes().getProperty("Rightclick1");
		com.Rightclick("xpath", Rightclick1, "IDQTC-00117,"+Widget_name+",Right click for display preference");
		String Fields = Common.readPropertyByDetailedQuotes().getProperty("Fields");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Fields, "IDQTC-00020,"+Widget_name+",Mouse hover on fields");
		com.sleepThread(1000);
		
	}
	
	@Then("^Delete all custom column sets$")
	public void Delete_all_custom_column_sets() throws Exception {
		
		int Size=driver.findElements(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div")).size();
		System.out.println("Size:"+Size);
		for (int i = 1; i <=Size; i++) {
			com.click("xpath","/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[1]/div[1]/span[2]/div","IDQTC-00020,"+Widget_name+",Delete all custom column sets,");
		com.sleepThread(2000);
		String Delete=Common.readPropertyByDetailedQuotes().getProperty("Delete");
		com.click("xpath",Delete,",,Click on Delete button");
		com.sleepThread(2000);
		com.startAction();
		String Yes_button=Common.readPropertyByDetailedQuotes().getProperty("Yes_button");
		com.MouseOverToclickabl("xpath",Yes_button,",,Click on yes button");
				}
		com.sleepThread(2000);
		String Close_button=Common.readPropertyByDetailedQuotes().getProperty("Close_button");
		com.click("xpath",Close_button, ",,Click on close button");
		
			
	}
	
	
	
	
	
	
}
