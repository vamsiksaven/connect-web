package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Screener {
	
	private static String Widget_name = null;
	public Common com = new Common();
	public Screener scr;
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Screener() {
		driver = Common.driver;
		login = Common.readPropertyByEstimates().getProperty("Login_button");
	}
	
	//Screener
	@Given("^Verify the Screener$")
	public void verify_the_Screener() throws Exception {
		com.sleepThread(12000);
		String Screener = Common.readPropertyByScreener().getProperty("Screener");
		System.out.println(Screener);		
		com.verifyElementPresent("xpath", Screener, "IS-00001,Screener,Verify the Screener");
	}

	@And("^Click on Screener$")
	public void click_on_Screener() throws Exception {
		com.sleepThread(12000);	
		String Screener = Common.readPropertyByScreener().getProperty("Screener");
		com.click("xpath", Screener, "IS-00002,Screener,Click on Screener");
	}
	
	//Symbol linking
	@When("^Verify the Symbol Linking in screener$")
	public void verify_the_Symbol_Linking_in_screener() throws Exception {
		com.sleepThread(3000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByScreener().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking, "IS-00003,"+Widget_name+",Verify the Symbol Linking");
	}

	@And("^Click on Symbol Linking in screener$")
	public void click_on_Symbol_Linking_in_screener() throws Exception {
		com.sleepThread(2000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Symbol_Linking = Common.readPropertyByScreener().getProperty("Symbol_Linking");
		com.click("xpath", Symbol_Linking, "IS-00004,"+Widget_name+",Click on Symbol Linking");
	}

	@And("^click on each Check Functionalities in symbol linking in screener$")
	public void click_on_each_Check_Functionalities_in_symbol_linking_in_screener() throws Exception {
		scr = new Screener();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		int count = driver
				.findElements(By.xpath("//*[contains(@data-automation-id,'menu-list')]/ul/li/button[1]")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[contains(@data-automation-id,'menu-list')]/ul/li[" + i + "]/button[1]",
					"IS-00005,"+Widget_name+",Verify on each Check Functionalities");
			com.sleepThread(1000);
			com.click("xpath", "//*[contains(@data-automation-id,'menu-list')]/ul/li[" + i + "]/button[1]",
					"IS-00006,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			scr.click_on_Symbol_Linking_in_screener();
		}

		/*
		 * com.verifyElementPresent("xpath",
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+i+"]/button/label"
		 * ); String t=driver.findElement(By.xpath(
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[\"+i+\"]/button/label"
		 * )).getText(); System.out.println(t+"****************");
		 * com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+
		 * i+"]/button/label"); com.sleepThread(3000);
		 */

		scr = new Screener();
		int count1 = driver
				.findElements(By.xpath("//*[contains(@data-automation-id,'menu-list')]/ul/li/button[1]")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[contains(@data-automation-id,'menu-list')]/ul/li[" + j + "]/button[1]",
					"IS-00005,"+Widget_name+",Verify on each Check Functionalities");
			com.sleepThread(1000);
			com.click("xpath", "//*[contains(@data-automation-id,'menu-list')]/ul/li[" + j + "]/button[1]",
					"IS-00006,"+Widget_name+",Click on each Check Functionalities");
			com.sleepThread(3000);
			scr.click_on_Symbol_Linking_in_screener();
		}
		
	}
	
	//Add criteria
	@Given("^Verify Add and click on Add criteria$")
	public void verify_Add_and_click_on_Add_criteria() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Addcriteria = Common.readPropertyByScreener().getProperty("Addcriteria");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Addcriteria,"IS-00011,"+Widget_name+",Verify Add criteria");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Addcriteria, "IS-00011,"+Widget_name+",Click on Add criteria");
	}

	@Then("^Click on industry and click on select dropdown$")
	public void click_on_industry_and_click_on_select_dropdown() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Industry = Common.readPropertyByScreener().getProperty("Industry");
		String select = Common.readPropertyByScreener().getProperty("select");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Industry,"IS-00011,"+Widget_name+",Click on Industry");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", select, "IS-00011,"+Widget_name+",Click on Select");
	}

	@Then("^Click on first option in industry list$")
	public void click_on_first_option_in_industry_list() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String industrylist1 = Common.readPropertyByScreener().getProperty("industrylist1");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", industrylist1,"IS-00011,"+Widget_name+",Click on Industry list option one");
	}
	
	//Verifying New Screen
	@Given("^Click on quick screen dropdown and click on New$")
	public void click_on_quick_screen_dropdown_and_click_on_New() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown = Common.readPropertyByScreener().getProperty("Quickscreendropdown");
		String New = Common.readPropertyByScreener().getProperty("New");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", New, "IS-00011,"+Widget_name+",Click on New");
	}

	@Then("^Verify new screen dialog box and Click on close button$")
	public void verify_new_screen_dialog_box_and_Click_on_close_button() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Newscreendialogbox = Common.readPropertyByScreener().getProperty("Newscreendialogbox");
		String close = Common.readPropertyByScreener().getProperty("close");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Newscreendialogbox,"IS-00011,"+Widget_name+",Verify New Screen dialogue box");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", close, "IS-00011,"+Widget_name+",Click on close");
	}

	@Then("^Click on quick screen dropdown and click on New and then click on cancel$")
	public void click_on_quick_screen_dropdown_and_click_on_New_click_on_cancel() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String New = Common.readPropertyByScreener().getProperty("New");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", New, "IS-00011,"+Widget_name+",Click on New");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel, "IS-00011,"+Widget_name+",Click on Cancel");
	}

	@Then("^Click on quick screen dropdown and click on New and enter the screen name \"([^\"]*)\"$")
	public void click_on_quick_screen_dropdown_and_click_on_New_enter_the_screen_name(String name) throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String New = Common.readPropertyByScreener().getProperty("New");
		String screennameinput = Common.readPropertyByScreener().getProperty("screennameinput");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", New, "IS-00011,"+Widget_name+",Click on New");
		com.sleepThread(3000);
		com.sendKeys("xpath", screennameinput, name, "IS-00011,"+Widget_name+",Enter new screen name");
	}

	@And("^Click on OK and verify new screen is addeed or not$")
	public void click_on_OK_and_verify_new_screen_is_addeed_or_not() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String Newscreenname = Common.readPropertyByScreener().getProperty("Newscreenname");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", OK,"IS-00011,"+Widget_name+",Click on OK");
		com.sleepThread(3000);
		String newscreen = "test";
		com.verifyText("xpath", Newscreenname, newscreen, "IDQTC-00026,"+Widget_name+",Verify newly added screen name");
	}
	
	//Verifying Save screen and Save Screen as
	@Given("^Click on Add criteria and click on Last and enter inputone \"([^\"]*)\" and inputtwo \"([^\"]*)\"$")
	public void click_on_Add_criteria_and_click_on_Last_and_enter_inputone_and_inputtwo(String inputone, String inputtwo) throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Addcriteria = Common.readPropertyByScreener().getProperty("Addcriteria");
		String Last = Common.readPropertyByScreener().getProperty("Last");
		String input1 = Common.readPropertyByScreener().getProperty("input1");
		String input2 = Common.readPropertyByScreener().getProperty("input2");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Addcriteria,"IS-00011,"+Widget_name+",Click on Add");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Last, "IS-00011,"+Widget_name+",Click on Last");
		com.sleepThread(4000);
		com.sendKeys("xpath", input1, inputone, "IS-00011,"+Widget_name+",Enter input one");
		com.sleepThread(4000);
		com.sendKeys("xpath", input2, inputtwo, "IS-00011,"+Widget_name+",Enter input two");
	}

	@Then("^Click on quick screen dropdown and click on Save Screen$")
	public void click_on_quick_screen_dropdown_and_click_on_Save_Screen() throws Throwable {
		com.sleepThread(20000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String Savescreen = Common.readPropertyByScreener().getProperty("Savescreen");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Savescreen, "IS-00011,"+Widget_name+",Click on Save Screen");
	}

	@Then("^Click on quick screen dropdown and click on Save Screen as$")
	public void click_on_quick_screen_dropdown_and_click_on_Save_Screen_as() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String SaveScreenAs = Common.readPropertyByScreener().getProperty("SaveScreenAs");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", SaveScreenAs, "IS-00011,"+Widget_name+",Click on Save Screen");
	}

	@Then("^Verify Save screen as dialog box and click on cancel$")
	public void verify_Save_screen_as_dialog_box_and_click_on_cancel() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Savescreenasdialoguebox = Common.readPropertyByScreener().getProperty("Savescreenasdialoguebox");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Savescreenasdialoguebox,"IS-00011,"+Widget_name+",Verify Save Screen as dialogue box");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel, "IS-00011,"+Widget_name+",Click on Cancel");
	}

	@Then("^Click on quick screen dropdown and click save screen as$")
	public void click_on_quick_screen_dropdown_and_clear_input_and_enter_name() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String SaveScreenAs = Common.readPropertyByScreener().getProperty("SaveScreenAs");
		String Saveasinput = Common.readPropertyByScreener().getProperty("Saveasinput");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", SaveScreenAs,"IS-00011,"+Widget_name+",Click on Save Screen As");
//		com.sleepThread(9000);
//		com.ClearTextField("xpath", Saveasinput, "IS-00011,"+Widget_name+",Clear save as input");
//		com.sleepThread(4000);
//		com.sendKeys("xpath", Saveasinput, name, "IS-00011,"+Widget_name+",Enter save as input");
	}

	@Then("^Click on OK and verify save as screen name$")
	public void click_on_OK_and_verify_save_as_screen_name() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String Saveasscreenname = Common.readPropertyByScreener().getProperty("Saveasscreenname");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", OK,"IS-00011,"+Widget_name+",Click on OK");
		com.sleepThread(3000);
		String saveasscreen = "Last 0-30";
		com.verifyText("xpath", Saveasscreenname, saveasscreen, "IDQTC-00026,"+Widget_name+",Verify newly added save as screen");
	}
	
	
	//Verifying manage screens
	@Given("^Click on quick screen dropdown and click on manage screens and click on close$")
	public void click_on_quick_screen_dropdown_and_click_on_manage_screens_and_click_on_close() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String Managescreens = Common.readPropertyByScreener().getProperty("Managescreens");
		String close = Common.readPropertyByScreener().getProperty("close");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Managescreens, "IS-00011,"+Widget_name+",Click on Manage screens");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", close, "IS-00011,"+Widget_name+",Click on Close");
	}

	@Then("^Click on quick screen dropdown and click on manage screens and click on close button$")
	public void click_on_quick_screen_dropdown_and_click_on_manage_screens_and_click_on_close_button() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String Managescreens = Common.readPropertyByScreener().getProperty("Managescreens");
		String Closebutton = Common.readPropertyByScreener().getProperty("Closebutton");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Managescreens, "IS-00011,"+Widget_name+",Click on Manage screens");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Closebutton, "IS-00011,"+Widget_name+",Click on Close button");
	}

	@And("^Click on quick screen dropdown and click on manage screens and click on New$")
	public void click_on_quick_screen_dropdown_and_click_on_manage_screens_and_click_on_New() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Quickscreendropdown1 = Common.readPropertyByScreener().getProperty("Quickscreendropdown1");
		String Managescreens = Common.readPropertyByScreener().getProperty("Managescreens");
		String New = Common.readPropertyByScreener().getProperty("New");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Quickscreendropdown1,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Managescreens, "IS-00011,"+Widget_name+",Click on Manage screens");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", New, "IS-00011,"+Widget_name+",Click on New");
	}

	@Then("^Enter the screen name \"([^\"]*)\" and click on Ok and verify added screen name$")
	public void enter_the_screen_name_and_click_on_Ok_and_verify_added_screen_name(String name) throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savesinputtext = Common.readPropertyByScreener().getProperty("savesinputtext");
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String test1 = Common.readPropertyByScreener().getProperty("test1");
		com.sleepThread(10000);
		com.sendKeys("xpath", savesinputtext, name, "IS-00011,"+Widget_name+",Enter Add new screen input");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", OK, "IS-00011,"+Widget_name+",Click on Manage screens");
		com.sleepThread(3000);
		String newscreen = "test1";
		com.verifyText("xpath", test1, newscreen, "IDQTC-00026,"+Widget_name+",Verify newly added screen name");
	}

	@Then("^Click on New and then click on cancel$")
	public void click_on_New_and_then_click_on_cancel() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		String New = Common.readPropertyByScreener().getProperty("New");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", New, "IS-00011,"+Widget_name+",Click on New");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel, "IS-00011,"+Widget_name+",Click on Cancel");
	}

	@And("^Click on required screen name and then click on open and verify opened screen name$")
	public void click_on_required_screen_name_and_then_click_on_open_and_verify_opened_screen_name() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String test = Common.readPropertyByScreener().getProperty("test");
		String Open = Common.readPropertyByScreener().getProperty("Open");
		String verifyopenedscreen = Common.readPropertyByScreener().getProperty("verifyopenedscreen");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", test, "IS-00011,"+Widget_name+",Click on screen name test");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Open, "IS-00011,"+Widget_name+",Click on Open");
		com.sleepThread(5000);
		String openedscreen = "test";
		com.verifyText("xpath", verifyopenedscreen, openedscreen, "IDQTC-00026,"+Widget_name+",Verify copied screen name");
	}

//	@And("^Click on quick screen dropdown and click on manage screens and click on copy$")
//	public void click_on_quick_screen_dropdown_and_click_on_manage_screens_and_click_on_copy() throws Throwable {
//		com.sleepThread(5000);
//		com.startAction();
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
//		String test = Common.readPropertyByScreener().getProperty("test");
//		String manage = Common.readPropertyByScreener().getProperty("manage");
//		String Copy = Common.readPropertyByScreener().getProperty("Copy");
//		com.sleepThread(10000);
//		com.MouseOverToclickabl("xpath", test,"IS-00011,"+Widget_name+",Click on quick screen dropdown");
//		com.sleepThread(6000);
//		com.MouseOverToclickabl("xpath", manage, "IS-00011,"+Widget_name+",Click on Manage screens");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", Copy, "IS-00011,"+Widget_name+",Click on Copy");
//	}

	@Then("^Click on copy Enter the copy screen name \"([^\"]*)\" and then click on ok and verify copied screen name$")
	public void enter_the_copy_screen_name_and_then_click_on_ok_and_verify_copied_screen_name(String name) throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Copy = Common.readPropertyByScreener().getProperty("Copy");
		String savesinputtext = Common.readPropertyByScreener().getProperty("savesinputtext");
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String testcopy = Common.readPropertyByScreener().getProperty("testcopy");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Copy, "IS-00011,"+Widget_name+",Click on Copy");
		com.sleepThread(5000);
		com.sendKeys("xpath", savesinputtext, name, "IS-00011,"+Widget_name+",Enter Add new screen input");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", OK, "IS-00011,"+Widget_name+",Click on ok");
		com.sleepThread(3000);
		String copiedscreen = "testcopy";
		com.verifyText("xpath", testcopy, copiedscreen, "IDQTC-00026,"+Widget_name+",Verify copied screen name");
	}

	@And("^Click on screen name thats need to be deleted and click on delete and then click on Yes$")
	public void click_on_screen_name_thats_need_to_be_deleted_and_then_click_on_Yes() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String test1 = Common.readPropertyByScreener().getProperty("test1");
		String Yes = Common.readPropertyByScreener().getProperty("Yes");
		String Delete = Common.readPropertyByScreener().getProperty("Delete");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", test1,"IS-00011,"+Widget_name+",Click on screen name that has to be deleted");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Delete, "IS-00011,"+Widget_name+",Click on Delete");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Yes, "IS-00011,"+Widget_name+",Click on Manage screens");
	}

	@Then("^Click on screen name and click on delete and then click on No$")
	public void click_on_screen_name_and_then_click_on_No() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String test = Common.readPropertyByScreener().getProperty("test");
		String No = Common.readPropertyByScreener().getProperty("No");
		String Delete = Common.readPropertyByScreener().getProperty("Delete");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", test,"IS-00011,"+Widget_name+",Click on screen name that has to be deleted");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Delete, "IS-00011,"+Widget_name+",Click on Delete");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", No, "IS-00011,"+Widget_name+",Click on No");
	}

	@Then("^Click on screen name and click on delete and then click on cancel$")
	public void click_on_screen_name_and_thenn_click_on_cancel() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String testcopy = Common.readPropertyByScreener().getProperty("testcopy");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		String Delete = Common.readPropertyByScreener().getProperty("Delete");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", testcopy,"IS-00011,"+Widget_name+",Click on screen name that has to be deleted");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Delete, "IS-00011,"+Widget_name+",Click on Delete");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel, "IS-00011,"+Widget_name+",Click on Cancel");
	}
	
	//Verifying Save dropdown
	@Given("^Click on save dropdown and then click on save screen$")
	public void click_on_save_dropdown_and_then_click_on_save_screen() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String Savescreen = Common.readPropertyByScreener().getProperty("Savescreen");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Savescreen, "IS-00011,"+Widget_name+",Click on Save Screen");
	}

	@And("^click on Add criteria and select sector and select energy$")
	public void click_on_Add_criteria_and_select_sector_and_select_energy() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Sector = Common.readPropertyByScreener().getProperty("Sector");
		String select = Common.readPropertyByScreener().getProperty("select");
		String Addcriteria = Common.readPropertyByScreener().getProperty("Addcriteria");
		String Sectorlist1 = Common.readPropertyByScreener().getProperty("Sectorlist1");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Addcriteria,"IS-00011,"+Widget_name+",Click on Add criteria");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Sector, "IS-00011,"+Widget_name+",Click on Sector");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", select, "IS-00011,"+Widget_name+",Click on Select");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Sectorlist1, "IS-00011,"+Widget_name+",Click on Energy");
	}

	@Then("^Click on save dropdown and then click on Save Screen as and click on Ok and verify added screen$")
	public void click_on_save_dropdown_and_then_click_on_Save_Screen_as_and_click_on_Ok_and_verify_added_screen() throws Throwable {
		com.sleepThread(7000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String SaveScreenAs = Common.readPropertyByScreener().getProperty("SaveScreenAs");
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String Saveasenergylist = Common.readPropertyByScreener().getProperty("Saveasenergylist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", SaveScreenAs, "IS-00011,"+Widget_name+",Click on Save Screen as");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", OK,"IS-00011,"+Widget_name+",Click on ok");
		com.sleepThread(5000);
		String energylist = "Energy";
		com.verifyText("xpath", Saveasenergylist, energylist, "IS-00011,"+Widget_name+",Verify Save as screen name");
	}

	@And("^Select symbols from list of symbols and click on save dropdown$")
	public void select_symbols_from_list_of_symbols_and_click_on_save_dropdown() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String symbol1 = Common.readPropertyByScreener().getProperty("symbol1");
		String symbol2 = Common.readPropertyByScreener().getProperty("symbol2");
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", symbol1,"IS-00011,"+Widget_name+",Click on symbol one");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", symbol2, "IS-00011,"+Widget_name+",Click on Save symbol two");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
	}

	@Then("^click on save dropdown and click on save selected symbols as watchlist and click on cancel$")
	public void click_on_save_selected_symbols_as_watchlist_and_click_on_cancel() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String saveselectedsymbolsaswatchlist = Common.readPropertyByScreener().getProperty("saveselectedsymbolsaswatchlist");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", saveselectedsymbolsaswatchlist, "IS-00011,"+Widget_name+",Click on Save selected symbols as watchlist");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Cancel, "IS-00011,"+Widget_name+",Click on Cancel");
	}

	@Then("^Click on save dropdown and click on save selected symbols as watchlist and clcik on close$")
	public void click_on_save_selected_symbols_as_watchlist_and_clcik_on_close() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String saveselectedsymbolsaswatchlist = Common.readPropertyByScreener().getProperty("saveselectedsymbolsaswatchlist");
		String close = Common.readPropertyByScreener().getProperty("close");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", saveselectedsymbolsaswatchlist, "IS-00011,"+Widget_name+",Click on Save selected symbols as watchlist");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", close, "IS-00011,"+Widget_name+",Click on Close");
	}

	@Then("^Click on save dropdown and click on save selected symbols as watchlist and give symbol listname \"([^\"]*)\" and click on ok$")
	public void click_on_save_selected_symbols_as_watchlist_and_give_symbol_listname_and_click_on_ok(String listname) throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String symbollistinput = Common.readPropertyByScreener().getProperty("symbollistinput");
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String saveselectedsymbolsaswatchlist = Common.readPropertyByScreener().getProperty("saveselectedsymbolsaswatchlist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", saveselectedsymbolsaswatchlist,"IS-00011,"+Widget_name+",Click on save selected symbolas watchlist");
		com.sleepThread(4000);
		com.sendKeys("xpath", symbollistinput, listname, "IS-00011,"+Widget_name+",Enter the symbol list name");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", OK, "IS-00011,"+Widget_name+",Click on OK");
	}

	@Then("^Select another symbol and click on save dropdown$")
	public void select_another_symbol_and_click_on_save_dropdown() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String savedropdown = Common.readPropertyByScreener().getProperty("savedropdown");
		String symbol3 = Common.readPropertyByScreener().getProperty("symbol3");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", symbol3,"IS-00011,"+Widget_name+",Click on symbol to add");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", savedropdown,"IS-00011,"+Widget_name+",Click on save dropdown");		
	}

	@Then("^Mouse hover on Add selected symbols to watchlist and click on energysymbollist$")
	public void mouse_hover_on_Add_selected_symbols_to_watchlist_and_click_on_energysymbollist() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Addselectedsymbolstowatchlist = Common.readPropertyByScreener().getProperty("Addselectedsymbolstowatchlist");
		String energysymbollist = Common.readPropertyByScreener().getProperty("energysymbollist");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Addselectedsymbolstowatchlist,"IS-00011,"+Widget_name+",Click on Add selected symbols to watchlist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", energysymbollist,"IS-00011,"+Widget_name+",Click on symbol list to add");
	}
	
	//Verifying refresh button
	@Then("^Click on refresh button$")
	public void Click_on_refresh_button() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Refresh = Common.readPropertyByScreener().getProperty("Refresh");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Refresh,"IS-00011,"+Widget_name+",Click on refresh button");
	}
	
	//Verifying View and its options
	@Given("^Right click on window and verify view options$")
	public void right_click_on_window_and_verify_view_options() throws Throwable {
		com.startAction();
		com.sleepThread(6000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String View = Common.readPropertyByScreener().getProperty("View");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick, "IS-00059,"+Widget_name+",Right click on window for view");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", View, "IS-00060,"+Widget_name+",Verify whether view is present or not");
	}

	@Then("^Click on sub menus in view option and verify all options$")
	public void click_on_sub_menus_in_view_option_and_verify_all_options() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String View = Common.readPropertyByScreener().getProperty("View");
		com.MouseOverToElement("xpath", View, "IS-00061,"+Widget_name+",mouse over on view option");
		
		com.sleepThread(2000);
		for (int i = 1; i <= 6; i++) {
			com.MouseOverToclickabl("xpath", "//*[contains(@data-automation-id,'menu-list')]/ul//li[@class='ice-menu-item css-z9z6jv']//li[" + i + "]",
					"IS-00062,Charts,Click on submenus in view option");
			com.sleepThread(3000);
			String second_widget = Common.readPropertyByDetailedQuotes().getProperty("second_widget");
			String widgetname = driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("second_widget"))).getText();
			com.verifyText("xpath", second_widget, widgetname, "IS-00063,"+Widget_name+",Verify " + widgetname + " widget name");
			com.sleepThread(3000);
			com.Rightclick("xpath", second_widget, "IS-00064,"+Widget_name+",Right click on new widget name");
			com.sleepThread(3000);
			String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
			com.sleepThread(3000);
			com.click("xpath", Closetab, "IS-00065,"+Widget_name+",Click on Close Tab and verify the tab is closing or not");
			com.sleepThread(30000);
			String symbol1 = Common.readPropertyByScreener().getProperty("symbol1");
			String symbolone = Common.readPropertyByScreener().getProperty("symbolone");
			com.sleepThread(3000);
			com.MouseOverToclickabl("xpath", symbol1, "IS-00059,"+Widget_name+",Right click on window for Add to symbol list");
			String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
			com.sleepThread(3000);
			com.Rightclick("xpath", symbolone,
					"ICTC-00066,Charts,Right click on window");
			com.MouseOverToElement("xpath", View, "IS-00067,"+Widget_name+",mouse over on view option");
			com.sleepThread(3000);
       
		}
		com.sleepThread(4000);
		com.click("xpath", View, "IS-00068,"+Widget_name+",Click on View");
	}
	
	//Verifying selected symbols and its all options
	@Given("^Click on selected symbols dropdown and click on save selected symbols as watchlist and give name \"([^\"]*)\" and click on ok$")
	public void click_on_selected_symbols_dropdown_and_click_on_save_selected_symbols_as_watchlist_and_give_name_and_click_on_ok(String name) throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Selectedsymbols = Common.readPropertyByScreener().getProperty("Selectedsymbols");
		String selectedsymbolsinput = Common.readPropertyByScreener().getProperty("selectedsymbolsinput");
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String saveselectedsymbolsaswatchlist = Common.readPropertyByScreener().getProperty("saveselectedsymbolsaswatchlist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Selectedsymbols,"IS-00011,"+Widget_name+",Click on selected symbols dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", saveselectedsymbolsaswatchlist,"IS-00011,"+Widget_name+",Click on save selected symbolas watchlist");
		com.sleepThread(4000);
		com.sendKeys("xpath", selectedsymbolsinput, name, "IS-00011,"+Widget_name+",Enter the symbol list name");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", OK, "IS-00011,"+Widget_name+",Click on OK");
	}

	@And("^Click on selected symbols dropdown and hover on Add selected symbols to watchlist and click on energysymbollist$")
	public void click_on_selected_symbols_dropdown_and_hover_on_Add_selected_symbols_to_watchlist_and_click_on_energysymbollist() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Selectedsymbols = Common.readPropertyByScreener().getProperty("Selectedsymbols");
		String Addselectedsymbolstowatchlist = Common.readPropertyByScreener().getProperty("Addselectedsymbolstowatchlist");
		String energysymbollist = Common.readPropertyByScreener().getProperty("energysymbollist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Selectedsymbols,"IS-00011,"+Widget_name+",Click on selected symbols dropdown");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Addselectedsymbolstowatchlist,"IS-00011,"+Widget_name+",Click on Add selected symbols to watchlist");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", energysymbollist,"IS-00011,"+Widget_name+",Click on symbol list to add");
	}

	@And("^Click on selected symbols dropdown and hover on view selected symbols in and click on available list$")
	public void click_on_selected_symbols_dropdown_and_hover_on_view_selected_symbols_in_and_click_on_available_list() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Selectedsymbols = Common.readPropertyByScreener().getProperty("Selectedsymbols");
		String Viewselectedsymbolsin = Common.readPropertyByScreener().getProperty("Viewselectedsymbolsin");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Selectedsymbols,"IS-00011,"+Widget_name+",Click on selected symbols dropdown");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Viewselectedsymbolsin,"IS-00011,"+Widget_name+",Click on view selected symbols in");
		com.sleepThread(3000);
		for (int i = 1; i <= 2; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li[" + i + "]/button",
					"IS-00062,Charts,Click on submenus");
			com.sleepThread(3000);
			String second_widget = Common.readPropertyByDetailedQuotes().getProperty("second_widget");
			String symbol8 = Common.readPropertyByScreener().getProperty("symbol8");
			String symbol9 = Common.readPropertyByScreener().getProperty("symbol9");
			String widgetname = driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("second_widget"))).getText();
			com.verifyText("xpath", second_widget, widgetname, "IS-00063,"+Widget_name+",Verify " + widgetname + " widget name");
			com.sleepThread(3000);
			com.Rightclick("xpath", second_widget, "IS-00064,"+Widget_name+",Right click on new widget name");
			com.sleepThread(3000);
			String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
			com.click("xpath", Closetab, "IS-00065,"+Widget_name+",Click on Close Tab and verify the tab is closing or not");
			com.sleepThread(25000);
			com.MouseOverToclickabl("xpath", symbol8,"IS-00011,"+Widget_name+",Click on symbols to add");
			com.sleepThread(3000);
			com.MouseOverToclickabl("xpath", symbol9,"IS-00011,"+Widget_name+",Click on symbols to add");
			com.sleepThread(4000);
			com.MouseOverToclickabl("xpath", Selectedsymbols,"IS-00011,"+Widget_name+",Click on selected symbols dropdown");
			com.sleepThread(3000);
			com.MouseOverToElement("xpath", Viewselectedsymbolsin, "IS-00067,"+Widget_name+",mouse over on view selected symbols in");
			com.sleepThread(3000);     
		}
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Viewselectedsymbolsin, "IS-00068,"+Widget_name+",Click on View");
	}

	@Then("^Click on symbols to add and click on selected symbols dropdown and click on sort selected symbols to top$")
	public void click_on_symbols_to_add_and_click_on_selected_symbols_dropdown_and_click_on_sort_selected_symbols_to_top() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Selectedsymbols = Common.readPropertyByScreener().getProperty("Selectedsymbols");
		String Sortsymbolstotop = Common.readPropertyByScreener().getProperty("Sortsymbolstotop");
		String symbol10 = Common.readPropertyByScreener().getProperty("symbol10");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", symbol10,"IS-00011,"+Widget_name+",Click on symbols to add");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Selectedsymbols,"IS-00011,"+Widget_name+",Click on selected symbols dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Sortsymbolstotop,"IS-00011,"+Widget_name+",Click on Add selected symbols to watchlist");
	}
	
	//Verifying Add to symbol list and its options
	@Given("^Right click on window and verify Add to symbol list$")
	public void right_click_on_window_and_verify_Add_to_symbol_list() throws Throwable {
		com.startAction();
		com.sleepThread(6000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Addtosymbollist = Common.readPropertyByScreener().getProperty("Addtosymbollist");
		String symbolone = Common.readPropertyByScreener().getProperty("symbolone");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", symbol1, "IS-00059,"+Widget_name+",click on symbol to Add to symbol list");
		com.sleepThread(3000);
		com.Rightclick("xpath", symbolone, "IS-00059,"+Widget_name+",Right click on window for Add to symbol list");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Addtosymbollist, "IS-00060,"+Widget_name+",Verify whether Add to symbol list is present or not");
	}

	@Then("^Click on sub menus in Add to symbol list$")
	public void click_on_sub_menus_in_Add_to_symbol_list() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Addtosymbollist = Common.readPropertyByScreener().getProperty("Addtosymbollist");
		com.MouseOverToElement("xpath", Addtosymbollist, "IS-00061,"+Widget_name+",mouse over on view option");
		
		com.sleepThread(2000);
		for (int i = 1; i <= 17; i++) {
			com.MouseOverToclickabl("xpath", "//*[contains(@data-automation-id,'menu-list')]/ul//li[@class='ice-menu-item css-z9z6jv']//li[" + i + "]",
					"IS-00062,Charts,Click on submenus in view option");
			com.sleepThread(5000);
			String symbolone = Common.readPropertyByScreener().getProperty("symbolone");
			com.Rightclick("xpath", symbolone,
					"IS-00066,Charts,Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Addtosymbollist, "IS-00067,"+Widget_name+",mouse over on Add to symbol list option");
			com.sleepThread(2000);
       
		}
		com.sleepThread(4000);
		com.click("xpath", Addtosymbollist, "IS-00068,"+Widget_name+",Click on Add to symbollist");
	}
	
	//Verifying Insert columns
	@Given("^Right click and Click on Insert columns and click on close$")
	public void right_click_and_Click_on_Insert_columns_and_click_on_close() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Insertcolumns = Common.readPropertyByScreener().getProperty("Insertcolumns");
		String close = Common.readPropertyByScreener().getProperty("close");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Insertcolumns,"IS-00011,"+Widget_name+",Click on insert columns");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", close,"IS-00011,"+Widget_name+",Click on close");
	}

	@And("^Right click and Click on Insert columns and click on cancel$")
	public void right_click_and_Click_on_Insert_columns_and_click_on_cancel() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Insertcolumns = Common.readPropertyByScreener().getProperty("Insertcolumns");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Insertcolumns,"IS-00011,"+Widget_name+",Click on insert columns");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel,"IS-00011,"+Widget_name+",Click on Cancel");
	}

	@And("^Right click and Click on insert columns and check expand or compress$")
	public void right_click_and_Click_on_insert_columns_and_check_expand_or_compress() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Insertcolumns = Common.readPropertyByScreener().getProperty("Insertcolumns");
		String expandorcompress = Common.readPropertyByScreener().getProperty("expandorcompress");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Insertcolumns,"IS-00011,"+Widget_name+",Click on insert columns");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", expandorcompress,"IS-00011,"+Widget_name+",Click on expand or compress");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", expandorcompress,"IS-00011,"+Widget_name+",Click on expand or compress");
	}

	@And("^Enter column name \"([^\"]*)\" in the search field name and click on exit date$")
	public void enter_column_name_in_the_search_field_name_and_click_on_exit_date(String name) throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Searchcolumns = Common.readPropertyByScreener().getProperty("Searchcolumns");
		String Exitdate = Common.readPropertyByScreener().getProperty("Exitdate");
		com.sleepThread(3000);
		com.sendKeys("xpath", Searchcolumns, name, "IS-00011,"+Widget_name+",enter column name in search field name");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Exitdate,"IS-00011,"+Widget_name+",Click on exit date column");;
	}

	@Then("^click on ok and verify the added column$")
	public void click_on_ok_and_verify_the_added_column() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String OK = Common.readPropertyByScreener().getProperty("OK");
		String Exitdate = Common.readPropertyByScreener().getProperty("Exitdate");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", OK,"IS-00011,"+Widget_name+",click on ok");
		com.sleepThread(3000);
		String addedcolumn = "Exit Date";
		com.verifyText("xpath", Exitdate, addedcolumn, "IS-00011,"+Widget_name+",Verify added column-Exit Date");
	}

	//Verifying delete selected columns
	@Given("^Right click and click on delete selected columns$")
	public void right_click_and_click_on_delete_selected_columns() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Timecolumn = Common.readPropertyByScreener().getProperty("Timecolumn");
		String Deleteselectedcolumns = Common.readPropertyByScreener().getProperty("Deleteselectedcolumns");
		com.sleepThread(3000);
		com.Rightclick("xpath", Timecolumn,"IS-00011,"+Widget_name+",Right click on time column");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Deleteselectedcolumns,"IS-00011,"+Widget_name+",Click on delete selected columns");
	}
	
	//Verifying Edit and its options
	@Given("^Right click on window and verify edit option$")
	public void right_click_on_window_and_verify_edit_option() throws Throwable {
		com.startAction();
		com.sleepThread(6000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Edit = Common.readPropertyByScreener().getProperty("Edit");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick, "IS-00059,"+Widget_name+",Right click on window for Edit");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Edit, "IS-00060,"+Widget_name+",Verify whether Edit is present or not");
	}

	@Given("^Click on sub menus in edit option$")
	public void click_on_sub_menus_in_edit_option() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Edit = Common.readPropertyByScreener().getProperty("Edit");
		com.MouseOverToElement("xpath", Edit, "IS-00061,"+Widget_name+",mouse over on Edit option");
		
		com.sleepThread(2000);
		for (int i = 1; i <= 3; i++) {
			com.MouseOverToclickabl("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[7]/div/ul/li[" + i + "]/button",
					"IS-00062,Charts,Click on submenus in view option");
			com.sleepThread(5000);
			String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
			com.Rightclick("xpath", Rightclick,
					"IS-00066,Charts,Right click on window");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Edit, "IS-00067,"+Widget_name+",mouse over on Edit option");
			com.sleepThread(2000);
      
		}
		com.sleepThread(4000);
		com.click("xpath", Edit, "IS-00068,"+Widget_name+",Click on Edit");
	}
	
	//Verifying default and its options
	@Given("^Right click and Hover on defaults and click on Save default properties to the screener$")
	public void hover_on_defaults_and_click_on_Save_default_properties_to_the_detailed_quotes() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Default = Common.readPropertyByScreener().getProperty("Default");
		String Overwriteyes = Common.readPropertyByScreener().getProperty("Overwriteyes");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IS-00101,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Default, "IS-00102,"+Widget_name+",Mouse hover on Default");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[11]/div/ul/li[2]/button",
				"IDQTC-00021,"+Widget_name+",Click on Save default properties");
		com.sleepThread(2000);
		com.click("xpath", Overwriteyes, "IS-00104,"+Widget_name+",Click on overwrite Yes");
		com.sleepThread(2000);
		com.click("xpath", Overwriteyes, "IS-00104,"+Widget_name+",Click on overwrite Ok");
		com.sleepThread(2000);
	}

	@Then("^Right click and Hover on defaults and click on Apply default properties to the screener$")
	public void hover_on_defaults_and_click_on_Apply_default_properties_to_the_detailed_quotes() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Default = Common.readPropertyByScreener().getProperty("Default");
		com.sleepThread(1000);
		com.Rightclick("xpath", Rightclick, "IS-00101,"+Widget_name+", Right click on window");
		com.sleepThread(2000);
		com.MouseOverToElement("xpath", Default, "IS-00102,"+Widget_name+",Mouse hover on Default");
		com.sleepThread(1000);
		com.MouseOverToclickabl("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[11]/div/ul/li[1]/button",
				"IDQTC-00021,"+Widget_name+",Click on Apply default properties");
		com.sleepThread(2000);
	}
	
	//Verifying display preferences and its options
	@Given("^Right click on window and verify display preferences options$")
	public void right_click_on_window_and_verify_display_preferences_options() throws Throwable {
		com.startAction();
		com.sleepThread(6000);
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick, "IS-00059,"+Widget_name+",Right click on window for Edit");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Displaypreferences, "IS-00060,"+Widget_name+",Verify whether Display preferences is present or not");
	}

	@Given("^Click on display preferences and click on close$")
	public void click_on_display_preferences_and_click_on_close() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String close = Common.readPropertyByScreener().getProperty("close");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", close,"IS-00011,"+Widget_name+",Click on close");
	}

	@Given("^Right click and click on display preferences and click on cancel$")
	public void right_click_and_click_on_display_preferences_and_click_on_cancel() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Cancel = Common.readPropertyByScreener().getProperty("Cancel");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Cancel,"IS-00011,"+Widget_name+",Click on Cancel");
	}

	@Then("^Right click and click on display preferences and click on criteria left and click on save$")
	public void right_click_and_click_on_display_preferences_and_click_on_criteria_left_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Criterialeft = Common.readPropertyByScreener().getProperty("Criterialeft");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Criterialeft,"IS-00011,"+Widget_name+",Click on criteria left pane");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on Save");
	}

	@Then("^Right click and click on display preferences and click on criteria top and click on save$")
	public void right_click_and_click_on_display_preferences_and_click_on_criteria_top_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Criteriatop = Common.readPropertyByScreener().getProperty("Criteriatop");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Criteriatop,"IS-00011,"+Widget_name+",Click on criteria top pane");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on Save");
	}

	@Then("^Right click and click on display preferences and click on criteria right and click on save$")
	public void right_click_and_click_on_display_preferences_and_click_on_criteria_right_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Criteriaright = Common.readPropertyByScreener().getProperty("Criteriaright");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Criteriaright,"IS-00011,"+Widget_name+",Click on criteria right pane");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on Save");
	}
	
	//Verifying auto refresh and append criteria as columns
	@Given("^Right click on window and click on display prefrences and click on auto refresh$")
	public void right_click_on_window_and_click_on_display_prefrences_and_click_on_auto_refresh() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Autorefresh = Common.readPropertyByScreener().getProperty("Autorefresh");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Autorefresh,"IS-00011,"+Widget_name+",Click on auto refresh");
	}

	@Given("^Click on refresh time dropdown and click on Every ten minutes and click on save$")
	public void click_on_refresh_time_dropdown_and_click_on_Every_ten_minutes_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String refreshtimedropdown = Common.readPropertyByScreener().getProperty("refreshtimedropdown");
		String Every10minutes = Common.readPropertyByScreener().getProperty("Every10minutes");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", refreshtimedropdown,"IS-00011,"+Widget_name+",click on refresh time dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Every10minutes,"IS-00011,"+Widget_name+",click on Every 10 minutes");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",Click on save");
	}

	@Given("^Right click on window and click on display prefrences and click on append criteria as columns and click on save$")
	public void right_click_on_window_and_click_on_display_prefrences_and_click_on_append_criteria_as_columns_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String Appendcriteriaascolumns = Common.readPropertyByScreener().getProperty("Appendcriteriaascolumns");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Appendcriteriaascolumns,"IS-00011,"+Widget_name+",Click on append criteria as columns");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on Save");
	}

	//Verifying symbol field and its options
	@Given("^Right click on window and click on display prefrences and click on symbol field$")
	public void right_click_on_window_and_click_on_display_prefrences_and_click_on_symbol_field() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		String SymbolField = Common.readPropertyByScreener().getProperty("SymbolField");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", SymbolField,"IS-00011,"+Widget_name+",Click on symbol field");
	}

	@Then("^Click on show symbol as description and click on save$")
	public void click_on_show_symbol_as_description_and_click_on_save() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String ShowSymbolasdescription = Common.readPropertyByScreener().getProperty("ShowSymbolasdescription");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.Rightclick("xpath", ShowSymbolasdescription,"IS-00011,"+Widget_name+",Click on show symbol as description");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}
	
	@Then("^Right click on window and click on display preferences$")
	public void right_click_on_window_and_click_on_display_preferences() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Displaypreferences = Common.readPropertyByScreener().getProperty("Displaypreferences");
		String Rightclick = Common.readPropertyByScreener().getProperty("Rightclick");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Displaypreferences,"IS-00011,"+Widget_name+",click on display preferences");
	}

	@Then("^Click on click Action twice to disable and enable and click on save$")
	public void click_on_click_Action_twice_to_disable_and_enable_and_click_on_dropdown() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String ClickAction = Common.readPropertyByScreener().getProperty("ClickAction");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", ClickAction,"IS-00011,"+Widget_name+",click on click action");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", ClickAction,"IS-00011,"+Widget_name+",click on click action again");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on click action again");
	}

//	@Then("^Select the action and click on save$")
//	public void select_the_action_and_click_on_save() throws Throwable {
//		com.sleepThread(5000);
//		com.startAction();
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
//		String selectclickaction = Common.readPropertyByScreener().getProperty("selectclickaction");
//		String Save = Common.readPropertyByScreener().getProperty("Save");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", selectclickaction,"IS-00011,"+Widget_name+",select click action");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on click action again");
//	}

	@Then("^Clcik on symbol and verify it is opened or not and click on close tab$")
	public void clcik_on_symbol_and_verify_it_is_opened_or_not_and_click_on_close_tab() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String symbolone = Common.readPropertyByScreener().getProperty("symbolone");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", symbolone,"IS-00011,"+Widget_name+",select click action");
		String second_widget = Common.readPropertyByDetailedQuotes().getProperty("second_widget");
		String widgetname = driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("second_widget"))).getText();
		com.verifyText("xpath", second_widget, widgetname, "IS-00063,"+Widget_name+",Verify " + widgetname + " widget name");
		com.sleepThread(3000);
		com.Rightclick("xpath", second_widget, "IS-00064,"+Widget_name+",Right click on new widget name");
		com.sleepThread(3000);
		String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
		com.click("xpath", Closetab, "IS-00065,"+Widget_name+",Click on Close Tab and verify the tab is closing or not");
		com.sleepThread(25000);
	}

	@Then("^Click on double click Action twice to disable and enable and click on save$")
	public void click_on_double_click_Action_twice_to_disable_and_enable_and_click_on_dropdown() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Doubleclick = Common.readPropertyByScreener().getProperty("Doubleclick");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Doubleclick,"IS-00011,"+Widget_name+",Right click on window");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Doubleclick,"IS-00011,"+Widget_name+",click on double click drropdown again");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}

//	@Then("^Select the double click action and click on save$")
//	public void select_the_double_click_action_and_click_on_save() throws Throwable {
//		com.sleepThread(5000);
//		com.startAction();
//		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
//		String selectdoubleclickaction = Common.readPropertyByScreener().getProperty("selectdoubleclickaction");
//		String Save = Common.readPropertyByScreener().getProperty("Save");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", selectdoubleclickaction,"IS-00011,"+Widget_name+",Right click on window");
//		com.sleepThread(3000);
//		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on double click drropdown again");
//	}

	@Then("^Clcik on symbol for double click action and verify it is opened or not and click on close tab$")
	public void clcik_on_symbol_for_double_click_action_and_verify_it_is_opened_or_not_and_click_on_close_tab() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String symbolone = Common.readPropertyByScreener().getProperty("symbolone");
		com.sleepThread(3000);
		com.double_click_on_element("xpath", symbolone,"IS-00011,"+Widget_name+",Double click on symbol");
		String second_widget = Common.readPropertyByDetailedQuotes().getProperty("second_widget");
		String widgetname = driver.findElement(By.xpath(Common.readPropertyByDetailedQuotes().getProperty("second_widget"))).getText();
		com.verifyText("xpath", second_widget, widgetname, "IS-00063,"+Widget_name+",Verify " + widgetname + " widget name");
		com.sleepThread(3000);
		com.Rightclick("xpath", second_widget, "IS-00064,"+Widget_name+",Right click on new widget name");
		com.sleepThread(3000);
		String Closetab = Common.readPropertyByDetailedQuotes().getProperty("Closetab");
		com.click("xpath", Closetab, "IS-00065,"+Widget_name+",Click on Close Tab and verify the tab is closing or not");
		com.sleepThread(25000);
	}

	@Then("^Click on show fiftytwo week indicator and click on save$")
	public void click_on_show_fiftytwo_week_indicator_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String show52weekindicator = Common.readPropertyByScreener().getProperty("show52weekindicator");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", show52weekindicator,"IS-00011,"+Widget_name+",click on 52 weel indicator");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}

	@Then("^Click Activity indicator color and click on more colors$")
	public void click_Activity_indicator_color_and_click_on_more_colors() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Activityindicatorcolor = Common.readPropertyByScreener().getProperty("Activityindicatorcolor");
		String morecolors = Common.readPropertyByScreener().getProperty("morecolors");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Activityindicatorcolor,"IS-00011,"+Widget_name+",Click on Activity indicator color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", morecolors,"IS-00011,"+Widget_name+",click on more colors");
	}

	@Then("^select color and click on save$")
	public void select_color_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String bluecolor = Common.readPropertyByScreener().getProperty("bluecolor");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", bluecolor,"IS-00011,"+Widget_name+",Click on required color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}
	
	@Then("^Click on formatting and click on show full precision on non traded and traded data and click on save$")
	public void click_on_formatting_and_click_on_show_full_precision_on_non_traded_and_traded_data() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Formatting = Common.readPropertyByScreener().getProperty("Formatting");
		String showfullprecisiononnontradeddata = Common.readPropertyByScreener().getProperty("showfullprecisiononnontradeddata");
		String showfullprecisionontradeddata = Common.readPropertyByScreener().getProperty("showfullprecisionontradeddata");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Formatting,"IS-00011,"+Widget_name+",Click on formatting");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", showfullprecisiononnontradeddata,"IS-00011,"+Widget_name+",click on show full precision on non traded data");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", showfullprecisionontradeddata,"IS-00011,"+Widget_name+",click on show precision on traded data");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}

	@Then("^Click on fiftytwo week indicator and click on font color and click more colors$")
	public void click_on_fiftytwo_week_indicator_and_click_on_font_color_and_click_more_colors() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String fiftytwoweekindicator = Common.readPropertyByScreener().getProperty("fiftytwoweekindicator");
		String Fontcolor = Common.readPropertyByScreener().getProperty("Fontcolor");
		String morecolors = Common.readPropertyByScreener().getProperty("morecolors");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", fiftytwoweekindicator,"IS-00011,"+Widget_name+",Click on 52 week indicator");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Fontcolor,"IS-00011,"+Widget_name+",click on font color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", morecolors,"IS-00011,"+Widget_name+",click on more colors");
	}

	@Then("^Click on color and click on save$")
	public void click_on_color_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String fontcolorblue = Common.readPropertyByScreener().getProperty("fontcolorblue");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", fontcolorblue,"IS-00011,"+Widget_name+",Click on font color as blue");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}

	@Then("^Click on outline color and click more colors$")
	public void click_on_outline_color_and_click_more_colors() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Outlinecolor = Common.readPropertyByScreener().getProperty("Outlinecolor");
		String morecolors = Common.readPropertyByScreener().getProperty("morecolors");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Outlinecolor,"IS-00011,"+Widget_name+",click on outline color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", morecolors,"IS-00011,"+Widget_name+",click on more colors");
	}

	@Then("^Click on orange color and click on save$")
	public void click_on_orange_color_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String outlinecolororange = Common.readPropertyByScreener().getProperty("outlinecolororange");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", outlinecolororange,"IS-00011,"+Widget_name+",Click on outline color as orange");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}
	
	@Then("^Click on slider color and click more colors$")
	public void click_on_slider_color_and_click_more_colors() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Slidercolor = Common.readPropertyByScreener().getProperty("Slidercolor");
		String morecolors = Common.readPropertyByScreener().getProperty("morecolors");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Slidercolor,"IS-00011,"+Widget_name+",click on slider color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", morecolors,"IS-00011,"+Widget_name+",click on more colors");
	}
	
	@Then("^Click on ice blue color and click on save$")
	public void click_on_ice_blue_color_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String slidericebluecolor = Common.readPropertyByScreener().getProperty("slidericebluecolor");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", slidericebluecolor,"IS-00011,"+Widget_name+",Click on slider color as ice blue");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
	}
		
	@Then("^Click on fill color and click more colors$")
	public void click_on_fill_color_and_click_more_colors() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String Fillcolor = Common.readPropertyByScreener().getProperty("Fillcolor");
		String morecolors = Common.readPropertyByScreener().getProperty("morecolors");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Fillcolor,"IS-00011,"+Widget_name+",click on fill color");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", morecolors,"IS-00011,"+Widget_name+",click on more colors");
	}
	
	@Then("^Click on green color and click on save$")
	public void click_on_green_color_and_click_on_save() throws Throwable {
		com.sleepThread(5000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByScreener().getProperty("Widget_name"))).getText();
		String fillcolorgreen = Common.readPropertyByScreener().getProperty("fillcolorgreen");
		String Save = Common.readPropertyByScreener().getProperty("Save");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", fillcolorgreen,"IS-00011,"+Widget_name+",Click on fill color as green");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Save,"IS-00011,"+Widget_name+",click on save");
		com.sleepThread(3000);
	}
	
	  //Column set
	   @Given("^Click default column set$")
	   public void click_on_default_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByScreener().getProperty("Columnsetdropdown");
			com.sleepThread(7000);
			com.startAction();
			com.MouseOverToElement("xpath", Columnsetdropdown, "ILTC-00029,Options,Mouse hover on column set dropdown");
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on column set dropdown");			
	   }

	   @Then("^select column set for which you want to get desired results$")
	   public void select_the_column_set_for_which_you_want_to_get_desired_results() throws Throwable {
		    String Defaultdropdown = Common.readPropertyByScreener().getProperty("Defaultdropdown");
			com.sleepThread(3000);
			com.startAction();
			com.MouseOverToElement("xpath", Defaultdropdown, "ILTC-00030,Options,Mouse hover on Default column set");
			com.click("xpath", Defaultdropdown, "ILTC-00030,Options,Click on Default column set");
	   }

	   @Then("^Verify columns whether they are from selected column set or not$")
	   public void verify_the_columns_whether_they_are_from_selected_column_set_or_not() throws Throwable {
		    String percentagechange = Common.readPropertyByScreener().getProperty("percentagechange");
			String Bid = Common.readPropertyByScreener().getProperty("Bid");
			String Ask = Common.readPropertyByScreener().getProperty("Ask");
			String Close = Common.readPropertyByScreener().getProperty("Close");
			String Exthrs = Common.readPropertyByScreener().getProperty("Exthrs");
			com.sleepThread(5000);
			String percentchange = "% Change";
			String bidtext = "Bid";
			String Asktext = "Ask";
			String closetext = "Close";
			String Exthrstext = "ExtHours";
			com.verifyText("xpath", percentagechange, percentchange, "ILTC-00030,Options,Verify % cha ge text column of Selected columns set");
			com.sleepThread(5000);
			com.verifyText("xpath", Bid, bidtext, "ILTC-00030,Options,Verify bid text column of Selected column set");
			com.sleepThread(5000);
			com.verifyText("xpath", Ask, Asktext, "ILTC-00030,Options,Verify ask text column of Selected column set");
			com.sleepThread(5000);
			com.verifyText("xpath", Close, closetext, "ILTC-00030,Options,Verify close text column of Selected column set");
			com.sleepThread(5000);
			com.verifyText("xpath", Exthrs, Exthrstext, "ILTC-00030,Options,Verify ExtHours text column of Selected column set");
	   }
	   
	   //Duplicate column set
	   @Given("^Click on default column set and then select New$")
	   public void click_on_the_default_column_set_and_select_New() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByScreener().getProperty("Columnsetdropdown");
			String Newdropdown = Common.readPropertyByScreener().getProperty("Newdropdown");
			com.sleepThread(6000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on Default column set");
			com.sleepThread(5000);
			//com.waitUntilElementPresent(NewColumnset);
			com.startAction();
			com.MouseOverToElement("xpath", Newdropdown, "ILTC-00030,Options,Click on New column set dropdown");
			com.click("xpath", Newdropdown, "ILTC-00030,Options,Click on New column set dropdown");
	   }

	   @Then("^Enter the Name \"([^\"]*)\" of new column set$")
	   public void enter_Name_of_new_column_set(String Name) throws Throwable {
		    String Nameinput = Common.readPropertyByScreener().getProperty("Nameinput");
			com.sleepThread(3000);
			com.sendKeys("xpath", Nameinput, Name, "ITLC-31,Options,Enter the name for column set");
	   }

	   @Then("^Select available columns and then click right arrow$")
	   public void select_the_available_columns_and_click_right_arrow() throws Throwable {
		    String Priceandvolume = Common.readPropertyByScreener().getProperty("Priceandvolume");
			String Asksize = Common.readPropertyByScreener().getProperty("Asksize");
			String Bidsize = Common.readPropertyByScreener().getProperty("Bidsize");
			String rightarrow = Common.readPropertyByScreener().getProperty("rightarrow");
			com.sleepThread(5000);
			com.click("xpath", Priceandvolume, "ITLC-32,Options,click on price and volume in available columns");
			com.sleepThread(3000);
			com.click("xpath", Asksize, "ITLC-35,Options,click on Ask size in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", Bidsize, "ITLC-35,Options,click on Bid size in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");		
	   }

	   @Then("^click on the save and again click on default dropdown$")
	   public void click_on_save_and_again_click_on_default_dropdown() throws Throwable {
		    String savecolumnset = Common.readPropertyByScreener().getProperty("Savecolumnset");
			String Columnsetdropdown = Common.readPropertyByScreener().getProperty("Columnsetdropdown");
			com.sleepThread(5000);
			com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on default column set");
	   }

	   @Then("^Click on New and enter Same Name \"([^\"]*)\"$")
	   public void click_on_New_and_enter_the_Same_Name(String Name) throws Throwable {
		    String Newdropdown = Common.readPropertyByScreener().getProperty("Newdropdown");
			String Nameinput = Common.readPropertyByScreener().getProperty("Nameinput");
			com.sleepThread(5000);
			com.click("xpath", Newdropdown, "ILTC-00029,Options,Click on New column set");
			com.sendKeys("xpath", Nameinput, Name, "ITLC-35,Options,Verify entering symbol input");
	   }

	   @Then("^Add the available columns by clicking on the right arrow$")
	   public void add_available_columns_by_clicking_on_the_right_arrow() throws Throwable {
		    String Priceandvolume = Common.readPropertyByScreener().getProperty("Priceandvolume");
			String Askyield = Common.readPropertyByScreener().getProperty("Askyield");
			String Averaegevolume = Common.readPropertyByScreener().getProperty("Averaegevolume");
			String rightarrow = Common.readPropertyByScreener().getProperty("rightarrow");
			com.sleepThread(3000);
			com.click("xpath", Priceandvolume, "ITLC-32,Options,click on price and volume in available columns");
			com.sleepThread(3000);
			com.click("xpath", Averaegevolume, "ITLC-35,Options,click on Avreage volume in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", Askyield, "ITLC-35,Options,click on Ask Yield in price and volume");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
	   }

	   @Then("^click on save and check duplicate column set should not be added and click on cancel after verification$")
	   public void click_on_the_save_and_duplicate_column_set_should_not_be_added_and_click_on_cancel_after_verification() throws Throwable {
		    String Savecolumnset = Common.readPropertyByScreener().getProperty("Savecolumnset");
			String cancelcolumnset = Common.readPropertyByScreener().getProperty("cancelcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Savecolumnset, "ILTC-00029,Options,Click on Save column set and colum set not added");
			com.sleepThread(9000);
			com.click("xpath", cancelcolumnset, "ILTC-00029,Options,Click on cancel column set");
	   }
	   
	   //Editing column set
	   @Given("^Click on columnset dropdown and then click manage column set$")
	   public void click_on_the_columnset_dropdown_and_then_click_on_manage_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByScreener().getProperty("Columnsetdropdown");
			String Managecolumnset = Common.readPropertyByScreener().getProperty("Managecolumnsset");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on Columnset");
			com.sleepThread(4000);
			com.click("xpath", Managecolumnset, "ILTC-00029,Options,Click on Manage column set"); 
	   }

	   @Then("^Select column set that needs to be edited and then click on edit$")
	   public void select_the_column_set_that_needs_to_be_edited_and_click_on_edit() throws Throwable {
		    String customcolumnset = Common.readPropertyByScreener().getProperty("customcolumnset");
			String Editcolumnset = Common.readPropertyByScreener().getProperty("Editcolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnset, "ILTC-00029,Options,Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", Editcolumnset, "ILTC-00029,Options,Click on Edit column set");
	   }

	   @Then("^clear the Name field and enter New Name \"([^\"]*)\"$")
	   public void clear_Name_field_and_enter_the_New_Name(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByScreener().getProperty("Editnameinput");
			com.sleepThread(5000);
			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,Options,Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,Options,Verify entering Name input");
	   }

	   @Then("^Click on the Save and then verify columnset name$")
	   public void click_on_Save_and_verify_columnset_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByScreener().getProperty("Editsavecolumnset");
			String customcolumnsetedit = Common.readPropertyByScreener().getProperty("customcolumnsetedit");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(customcolumnsetedit);
			String text ="Testcolumnset1";
			com.verifyText("xpath", customcolumnsetedit, text, "ITLC-00029,Options, Verify Edited column set name");
			//com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on cancel column set");
	   }

	   //Copy column set
	   @Given("^Select column set that needs to be copied and then click on the copy column set$")
	   public void select_the_column_set_that_needs_to_be_copied_and_Click_on_copy_column_set() throws Throwable {
		    String customcolumnsetedit = Common.readPropertyByScreener().getProperty("customcolumnsetedit");
			String copycolumnset = Common.readPropertyByScreener().getProperty("copycolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnsetedit, "ILTC-00029,Options,Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", copycolumnset, "ILTC-00029,Options,Click on Copy column set");
	   }

	   @Then("^Clear input name and enter new column set Name \"([^\"]*)\" and add column$")
	   public void clear_the_name_and_enter_new_column_set_Name_and_add_column(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByScreener().getProperty("Editnameinput");
			String Priceandvolume = Common.readPropertyByScreener().getProperty("Priceandvolume");
			String rightarrow = Common.readPropertyByScreener().getProperty("rightarrow");
			String BidAsk = Common.readPropertyByScreener().getProperty("BidAsk");
//			com.sleepThread(5000);
//			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,Options,Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,Options,Verify entering Name input");
			com.sleepThread(3000);
			com.click("xpath", Priceandvolume, "ITLC-32,Options,click on price and volume in available columns");
			com.sleepThread(3000);
			com.click("xpath", BidAsk, "ITLC-35,Options,click on Bid-Ask in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
	   }

	   @Then("^Click on save and the verify the copied column set name$")
	   public void click_on_save_and_verify_copied_column_set_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByScreener().getProperty("Editsavecolumnset");
			String Copiedcustomcolumnset = Common.readPropertyByScreener().getProperty("Copiedcustomcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(Copiedcustomcolumnset);
			String text ="Test";
			com.verifyText("xpath", Copiedcustomcolumnset, text, "ITLC-00029,Options, Verify Copied column set name");
	   }
	   
	   //Delete column set
	   @Given("^Click on the delete button and then click on the confirmation ok button$")
	   public void click_on_delete_button_and_then_click_on_Confirmation_ok_button() throws Throwable {
		    String customcolumnsetedit = Common.readPropertyByScreener().getProperty("customcolumnsetedit");
		    String Deletecolumnset = Common.readPropertyByScreener().getProperty("Deletecolumnset");
			String Deleteconfirmationcolumnset = Common.readPropertyByScreener().getProperty("Deleteconfirmationcolumnset");
			com.sleepThread(5000);
			com.MouseOverToclickabl("xpath", customcolumnsetedit, "ILTC-00029,Options,Click on Column set");
			com.sleepThread(5000);
			com.click("xpath", Deletecolumnset, "ILTC-00029,Options,Click on Delete Column set");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", Deleteconfirmationcolumnset, "ILTC-00029,Options,Mouse hover on Delete Confirmation");
			com.click("xpath", Deleteconfirmationcolumnset, "ILTC-00029,Options,Click on Delete Confirmation");
	   }

	   @Then("^Verify whether column set was deleted or not$")
	   public void verify_whether_column_set_is_deleted_or_not() throws Throwable {
		    String Copiedcustomcolumnset = Common.readPropertyByScreener().getProperty("Copiedcustomcolumnset");
			String closecolumnset = Common.readPropertyByScreener().getProperty("close");
			com.sleepThread(4000);
			String text ="Test";
			com.verifyTextnotdisplaying("xpath", Copiedcustomcolumnset, text, "ITLC-00029,Options, Verify Deleted column set name");
			com.sleepThread(4000);
			com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on Close");
	   }
}
