package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Market_Depth {
	public Common com = new Common();
	public Market_Depth MD;
	public WebDriver driver;
	public String Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public Market_Depth() {
		driver = Common.driver;
	}
	
	@Given("^Verify the Market Depth$")
	public void Verify_the_Market_Depth() throws Exception {
		
		String  Market_Depth = Common.readPropertyByMarket_Depth().getProperty("Market_Depth1");
		com.verifyElementPresent("xpath",Market_Depth, "ICATC-00001,Chart,Verify the Market Depth");
	}
	@And("^Click on Market Depth$")
	public void Click_on_Market_Depth() throws Exception {
		String Add_Widget = Common.readPropertyByMarket_Depth().getProperty("Add_Widget");
		com.click("xpath",Add_Widget,"clicked on + icon");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//com.click("xpath", Add_Widget, "clicked on + icon");
		com.sleepThread(2000);
		String  Market_Depth = Common.readPropertyByMarket_Depth().getProperty("Market_Depth");
		com.sleepThread(2000);
		com.click("xpath",Market_Depth, "ICATC-00002,Chart,Click on Market Depth");
				}
	@When("^Verify the Symbol Linking in Market Depth$")
	public void Verify_the_Symbol_Linking_in_Market_Depth() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByMarket_Depth().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking,
				"ICATC-00003," + Widget_name + ",Verify the Symbol Linking in Market_Depth");
	}

	@And("^Click on Symbol Linking in Market Depth$")
	public void click_on_Symbol_Linking_in_Market_Depth() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Symbol_Linking = Common.readPropertyByMarket_Depth().getProperty("Symbol_Linking");
		com.sleepThread(3000);
		com.click("xpath", Symbol_Linking, "ICATC-00004," + Widget_name + ",Click on Symbol Linking in Calendar");
	}

	@And("^click on each Check Functionalities in Market Depth$")
	public void check_Functionalities_in_Market_Depth() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		MD=new Market_Depth();
		int count = driver
				.findElements(By.xpath("//div[@class='css-14gmpk3']//li//button[1]")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//div[@class='css-14gmpk3']//li["+i+"]//button[1]",
					"ICATC-00005," + Widget_name + ",Verify the each Check Functionalities in Market_Depth");
			com.click("xpath", "//div[@class='css-14gmpk3']//li["+i+"]//button[1]",
					"ICATC-00006," + Widget_name + ",Click on each Check Functionalities in Market_Depth");
			com.sleepThread(3000);
			MD.click_on_Symbol_Linking_in_Market_Depth();
		}
		MD=new Market_Depth();
		int count1 = driver
				.findElements(By.xpath("//div[@class='css-14gmpk3']//li//button[1]")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//div[@class='css-14gmpk3']//li["+j+"]//button[1]",
					"ICATC-00005," + Widget_name + ",Verify the each Check Functionalities in Market_Depth");
			com.click("xpath", "//div[@class='css-14gmpk3']//li["+j+"]//button[1]",
					"ICATC-00006," + Widget_name + ",Click on each Check Functionalities in Market_Depth");
			com.sleepThread(3000);
			MD.click_on_Symbol_Linking_in_Market_Depth();
		}
		com.click("xpath", "//div[@class='css-14gmpk3']//li[12]//button[1]",
				"ICATC-00006," + Widget_name + ",Click on each Check Functionalities in Market_Depth");
		com.sleepThread(3000);
	}
	
	
		@When("^Verify the Enter_symbol Drop Down in Market Depth$")
		public void Verify_the_Enter_symbol_Market_Depth() throws Exception {
			String ICE_Drop_Down = Common.readPropertyByMarket_Depth().getProperty("ICE_Drop_Down");
			com.sleepThread(1000);
			Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
					.getText();
			com.verifyElementPresent("xpath", ICE_Drop_Down,
					"ICATC-00007," + Widget_name + ",Verify the Enter_symbol Drop Down");
		}

		@And("^Click on Enter_symbol Drop Down in Market Depth$")
		public void Click_on_ICE_Drop_Down() throws Exception {
			String ICE_Drop_Down = Common.readPropertyByMarket_Depth().getProperty("ICE_Drop_Down");
			com.sleepThread(3000);
			Widget_name = driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name")))
					.getText();
			com.click("xpath", ICE_Drop_Down, "ICATC-00008," + Widget_name + ",Click on Enter_symbol Drop Down");
		}

		@And("^Enter_symbol the each list in Market Depth$")
		public void Enter_symbol_the_each_list() throws Exception {
			MD=new Market_Depth();
			int size = driver.findElements(By.xpath("//div[@class='pt-popover-content']//div")).size();
			System.out.println("suggestion item " + size);
			for (int i = 2; i < size; i++) {
				System.out.println(i);
				com.startAction();
				// com.MouseOverToElement("xpath","/html/body/div[6]/div/span/div/div/div[2]/div/div["+i+"]/span/span","");
				String text = driver
						.findElement(By.xpath("//div[@class='pt-popover-content']//div["+i+"]"))
						.getText();
				System.out.println("text" + text);
				com.MouseOverToclickabl("xpath", "//div[@class='pt-popover-content']//div["+i+"]",
						"ICATC-00009," + Widget_name + ",Click on_symbol the " + text + " list");
				driver.navigate().refresh();
				com.sleepThread(10000);
				try {
					com.sleepThread(9000);
					String Select_text = driver
							.findElement(By.xpath(
									"//*[@id='7']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div/div[1]/span[2]"))
							.getText();
					System.out.println("Select_text" + Select_text);
					if (Select_text.equals(text)) {
						com.Creatlogfile(Date_Time + "," + "ICATC-00010," + Widget_name + ",User selected symbol " + text
								+ " is chart header table dispalyed or not" + ",Pass");
					} else {
						com.Creatlogfile(Date_Time + "," + "ICATC-00010," + Widget_name + ",User selected symbol " + text
								+ " is chart header table dispalyed or not" + ",Fail");
					}
				} catch (Exception e) {
					com.Creatlogfile(Date_Time + "," + "ICATC-00010," + Widget_name
							+ ",User selected symbol data is not present" + ",Pass");
				}
				try {
					com.sleepThread(9000);
					String Input_text = driver.findElement(By.xpath(
							"//*[@id='0']/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span[1]/div/span/div/input"))
							.getAttribute("value");
					System.out.println("Input_text" + Input_text);
					if (text.equals(Input_text)) {
						com.Creatlogfile(Date_Time + "," + "ICATC-00011," + Widget_name + ",User selected symbol "
								+ Input_text + " is symbol drop down is dispalyed or not" + ",Pass");
					} else {
						com.Creatlogfile(Date_Time + "," + "ICATC-00011," + Widget_name + ",User selected symbol "
								+ Input_text + " is symbol drop down is not dispalyed" + ",Fail");
					}
				} catch (Exception e) {
					com.Creatlogfile(Date_Time + "," + "ICATC-00010," + Widget_name
							+ ",User selected symbol data is not present" + ",Pass");
				}
				com.sleepThread(2000);
				MD.Click_on_ICE_Drop_Down();
				
			}
		}
		
	
		@When("^Right click on data box in Market Depth$")
		public void Right_click_on_data_box_in_Market_Depth() throws Exception
		{
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			com.startAction();
			String data_box=Common.readPropertyByMarket_Depth().getProperty("data_box");
			com.Rightclick("xpath",data_box,"INTC-00010,"+Widget_name+",click on data box in Market Depth");
		}
		@And("^Click on column option$")
		public void Click_on_column_option() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			com.startAction();
			String Column =Common.readPropertyByMarket_Depth().getProperty("Column");
			com.MouseOverToclickabl("xpath",Column,"INTC-00010,"+Widget_name+",Clicked on column option");
	}
		
		@And("^Verify Market Depth Column Selection pop title in Market Depth$")
		public void Verify_Market_Depth_Column_Selection_pop_title_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Display_Preferences_pop_title = Common.readPropertyByMarket_Depth()
					.getProperty("Display_Preferences_pop_title");
			com.verifyElementPresent("xpath", Display_Preferences_pop_title,
					"IWLTC-00026,"+Widget_name+",Verify Display Preferences pop title");
		}

		@And("^Verify Market Depth Column Selection pop close icon in Market Depth$")
		public void Verify_Market_Depth_Column_Selection_pop_close_icon_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_close_icon");
			com.verifyElementPresent("xpath", Display_Preferences_pop_close_icon,
					"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
		}

		@And("^Verify Market Depth Column Selection pop save button in Market Depth$")
		public void Verify_Market_Depth_Column_Selection_pop_button_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_Apply");
			com.verifyElementPresent("xpath", Display_Preferences_pop_Apply,
					"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
		}

		@And("^Verify Market Depth Column Selection pop Cancel button in Market Depth$")
		public void Verify_Market_Depth_Column_Selection_pop_Cancel_button_in_Market_Depth() throws Exception {
			com.sleepThread(2000);
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_Cancel");
			com.verifyElementPresent("xpath", Display_Preferences_pop_Cancel,
					"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
		}
		
		@And("^Click on Market Depth Column Selection pop close icon in Market Depth$")
		public void Click_on_Market_Depth_Column_Selection_pop_close_icon_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			com.startAction();
			String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_close_icon");
			com.MouseOverToclickabl("xpath", Display_Preferences_pop_close_icon,
					"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
		}

		@And("^Click on Market Depth Column Selection pop save button in Market Depth$")
		public void Click_on_Market_Depth_Column_Selection_pop_save_button_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			com.startAction();
			String Display_Preferences_pop_Apply1 = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_Apply");
			com.MouseOverToclickabl("xpath", Display_Preferences_pop_Apply1,
					"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
		}

		@And("^Click on Market Depth Column Selection pop Cancel button in Market Depth$")
		public void Click_on_Market_Depth_Column_Selection_pop_Cancel_button_in_Market_Depth() throws Exception {
			com.sleepThread(2000);
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			com.startAction();
			String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_Cancel");
			com.MouseOverToclickabl("xpath", Display_Preferences_pop_Cancel,
					"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
		}		
		@And("^Verify Available Columns title in Market Depth Column Selection pop in Market Depth$")
		public void Verify_Available_Columns_title_in_Market_Depth_Column_Selection_pop_in_Market_Depth() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Available_Columns = Common.readPropertyByMarket_Depth()
					.getProperty("Available_Columns");
			com.verifyElementPresent("xpath",Available_Columns,"IWLTC-00171,"+Widget_name+",Verify Available Columns title in Save Column Set pop");
		}

		@And("^Verify Search box Available Columns title below in Market Depth Column Selection pop in Market Depth$")
		public void Verify_Search_box_Available_Columns_title_below_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box = Common.readPropertyByMarket_Depth()
					.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box");
			com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box,
					"IWLTC-00172,"+Widget_name+",Verify Search box Available Columns title below in Save Column Set pop");
		}

		@And("^Verify Selected Columns title in Market Depth Column Selection pop in Market Depth$")
		public void Verify_Selected_Columns_title_in_Save_Column_Set() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title = Common.readPropertyByMarket_Depth()
					.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title");
			com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title,
					"IWLTC-00173,"+Widget_name+",Verify Selected Columns title in Save Column Set");
		}

		@And("^Verify Search box Selected Columns title below in Market Depth Column Selection pop in Market Depth$")
		public void Verify_Search_box_Selected_Columns_title_below_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box = Common.readPropertyByMarket_Depth()
					.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box");
			com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box,
					"IWLTC-00174,"+Widget_name+",Verify Search box Selected Columns title below in Save Column Set pop");
		}

		@And("Verify Set this column set as default checkbox in Market Depth Column Selection pop in Market Depth")
		public void Verify_Set_this_column_set_as_default_checkbox_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Pre_defined_Column_Sets_Save_column_set_checkbox = Common.readPropertyByWatch_List()
					.getProperty("Pre_defined_Column_Sets_Save_column_set_checkbox");
			com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_checkbox,
					"IWLTC-00175,"+Widget_name+",Verify Set this column set as default checkbox in Save Column Set pop");
		}

		@And("^Verify Available Columns Each list in Market Depth Column Selection pop in Market Depth$")
		public void Verify_Available_Columns_Each_list_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			int Available_Columns_list = driver.findElements(By.xpath(
					"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println("" + Available_Columns_list);

			for (int i = 1; i <= 2; i++) {
				com.sleepThread(2000);
				com.verifyElementPresent("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[1]/span[2]/div",
						"IWLTC-00175,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
				com.click("xpath",
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[1]/span[2]/div",
						"IWLTC-00176,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
				int sublist = driver.findElements(By.xpath(
						"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
						.size();
				System.out.println("sublist:" + sublist);
				for (int j = 1; j <= 2; j++) {
					com.sleepThread(2000);
					com.verifyElementPresent("xpath",
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
									+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div",
							"IWLTC-00177,"+Widget_name+",Verify Sublist Available Columns Each list in Save Column Set pop");
					com.click("xpath",
							"/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[\"+i+\"]/div[2]/div/ul/li[\"+j+\"]/div[1]/span[2]/div",
							"IWLTC-00178,"+Widget_name+",Click on Sublist Available Columns Each list in Save Column Set pop");
					com.sleepThread(2000);
					String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByWatch_List()
							.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
					com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right,
							"IWLTC-00179,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow right");
				}
				int Selected_Columns_list = driver
						.findElements(By.xpath(
								"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[1]/span/div/div[3]/div"))
						.size();
				System.out.println(Selected_Columns_list);
				for (int k = 1; k <= 2; k++) {
					com.verifyElementPresent("xpath",
							"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[1]/span/div/div[3]/div/button["+k+"]",
									
							"IWLTC-00180,"+Widget_name+",Verify Available Columns Each list in Save Column Set pop");
					com.click("xpath",
							"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[1]/span/div/div[3]/div/button["+k+"]",
							"IWLTC-00181,"+Widget_name+",Click on Available Columns Each list in Save Column Set pop");
					com.sleepThread(2000);
					String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByWatch_List()
							.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
					com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left,
							"IWLTC-00182,"+Widget_name+",Click on Pre defined Column Sets Add Column Set arrow left");
				}
			}
		}

		@And("^Verify double Arrow right icon in Market Depth Column Selection pop in Market Depth$")
		public void Verify_double_Arrow_right_icon_in_Save_Column_Set_pop() throws Exception {
			com.sleepThread(5000);
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Double_Right_Arrow = Common.readPropertyByMarket_Depth()
					.getProperty("Double_Right_Arrow");
			// com.MouseOverToclickabl("xpath",
			// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
			com.verifyElementPresent("xpath",Double_Right_Arrow ,
					"IWLTC-00183,"+Widget_name+",Verifying double Arrow right icon in Market Depth Column Selection pop in Market Depth");
		}

		@And("^Verify double Arrow left icon in Market Depth Column Selection pop in Market Depth$")
		public void Verify_double_Arrow_left_icon_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Double_Left_Arrow = Common.readPropertyByMarket_Depth()
					.getProperty("Double_Left_Arrow");
			// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
			com.verifyElementPresent("xpath",Double_Left_Arrow ,
					"IWLTC-00184,"+Widget_name+",Verifying double Arrow left icon");
		}

		@And("^Verify down arrow default disable or not in Market Depth Column Selection pop in Market Depth$")
		public void Verify_down_arrow_default_disable_or_not_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Down_Arrow = Common.readPropertyByMarket_Depth()
					.getProperty("Down_Arrow");
			com.verifyElementPresent("xpath",Down_Arrow ,
					"IWLTC-00185,"+Widget_name+",Verify down arrow");
		}

		@And("^Verify up arrow default disable or not in Market Depth Column Selection pop in Market Depth$")
		public void Verify_up_arrow_default_disable_or_not_in_Save_Column_Set_pop() throws Exception {
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String Up_Arrow = Common.readPropertyByMarket_Depth()
					.getProperty("Up_Arrow");
			com.verifyElementPresent("xpath",Up_Arrow ,
					"IWLTC-00186,"+Widget_name+",Verify up arrow");
			
			String Display_Preferences_pop_Apply1 = Common.readPropertyByWatch_List()
					.getProperty("Display_Preferences_pop_Apply");
			com.MouseOverToclickabl("xpath", Display_Preferences_pop_Apply1,
					"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
		}

		@Then("^verify the View option in Market Depth$")
		public void verify_the_View_option_in_Market_Depth() throws Exception
		{
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String View=Common.readPropertyByMarket_Depth().getProperty("View");
			com.verifyElementPresent("xpath",View,"INTC-00010,"+Widget_name+", Date_Time");

		}
		@And("^Click on submenus in view option in Market Depth$")
		public void Click_on_submenus_in_view_option_in_Market_Depth() throws Exception
		{
			Widget_name = driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name")))
					.getText();
			com.startAction();
			String Rightclick_view_option = Common.readPropertyByMarket_Depth().getProperty("Rightclick_view_option");
			com.MouseOverToElement("xpath", Rightclick_view_option, ",Chart,mouse over on view option");
			int size = driver.findElements(By.xpath("//*[@id=container]/div/div/div/div/div[6]/div/ul/li[3]/div/ul/li"))
					.size();
			for (int i = 1; i < size; i++) {
				com.click("xpath", "//*[@id=container]/div/div/div/div/div[6]/div/ul/li[3]/div/ul/li[" + i + "]",
						"ICTC-00190," + Widget_name + ",Click on submenus in view option");
				com.sleepThread(2000);
				com.startAction();
				String second_widget = Common.readPropertyByChart().getProperty("second_widget");
				com.Rightclick("xpath", second_widget, ",Chart,Right click on open the new widget name");
				com.sleepThread(1000);
				String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
				com.click("xpath", Close_Tab, ",Chart,Click on Close Tab and verify the tab is closeing or not");
				com.sleepThread(5000);
				String data_box = Common.readPropertyByMarket_Depth().getProperty("data_box");
				com.Rightclick("xpath", data_box,
						"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
				com.MouseOverToElement("xpath", Rightclick_view_option, ",Chart,mouse over on view option");

			}
		}
		@And("^Verify the Add to Symbol List option in Market Depth$")
		public void Verify_the_Add_to_Symbol_List_option_in_Market_Depth() throws Exception
		{
			Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
			String data_box = Common.readPropertyByMarket_Depth().getProperty("data_box");
			com.Rightclick("xpath", data_box,
					"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
			
			String Add_To_Symbol=Common.readPropertyByMarket_Depth().getProperty("Add_To_Symbol");
			com.verifyElementPresent("xpath",Add_To_Symbol,"INTC-00010,"+Widget_name+",Verify Add to Symbol List");
		}
		
		@And("^Click on Add to Symbol List option in Market Depth$")
		public void Click_on_Add_to_Symbol_List_option_in_Market_Depth() throws Exception
		{
			Widget_name = driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name")))
					.getText();
			
			String data_box = Common.readPropertyByMarket_Depth().getProperty("data_box");
			com.Rightclick("xpath", data_box,
					"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
			
			com.startAction();
			String Add_To_Symbol = Common.readPropertyByMarket_Depth().getProperty("Add_To_Symbol");
			com.MouseOverToElement("xpath",Add_To_Symbol , ",Chart,mouse over on view option");
			int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[2]/div/ul/li"))
					.size();
			for (int i = 1; i < size; i++) {
				com.click("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[2]/div/ul/li[" + i + "]",
						"ICTC-00190," + Widget_name + ",Click on submenus in view option");
				com.sleepThread(5000);
				
				com.Rightclick("xpath", data_box,
						"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
				com.MouseOverToElement("xpath",data_box, ",Chart,mouse over on view option");
		}
		}
			@And("^Click on defauilts in Market Depth$")
			public void Click_on_defauilts_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String data_box = Common.readPropertyByMarket_Depth().getProperty("data_box");
				com.Rightclick("xpath", data_box,
						"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
				String Defaults=Common.readPropertyByMarket_Depth().getProperty("Defaults");
				com.MouseOverToclickabl("xpath",Defaults,"INTC-00010,"+Widget_name+",Click on defauilts");

			}
			@And("^Verify the sub_menus in Defaults options$")
			public void Verify_the_sub_menus_in_Defaults_options() throws Exception {
				Widget_name = driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name")))
						.getText();
				String data_box = Common.readPropertyByMarket_Depth().getProperty("data_box");
				com.Rightclick("xpath", data_box,
						"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
				String Defaults_option = Common.readPropertyByMarket_Depth().getProperty("Defaults");
				com.MouseOverToElement("xpath", Defaults_option,
						"ICTC-00204," + Widget_name + ",Verify the submenus in Defaults options");

				int size = driver
						.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li[4]/div/ul/li"))
						.size();
				for (int i = 1; i <= size; i++) {
					com.verifyElementPresent("xpath",
							"//*[@id='container']/div/div/div/div/div[6]/div/ul/li[4]/div/ul/li[" + i + "]",
							"," + Widget_name + ",Verify the submenus in Defaults options");
				}
			}
			@And("^Click on Display preferences in Market Depth$")
			public void Click_on_Display_preferences_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String Display_preferences=Common.readPropertyByNews().getProperty("Display_preferences");
				com.MouseOverToclickabl("xpath",Display_preferences,"INTC-00010,"+Widget_name+",Click on Display preferences");
		}
			
			@And("^Verify Display Preferences pop title in Market Depth$")
			public void Verify_Display_Preferences_pop_title_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				String Display_Preferences_pop_title = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_title");
				com.verifyElementPresent("xpath", Display_Preferences_pop_title,
						"IWLTC-00026,"+Widget_name+",Verify Display Preferences pop title");
			}

			@And("^Verify Display Preferences pop close icon in Market Depth$")
			public void Verify_Display_Preferences_pop_close_icon_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_close_icon");
				com.verifyElementPresent("xpath", Display_Preferences_pop_close_icon,
						"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
			}

			@And("^Verify Display Preferences pop save button in Market Depth$")
			public void Verify_Display_Preferences_p_button_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_Apply");
				com.verifyElementPresent("xpath", Display_Preferences_pop_Apply,
						"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
			}

			@And("^Verify Display Preferences pop Cancel button in Market Depth$")
			public void Verify_Display_Preferences_pop_Cancel_button_in_Market_Depth() throws Exception {
				com.sleepThread(2000);
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_Cancel");
				com.verifyElementPresent("xpath", Display_Preferences_pop_Cancel,
						"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
			}
			
			@And("^Click on Display Preferences pop close icon in Market Depth$")
			public void Click_on_Display_Preferences_pop_close_icon_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_close_icon");
				com.MouseOverToclickabl("xpath", Display_Preferences_pop_close_icon,
						"IWLTC-00027,"+Widget_name+",Verify Display Preferences pop close icon");
			}

			@And("^Click on Display Preferences pop save button in Market Depth$")
			public void Click_on_Display_Preferences_pop_save_button_in_Market_Depth() throws Exception {
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_Apply");
				com.MouseOverToclickabl("xpath", Display_Preferences_pop_Apply,
						"IWLTC-00029,"+Widget_name+",Verify Display Preferences pop Apply button");
			}

			@And("^Click on Display Preferences pop Cancel button in Market Depth$")
			public void Click_on_Display_Preferences_pop_Cancel_button_in_Market_Depth() throws Exception {
				com.sleepThread(2000);
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
						.getProperty("Display_Preferences_pop_Cancel");
				com.MouseOverToclickabl("xpath", Display_Preferences_pop_Cancel,
						"IWLTC-00030,"+Widget_name+",Verify Display Preferences pop Cancel button");
			}		
	@And("^Click on side by side view in Display preferences in Market Depth$")
	public void Click_on_side_by_side_view_in_Display_preferences_in_Market_Depth()
	{
		
	}
	@And("^Click on Depth of market view in Display preferences in Market Depth$")
	public void Click_on_Depth_of_market_view_in_Display_preferences_in_Market_Depth()
	{
		
	}
	@And("^Click on mirror view in Display preferences in Market Depth$")
	public void Click_on_mirror_view_in_Display_preferences_in_Market_Depth()
	{
		
	}
	
			@And("^Click on appearance option in Display preferences in Market Depth$")
			public void Click_on_appearance_option_in_Display_preferences_in_Market_Depth() throws Exception
			{
				com.sleepThread(2000);
				Widget_name=driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name"))).getText();
				com.startAction();
				String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
						.getProperty("");
				com.MouseOverToclickabl("xpath",Display_Preferences_pop_Cancel ,
						"IWLTC-00030,"+Widget_name+",Click on appearance option in Display preferences in Market Depth");

			}
			@And("^Display preferences appearance each colors it will showing more colors or not$")
			public void Display_preferences_appearance_each_colors_it_will_showing_more_colors_or_not() throws Exception {
				com.sleepThread(2000);
				Widget_name = driver.findElement(By.xpath(Common.readPropertyByMarket_Depth().getProperty("Widget_name")))
						.getText();
				int size = driver.findElements(By.xpath(
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr/td[2]/div/span/button"))
						.size();
				for (int i = 1; i < size; i++) {
					com.click("xpath",
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
									+ "]/td[2]/div/span/button",
							"ICTC-00100,Chart,Click on Right click each plot colors it will showing more colors or not");
					com.sleepThread(2000);
					com.verifyElementPresent("xpath", "//*[contains(text(),'More colors...')]",
							",Chart,showing more colors or not");
					com.sleepThread(2000);
					com.click("xpath",
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
									+ "]/td[2]/div/span/button",
							",Chart,Click on Right click each plot colors it will closing more colors or not");
				}
			}

}

