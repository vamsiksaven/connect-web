package Ide.Idp.StepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Watch_List {
	public Common com = new Common();
	public Watch_List wl;
	public WebDriver driver;
	public String whatch_list;

	public Watch_List() {
		driver = Common.driver;
	}

	@Given("^Verify the Watch List$")
	public void Verify_the_Watch_List() {
		com.sleepThread(100000);
		whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		System.out.println(whatch_list);
		com.verifyElementPresent("xpath", whatch_list);
	}

	@And("^Click on Watch List$")
	public void Click_on_Watch_List() {
		whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		com.click("xpath", whatch_list);
	}

	@When("^Verify the Symbol Linking$")
	public void Verify_the_Symbol_Linking() {
		com.sleepThread(3000);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking);
	}

	@And("^Click on Symbol Linking$")
	public void click_on_Symbol_Linking() {
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.click("xpath", Symbol_Linking);
	}

	@And("^click on each Check Functionalities$")
	public void check_Functionalities() {
		wl = new Watch_List();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}

		/*
		 * com.verifyElementPresent("xpath",
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+i+"]/button/label"
		 * ); String t=driver.findElement(By.xpath(
		 * "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[\"+i+\"]/button/label"
		 * )).getText(); System.out.println(t+"****************");
		 * com.click("xpath","//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li["+
		 * i+"]/button/label"); com.sleepThread(3000);
		 */

		wl = new Watch_List();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}
	}

	@When("^Click on my wath lists Drop Down$")
	public void Click_on_my_wath_lists_Drop_Down() {
		com.sleepThread(3000);
		String my_wath_list = Common.readPropertyByWatch_List().getProperty("my_wath_lists_Drop_Down");
		com.verifyElementPresent("xpath", my_wath_list);
		com.click("xpath", my_wath_list);
	}

	@When("^Right click on each symbol$")
	public void Right_click_on_each_symbol() {
		com.startAction();
		com.sleepThread(3000);
		String Right_click_on_symbol = Common.readPropertyByWatch_List().getProperty("Right_click_on_symbol");
		com.Rightclick("xpath", Right_click_on_symbol);
	}

	@And("^Verify view button$")
	public void Verify_view_button() {

		String View = Common.readPropertyByWatch_List().getProperty("View");
		com.startAction();
		com.MouseOverToElement("xpath", View);
		com.verifyElementPresent("xpath", View);
	}

	@And("^verify Detailed Quotes button$")
	public void verify_Detailed_Quotes_button() {

		com.sleepThread(2000);
		String Detailed_Quotes = Common.readPropertyByWatch_List().getProperty("Detailed_Quotes");
		com.startAction();
		com.MouseOverToElement("xpath", Detailed_Quotes);
		com.verifyElementPresent("xpath", Detailed_Quotes);
		// com.click("xpath", Detailed_Quotes);
	}

	@And("^verify Chart button$")
	public void verify_Chart_button() {
		com.sleepThread(2000);
		// wl=new Watch_List();
		String Chart = Common.readPropertyByWatch_List().getProperty("Chart");
		com.startAction();
		com.MouseOverToElement("xpath", Chart);
		com.verifyElementPresent("xpath", Chart);
	}

	@And("^verify Insert column$")
	public void verify_Insert_column() {
		com.sleepThread(2000);
		String Insert_column = Common.readPropertyByWatch_List().getProperty("Insert_column");
		com.startAction();
		com.MouseOverToElement("xpath", Insert_column);
		com.verifyElementPresent("xpath", Insert_column);
	}

	@And("^Delete selected column$")
	public void Delete_selected_column() {
		com.sleepThread(2000);
		String Delete_selected_column = Common.readPropertyByWatch_List().getProperty("Delete_selected_column");
		com.startAction();
		com.MouseOverToElement("xpath", Delete_selected_column);
		com.verifyElementPresent("xpath", Delete_selected_column);
	}

	@And("^verify Edit$")
	public void verify_Edit() {
		com.sleepThread(2000);
		String Edit = Common.readPropertyByWatch_List().getProperty("Edit");
		com.startAction();
		com.MouseOverToElement("xpath", Edit);
		com.verifyElementPresent("xpath", Edit);
	}

	@And("^verify Display Preferences$")
	public void verify_Display_Preferences() {
		com.sleepThread(2000);
		String Display_Preferences = Common.readPropertyByWatch_List().getProperty("Display_Preferences");
		com.startAction();
		com.MouseOverToElement("xpath", Display_Preferences);
		com.verifyElementPresent("xpath", Display_Preferences);
	}

	@And("^Click Display Preferences$")
	public void Click_Display_Preferences() {
		com.sleepThread(2000);
		String Display_Preferences = Common.readPropertyByWatch_List().getProperty("Display_Preferences");
		com.startAction();
		com.MouseOverToclickabl("xpath", Display_Preferences);
	}

	@And("^Verify Display Preferences pop title$")
	public void Verify_Display_Preferences_pop_title() {
		String Display_Preferences_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_title");
		com.verifyElementPresent("xpath", Display_Preferences_pop_title);
	}

	@And("^Verify Display Preferences pop close icon$")
	public void Verify_Display_Preferences_pop_close_icon() {
		String Display_Preferences_pop_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_close_icon");
		com.verifyElementPresent("xpath", Display_Preferences_pop_close_icon);
	}

	@And("^Verify Display Preferences pop ok button$")
	public void Verify_Display_Preferences_pop_ok_button() {
		String Display_Preferences_pop_ok = Common.readPropertyByWatch_List().getProperty("Display_Preferences_pop_ok");
		com.verifyElementPresent("xpath", Display_Preferences_pop_ok);
	}

	@And("^Verify Display Preferences pop Apply button$")
	public void Verify_Display_Preferences_pop_Apply_button() {
		String Display_Preferences_pop_Apply = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Apply");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Apply);
	}

	@And("^Verify Display Preferences pop Cancel button$")
	public void Verify_Display_Preferences_pop_Cancel_button() {
		String Display_Preferences_pop_Cancel = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Cancel");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Cancel);
	}

	@And("^Verify Display Preferences pop Auto sort check box$")
	public void Verify_Display_Preferences_pop_Auto_sort_check_box() {
		String Display_Preferences_pop_Auto_sort = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Auto_sort);
	}

	@And("^Click on Auto sort check box$")
	public void Click_on_Auto_sort_check_box() {
		String Display_Preferences_pop_Auto_sort = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort");
		com.click("xpath", Display_Preferences_pop_Auto_sort);
	}

	@And("^Verify Display Preferences pop Auto sort text box$")
	public void Verify_Display_Preferences_pop_Auto_sort_text_box() {
		String Display_Preferences_pop_Auto_sort_text_box = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Auto_sort_text_box");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Auto_sort_text_box);
	}

	@And("^Verify Display Preferences pop symbol field$")
	public void Verify_Display_Preferences_pop_symbol_field() {
		String Display_Preferences_pop_Symbol_Field = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Symbol_Field");
		com.verifyElementPresent("xpath", Display_Preferences_pop_Symbol_Field);
	}

	@And("^Click on symbol field$")
	public void Click_on_symbol_field() {
		String Display_Preferences_pop_Symbol_Field = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_Symbol_Field");
		com.click("xpath", Display_Preferences_pop_Symbol_Field);
	}

	@And("^Verify and Click on All check box$")
	public void Verify_and_Click_on_All_check_box() {
		int li = driver.findElements(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < li; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]");
			com.click("xpath", "/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]");
		}
	}

	@And("^Click on formatting$")
	public void Click_on_formatting() {
		String Display_Preferences_pop_formatting = Common.readPropertyByWatch_List()
				.getProperty("Display_Preferences_pop_formatting");
		com.click("xpath", Display_Preferences_pop_formatting);
	}

	@And("^Verify and Click on All check box in formatting$")
	public void Verify_and_Click_on_All_check_box_in_formatting() {
		int li = driver.findElements(By.xpath("/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < li; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]");
			com.click("xpath", "/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]");
		}
	}

	public void d() {
		String d = Common.readPropertyByWatch_List().getProperty("Symdol");
		com.startAction();
		com.double_click_an_element("xpath", d);
	}

	@And("^Verify and Click on My watch lists and Server Watch Lists$")
	public void Verify_and_Click_on_My_watch_lists_and_Server_Watch_Lists() {
		wl = new Watch_List();
		int count = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
				.size();

		int mylist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("mylist:" + mylist);
		int Serverlist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Serverlist:" + Serverlist);
		for (int i = 2; i < mylist; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div");
			com.click("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li["
					+ i + "]/div[1]/span[2]/div");
			wl.Click_on_my_wath_lists_Drop_Down();
		}
		for (int j = 1; j <= Serverlist; j++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div");
			com.click("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li["
					+ j + "]/div[1]/span[2]/div");
			System.out.println("Run++++++++++");
			com.sleepThread(6000);
			/*
			 * wl.Right_click_on_each_symbol(); com.sleepThread(3000);
			 * wl.Verify_view_button(); com.sleepThread(3000); wl.verify_Insert_column();
			 * wl.Delete_selected_column(); wl.verify_Edit();
			 * wl.verify_Display_Preferences(); wl.d();
			 * 
			 * wl.verify_Detailed_Quotes_button(); com.sleepThread(3000);
			 * wl.verify_Chart_button();
			 */
			wl.Click_on_my_wath_lists_Drop_Down();

		}

	}

	@When("^Click on New...$")
	public void Click_on_New() {
		com.sleepThread(2000);
		String my_wath_new = Common.readPropertyByWatch_List().getProperty("my_wath_list_New");
		com.click("xpath", my_wath_new);
	}

	@And("^Verify Add New Symbol List title$")
	public void Verify_Add_New_Symbol_List_title() {
		String symbol_list_title = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_title");
		com.verifyElementPresent("xpath", symbol_list_title);
	}

	@And("^Verify text box$")
	public void Verify_text_box() {
		String text_box = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_texbox");
		com.verifyElementPresent("xpath", text_box);
	}

	@And("^Verify ok button$")
	public void Verify_ok_button() {
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.verifyElementPresent("xpath", ok);
	}

	@And("^Verify cancel button$")
	public void Verify_cancel_button() {
		String cancel = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_cancel");
		com.verifyElementPresent("xpath", cancel);
		com.sleepThread(3000);
	}

	@And("^Verify close icon$")
	public void Verify_close_icon() {
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", close);
		com.sleepThread(3000);
	}

	@And("^Click on cancel button$")
	public void Click_on_cancel_button() {
		com.sleepThread(3000);
		String cancel = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_cancel");
		com.click("xpath", cancel);
	}

	@And("^Click on close icon$")
	public void Click_on_close_icon() {
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.click("xpath", close);
	}

	@And("^Enter the Symbol list name \"(.*?)\"$")
	public void Enter_symbol_list_name(String Test) {
		com.sleepThread(2000);
		String symbol_list_name = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_texbox");
		com.sendKeys("xpath", symbol_list_name, Test);
	}

	@And("^click on ok button$")
	public void click_on_ok_button() {
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.click("xpath", ok);
		com.sleepThread(3000);
	}

	@When("^Click on Save as...$")
	public void Click_on_save_as() {
		com.sleepThread(2000);
		String Save_as = Common.readPropertyByWatch_List().getProperty("my_wath_list_save_as");
		com.click("xpath", Save_as);
	}

	@And("^Verify Save Symbol List as title$")
	public void Verify_Save_Symbol_List_title() {
		String Save_symbol_list_title = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_title");
		com.verifyElementPresent("xpath", Save_symbol_list_title);
	}

	@And("^Verify text box in save sysmbol list pop$")
	public void Verify_text_box_in_save_sysmbol_list() {
		String save_text_box = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_texbox");
		com.verifyElementPresent("xpath", save_text_box);
	}

	@And("^Verify ok button in save sysmbol list pop$")
	public void Verify_ok_button_in_save_sysmbol_list_pop() {
		String ok = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_ok");
		com.verifyElementPresent("xpath", ok);
	}

	@And("^Verify cancel button in save sysmbol list pop$")
	public void Verify_cancel_button_in_save_sysmbol_list_pop() {
		String cancel = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_cancel");
		com.verifyElementPresent("xpath", cancel);
	}

	@And("^Verify close icon in save sysmbol list pop$")
	public void Verify_close_icon_in_save_sysmbol_list_pop() {
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", close);
	}

	@And("^Click on cancel button in save sysmbol list pop$")
	public void Click_on_cancel_button_in_save_sysmbol_list_pop() {
		String cancel = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_cancel");
		com.click("xpath", cancel);
		com.sleepThread(3000);
	}

	@And("^Click on close icon in save sysmbol list pop$")
	public void Click_on_close_icon_in_save_sysmbol_list_pop() {
		String close = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_close_icon");
		com.click("xpath", close);
		com.sleepThread(3000);
	}

	@And("^Enter the Symbol list name \"(.*?)\" in save sysmbol list pop$")
	public void Enter_save_symbol_list_name(String For_Test) {
		com.sleepThread(2000);
		String symbol_list_name = Common.readPropertyByWatch_List().getProperty("Save_Symbol_List_as_texbox");
		com.sendKeys("xpath", symbol_list_name, For_Test);
	}

	@And("^click on ok button in save sysmbol list pop$")
	public void click_on_ok_button_in_save_sysmbol_list_pop() {
		String ok = Common.readPropertyByWatch_List().getProperty("Add_New_Symbol_List_ok");
		com.click("xpath", ok);
		com.sleepThread(3000);
	}

	@When("^Click on Import from file...$")
	public void Click_on_Import_from_file() {
		String Import_file = Common.readPropertyByWatch_List().getProperty("my_wath_list_Import_from_file");
		com.click("xpath", Import_file);
	}

	@And("^Verify Import from file title$")
	public void Verify_Import_from_file_title() {
		String Import_from_file_title = Common.readPropertyByWatch_List().getProperty("Import_from_file_title");
		com.verifyElementPresent("xpath", Import_from_file_title);
	}

	@And("^Verify Select file in Import from file pop$")
	public void Verify_Select_file() {
		String Import_from_file_browse = Common.readPropertyByWatch_List().getProperty("Import_from_file_browse");
		com.verifyElementPresent("xpath", Import_from_file_browse);
	}

	@And("^Verify ok button in Import from file pop$")
	public void Verify_ok_buttom() {
		String Import_from_file_ok = Common.readPropertyByWatch_List().getProperty("Import_from_file_ok");
		com.verifyElementPresent("xpath", Import_from_file_ok);
	}

	@And("^Verify cancel button in Import from file pop$")
	public void Verify_cancel_button_Import_from_file() {
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.verifyElementPresent("xpath", Import_from_file_cancel);
	}

	@And("^Verify close icon in Import from file pop$")
	public void Verify_close_icon_Import_from_file() {
		String Import_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Import_from_file_close_icon");
		com.verifyElementPresent("xpath", Import_from_file_close_icon);
	}

	@And("^Click on close icon in Import from file pop$")
	public void Click_on_close_icon_in_Import_from_file() {
		String Import_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Import_from_file_close_icon");
		com.click("xpath", Import_from_file_close_icon);
	}

	@And("^Click on cancel button in Import from file pop$")
	public void Click_on_cancel_button_in_Import_from_file_pop() {
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.click("xpath", Import_from_file_cancel);
	}

	@And("^Select file in Import from file pop$")
	public void Select_file_in_Import_from_file_pop() {

	}

	@And("^click on ok button in Import from file pop$")
	public void click_on_ok_button_in_Import_from_file_pop() {
		String Import_from_file_cancel = Common.readPropertyByWatch_List().getProperty("Import_from_file_cancel");
		com.click("xpath", Import_from_file_cancel);
	}

	@When("^Click on Manage watchlists...$")
	public void Click_on_Manage_watchlists() {
		com.sleepThread(3000);
		String my_wath_list_Manage_watchlists = Common.readPropertyByWatch_List()
				.getProperty("my_wath_list_Manage_watchlists");
		com.click("xpath", my_wath_list_Manage_watchlists);
	}

	@And("^Verify Watch List title$")
	public void Verify_Watch_List_title() {
		String Manage_watchlists_title = Common.readPropertyByWatch_List().getProperty("Manage_watchlists_title");
		com.verifyElementPresent("xpath", Manage_watchlists_title);
	}

	@And("^Verify close icon in Manage watchlists pop$")
	public void Verify_close_icon_in_Manage_watchlists_pop() {
		String Manage_watchlists_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_close_icon);
	}

	@And("^Verify New button in Manage watchlists pop$")
	public void Verify_New_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_new_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_new_button");
		com.verifyElementPresent("xpath", Manage_watchlists_new_button);
	}

	@And("^Verify Import button in Manage watchlists pop$")
	public void Verify_Import_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_import_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_import_button");
		com.verifyElementPresent("xpath", Manage_watchlists_import_button);
	}

	@And("^Verify Export button in Manage watchlists pop$")
	public void Verify_Export_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_Export_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Export_button");
		com.verifyElementPresent("xpath", Manage_watchlists_Export_button);
	}

	@And("^Verify cancel button in Manage watchlists pop$")
	public void Verify_cancel_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_cancel_button");
		com.verifyElementPresent("xpath", Manage_watchlists_cancel_button);
	}

	@And("^Click on close icon in Manage watchlists pop$")
	public void Click_on_close_icon_in_Manage_watchlists_pop() {
		String Manage_watchlists_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_close_icon");
		com.click("xpath", Manage_watchlists_close_icon);
	}

	@And("^Click on cancel button in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_cancel_button");
		com.click("xpath", Manage_watchlists_cancel_button);
	}

	@When("^Click on New button in Manage watchlists pop$")
	public void Click_on_New_button_in_Manage_watchlists_pop() {
		com.sleepThread(3000);
		String Manage_watchlists_new_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_new_button");
		com.click("xpath", Manage_watchlists_new_button);
	}

	@And("^Verify Add New Symbol List title in Manage watchlists pop$")
	public void Verify_Add_New_Symbol_List_title_in_Manage_watchlists_pop() {
		String Manage_watchlists_Add_New_Symbol_List_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_title);
	}

	@And("^Verify text box Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_text_box_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Add_New_Symbol_List_texbox = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_texbox");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_texbox);
	}

	@And("^Verify ok button Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_ok_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Add_New_Symbol_List_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_ok);
	}

	@And("^Verify cancel button Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_cancel_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Add_New_Symbol_List_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_cancel);
	}

	@And("^Verify close icon Add New Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Add_New_Symbol_List_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Add_New_Symbol_List_close_icon);
	}

	@And("^Click on cancel button Add New Symbol List pop in Manage watchlists pop$")
	public void Click_on_cancel_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		com.sleepThread(3000);
		String Manage_watchlists_Add_New_Symbol_List_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_cancel");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_cancel);
	}

	@And("^Click on close icon Add New Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		com.sleepThread(3000);
		String Manage_watchlists_Add_New_Symbol_List_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_close_icon");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_close_icon);
	}

	@And("^Enter the Symbol list name \"(.*?)\" Add New Symbol List pop in Manage watchlists pop$")
	public void Enter_the_Symbol_list_name_Add_New_Symbol_List_pop_in_Manage_watchlists_pop(String test) {
		com.sleepThread(3000);
		String Manage_watchlists_Add_New_Symbol_List_texbox = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_texbox");
		com.sendKeys("xpath", Manage_watchlists_Add_New_Symbol_List_texbox, test);
	}

	@And("^click on ok button Add New Symbol List pop in Manage watchlists pop$")
	public void click_on_ok_button_Add_New_Symbol_List_pop_in_Manage_watchlists_pop() {
		com.sleepThread(3000);
		String Manage_watchlists_Add_New_Symbol_List_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Add_New_Symbol_List_ok");
		com.click("xpath", Manage_watchlists_Add_New_Symbol_List_ok);
	}

	@When("^Click on Import button in Manage watchlists pop$")
	public void Click_on_Import_button_in_Manage_watchlists_pop() {
		String Manage_watchlists_Import_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Import_button");
		com.click("xpath", Manage_watchlists_Import_button);
	}

	@And("^Verify Import from file title in Manage watchlists pop$")
	public void Verify_Import_from_file_title_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_title);
	}

	@And("^Verify Select file in Import from file pop in Manage watchlists pop$")
	public void Verify_Select_file_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_browse = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_browse");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_browse);
	}

	@And("^Verify ok button in Import from file pop in Manage watchlists pop$")
	public void Verify_ok_button_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_ok);
	}

	@And("^Verify cancel button in Import from file pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_cancel);
	}

	@And("^Verify close icon in Import from file pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Load_from_file_close_icon);
	}

	@And("^Click on close icon in Import from file pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_close_icon");
		com.click("xpath", Manage_watchlists_Load_from_file_close_icon);
	}

	@And("^Click on cancel button in Import from file pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_cancel");
		com.click("xpath", Manage_watchlists_Load_from_file_cancel);
	}

	@And("^Select file in Import from file pop in Manage watchlists pop$")
	public void Select_file_in_Import_from_file_pop_in_Manage_watchlists_pop() {

	}

	@And("^click on ok button in Import from file pop in Manage watchlists pop$")
	public void click_on_ok_button_in_Import_from_file_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Load_from_file_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Load_from_file_ok");
		com.click("xpath", Manage_watchlists_Load_from_file_ok);
	}

	@And("^Click on Frist label in Manage watchlists pop$")
	public void Click_on_Frist_label_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_label");
		com.click("xpath", Manage_watchlists_frist_label);
	}

	@And("^Verify Save Symbol List as label in Manage watchlists pop$")
	public void Verify_Save_Symbol_List_as_label_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label);
	}

	@When("^Click on Save Symbol List as label in Manage watchlists pop$")
	public void Click_on_Save_Symbol_List_as_label_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label");
		com.click("xpath", Manage_watchlists_frist_save_as_label);
	}

	@And("^Verify Save Symbol List as title in Manage watchlists pop$")
	public void Verify_Save_Symbol_List_title_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_title);
	}

	@And("^Verify text box in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_text_box_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_text_box");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_text_box);
	}

	@And("^Verify ok button in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_ok_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_ok);
	}

	@And("^Verify cancel button in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_Cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Cancel_button");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_Cancel_button);
	}

	@And("^Verify close icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_close_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_Close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_pop_Close_icon);
	}

	@And("^Click on cancel button in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_Cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Cancel_button");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_Cancel_button);
		com.sleepThread(3000);
	}

	@And("^Click on close icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_Close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_Close_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_Close_icon);
		com.sleepThread(3000);
	}

	@And("^Enter the Symbol list name \"(.*?)\" in save sysmbol list pop in Manage watchlists pop$")
	public void Enter_save_symbol_list_name_in_Manage_watchlists_pop(String For_Test) {
		com.sleepThread(2000);
		String Manage_watchlists_frist_save_as_label_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_text_box");
		com.sendKeys("xpath", Manage_watchlists_frist_save_as_label_pop_text_box, For_Test);
	}

	@And("^click on ok button in save sysmbol list pop in Manage watchlists pop$")
	public void click_on_ok_button_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_pop_ok");
		com.click("xpath", Manage_watchlists_frist_save_as_label_pop_ok);
		com.sleepThread(3000);
	}

	@When("^Verify Edit icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Edit_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Edit_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Edit_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Edit_icon);
	}

	@And("^Click on Edit icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_Edit_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Edit_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Edit_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Edit_icon);
		com.sleepThread(2000);
	}

	@And("^Verify Rename Symbol List title in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Rename_Symbol_List_title_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title);
	}

	@And("^Verify text box in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_text_box_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_title);
	}

	@And("^Verify ok button in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_ok_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok);
	}

	@And("^Verify cancel button in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_cancel_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel);

	}

	@And("^Verify close icon in Rename Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon = Common
				.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon);
	}

	@Then("^Clear the Symbol List name or not in Rename Symbol List pop in Manage watchlists pop$")
	public void Clear_the_Symbol_List_name_or_not_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box");
		com.ClearTextField("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box);
		com.sleepThread(2000);
	}

	@And("^Enter the Rename \"(.*?)\" in Rename Symbol List pop in Manage watchlists pop$")
	public void Enter_the_Rename_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop(String Test_For) {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box");
		com.sendKeys("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_text_box, Test_For);
	}

	@And("^Click on ok button in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_ok_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_ok);
	}

	@And("^Click on cancel button in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_cancel_button_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_cancel);
	}

	@And("^Click on close icon in Rename Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Rename_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon = Common
				.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Rename_Symbol_List_pop_close_icon);
	}

	@Then("^Verify Delete icon in save sysmbol list pop in Manage watchlists pop$")
	public void Verify_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Delete_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_frist_save_as_label_Delete_icon);
	}

	@And("^Click on Delete icon in save sysmbol list pop in Manage watchlists pop$")
	public void Click_on_Delete_icon_in_save_sysmbol_list_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_frist_save_as_label_Delete_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_frist_save_as_label_Delete_icon");
		com.click("xpath", Manage_watchlists_frist_save_as_label_Delete_icon);
	}

	@And("^Verify Remove Symbol List title in Manage watchlists pop$")
	public void Verify_Remove_Symbol_List_title_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_title = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_title");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_title);
	}

	@And("^Verify massage is showing or not in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_massage_is_showing_or_not_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		com.sleepThread(2000);
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_massage = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_massage");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_massage);
	}

	@And("^Verify Yes button in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes);
	}

	@And("^Verify No button in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_No_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_No = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_No");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_No);
	}

	@And("^Verify close icon in Remove Symbol List pop in Manage watchlists pop$")
	public void Verify_close_icon_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon");
		com.verifyElementPresent("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon);
	}

	@And("^Click on close icon in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_close_icon_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_close_icon);
	}

	@And("^Click on Yes button in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_Yes_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_Yes);
	}

	@And("^Click on No button in Remove Symbol List pop in Manage watchlists pop$")
	public void Click_on_No_button_in_Remove_Symbol_List_pop_in_Manage_watchlists_pop() {
		String Manage_watchlists_Delete_pop_Remove_Symbol_list_No = Common.readPropertyByWatch_List()
				.getProperty("Manage_watchlists_Delete_pop_Remove_Symbol_list_No");
		com.click("xpath", Manage_watchlists_Delete_pop_Remove_Symbol_list_No);
	}

	@When("^Pre defined Column Sets Drop Down$")
	public void Pre_defined_Column_Sets_Drop_Down() {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Drop_Down");
		com.click("xpath", Pre_defined_Column_Sets_Drop_Down);
	}

	@And("^Verify and Click on Custom Column Sets and Predefined Column Sets$")
	public void Verify_and_Click_on_Custom_Column_Sets_and_Predefined_Column_Sets() {
		wl = new Watch_List();
		int Predefined = driver.findElements(By.xpath(
				"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println(Predefined + "---------------");
		for (int j = 1; j <= Predefined; j++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div");
			com.click("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li["
					+ j + "]/div[1]/span[2]/div");
			wl.Pre_defined_Column_Sets_Drop_Down();
		}
	}

	@And("^Click on New...Pre defined Column Sets Drop Down$")
	public void Click_on_New_Pre_defined_Column_Sets_Drop_Down() {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_New_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_New_button");
		com.click("xpath", Pre_defined_Column_Sets_New_button);

	}

	@And("^Verify Add column set title$")
	public void Verify_Add_column_set_title() {
		String Pre_defined_Column_Sets_Add_Column_Set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_title);
	}

	@And("^Verify save button in Add column set$")
	public void Verify_save_button_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button);
	}

	@And("^Verify cancel button in Add column set$")
	public void Verify_cancel_button_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button);
	}

	@And("^Verify close icon in Add column set$")
	public void Verify_close_icon_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon);
	}

	@And("^Click on cancel button in Add column set$")
	public void Click_on_cancel_button_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_cancel_button);

	}

	@And("^Click on close icon in Add column set pop$")
	public void Click_on_close_icon_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_close_icon);
	}

	@And("^Verify name text box in Add column set pop$")
	public void Verify_name_text_box_in_Add_column_set_pop() {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Add_Column_Set_name_text_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_name_text_box);
	}

	@And("^Verify Available Columns title in Add column set pop$")
	public void Verify_Available_Columns_title_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_title);
	}

	@And("^Verify Search box Available Columns title below in Add column set pop$")
	public void Verify_Search_box_Available_Columns_title_below_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Available_Columns_search_box);
	}

	@And("^Verify Selected Columns title in Add column set$")
	public void Verify_Selected_Columns_title_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_title);
	}

	@And("^Verify Search box Selected Columns title below in Add column set pop$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_Selected_Columns_search_box);
	}

	@And("Verify Set this column set as default checkbox in Add column set pop")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_checkbox = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_checkbox);
	}

	@And("^Verify Available Columns Each list in Add column set pop$")
	public void Verify_Available_Columns_Each_list_in_Add_column_set_pop() {
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println(Available_Columns_list + "++++++++++++++");

		/*
		 * for(int i=1; i<=Available_Columns_list; i++){ com.sleepThread(5000);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[1]/span[2]/div"); System.out.println(i); int
		 * sublist=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li/div[1]/span[2]/div")).size();
		 * System.out.println(sublist+"****************"); for (int j = 1; j <=sublist;
		 * j++) { com.sleepThread(5000); System.out.println("loppnumber"+j);
		 * com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
		 * +i+"]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div"); com.sleepThread(5000);
		 * String Pre_defined_Column_Sets_Add_Column_Set_arrow_right=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_right"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_right); } int
		 * Selected_Columns_list=driver.findElements(By.xpath(
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"
		 * )).size(); System.out.println(Selected_Columns_list); for (int k = 1; k
		 * <=Selected_Columns_list; k++) { com.verifyElementPresent("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.click("xpath",
		 * "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
		 * +k+"]/div"); com.sleepThread(2000); String
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left=Common.
		 * readPropertyByWatch_List().getProperty(
		 * "Pre_defined_Column_Sets_Add_Column_Set_arrow_left"); com.click("xpath",
		 * Pre_defined_Column_Sets_Add_Column_Set_arrow_left); } }
		 */
		int i = 1;
		while (i <= Available_Columns_list) {
			com.sleepThread(5000);
			com.verifyElementPresent("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div");
			com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
					+ "]/div[1]/span[2]/div");
			System.out.println(i);
			int sublist = driver.findElements(
					By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println(sublist + "****************");

			int j = 1;
			while (j <= 28) {

				com.sleepThread(5000);
				System.out.println("loppnumber" + j);
				String text = driver.findElement(
						By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div"))
						.getText();
				System.out.println("text==" + text);
				com.verifyElementPresent("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div");
				com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
						+ i + "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div");
				com.sleepThread(5000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right);
				j++;
				int t = 1;
				while (t <= 28) {

					com.sleepThread(5000);
					System.out.println("loppnumber" + j);
					String text1 = driver.findElement(
							By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li["
									+ i + "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div"))
							.getText();
					System.out.println("text==" + text1);
					com.verifyElementPresent("xpath",
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
									+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div");
					com.click("xpath",
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
									+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div");
					com.sleepThread(5000);
					String Pre_defined_Column_Sets_Add_Column_Set_arrow_right1 = Common.readPropertyByWatch_List()
							.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
					com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right1);
					j++;
				}
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"))
					.size();
			System.out.println(Selected_Columns_list);
			int k = 1;
			while (k <= Selected_Columns_list) {
				com.verifyElementPresent("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button[" + k
								+ "]/div");
				com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
						+ k + "]/div");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left);
				k++;
			}
			i++;
		}
	}

	@And("^Verify double Arrow right icon in Add column set pop$")
	public void Verify_double_Arrow_right_icon_in_Add_column_set_pop() {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
	}

	@And("^Verify double Arrow left icon in Add column set pop$")
	public void Verify_double_Arrow_left_icon_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
	}

	@And("^Verify down arrow default disable or not in Add column set pop$")
	public void Verify_down_arrow_default_disable_or_not_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_down_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_down_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_down_arrow);
	}

	@And("^Verify up arrow default disable or not in Add column set pop$")
	public void Verify_up_arrow_default_disable_or_not_in_Add_column_set_pop() {
		String Pre_defined_Column_Sets_Add_Column_Set_up_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_up_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Add_Column_Set_up_arrow);
	}

	@And("^Click on save button in Add column set$")
	public void Click_on_save_button_in_Add_column_set() {
		String Pre_defined_Column_Sets_Add_Column_Set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_save_button);
	}

	@When("^Click on Save Column Set Pre defined Column Sets Drop Down$")
	public void Click_on_Save_Column_Set_Pre_defined_Column_Sets_Drop_Down() {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_Save_column_set = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set);
	}

	@And("^Verify Save Column Set title$")
	public void Verify_Save_Column_Set_title() {
		String Pre_defined_Column_Sets_Save_column_set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_title);
	}

	@And("^Verify save button in Save Column Set$")
	public void Verify_save_button_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_save_button);
	}

	@And("^Verify cancel button in Save Column Set$")
	public void Verify_cancel_button_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button);
	}

	@And("^Verify close icon in Save Column Set$")
	public void Verify_close_icon_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon);
	}

	@And("^Click on cancel button in Save Column Set$")
	public void Click_on_cancel_button_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_cancel_button);
	}

	// *****************************************************************************************************************

	@And("^Click on close icon in Save Column Set pop$")
	public void Click_on_close_icon_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_close_icon);
	}

	@And("^Verify name text box in Save Column Set pop$")
	public void Verify_name_text_box_in_Save_Column_Set_pop() {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Add_Column_Set_name_text_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Add_Column_Set_name_text_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Add_Column_Set_name_text_box);
	}

	@And("^Verify Available Columns title in Save Column Set pop$")
	public void Verify_Available_Columns_title_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_title);
	}

	@And("^Verify Search box Available Columns title below in Save Column Set pop$")
	public void Verify_Search_box_Available_Columns_title_below_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Available_Columns_search_box);
	}

	@And("^Verify Selected Columns title in Save Column Set$")
	public void Verify_Selected_Columns_title_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_title);
	}

	@And("^Verify Search box Selected Columns title below in Save Column Set pop$")
	public void Verify_Search_box_Selected_Columns_title_below_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_Selected_Columns_search_box);
	}

	@And("Verify Set this column set as default checkbox in Save Column Set pop")
	public void Verify_Set_this_column_set_as_default_checkbox_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_checkbox = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_checkbox");
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_checkbox);
	}

	@And("^Verify Available Columns Each list in Save Column Set pop$")
	public void Verify_Available_Columns_Each_list_in_Save_Column_Set_pop() {
		int Available_Columns_list = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println(Available_Columns_list + "++++++++++++++");

		for (int i = 1; i <= Available_Columns_list; i++) {
			com.sleepThread(2000);
			com.verifyElementPresent("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div");
			com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
					+ "]/div[1]/span[2]/div");
			int sublist = driver.findElements(By.xpath(
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
					.size();
			System.out.println(sublist + "****************");
			for (int j = 1; j <= sublist; j++) {
				com.sleepThread(2000);
				com.verifyElementPresent("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li[" + j + "]/div[1]/span[2]/div");
				com.click("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[1]/div[3]/div/ul/li[\"+i+\"]/div[2]/div/ul/li[\"+j+\"]/div[1]/span[2]/div");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_right = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_right");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_right);
			}
			int Selected_Columns_list = driver
					.findElements(By.xpath(
							"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button/div"))
					.size();
			System.out.println(Selected_Columns_list);
			for (int k = 1; k <= Selected_Columns_list; k++) {
				com.verifyElementPresent("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button[" + k
								+ "]/div");
				com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div[3]/div[3]/div/button["
						+ k + "]/div");
				com.sleepThread(2000);
				String Pre_defined_Column_Sets_Add_Column_Set_arrow_left = Common.readPropertyByWatch_List()
						.getProperty("Pre_defined_Column_Sets_Add_Column_Set_arrow_left");
				com.click("xpath", Pre_defined_Column_Sets_Add_Column_Set_arrow_left);
			}
		}
	}

	@And("^Verify double Arrow right icon in Save Column Set pop$")
	public void Verify_double_Arrow_right_icon_in_Save_Column_Set_pop() {
		com.sleepThread(5000);
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_right = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_right");
		// com.MouseOverToclickabl("xpath",
		// Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_right);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_right);
	}

	@And("^Verify double Arrow left icon in Save Column Set pop$")
	public void Verify_double_Arrow_left_icon_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_double_Arrow_left = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_double_Arrow_left");
		// com.MouseOverToclickabl("xpath",Pre_defined_Column_Sets_Add_Column_Set_double_Arrow_left);
		com.verifyElementPresent("xpath", Pre_defined_Column_Sets_Save_column_set_double_Arrow_left);
	}

	@And("^Verify down arrow default disable or not in Save Column Set pop$")
	public void Verify_down_arrow_default_disable_or_not_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_down_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_down_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Save_column_set_down_arrow);
	}

	@And("^Verify up arrow default disable or not in Save Column Set pop$")
	public void Verify_up_arrow_default_disable_or_not_in_Save_Column_Set_pop() {
		String Pre_defined_Column_Sets_Save_column_set_up_arrow = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_up_arrow");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Save_column_set_up_arrow);
	}

	@And("^Click on save button in Save Column Set$")
	public void Click_on_save_button_in_Save_Column_Set() {
		String Pre_defined_Column_Sets_Save_column_set_save_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Save_column_set_save_button");
		com.click("xpath", Pre_defined_Column_Sets_Save_column_set_save_button);
	}

	@When("^Click on Manage column set Pre defined Column Sets Drop Down$")
	public void Click_on_Manage_column_set_Pre_defined_Column_Sets_Drop_Down() {
		String Pre_defined_Column_Sets_Manage_column_set = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set);
	}

	@And("^Verify Manage column set title$")
	public void Verify_Manage_column_set_title() {
		String Pre_defined_Column_Sets_Manage_column_set_title = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_title");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_title);
	}

	@And("^Verify close icon in Manage column set$")
	public void Verify_close_icon_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon);
	}

	@And("^Verify cancel button in Manage column set$")
	public void Verify_cancel_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button);
	}

	@And("^Verify Edit button in Manage column set$")
	public void Verify_Edit_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_Edit_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Edit_button");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_Edit_button);
	}

	@And("^Verify Copy button in Manage column set$")
	public void Verify_Copy_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_Copy_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Copy_button");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_Copy_button);
	}

	@And("^Verify Delete button in Manage column set$")
	public void Verify_Delete_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_Delete_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_Delete_button");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_Delete_button);
	}

	@And("^Verify New button in Manage column set$")
	public void Verify_New_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_New_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_New_button");
		com.verifyElementdisable("xpath", Pre_defined_Column_Sets_Manage_column_set_New_button);
	}

	@And("^click on close icon in Manage column set$")
	public void click_on_close_icon_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_close_icon = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_close_icon");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_close_icon);
	}

	@And("^click on cancel button in Manage column set$")
	public void click_on_cancel_button_in_Manage_column_set() {
		String Pre_defined_Column_Sets_Manage_column_set_cancel_button = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Manage_column_set_cancel_button");
		com.click("xpath", Pre_defined_Column_Sets_Manage_column_set_cancel_button);
	}

}
