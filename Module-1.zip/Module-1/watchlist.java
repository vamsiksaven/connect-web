package watchlist;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
//import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class watchlist {

	public static void main(String[] args) throws InterruptedException, IOException {

		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		Properties obj = new Properties();
		FileInputStream objfile = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\properties\\watchlist.properties");
		obj.load(objfile);

		
		driver.get(obj.getProperty("URL"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		driver.findElement(By.xpath(obj.getProperty("username"))).sendKeys("vamsi.kamatam@theice.com");
		Thread.sleep(2000);
		System.out.println("username and password entered successfully");

		
		driver.findElement(By.xpath(obj.getProperty("password"))).sendKeys("Starts123");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath(obj.getProperty("Submit"))).click();
		

		//driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		////*[@id="0"]/div[1]/span
		if (driver.findElement(By.xpath("//span[contains(text(),'Principal Region')]")) != null) {
			System.out.println("logged in successfully");
		} else {
			System.out.println("login failed");
		}
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"0\"]/div[2]/div[2]/div/div/div[3]/button")).click();
		if (driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span/div/span/span/button/span"))
				.isDisplayed()) {
			System.out.println("New Watch List is displayed");
		} else {
			System.out.println("New Watch List is not displayed");
		}
		Actions act = new Actions(driver);

		act.doubleClick(driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div[1]")))
				.perform();

		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div[1]/span/div/input"))
				.sendKeys("IBM");
		driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div[1]/span/div/input"))
				.sendKeys(Keys.ENTER);

		Thread.sleep(2000);

		if (driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div[1]/div/div[3]/span"))
				.isDisplayed()) {
			System.out.println(driver.findElement(By.xpath(
					"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div[1]/div/div[3]/span"))
					.getText() + " data is displayed");
		} else {
			System.out.println("Data is absent");
		}		
		//Dropdown Xpath
		driver.findElement(By.xpath(
				"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span/div/span/span/button"))
				.click();
		//my wa 
		int mylist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("mylist:" + mylist);
		int Serverlist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Serverlist:" + Serverlist);
		
		for (int j = 1; j <= Serverlist; j++) {
			Thread.sleep(1000);
			//serverlist xpath
			driver.findElement(By.xpath("/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li["+j+"]/div[1]/span[2]/div")).click();
			//System.out.println("Run "+j);
			Thread.sleep(2000);
			//My Watchlist dropdown xpath
			driver.findElement(By.xpath(
					"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span/div/span/span/button"))
					.click();
			System.out.println(driver.findElement(By.xpath(
					"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span/div/span/span/button"))
					.getText()+" is functioning");

		}

	}

}































/*driver.findElement(By.xpath(
		"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div/div/div/div/div[1]/span/div/span/span/button"))
		.click();
Thread.sleep(2000);
driver.findElement(By.xpath(
		"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
		.click();
Thread.sleep(3000);

if (driver.findElement(By.xpath(
		"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div[1]/div[1]/div[2]/span"))
		.isDisplayed()) {
	System.out.println(driver.findElement(By.xpath(
			"//*[@id=\"0\"]/div[2]/div[2]/div/div/div/div/div[2]/div[2]/div[2]/div[1]/div/div/div/div[1]/div[1]/div[2]/span"))
			.getText() + " data is displayed");
} else {
	System.out.println("data is not displayed");
}*/