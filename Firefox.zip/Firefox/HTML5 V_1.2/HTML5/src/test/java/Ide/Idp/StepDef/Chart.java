package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Chart {

	public Common com = new Common();
	public Watch_List wl;
	public WebDriver driver;
	public Chart C;
	public String Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Chart() {
		driver = Common.driver;
	}

	@Given("^Verify the Chart$")
	public void Verify_the_chart() throws Exception {
		com.sleepThread(12000);
		String  Chart = Common.readPropertyByChart().getProperty("Chart");
		com.verifyElementPresent("xpath",Chart, "ICTC-00001,Chart,Verify the Chart");
	}
	@And("^Click on Chart$")
	public void Click_on_Chart() throws Exception {
		String  Chart = Common.readPropertyByChart().getProperty("Chart");
		com.sleepThread(12000);
		com.click("xpath",Chart, "ICTC-00002,Chart,Click on Chart");
	}

	@When("^Verify the Symbol Linking in Chart$")
	public void Verify_the_Symbol_Linking_in_Chart() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking,
				"ICTC-00003," + Widget_name + ",Verify the Symbol Linking in Chart");
	}

	@And("^Click on Symbol Linking in Chart$")
	public void click_on_Symbol_Linking_in_Chart() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.sleepThread(3000);
		com.click("xpath", Symbol_Linking, "ICTC-00004," + Widget_name + ",Click on Symbol Linking in Chart");
	}

	@And("^click on each Check Functionalities in Chart$")
	public void check_Functionalities_in_Chart() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		wl = new Watch_List();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00005," + Widget_name + ",Verify the each Check Functionalities in Chart");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00006," + Widget_name + ",Click on each Check Functionalities in Chart");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}

		wl = new Watch_List();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label",
					"ICTC-00005," + Widget_name + ",Verify the each Check Functionalities in Chart");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label",
					"ICTC-00006," + Widget_name + ",Click on each Check Functionalities in Chart");
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
		}
	}
	@When("^Click on more option$")
	public void Click_on_more_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String chart_icon_more = Common.readPropertyByChart().getProperty("chart_icon_more");
		com.sleepThread(1000);
		com.click("xpath", chart_icon_more,
				"," + Widget_name + ",Click on more option");
	}
	@Then("^Click on data view option$")
	public void Click_on_data_view_option() throws Exception
	{
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String chart_icon_more_Data_view = Common.readPropertyByChart().getProperty("chart_icon_more_Data_view");
		com.sleepThread(1000);
		com.click("xpath", chart_icon_more_Data_view,
				"," + Widget_name + ",Click on data view option");
		com.sleepThread(2000);
	}
		
	@When("^Verify the Enter_symbol Drop Down$")
	public void Verify_the_Enter_symbol_Drop_Down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.sleepThread(1000);
		com.verifyElementPresent("xpath", ICE_Drop_Down,
				"ICTC-00007," + Widget_name + ",Verify the Enter_symbol Drop Down");
	}

	@And("^Click on Enter_symbol Drop Down$")
	public void Click_on_ICE_Drop_Down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.sleepThread(3000);
		com.click("xpath", ICE_Drop_Down, "ICTC-00008," + Widget_name + ",Click on Enter_symbol Drop Down");
		/*
		 * System.out.println("suggestion item--------------");
		 * TimeUnit.MINUTES.sleep(1); int size = driver.findElements(By.xpath(
		 * "/html/body/div[2]/div/span/div/div/div[2]/div/div/span/span")).size();
		 * System.out.println("suggestion item " + size); for (int i = 2; i <size; i++)
		 * { if (driver.getTitle().equals("Chart")) { System.out.println(i);
		 * com.startAction(); com.MouseOverToclickabl("xpath",
		 * "/html/body/div[2]/div/span/div/div/div[2]/div/div[" + i + "]/span/span",
		 * "ICTC-00008,"+Widget_name+",Click on Each symbol list"); } }
		 */
	}

	@And("^Enter_symbol the each list$")
	public void Enter_symbol_the_each_list() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		int size = driver.findElements(By.xpath("/html/body/div[2]/div/span/div/div/div[2]/div/div/span/span")).size();
		System.out.println("suggestion item " + size);
		for (int i = 2; i < size; i++) {
			System.out.println(i);
			com.startAction();
			// com.MouseOverToElement("xpath","/html/body/div[6]/div/span/div/div/div[2]/div/div["+i+"]/span/span","");
			String text = driver
					.findElement(By.xpath("/html/body/div[2]/div/span/div/div/div[2]/div/div[" + i + "]/span/span"))
					.getText();
			System.out.println("text" + text);
			com.MouseOverToclickabl("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div[" + i + "]/span/span",
					"ICTC-00009," + Widget_name + ",Click on_symbol the " + text + " list");
			com.sleepThread(2000);
			String Select_text = driver.findElement(By.xpath(
					"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/div[4]/div[1]/table[1]/tbody[1]/tr[2]/td[1]/table[1]/tbody[1]/tr[1]/td[1]"))
					.getText();
			System.out.println("Select_text" + Select_text);
			if (text.equals(Select_text)) {
				com.Creatlogfile(Date_Time + "," + "ICTC-00047," + Widget_name + ",User selected symbol " + Select_text
						+ " is chart header table dispalyed or not" + ",Pass");
			} else {
				com.Creatlogfile(Date_Time + "," + "ICTC-00047," + Widget_name + ",User selected symbol " + Select_text
						+ " is chart header table dispalyed or not" + ",Fail");
			}
			com.sleepThread(2000);
			String Input_text = driver.findElement(By.xpath(
					"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]/div[1]/span[1]/div[1]/input[1]"))
					.getAttribute("value");
			System.out.println("Input_text" + Input_text);
			if (text.equals(Input_text)) {
				com.Creatlogfile(Date_Time + "," + "ICTC-00048," + Widget_name + ",User selected symbol " + Input_text
						+ " is symbol drop down is dispalyed or not" + ",Pass");
			} else {
				com.Creatlogfile(Date_Time + "," + "ICTC-00048," + Widget_name + ",User selected symbol " + Input_text
						+ " is symbol drop down is not dispalyed" + ",Fail");
			}
			com.sleepThread(2000);
			C.Click_on_ICE_Drop_Down();
		}
	}

	@And("^Verify the checkbox$")
	public void Verify_the_checkbox() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String checkbox = Common.readPropertyByChart().getProperty("checkbox");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", checkbox, "ICTC-00010," + Widget_name + ",Verify the checkbox");
	}

	@And("^Click on checkbox$")
	public void Click_on_checkbox() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String checkbox = Common.readPropertyByChart().getProperty("checkbox");
		com.sleepThread(3000);
		com.click("xpath", checkbox, "ICTC-00011," + Widget_name + ",Click on checkbox");
	}

	@When("^Verify the Delete button$")
	public void Verify_the_Delete_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Delete_button = Common.readPropertyByChart().getProperty("Delete_button");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", Delete_button, "ICTC-00012," + Widget_name + ",Verify the Delete button");
	}

	@Then("^Click on Delete button$")
	public void Click_on_Delete_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Delete_button = Common.readPropertyByChart().getProperty("Delete_button");
		com.sleepThread(2000);
		com.click("xpath", Delete_button, "ICTC-00013," + Widget_name + ",Click on Delete button");
	}

	@When("^Verify the Add button$")
	public void Verify_the_Add_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_Button = Common.readPropertyByChart().getProperty("Add_Button");
		com.verifyElementPresent("xpath", Add_Button, "ICTC-00014," + Widget_name + ",Verify the Add button");
	}

	@Then("^Click on Add button$")
	public void Click_on_Add_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_Button = Common.readPropertyByChart().getProperty("Add_Button");
		com.click("xpath", Add_Button, "ICTC-00015," + Widget_name + ",Click on Add button");
	}

	@When("^Verify the Down button$")
	public void Verify_the_Down_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Down_button = Common.readPropertyByChart().getProperty("Down_button");
		com.verifyElementPresent("xpath", Down_button, "ICTC-00016," + Widget_name + ",Verify the Down button");
	}

	@Then("^Click on Down button$")
	public void Click_on_Down_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Down_button = Common.readPropertyByChart().getProperty("Down_button");
		com.sleepThread(3000);
		com.click("xpath", Down_button, "ICTC-00017," + Widget_name + ",Click on Down button");
	}

	@And("^Select the Each name$")
	public void Select_the_Each_name() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int D_list = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button"))
				.size();
		// *[@id="container"]/div/div/div/div/div[5]/div/ul/li[1]/button
		System.out.println("Dow_button:" + D_list);
		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button",
					"ICTC-00018," + Widget_name + ",Verify the Each name");
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button",
					"ICTC-00019," + Widget_name + ",Select the Each name");
			com.sleepThread(2000);
			C = new Chart();
			C.Click_on_Down_button();
		}
	}

	@When("^Verify the chart icon uparrow$")
	public void Verify_the_chart_icon_uparrow() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String chart_icon_uparrow = Common.readPropertyByChart().getProperty("chart_icon_uparrow");
		com.verifyElementPresent("xpath", chart_icon_uparrow,
				"ICTC-00020," + Widget_name + ",Verify the chart icon uparrow");
	}

	@Then("^Click on the chart icon uparrow$")
	public void Click_on_the_chart_icon_uparrow() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String chart_icon_uparrow = Common.readPropertyByChart().getProperty("chart_icon_uparrow");
		com.click("xpath", chart_icon_uparrow, "ICTC-00021," + Widget_name + ",Click on the chart icon uparrow");
	}

	@And("^Select the Each Check boxes$")
	public void Select_the_Each_Check_boxes() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int C_list = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button/label"))
				.size();
		System.out.println("Check boxes:" + C_list);
		for (int i = 1; i < C_list; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00022," + Widget_name + ",Verify the Each Check boxes");
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00023," + Widget_name + ",Select the Each Check boxes");
			com.sleepThread(2000);
			C = new Chart();
			C.Click_on_the_chart_icon_uparrow();
		}
	}

	@When("^Verify the Available_Dropdown$")
	public void Verify_the_Available_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Available_Dropdown = Common.readPropertyByChart().getProperty("Available_Dropdown");
		com.verifyElementPresent("xpath", Available_Dropdown,
				"ICTC-00024," + Widget_name + ",Verify the Available_Dropdown");
	}

	@And("^Default Available is selectable or not$")
	public void Default_Available_is_selectable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Available_option = driver.findElement(By.xpath("//*[@value='Available']")).getAttribute("value");
		System.out.println(Available_option);
		if (Available_option.equals("Available")) {
			com.Creatlogfile(Date_Time + "," + "ICTC-00025," + Widget_name + ",Default Available is selectable or not"
					+ ",Pass");
		} else {
			com.Creatlogfile(Date_Time + "," + "ICTC-00025," + Widget_name + ",Default Available is selectable or not"
					+ ",Fail");
		}
	}

	@And("^click on Available Dropdown$")
	public void click_on_Available_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Available_Dropdown_arrow = Common.readPropertyByChart().getProperty("Available_Dropdown_arrow");
		com.sleepThread(5000);
		com.click("xpath", Available_Dropdown_arrow, "ICTC-00026," + Widget_name + ",Click on Available Dropdown");
	}

	@And("^Available option selectable or not$")
	public void Available_option_selectable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		C = new Chart();
		String Available=Common.readPropertyByChart().getProperty("Available");
		com.click("xpath",Available,"," + Widget_name + ",Click on Available option");
		//C.click_on_Available_Dropdown();
		com.sleepThread(5000);
		String Available_option = Common.readPropertyByChart().getProperty("Available_option");
		com.verifyElementPresent("xpath", Available_option,
				"ICTC-00027," + Widget_name + ",Available option selectable or not");
		com.sleepThread(3000);
		C.Default_Available_is_selectable_or_not();
	}

	@And("^Custom Range option is selectable or not$")
	public void Custom_Range_option_is_selectable_or_not() throws Exception {
		com.startAction();
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		// C.click_on_Available_Dropdown();
		com.sleepThread(1000);
		String Custom_Range_option = Common.readPropertyByChart().getProperty("Custom_Range_option");
		com.MouseOverToclickabl("xpath", Custom_Range_option,
				"ICTC-00028," + Widget_name + ",Custom Range option is selectable or not");
	}

	@Then("^Date Range pop is displayed or not$")
	public void Date_Range_pop_is_displayed_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Data_Range_pop = Common.readPropertyByChart().getProperty("Data_Range_pop");
		com.verifyElementPresent("xpath", Data_Range_pop,
				"ICTC-00029," + Widget_name + ",Date Range pop is displayed or not");
	}

	@And("^Verify the cross in date range pop$")
	public void Verify_the_cross_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cross_icon_Data_Range_pop = Common.readPropertyByChart().getProperty("Cross_icon_Data_Range_pop");
		com.verifyElementPresent("xpath", Cross_icon_Data_Range_pop,
				"ICTC-00030," + Widget_name + ",Verify the cross in date range pop");
	}

	@And("^Verify the OK button in date range pop$")
	public void Verify_the_OK_butto_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Ok_button_Data_Range_pop = Common.readPropertyByChart().getProperty("Ok_button_Data_Range_pop");
		com.verifyElementPresent("xpath", Ok_button_Data_Range_pop,
				"ICTC-00031," + Widget_name + ",Verify the OK button in date range pop");
	}

	@And("^Verify the Cancel button in date range pop$")
	public void Verify_the_Cancel_button_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cancel_button_Data_Range_pop = Common.readPropertyByChart().getProperty("Cancel_button_Data_Range_pop");
		com.verifyElementPresent("xpath", Cancel_button_Data_Range_pop,
				"ICTC-00032," + Widget_name + ",Verify the Cancel button in date range pop");
	}

	@And("^Verify the Aggregation Drop down in date range pop$")
	public void Verify_the_Aggregation_Drop_down_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Aggregation_Drop_down_date_range_pop = Common.readPropertyByChart()
				.getProperty("Aggregation_Drop_down_date_range_pop");
		com.verifyElementPresent("xpath", Aggregation_Drop_down_date_range_pop,
				"ICTC-00033," + Widget_name + ",Verify the Aggregation Drop down in date range pop");
	}

	@And("^Verify the From date field in date range pop$")
	public void Verify_the_From_date_field_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String From_date_field_date_range_pop = Common.readPropertyByChart()
				.getProperty("From_date_field_date_range_pop");
		com.verifyElementPresent("xpath", From_date_field_date_range_pop,
				"ICTC-00034," + Widget_name + ",Verify the From date field in date range pop");
	}

	@And("^Verify the To date field in date range pop$")
	public void Verify_the_To_date_field_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String To_date_field_date_range_pop = Common.readPropertyByChart().getProperty("To_date_field_date_range_pop");
		com.verifyElementPresent("xpath", To_date_field_date_range_pop,
				"ICTC-00035," + Widget_name + ",Verify the To date field in date range pop");
	}

	@And("^Click on Cross icon in date range pop$")
	public void Click_on_Cross_icon_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cross_icon_Data_Range_pop = Common.readPropertyByChart().getProperty("Cross_icon_Data_Range_pop");
		com.click("xpath", Cross_icon_Data_Range_pop,
				"ICTC-0036," + Widget_name + ",Click on Cross icon in date range pop");
		C = new Chart();
		C.click_on_Available_Dropdown();
		C.Custom_Range_option_is_selectable_or_not();
	}

	@And("^Click on Cancel button in date range pop$")
	public void Click_on_Cancel_button_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cancel_button_Data_Range_pop = Common.readPropertyByChart().getProperty("Cancel_button_Data_Range_pop");
		com.click("xpath", Cancel_button_Data_Range_pop,
				"ICTC-0037," + Widget_name + ",Click on Cancel button in date range pop");
		C = new Chart();
		C.click_on_Available_Dropdown();
		C.Custom_Range_option_is_selectable_or_not();
	}

	@And("^Default Fron date Time input field is disabled or not in date range pop$")
	public void Default_Fron_date_Time_input_field_is_disabled_or_not_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String From_date_Time_input_field_disabled_date_range_pop = Common.readPropertyByChart()
				.getProperty("From_date_Time_input_field_disabled_date_range_pop");
		com.verifyElementdisable("xpath", From_date_Time_input_field_disabled_date_range_pop, "ICTC-00038,"
				+ Widget_name + ",Default Fron date Time input field is disabled or not in date range pop");
	}

	@And("^Default To date Time input field is disabled or not in date range pop$")
	public void Default_To_date_Time_input_field_is_disabled_or_not_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String To_date_Time_input_field_disabled_date_range_pop = Common.readPropertyByChart()
				.getProperty("To_date_Time_input_field_disabled_date_range_pop");
		com.verifyElementdisable("xpath", To_date_Time_input_field_disabled_date_range_pop,
				"ICTC-00039," + Widget_name + ",Default To date Time input field is disabled or not in date range pop");
	
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cancel_button_Data_Range_pop = Common.readPropertyByChart().getProperty("Cancel_button_Data_Range_pop");
		com.click("xpath", Cancel_button_Data_Range_pop,
				"ICTC-0037," + Widget_name + ",Click on Cancel button in date range pop");		
	}

	@Then("^Select the particular Form date in date range pop$")
	public void Select_the_particular_Form_date_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		C.click_on_Available_Dropdown();
		C.Custom_Range_option_is_selectable_or_not();	
		String From_date_field_date_range_pop = Common.readPropertyByChart()
				.getProperty("From_date_field_date_range_pop");
		com.click("xpath", From_date_field_date_range_pop,
				"ICTC-00040," + Widget_name + ",Select the particular Form date in date range pop");
		com.sleepThread(2000);
		String From_date_Year = Common.readPropertyByChart().getProperty("From_date_Year");
		String From_date_month = Common.readPropertyByChart().getProperty("From_date_month");
		com.handle_to_calendar("xpath", From_date_Year, "xpath", From_date_month,"2019",6,3);
		com.sleepThread(2000);
		com.click("xpath", From_date_field_date_range_pop,
				"ICTC-00040," + Widget_name + ",Select the particular Form date in date range pop");
		com.sleepThread(2000);
		String Data_Range_pop = Common.readPropertyByChart().getProperty("Data_Range_pop");
		com.click("xpath", Data_Range_pop,
				"ICTC-00029," + Widget_name + ",Click on data range pop title");
	}

	@Then("^Select the particular To date in date range pop$")
	public void Select_the_particular_To_date_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String To_date_field_date_range_pop = Common.readPropertyByChart().getProperty("To_date_field_date_range_pop");
		com.click("xpath",To_date_field_date_range_pop,
				"ICTC-00041," + Widget_name + ",Select the particular To date in date range pop");
		com.sleepThread(2000);
		String To_date_Year = Common.readPropertyByChart().getProperty("To_date_Year");
		String To_date_month = Common.readPropertyByChart().getProperty("To_date_month");
		com.handle_to_calendar("xpath",To_date_Year, "xpath",To_date_month, "2019",7,6);
		com.sleepThread(2000);
		String Data_Range_pop = Common.readPropertyByChart().getProperty("Data_Range_pop");
		com.click("xpath", Data_Range_pop,
				"ICTC-00029," + Widget_name + ",Click on data range pop title");
	}

	@Then("^Select on each option in Aggregation drop down in date range pop$")
	public void Select_on_each_option_in_Aggregation_drop_down_in_date_range_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Aggregation_Drop_down_date_range_pop = Common.readPropertyByChart()
				.getProperty("Aggregation_Drop_down_date_range_pop");
		com.select_the_Drop_Down_values("xpath", Aggregation_Drop_down_date_range_pop,
				"ICTC-00042," + Widget_name + ",Select on each option in Aggregation drop down in date range pop");
	}

	@And("^Select the Aggregation drop down hours option Time input fields Frome and To enable or not$")
	public void Select_the_Aggregation_drop_down_hours_option_Time_input_fields_Frome_and_To_enable_or_not()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String From_date_Time_input_field_disabled_date_range_pop = Common.readPropertyByChart()
				.getProperty("From_date_Time_input_field_disabled_date_range_pop");
		com.verifyElementEnabled("xpath", From_date_Time_input_field_disabled_date_range_pop, "ICTC-00043,"
				+ Widget_name + ",Select the Aggregation drop down hours option Time input fields Frome enable or not");
		String To_date_Time_input_field_disabled_date_range_pop = Common.readPropertyByChart()
				.getProperty("To_date_Time_input_field_disabled_date_range_pop");
		com.verifyElementEnabled("xpath", To_date_Time_input_field_disabled_date_range_pop, "ICTC-00044," + Widget_name
				+ ",Select the Aggregation drop down hours option Time input fields To enable or not");
		String Cancel_button_Data_Range_pop = Common.readPropertyByChart().getProperty("Cancel_button_Data_Range_pop");
		com.click("xpath", Cancel_button_Data_Range_pop,
				"ICTC-0037," + Widget_name + ",Click on Cancel button in date range pop");
	}

	@Then("^Verify and select the Each value in Avaolable Dropdown$")
	public void Verify_and_select_the_Each_value_in_Avaolable_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();		
		C = new Chart();
		C.click_on_Available_Dropdown();		
		int A_list = driver.findElements(By.xpath("/html/body/div[3]/div/span/div/div/div[2]/div/div/div"))
				.size();
		System.out.println("Avaolable:" + A_list);
		for (int i = 3; i <A_list; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[" + i + "]",
					"ICTC-00045," + Widget_name + ",Verify the Each value in Avaolable Dropdown");
			com.click("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div/div[" + i +"]",
					"ICTC-00046," + Widget_name + ",Verify and select the Each value in Avaolable Dropdown");
			C = new Chart();
			C.click_on_Available_Dropdown();
		}
		
		com.click("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div/div["+A_list+"]",
				"ICTC-00046," + Widget_name + ",Verify and select the Each value in Avaolable Dropdown");
	}

	@When("^Verify the 1_min Dropdown$")
	public void Verify_the_1_min_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String min_Dropdown = Common.readPropertyByChart().getProperty("1_min_Dropdown");
		com.verifyElementPresent("xpath", min_Dropdown, "ICTC-00049," + Widget_name + ",Verify the 1_min Dropdown");
	}

	@And("^Click on 1 min Dropdown$")
	public void Click_on_1_min_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String min_Dropdown_arrow = Common.readPropertyByChart().getProperty("1_min_Dropdown_arrow");
		com.click("xpath", min_Dropdown_arrow, "ICTC-00050," + Widget_name + ",Click on 1 min Dropdown");
	}

	@Then("^Verify and select the Each value in 1min Dropdown$")
	public void Verify_and_select_the_Each_value_in_1_min_Dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int min_list = driver.findElements(By.xpath("/html/body/div[4]/div/span/div/div/div[2]/div/div/div")).size();
		System.out.println("1 min Dropdown:" + min_list);
		for (int i = 1; i <min_list; i++) {
			com.startAction();
			com.verifyElementPresent("xpath", "/html/body/div[4]/div/span/div/div/div[2]/div/div/div["+ i +"]",
					"ICTC-00051," + Widget_name + ",Verify and select the Each value in 1 min Dropdown");
			com.MouseOverToclickabl("xpath", "/html/body/div[4]/div/span/div/div/div[2]/div/div/div["+ i +"]",
					"ICTC-00052," + Widget_name + ",Select the Each value in 1 min Dropdown");
			com.sleepThread(2000);
			C = new Chart();
			C.Click_on_1_min_Dropdown();
		}
		com.MouseOverToclickabl("xpath", "/html/body/div[4]/div/span/div/div/div[2]/div/div/div["+min_list+"]",
				"ICTC-00052," + Widget_name + ",Select the Each value in 1 min Dropdown");

	}

	@When("^Verify the chart-icon$")
	public void Verify_the_chart_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String chart_icon = Common.readPropertyByChart().getProperty("chart_icon");
		com.verifyElementPresent("xpath", chart_icon, "ICTC-00053," + Widget_name + ",Verify the chart-icon");
	}

	@Then("^Click on chart-icon$")
	public void Click_on_chart_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		com.startAction();
		String chart_icon = Common.readPropertyByChart().getProperty("chart_icon");
		//com.MouseOverToclickabl("xpath", chart_icon, "ICTC-00054," + Widget_name + ",Click on chart-icon");
		com.click("xpath",chart_icon, "," + Widget_name + ",Click on chart-icon");
	}

	@And("^Verify the Studies pop title$")
	public void Verify_the_Studies_pop_title() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Studies_pop_title = Common.readPropertyByChart().getProperty("Studies_pop_title");
		com.verifyText_Using_String("xpath", Studies_pop_title, "Studies",
				"ICTC-00055," + Widget_name + ",Verify the Studies pop title");
	}

	@And("^Verify the Close icon Studies pop$")
	public void Verify_the_Close_icon_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Close_icon_Studies_pop = Common.readPropertyByChart().getProperty("Close_icon_Studies_pop");
		com.verifyElementPresent("xpath", Close_icon_Studies_pop,
				"ICTC-00056," + Widget_name + ",Verify the Close icon Studies pop");
	}

	@And("^Verify the Add button Studies pop$")
	public void Verify_the_Add_button_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_button_Studies_pop = Common.readPropertyByChart().getProperty("Add_button_Studies_pop");
		com.verifyElementPresent("xpath", Add_button_Studies_pop,
				"ICTC-00057," + Widget_name + ",Verify the Add button Studies pop");
	}

	@And("^Verify the Down button besaid Add button Studies pop$")
	public void Verify_the_Down_button_besaid_Add_button_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Down_button_besaid_Add_button_Studies_pop = Common.readPropertyByChart()
				.getProperty("Down_button_besaid_Add_button_Studies_pop");
		com.verifyElementPresent("xpath", Down_button_besaid_Add_button_Studies_pop,
				"ICTC-00058," + Widget_name + ",Verify the Down button besaid Add button Studies pop");
	}

	@And("^Verify the Cancel button Studies pop$")
	public void Verify_the_Cancel_button_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cancel_button__Studies_pop = Common.readPropertyByChart().getProperty("Cancel_button__Studies_pop");
		com.verifyElementPresent("xpath", Cancel_button__Studies_pop,
				"ICTC-00059," + Widget_name + ",Verify the Cancel button Studies pop");
	}

	@Then("^Click on Close icon in Studies pop$")
	public void Click_on_Close_icon_in_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Close_icon_Studies_pop = Common.readPropertyByChart().getProperty("Close_icon_Studies_pop");
		com.click("xpath", Close_icon_Studies_pop, "ICTC-00060," + Widget_name + ",Click on Close icon in Studies pop");

	}

	@Then("^Click on Cancel button in Studies pop$")
	public void Click_on_Cancel_button_in_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Cancel_button__Studies_pop = Common.readPropertyByChart().getProperty("Cancel_button__Studies_pop");
		com.click("xpath", Cancel_button__Studies_pop,
				"ICTC-00061," + Widget_name + ",Click on Cancel button in Studies pop");

	}

	@And("^Click on each option and verify the each option opening or not$")
	public void Click_on_each_option_and_verify_the_each_option_opening_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int Size = driver.findElements(By.xpath(
				"/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[1]/div[2]/div/button/div"))
				.size();
		System.out.println("Studies pop option:" + Size);
		for (int i = 1; i < Size; i++) {
			String text = driver.findElement(
					By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[1]/div[2]/div/button["+i+"]/div"))
					.getText();
			com.click("xpath",
					"/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[1]/div[2]/div/button["+i+"]/div","ICTC-00062," + Widget_name + ",Click on " + text + " option");
			com.sleepThread(2000);
			String open_text = driver
					.findElement(By.xpath("//*[contains(@class,'d-flex-fix d-studies-description-title')]")).getText();
			com.sleepThread(2000);
			if (text.equals(open_text)) {
				com.Creatlogfile(Date_Time + "," + ",Chart,verify the each option opening or not" + ",Pass");
			} else {
				com.Creatlogfile(Date_Time + "," + ",Chart,verify the each option opening or not" + ",Fail");
			}
		}
	}

	@And("^Click on Add button in Studies pop$")
	public void Click_on_Add_button_in_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_button_Studies_pop = Common.readPropertyByChart().getProperty("Add_button_Studies_pop");
		com.click("xpath", Add_button_Studies_pop, "ICTC-00063," + Widget_name + ",Click on Add button in Studies pop");

	}

	@Then("^Click on Down button and verify each option in besaid Add button Studies pop$")
	public void Click_on_Down_button_and_verify_each_option_in_besaid_Add_button_Studies_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Down_button_besaid_Add_button_Studies_pop = Common.readPropertyByChart()
				.getProperty("Down_button_besaid_Add_button_Studies_pop");
		com.click("xpath", Down_button_besaid_Add_button_Studies_pop, "ICTC-00064," + Widget_name
				+ ",Click on Down button and verify each option in besaid Add button Studies pop");
		com.sleepThread(2000);
		int size = driver.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button"))
				.size();

		for (int i = 1; i < 1; i++) {
			com.verifyElementPresent("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button",
					",Chart,verify each option in besaid Add button Studies pop");
		}

	}

	@When("^Verify the Chart more icon$")
	public void Verify_the_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_more_icon = Common.readPropertyByChart().getProperty("Chart_more_icon");
		com.verifyElementPresent("xpath", Chart_more_icon, "ICTC-00065," + Widget_name + ",Verify the Chart more icon");
	}

	@Then("^Click on Chart more icon$")
	public void Click_on_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Chart_more_icon = Common.readPropertyByChart().getProperty("Chart_more_icon");
		com.click("xpath", Chart_more_icon, "ICTC-00067," + Widget_name + ",Click on Chart more icon");
	}

	@And("^Click on Chart Object Properties$")
	public void Click_on_Chart_Object_Properties() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties = Common.readPropertyByChart().getProperty("Chart_Object_Properties");
		com.click("xpath", Chart_Object_Properties, "ICTC-00068," + Widget_name + ",Click on Chart Object Properties");

	}

	@When("^Verify the Chart Object Properties pop title$")
	public void Verify_the_Chart_Object_Properties_pop_title() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_title = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_title");
		com.verifyElementPresent("xpath", Chart_Object_Properties_pop_title,
				"ICTC-00069," + Widget_name + ",Verify the Chart Object Properties pop title");
	}

	@Then("^Verify the close icon in Chart Object Properties pop$")
	public void Verify_the_close_icon_in_Chart_Object_Properties_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_close_icon = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_close_icon");
		com.verifyElementPresent("xpath", Chart_Object_Properties_pop_close_icon,
				"ICTC-00070," + Widget_name + ",Verify the close icon in Chart Object Properties pop");
	}

	@And("^Verify the ok button in Chart Object Properties pop$")
	public void Verify_the_ok_button_in_Chart_Object_Properties_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_ok_button = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_ok_button");
		com.verifyElementPresent("xpath", Chart_Object_Properties_pop_ok_button,
				"ICTC-00071," + Widget_name + ",Verify the ok button in Chart Object Properties pop");
	}

	@And("^Verify the Cancel button in Chart Object Properties pop$")
	public void Verify_the_Cancel_button_in_Chart_Object_Properties_pop() throws Exception {
		String Chart_Object_Properties_pop_cancel_button = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_cancel_button");
		com.verifyElementPresent("xpath", Chart_Object_Properties_pop_cancel_button,
				"ICTC-00072," + Widget_name + ",Verify the Cancel button in Chart Object Properties pop");
	}

	@And("^Verify the pane list in Chart Object Properties pop$")
	public void Verify_the_pane_list_in_Chart_Object_Properties_pop() throws Exception {
		int Pane_Size = driver
				.findElements(By.xpath(
						"/html/body/div[3]/div/span/div[2]/div/div[2]/div/div/div[1]/div/ul/li/div[1]/span[2]/div"))
				.size();

		for (int i = 1; i <= Pane_Size; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div[2]/div/div[2]/div/div/div[1]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div",
					"ICTC-00073," + Widget_name + ",Verify the pane list in Chart Object Properties pop");

			int pane_list = driver.findElements(By.xpath(
					"/html/body/div[3]/div/span/div[2]/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li/div[1]/span[3]/div"))
					.size();
			for (int j = 1; j <= pane_list; j++) {
				com.verifyElementPresent("xpath",
						"/html/body/div[3]/div/span/div[2]/div/div[2]/div/div/div[1]/div/ul/li[" + i
								+ "]/div[2]/div/ul/li/div[1]/span[3]/div",
						",Chart,Verify the pane list in Chart Object Properties pop");

			}

		}

	}

	@Then("^Verify the plot type drop down in Chart Object Properties pop AAPL Pane$")
	public void Verify_the_plot_type_drop_down_in_Chart_Object_Properties_pop_AAPL_Pane() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_Plot_type_in_AAPL = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_Plot_type_in_AAPL");
		com.verifyElementPresent("xpath", Chart_Object_Properties_pop_Plot_type_in_AAPL, "ICTC-00074," + Widget_name
				+ ",Verify the plot type drop down in Chart Object Properties pop AAPL Pane");
	}

	@And("^Select the All plot type drop down values in Chart Object Properties pop AAPL Pane$")
	public void Select_the_All_plot_type_drop_down_values_in_Chart_Object_Properties_pop_AAPL_Pane() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_Plot_type_in_AAPL = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_Plot_type_in_AAPL");
		com.select_the_Drop_Down_values("xpath", Chart_Object_Properties_pop_Plot_type_in_AAPL, "ICTC-00075,"
				+ Widget_name + ",Select the All plot type drop down values in Chart Object Properties pop AAPL Pane");
	}

	@And("^Click on close icon in Chart Object Properties pop$")
	public void Click_on_close_icon_in_Chart_Object_Properties_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_close_icon = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_close_icon");
		com.click("xpath", Chart_Object_Properties_pop_close_icon,
				"ICTC-00076," + Widget_name + ",Click on close icon in Chart Object Properties pop");
	}

	@And("^Click on Cancel button in Chart Object Properties pop$")
	public void Click_on_Cancel_button_in_Chart_Object_Properties_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_cancel_button = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_cancel_button");
		com.click("xpath", Chart_Object_Properties_pop_cancel_button,
				"ICTC-00077," + Widget_name + ",Click on Cancel button in Chart Object Properties pop");
	}

	@And("^Select the each velue plot type drop down$")
	public void Select_the_each_velue_plot_type_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Plot_type = Common.readPropertyByChart().getProperty("Plot_type");
		com.select_the_Drop_Down_values("xpath", Plot_type,
				"ICTC-00078," + Widget_name + ",Select the each velue plot type drop down");

	}

	@And("^Unselect the use single color check box showing default color and up color and down color or not$")
	public void Unselect_the_use_single_color_check_box_showing_default_color_and_up_color_and_down_color_or_not()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String MSFT = Common.readPropertyByChart().getProperty("MSFT");
		com.click("xpath", MSFT, "," + Widget_name + ",Click on MSFT option");
		com.sleepThread(2000);
		String use_single_color_check_box = Common.readPropertyByChart().getProperty("use_single_color_check_box");
		com.click("xpath", use_single_color_check_box, "ICTC-00079," + Widget_name
				+ ",Unselect the use single color check box showing default color and up color and down color or not");
		com.sleepThread(2000);
		// String default_color =
		// Common.readPropertyByChart().getProperty("default_color");
		// com.verifyElementPresent("xpath", default_color, ",Chart,Verify the defaul
		// color option");
		// String up_color = Common.readPropertyByChart().getProperty("up_color");
		// com.verifyElementPresent("xpath", up_color, ",Chart,Verify the up color
		// option");
		//
		// String down_color = Common.readPropertyByChart().getProperty("down_color");
		// com.verifyElementPresent("xpath", down_color, ",Chart,Verify the down color
		// option");

	}

	@And("^Click on default color and up color and down color icon or not$")
	public void Click_on_default_color_and_up_color_and_down_color_icon_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String default_color = Common.readPropertyByChart().getProperty("default_color");
		com.click("xpath", default_color, ",Chart,Click on defaul color option");
		com.sleepThread(5000);
		String default_more_color = Common.readPropertyByChart().getProperty("default_more_color");
		com.click("xpath", default_more_color,
				"ICTC-00080," + Widget_name + ",defaul color option opning the more colors box shoing or not");
		com.sleepThread(2000);
		String MSFT = Common.readPropertyByChart().getProperty("MSFT");
		com.click("xpath", MSFT, "," + Widget_name + ",Click on MSFT option");
		com.sleepThread(2000);
		String up_color = Common.readPropertyByChart().getProperty("up_color");
		com.click("xpath", up_color, ",Chart,Click on up color option");
		com.sleepThread(2000);
		String up_more_color = Common.readPropertyByChart().getProperty("up_more_color");
		com.click("xpath", up_more_color, ",Chart,up color option opning the more colors box shoing or not");
		com.sleepThread(2000);
		com.click("xpath", MSFT, "," + Widget_name + ",Click on MSFT option");
		com.sleepThread(2000);
		String down_color = Common.readPropertyByChart().getProperty("down_color");
		com.click("xpath", down_color, ",Chart,Click on up color option opning the more colors box");
		String down_more_color = Common.readPropertyByChart().getProperty("down_more_color");
		com.sleepThread(2000);
		com.click("xpath", down_more_color, ",Chart,up color option opning the more colors box shoing or not");
	
	}

	@And("^Select the use single color check box it will showing single color or not$")
	public void Select_the_use_single_color_check_box_it_will_showing_single_color_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String use_single_color_check_box = Common.readPropertyByChart().getProperty("use_single_color_check_box");
		com.click("xpath", use_single_color_check_box, "ICTC-00081," + Widget_name
				+ ",Unselect the use single color check box showing default color and up color and down color or not");
		com.sleepThread(2000);
		String Single_color = Common.readPropertyByChart().getProperty("Single_color");
		com.verifyElementPresent("xpath", Single_color, ",Chart,verify the single color option");

	}

	@And("^Click on single color icon$")
	public void Click_on_single_color_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Single_color = Common.readPropertyByChart().getProperty("Single_color");
		com.click("xpath", Single_color, "ICTC-00082," + Widget_name + ",Click on single color option");
		com.sleepThread(2000);
		String Single_more_color = Common.readPropertyByChart().getProperty("Single_more_color");
		com.click("xpath", Single_more_color, ",Chart,single color option opning the more colors box shoing or not");
	}

	@And("Click on OK button in Chart Object Properties pop")
	public void Click_on_OK_button_in_Chart_Object_Properties_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Object_Properties_pop_ok_button = Common.readPropertyByChart()
				.getProperty("Chart_Object_Properties_pop_ok_button");
		com.click("xpath", Chart_Object_Properties_pop_ok_button,
				"ICTC-00083," + Widget_name + ",Click on OK button in Chart Object Properties pop");
	}

	@Then("^Click on Display Preferences in Chart more icon$")
	public void Click_on_Display_Preferences_in_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Display_Preferences = Common.readPropertyByChart().getProperty("Display_Preferences");
		com.click("xpath", Display_Preferences,
				"ICTC-00084," + Widget_name + ",Click on Display Preferences in Chart more icon");
	}

	@And("^Verify the Chart Display Preferences pop title$")
	public void Verify_the_Chart_Display_Preferences_pop_title() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_title = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_title");
		com.verifyElementPresent("xpath", Chart_Display_Preferences_pop_title,
				"ICTC-00085," + Widget_name + ",Verify the Chart Display Preferences pop title");
	}

	@And("^Verify the Close icon in Chart Display Preferences pop$")
	public void Verify_the_Close_icon_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_close_icon = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_close_icon");
		com.verifyElementPresent("xpath", Chart_Display_Preferences_pop_close_icon,
				"ICTC-00086," + Widget_name + ",Verify the Close icon in Chart Display Preferences pop");
	}

	@And("^Verify the Cancel button in Chart Display Preferences pop$")
	public void Verify_the_Cancel_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_Cancel_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_Cancel_button");
		com.verifyElementPresent("xpath", Chart_Display_Preferences_pop_Cancel_button,
				"ICTC-00087," + Widget_name + ",Verify the Cancel button in Chart Display Preferences pop");
	}

	@And("^Verify the OK button in Chart Display Preferences pop$")
	public void Verify_the_OK_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_OK_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_OK_button");
		com.verifyElementPresent("xpath", Chart_Display_Preferences_pop_OK_button,
				"ICTC-00088," + Widget_name + ",Verify the OK button in Chart Display Preferences pop");
	}

	@And("^Verify the Apply button in Chart Display Preferences pop$")
	public void Verify_the_Apply_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(32000);
		String Chart_Display_Preferences_pop_Apply_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_Apply_button");
		com.verifyElementPresent("xpath", Chart_Display_Preferences_pop_Apply_button,
				"ICTC-00089," + Widget_name + ",Verify the Apply button in Chart Display Preferences pop");
	}

	@And("^verify the left side list and Click on All Items$")
	public void verify_the_left_side_list_and_Click_on_All_Items() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int list = driver.findElements(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[1]/div/button"))
				.size();
		for (int i = 1; i <= list; i++) {
			com.verifyElementPresent("xpath",
					"/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[1]/div/button[" + i + "]",
					"ICTC-00090," + Widget_name + ",Verify the left side list and Click on All Items");
			com.sleepThread(2000);
			com.click("xpath", "/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[1]/div/button[" + i + "]",
					",Chart,Click on left side list and Click on All Items");
		}
	}

	@And("^Click on Close icon in Chart Display Preferences pop$")
	public void Click_on_Close_icon_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_close_icon = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_close_icon");
		com.click("xpath", Chart_Display_Preferences_pop_close_icon,
				"ICTC-00091," + Widget_name + ",Click on Close icon in Chart Display Preferences pop");
	}

	@And("^Click on Cancel button in Chart Display Preferences pop$")
	public void Click_on_Cancel_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_Cancel_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_Cancel_button");
		com.click("xpath", Chart_Display_Preferences_pop_Cancel_button,
				"ICTC-00092," + Widget_name + ",Click on Cancel button in Chart Display Preferences pop");
	}

	@And("Click on OK button in Chart Display Preferences pop")
	public void Click_on_OK_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_OK_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_OK_button");
		com.click("xpath", Chart_Display_Preferences_pop_OK_button,
				"ICTC-00093," + Widget_name + ",Click on OK button in Chart Display Preferences pop");
	}

	@And("Click on save button in Chart Display Preferences pop")
	public void Click_on_Apply_button_in_Chart_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_Display_Preferences_pop_Apply_button = Common.readPropertyByChart()
				.getProperty("Chart_Display_Preferences_pop_Apply_button");
		com.click("xpath", Chart_Display_Preferences_pop_Apply_button,
				"ICTC-00094," + Widget_name + ",Click on save button in Chart Display Preferences pop");
	}

	@Then("^unselect the use theme default check box Background color is enable or not$")
	public void unselect_the_use_theme_default_check_box_Background_color_is_enable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		String use_theme_default_check_box = Common.readPropertyByChart().getProperty("use_theme_default_check_box");
		com.verifyElementisSelected("xpath", use_theme_default_check_box, "ICTC-00095," + Widget_name
				+ ",unselect the use theme default check box Background color is enable or not");
		String Background_color = Common.readPropertyByChart().getProperty("Background_color");
		com.verifyElementPresent("xpath", Background_color, ",Chart,Background color is enable or not");
	}

	@And("^Click on Background color it will showing more colors or not$")
	public void Click_on_Background_color_it_will_showing_more_colors_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Background_color = Common.readPropertyByChart().getProperty("Background_color");
		com.click("xpath", Background_color,
				"ICTC-00096," + Widget_name + ",Click on Background color it will showing more colors or not");
		// String Background_more_color =
		// Common.readPropertyByChart().getProperty("Background_more_color");
		// com.click("xpath", Background_more_color,
		// ",Chart,Background color option opning the more colors box shoing or not");

	}

	@And("^Click on selected object color it will showing more colors or not$")
	public void Click_on_selected_object_color_it_will_showing_more_colors_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String selected_object_color = Common.readPropertyByChart().getProperty("selected_object_color");
		com.click("xpath", selected_object_color,
				"ICTC-00097," + Widget_name + ",Click on selected object color it will showing more colors or not");
		com.sleepThread(2000);
		String selected_object_more_color = Common.readPropertyByChart().getProperty("selected_object_more_color");
		com.click("xpath", selected_object_more_color,
				",Chart,selected object color option opning the more colors box shoing or not");

	}

	@And("^select the use theme default check box Background color is disable or not$")
	public void select_the_use_theme_default_check_box_Background_color_is_disable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String use_theme_default_check_box = Common.readPropertyByChart().getProperty("use_theme_default_check_box");
		com.verifyElementisSelected("xpath", use_theme_default_check_box, "ICTC-00098," + Widget_name
				+ ",select the use theme default check box Background color is disable or not");
		String Background_color = Common.readPropertyByChart().getProperty("Background_color");
		com.verifyElementPresent("xpath", Background_color, ",Chart,Background color is disable or not");

	}

	@Then("^Click on Plot colors option display the related functions or not in Display Preferences pop$")
	public void Click_on_Plot_colors_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String plot_colors = Common.readPropertyByChart().getProperty("plot_colors");
		com.click("xpath", plot_colors, "ICTC-00099," + Widget_name
				+ ",Click on Plot colors option display the related functions or not in Display Preferences pop");
		String Plot_colors_text = Common.readPropertyByChart().getProperty("Plot_colors_text");
		com.verifyElementPresent("xpath", Plot_colors_text,
				",Chart,Plot colors option display the related functions or not in Display Preferences pop");

	}

	@And("^Click on each plot colors it will showing more colors or not$")
	public void Click_on_each_plot_colors_it_will_showing_more_colors_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int size = driver.findElements(By.xpath(
				"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr/td[2]/div/span/button"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
							+ "]/td[2]/div/span/button",
					"ICTC-00100," + Widget_name + ",Click on each plot colors it will showing more colors or not");
			com.sleepThread(2000);
			com.verifyElementPresent("xpath", "//*[contains(text(),'More colors...')]",
					",Chart,showing more colors or not");
			com.sleepThread(2000);
			com.click("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
							+ "]/td[2]/div/span/button",
					",Chart,Click on each plot colors it will closing more colors or not");
		}
	}

	@Then("^Click on Data view option display the related functions or not in Display Preferences pop$")
	public void Click_on_Data_view_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Data_view = Common.readPropertyByChart().getProperty("Data_view");
		com.click("xpath", Data_view, "ICTC-00101," + Widget_name
				+ ",Click on Data view option display the related functions or not in Display Preferences pop");
		String Data_view_text = Common.readPropertyByChart().getProperty("Data_view_text");
		com.verifyElementPresent("xpath", Data_view_text,
				",Chart,Data view option display the related functions or not in Display Preferences pop");
	}

	@Then("^Click on Header and footer option display the related functions or not in Display Preferences pop$")
	public void Click_on_Header_and_footer_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Header_Footer = Common.readPropertyByChart().getProperty("Header_Footer");
		com.click("xpath", Header_Footer, "ICTC-00102," + Widget_name
				+ ",Click on Header and footer option display the related functions or not in Display Preferences pop");
		String Header_Footer_text = Common.readPropertyByChart().getProperty("Header_Footer_text");
		com.verifyElementPresent("xpath", Header_Footer_text,
				",Chart,Header and footer option display the related functions or not in Display Preferences pop");
	}

	@And("^Click on each Redio buttons Chart Header in Display Preferences pop$")
	public void Click_on_each_Redio_buttons_Chart_Header_in_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int size = driver
				.findElements(By.xpath(
						"/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/div/label[" + i
							+ "]",
					"ICTC-00103," + Widget_name
							+ ",Click on each Redio buttons Chart Header in Display Preferences pop");
		}
	}

	@And("^Click on each check box Chart Header in Display Preferences pop$")
	public void Click_on_each_check_box_Chart_Header_in_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int size = driver
				.findElements(By
						.xpath("/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/label[" + i + "]",
					"ICTC-00104," + Widget_name + ",Click on each check box Chart Header in Display Preferences pop");
		}
	}

	@And("^Verify the Show Footer check box in chart footer$")
	public void Verify_the_Show_Footer_check_box_in_chart_footer() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Show_Footer_checkbox = Common.readPropertyByChart().getProperty("Show_Footer_checkbox");
		com.click("xpath", Show_Footer_checkbox,
				"ICTC-00105," + Widget_name + ",Verify the Show Footer check box in chart footer");

	}

	@Then("^Click on Markers and Flage option display the related functions or not in Display Preferences pop$")
	public void Click_on_Markers_and_Flage_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Markers_Flags = Common.readPropertyByChart().getProperty("Markers_Flags");
		com.click("xpath", Markers_Flags, "ICTC-00106," + Widget_name
				+ ",Click on Markers and Flage option display the related functions or not in Display Preferences pop");
		String Markers_Flags_text = Common.readPropertyByChart().getProperty("Markers_Flags_text");
		com.verifyElementPresent("xpath", Markers_Flags_text,
				",Chart,Markers and Flage option display the related functions or not in Display Preferences pop");
	}

	@And("^Select on each value in symbol value marker drop down$")
	public void Select_on_each_value_in_symbol_value_marker_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String symbol_value_marker_drop_down = Common.readPropertyByChart()
				.getProperty("symbol_value_marker_drop_down");
		com.select_the_Drop_Down_values("xpath", symbol_value_marker_drop_down,
				"ICTC-00107," + Widget_name + ",Select on each value in symbol value marker drop down");

	}

	@And("^select the each value symbol Marker Location drop down$")
	public void select_the_each_value_symbol_Marker_Location_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String symbol_Marker_Location = Common.readPropertyByChart().getProperty("symbol_Marker_Location");
		com.select_the_Drop_Down_values("xpath", symbol_Marker_Location,
				"ICTC-00108," + Widget_name + ",select the each value symbol Marker Location drop down");

	}

	@And("^select the each value study value marker drop down$")
	public void select_the_each_value_study_value_marker_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String study_value_marker_drop_down = Common.readPropertyByChart().getProperty("study_value_marker_drop_down");
		com.select_the_Drop_Down_values("xpath", study_value_marker_drop_down,
				"ICTC-00109," + Widget_name + ",select the each value study value marker drop down");

	}

	@And("^select the each value study Marker Location drop down$")
	public void select_the_each_value_study_Marker_Location_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String study_Marker_Location_drop_down = Common.readPropertyByChart()
				.getProperty("study_Marker_Location_drop_down");
		com.select_the_Drop_Down_values("xpath", study_Marker_Location_drop_down,
				"ICTC-00110," + Widget_name + ",select the each value study Marker Location drop down");

	}

	@Then("^Click on each color option it will showing more colors or not$")
	public void Click_on_each_color_option_it_will_showing_more_colors_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int R_size = driver.findElements(By.xpath(
				"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr/td[3]/div/span/button"))
				.size();
		int C_size = driver.findElements(By.xpath(
				"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr[1]/td/div/span/button"))
				.size();
		for (int j = 3; j < 2; j++) {
			for (int i = 1; i < R_size; i++) {
				com.click("xpath",
						"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
								+ i + "]/td[" + j + "]/div/span/button",
						"ICTC-00111," + Widget_name + ",Click on each color option it will showing more colors or not");
				com.sleepThread(2000);
				com.verifyElementPresent("xpath", "//*[contains(text(),'More colors...')]",
						"showing more colors or not");
				com.sleepThread(2000);
				com.click("xpath",
						"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
								+ i + "]/td[" + j + "]/div/span/button",
						"ICTC-00112," + Widget_name + ",Click on each color option it will closing more colors or not");
			}
		}

	}

	@And("^Click on each check box in Markers and Flage option$")
	public void Click_on_each_check_box_in_Markers_and_Flage_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath(
				"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr/td[2]/label/input"))
				.size();
		for (int i = 1; i < size; i++) {
			com.verifyElementisSelected("xpath",
					"/html/body/div[6]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
							+ i + "]/td[2]/label/input",
					"ICTC-00113," + Widget_name + ",Click on each check box in Markers and Flage option");
		}
	}

	@Then("^Click on Grid Lines option display the related functions or not in Display Preferences pop$")
	public void Click_on_Grid_Lines_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Grid_lines = Common.readPropertyByChart().getProperty("Grid_lines");
		com.click("xpath", Grid_lines, "ICTC-00114," + Widget_name
				+ ",Click on Grid Lines option display the related functions or not in Display Preferences pop");
		String Grid_lines_text = Common.readPropertyByChart().getProperty("Grid_lines_text");
		com.verifyElementPresent("xpath", Grid_lines_text,
				",Chart,Grid Lines option display the related functions or not in Display Preferences pop");

	}

	@And("^Click on each check box in Grid Lines option$")
	public void Click_on_each_check_box_in_Grid_Lines_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"ICTC-00115," + Widget_name + ",Click on each check box in Grid Lines option");
		}
	}

	@And("^Click on Grid color option it will showing more colors or not$")
	public void Click_on_Grid_color_option_it_will_showing_more_colors_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Grid_Color = Common.readPropertyByChart().getProperty("Grid_Color");
		com.click("xpath", Grid_Color,
				"ICTC-00116," + Widget_name + ",Click on Grid color option it will showing more colors or not");
		com.sleepThread(2000);
		String Grid_more_color = Common.readPropertyByChart().getProperty("Grid_more_color");
		com.click("xpath", Grid_more_color, "ICTC-00117," + Widget_name + ",showing more colors or not");

	}

	@And("^Select the each value in Grid style drop down$")
	public void Select_the_each_value_i_Grid_style_drop_down() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Grid_style_drop_down = Common.readPropertyByChart().getProperty("Grid_style_drop_down");
		com.select_the_Drop_Down_values("xpath", Grid_style_drop_down,
				"ICTC-00118," + Widget_name + ",Select the each value in Grid style drop down");
	}

	@Then("^Click on Formating option display the related functions or not in Display Preferences pop$")
	public void Click_on_Formating_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Formatting = Common.readPropertyByChart().getProperty("Formatting");
		com.click("xpath", Formatting, "ICTC-00119," + Widget_name
				+ ",Click on Formating option display the related functions or not in Display Preferences pop");
		String Formatting_text = Common.readPropertyByChart().getProperty("Formatting_text");
		com.verifyElementPresent("xpath", Formatting_text,
				",Chart,Formating option display the related functions or not in Display Preferences pop");

	}

	@And("^click on show full precision check box in Formatting option$")
	public void click_on_show_full_precision_check_box_in_Formatting_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Formatting_chechbox = Common.readPropertyByChart().getProperty("Formatting_chechbox");
		com.click("xpath", Formatting_chechbox,
				"ICTC-00120," + Widget_name + ",click on show full precision check box in Formatting option");
	}

	@Then("^Click on Defaults option display the related functions or not in Display Preferences pop$")
	public void Click_on_Defaults_option_display_the_related_functions_or_not_in_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Defaults = Common.readPropertyByChart().getProperty("Defaults");
		com.click("xpath", Defaults, "ICTC-00121," + Widget_name
				+ ",Click on Defaults option display the related functions or not in Display Preferences pop");
		String Defaults_text = Common.readPropertyByChart().getProperty("Defaults_text");
		com.verifyElementPresent("xpath", Defaults_text,
				",Chart,Defaults option display the related functions or not in Display Preferences pop");

	}

	@Then("^Click on Each check boxes in Chart more icon$")
	public void Click_on_Each_check_boxes_in_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		int list = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button/label"))
				.size();
		for (int i = 3; i <= list; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00122," + Widget_name + ",Click on Each check boxes in Chart more icon");
			C.Click_on_Chart_more_icon();
		}
	}

	@Then("^focus on mouseover on Grid in Chart more icon$")
	public void focus_on_mouseover_on_Grid_in_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Chart_more_icon_Grid = Common.readPropertyByChart().getProperty("Chart_more_icon_Grid");
		com.startAction();
		com.MouseOverToElement("xpath", Chart_more_icon_Grid, ",Chart,");
		int list = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[12]/div/ul/li"))
				.size();
		for (int i = 1; i <= list; i++) {
			com.MouseOverToElement("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[12]/div/ul/li[" + i + "]",
					"ICTC-00123," + Widget_name + ",focus on mouseover on Grid in Chart more icon");
			com.verifyElementPresent("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[12]/div/ul/li[" + i + "]",
					",Chart,Verify the Grid in Chart more icon");
		}

	}

	@When("^Verify the Flag icon$")
	public void Verify_the_Flag_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Flags_Icon = Common.readPropertyByChart().getProperty("Flags_Icon");
		com.verifyElementPresent("xpath", Flags_Icon, "ICTC-00124," + Widget_name + ",Verify the Flag icon");
	}

	@Then("^Click on Flag icon$")
	public void Click_on_Flag_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Flags_Icon = Common.readPropertyByChart().getProperty("Flags_Icon");
		com.click("xpath", Flags_Icon, "ICTC-00125," + Widget_name + ",Click on Flag icon");
	}

	@And("^Click on Each value$")
	public void Click_on_Each_value() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		int list = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button/label"))
				.size();
		for (int i = 1; i < list; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00126," + Widget_name + ",Click on Each value");
			com.sleepThread(2000);
			C.Click_on_Flag_icon();
		}
	}

	@When("^Verify the Templates Icon$")
	public void Verify_the_Templates_Icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Templates_Icon = Common.readPropertyByChart().getProperty("Templates_Icon");
		com.verifyElementPresent("xpath", Templates_Icon, "ICTC-00127," + Widget_name + ",Verify the Templates Icon");
	}

	@Then("^Click on Templates Icon$")
	public void Click_on_Templates_Icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Templates_Icon = Common.readPropertyByChart().getProperty("Templates_Icon");
		com.click("xpath", Templates_Icon, "ICTC-00128," + Widget_name + ",Click on Templates Icon");
	}

	@And("^Verify the list in Templates Icon$")
	public void Verify_the_list_in_Templates_Icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button")).size();
		for (int i = 1; i <= size; i++) {
			com.verifyElementPresent("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button",
					"ICTC-00129," + Widget_name + ",Verify the list in Templates Icon");
		}
	}

	@And("^Focus on mouseover in save current template as$")
	public void Focus_on_mouseover_in_save_current_template_as() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		com.startAction();
		String save_current_template_as = Common.readPropertyByChart().getProperty("save_current_template_as");
		com.MouseOverToElement("xpath", save_current_template_as,
				"ICTC-00130," + Widget_name + ",Focus on mouseover in save current template as");
	}

	@And("^Mouseover on New Chart template$")
	public void Mouseover_on_New_Chart_template() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		com.startAction();
		String New_Chart_template = Common.readPropertyByChart().getProperty("New_Chart_template");
		com.MouseOverToElement("xpath", New_Chart_template,
				"ICTC-00131," + Widget_name + ",Mouseover on New Chart template");
		com.verifyElementPresent("xpath", New_Chart_template, ",Chart,Verify the New Chart template");
	}

	@And("^Click on New chart template$")
	public void Click_on_New_chart_template() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String New_Chart_template = Common.readPropertyByChart().getProperty("New_Chart_template");
		com.MouseOverToclickabl("xpath", New_Chart_template,
				"ICTC-00132," + Widget_name + ",Click on New chart template");
	}

	@Then("^Verify the title in New chart template pop$")
	public void Verify_the_title_in_New_chart_template_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String New_chart_template_pop_title = Common.readPropertyByChart().getProperty("New_chart_template_pop_title");
		com.verifyElementPresent("xpath", New_chart_template_pop_title,
				"ICTC-00137," + Widget_name + ",Verify the title in New chart template pop");
	}

	@And("^Verify the cross icon$")
	public void Verify_the_cross_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_cross_icon = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_cross_icon");
		com.verifyElementPresent("xpath", New_chart_template_pop_cross_icon,
				"ICTC-00138," + Widget_name + ",Verify the cross icon");
	}

	@And("^Verify the cancel button$")
	public void Verify_the_cancel_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_cancel_button = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_cancel_button");
		com.verifyElementPresent("xpath", New_chart_template_pop_cancel_button,
				"ICTC-00139," + Widget_name + ",Verify the cancel button");
	}

	@And("^Verify the ok button is disable or not$")
	public void Verify_the_ok_button_is_disable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_Ok_button = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_Ok_button");
		com.verifyElementPresent("xpath", New_chart_template_pop_Ok_button,
				"ICTC-00140," + Widget_name + ",Verify the ok button is disable or not");
	}

	@And("^verify the Name input text box$")
	public void verify_the_Name_input_text_box() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_name_input_felid = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_name_input_felid");
		com.verifyElementPresent("xpath", New_chart_template_pop_name_input_felid,
				"ICTC-00141," + Widget_name + ",verify the Name input text box");
	}

	@And("^Enter the input data in name felid \"(.*?)\"$")
	public void Enter_the_input_data_in_name_felid(String Test) throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_name_input_felid = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_name_input_felid");
		com.sendKeys("xpath", New_chart_template_pop_name_input_felid, Test,
				"ICTC-00142," + Widget_name + ",Enter the input data in name felid");
	}

	@And("^Verify the OK button is enable or not$")
	public void Verify_the_OK_button_is_enable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_Ok_button = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_Ok_button");
		com.verifyElementEnabled("xpath", New_chart_template_pop_Ok_button,
				"ICTC-00143," + Widget_name + ",Verify the OK button is enable or not");
	}

	@And("^Click on OK button$")
	public void Click_on_OK_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String New_chart_template_pop_Ok_button = Common.readPropertyByChart()
				.getProperty("New_chart_template_pop_Ok_button");
		com.click("xpath", New_chart_template_pop_Ok_button, "ICTC-00144," + Widget_name + ",Click on OK button");
	}

	@Then("^Click on Customize option$")
	public void Click_on_Customize_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Customize_in_Templates_Icon = Common.readPropertyByChart().getProperty("Customize_in_Templates_Icon");
		com.click("xpath", Customize_in_Templates_Icon, "ICTC-00145," + Widget_name + ",Click on Customize option");

	}

	@And("^Verify the Customize pop title$")
	public void Verify_the_Customize_pop_title() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Chart_Templates_title_Customize_pop = Common.readPropertyByChart()
				.getProperty("Chart_Templates_title_Customize_pop");
		com.verifyElementPresent("xpath", Chart_Templates_title_Customize_pop,
				"ICTC-00146," + Widget_name + ",Verify the Customize pop title");
	}

	@And("^Verify the cross icon in Customize pop$")
	public void Verify_the_cross_icon_in_Customize_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Close_Icon_Customize_pop = Common.readPropertyByChart().getProperty("Close_Icon_Customize_pop");
		com.verifyElementPresent("xpath", Close_Icon_Customize_pop,
				"ICTC-00147," + Widget_name + ",Verify the cross icon in Customize pop");
	}

	@And("^Verify the close button in Customize pop$")
	public void Verify_the_close_button_in_Customize_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Close_button_Customize_pop = Common.readPropertyByChart().getProperty("Close_button_Customize_pop");
		com.verifyElementPresent("xpath", Close_button_Customize_pop,
				"ICTC-00148," + Widget_name + ",Verify the close button in Customize pop");
	}

	@And("^Verify the Move up button is disabled or not$")
	public void Verify_the_Move_up_button_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Move_up_button_Customize_pop = Common.readPropertyByChart().getProperty("Move_up_button_Customize_pop");
		com.verifyElementPresent("xpath", Move_up_button_Customize_pop,
				"ICTC-00149," + Widget_name + ",Verify the Move up button is disabled or not");
	}

	@And("^Verify the Move Down button is disabled or not$")
	public void Verify_the_Move_Down_button_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Move_Down_button_Customize_pop = Common.readPropertyByChart()
				.getProperty("Move_Down_button_Customize_pop");
		com.verifyElementPresent("xpath", Move_Down_button_Customize_pop,
				"ICTC-00150," + Widget_name + ",Verify the Move Down button is disabled or not");
	}

	@And("^Verify the Rename button is disabled or not$")
	public void Verify_the_Rename_button_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Rename_button_Customize_pop = Common.readPropertyByChart().getProperty("Rename_button_Customize_pop");
		com.verifyElementPresent("xpath", Rename_button_Customize_pop,
				"ICTC-00151," + Widget_name + ",Verify the Rename button is disabled or not");
	}

	@And("^Verify the Delete button is disabled or not$")
	public void Verify_the_Delete_button_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Delete_button_Customize_pop = Common.readPropertyByChart().getProperty("Delete_button_Customize_pop");
		com.verifyElementPresent("xpath", Delete_button_Customize_pop,
				"ICTC-00152," + Widget_name + ",Verify the Delete button is disabled or not");
	}

	@And("^Verify the Apply button is disabled or not$")
	public void Verify_the_Apply_button_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Apply_button_Customize_pop = Common.readPropertyByChart().getProperty("Apply_button_Customize_pop");
		com.verifyElementPresent("xpath", Apply_button_Customize_pop,
				"ICTC-00153," + Widget_name + ",Verify the Apply button is disabled or not");
	}

	@And("^Verify the Apply Template with colors checkbox is disabled or not$")
	public void Verify_the_Apply_Template_with_colors_checkbox_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Check_box_Customize_pop = Common.readPropertyByChart().getProperty("Check_box_Customize_pop");
		com.verifyElementPresent("xpath", Check_box_Customize_pop,
				"ICTC-00154," + Widget_name + ",Verify the Apply Template with colors checkbox is disabled or not");
	}

	@And("^Click on cross icon in Customize pop$")
	public void Click_on_cross_icon_in_Customize_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Close_Icon_Customize_pop = Common.readPropertyByChart().getProperty("Close_Icon_Customize_pop");
		com.click("xpath", Close_Icon_Customize_pop,
				"ICTC-00155," + Widget_name + ",Click on cross icon in Customize pop");
	}

	@And("^Click on close button in Customize pop$")
	public void Click_on_close_button_in_Customize_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Close_button_Customize_pop = Common.readPropertyByChart().getProperty("Close_button_Customize_pop");
		com.click("xpath", Close_button_Customize_pop,
				"ICTC-00156," + Widget_name + ",Click on close button in Customize pop");
	}

	@When("^Verify the Compare option$")
	public void Verify_the_Compare_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Compare = Common.readPropertyByChart().getProperty("Compare");
		com.verifyElementPresent("xpath", Compare, "ICTC-00157," + Widget_name + ",Verify the Compare option");

	}

	@Then("^Click on Compare option$")
	public void Click_on_Compare_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Compare = Common.readPropertyByChart().getProperty("Compare");
		com.click("xpath", Compare, "ICTC-00158," + Widget_name + ",Click on Compare option");
	}

	@And("^Verify the title in Compare pop$")
	public void Verify_the_title_in_Compare_pop() throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Compare_pop_title = Common.readPropertyByChart().getProperty("Compare_pop_title");
		com.verifyText_Using_String("xpath", Compare_pop_title, "Compare",
				"ICTC-00159," + Widget_name + ",Verify the title in Compare pop");
	}

	@And("^Verify the Cross icon in Compare pop$")
	public void Verify_the_Cross_icon_in_Compare_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String cross_icon_Compare_pop = Common.readPropertyByChart().getProperty("cross_icon_Compare_pop");
		com.verifyElementPresent("xpath", cross_icon_Compare_pop,
				"ICTC-00160," + Widget_name + ",Verify the Cross icon in Compare pop");
	}

	@And("^Verify the All checkbox$")
	public void Verify_the_All_label() throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver
				.findElements(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/fieldset[1]/div/div[1]/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "/html/body/div[7]/div/span/div[2]/div/div[2]/fieldset[1]/div/div[1]/label[" + i + "]",
					"ICTC-00161," + Widget_name + ",Verify the All checkbox");
		}
		int size1 = driver
				.findElements(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/fieldset[1]/div/div[2]/label"))
				.size();
		for (int i = 1; i < size1; i++) {
			com.click("xpath", "/html/body/div[7]/div/span/div[2]/div/div[2]/fieldset[1]/div/div[2]/label[" + i + "]",
					",Chart,Verify the All checkbox");
		}
	}

	@Then("^Select on lable Add option is enable or not$")
	public void Select_on_lable_Add_option_is_enable_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_button_compare_pop = Common.readPropertyByChart().getProperty("Add_button_compare_pop");
		com.verifyElementEnabled("xpath", Add_button_compare_pop,
				"ICTC-00162," + Widget_name + ",Select on lable Add option is enable or not");
	}

	@And("^Click on Add button in Compare pop$")
	public void Click_on_Add_button_in_Compare_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_button_compare_pop = Common.readPropertyByChart().getProperty("Add_button_compare_pop");
		com.click("xpath", Add_button_compare_pop, "ICTC-00163," + Widget_name + ",Click on Add button in Compare pop");
	}

	@And("^Verify all menuitem in Add button Compare pop$")
	public void Verify_all_menuitem_in_Add_button_Compare_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("/html/body/div[1]/div/div/div/div/div[5]/div/ul/li/button"))
				.size();
		for (int i = 1; i <2; i++) {
			com.verifyElementEnabled("xpath",
					"/html/body/div[1]/div/div/div/div/div[5]/div/ul/li["+i+"]/button",
					"ICTC-00164," + Widget_name + ",Verify all menuitem in Add button Compare pop");
		}

	}

	@When("^Click on right click on option in widget name$")
	public void Click_on_right_click_on_option_in_widget_name() throws Exception {
		com.sleepThread(6000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab, ",Chart,Mouse over on widget name");
		com.Rightclick("xpath", Widget_tab, "ICTC-00165,Chart,Click on right click on option in widget name");
	}

	@Then("^Click on Tearout Tab$")
	public void Click_on_Tearout_Tab() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Tearout_Tab = Common.readPropertyByChart().getProperty("Tearout_Tab");
		com.sleepThread(3000);
		String New_window_widget_name = Common.readPropertyByChart().getProperty("New_window_widget_name");
		com.switch_to_new_window("xpath", Tearout_Tab, "ICTC-00169," + Widget_name + ",Click on Tearout Tab", "xpath",
				New_window_widget_name, ",Chart,Switch to New Window verify the widget tab");
	}

	@And("^Click on Close Tab and verify the tab is closeing or not$")
	public void Click_on_Close_Tab() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
//		String Launch_menu_widget1 = Common.readPropertyByChart().getProperty("Launch_menu_widget1");
//		com.click("xpath", Launch_menu_widget1, ",Chart,Click on first widget in Launch menu");
		com.sleepThread(3000);
		C.Click_on_right_click_on_option_in_widget_name();
		com.sleepThread(1000);
		String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab,
				"ICTC-00170," + Widget_name + ",Click on Close Tab and verify the tab is closeing or not");
		com.sleepThread(2000);
		String Launch_menu = Common.readPropertyByChart().getProperty("Launch_menu");
		com.verifyElementEnabled("xpath", Launch_menu, ",Chart,Verify the Launch menu is displayed or not");
	}

	@And("^Click on Close Other Tabs all taba is closing or not$")
	public void Click_on_Close_Other_Tabs() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Launch_menu_widget1 = Common.readPropertyByChart().getProperty("Launch_menu_widget1");
		com.click("xpath", Launch_menu_widget1, ",Chart,Click on first widget in Launch menu");
		String add_tab = Common.readPropertyByChart().getProperty("add_tab");
		com.click("xpath", add_tab, ",Chart,Click on Add tab opning Launch menu or not");
		com.sleepThread(2000);
		String Launch_menu_widget2 = Common.readPropertyByChart().getProperty("Launch_menu_widget2");
		com.click("xpath", Launch_menu_widget2, ",Chart,Click on second widget in Launch menu");
		C = new Chart();
		C.Click_on_right_click_on_option_in_widget_name();
		com.sleepThread(1000);
		String Close_Other_Tabs = Common.readPropertyByChart().getProperty("Close_Other_Tabs");
		com.click("xpath", Close_Other_Tabs,
				"ICTC-00171," + Widget_name + ",Click on Close Other Tabs all taba is closing or not");
		com.sleepThread(1000);
		com.verifyElementPresent("xpath", add_tab, "," + Widget_name + ",all tabs is closing or not");
	}

	@And("^Click on Close Other Tabs all tabs$")
	public void Click_on_Close_Other_Tabs_all_tabs() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(1000);
		String Close_Other_Tabs = Common.readPropertyByChart().getProperty("Close_Other_Tabs");
		com.click("xpath", Close_Other_Tabs,
				"ICTC-00172," + Widget_name + ",Click on Close Other Tabs all taba is closing or not");
	}

	@And("^Click on Close Tab in widget name$")
	public void Click_on_Close_Tab_in_widget_name() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(1000);
		String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab, "ICTC-00173,Chart,Click on Close Tab in widget name");

	}

	@When("^verify the Show Region Menu$")
	public void verify_the_Show_Region_Menu() throws Exception {
		com.sleepThread(6000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Show_Region_Menu = Common.readPropertyByChart().getProperty("Show_Region_Menu");
		com.verifyElementEnabled("xpath", Show_Region_Menu,
				"," + Widget_name + ",verify the Show Region Menu");
	}

	@Then("^Click on Show Region Menu$")
	public void Click_on_Show_Region_Menu() throws Exception {
//		String Options = Common.readPropertyByoptions().getProperty("Options");
//		com.sleepThread(6000);
//		com.click("xpath", Options, "IOTC-00002,Options,Click on Options");
//		com.sleepThread(4000);		
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Show_Region_Menu = Common.readPropertyByChart().getProperty("Show_Region_Menu");
		com.click("xpath", Show_Region_Menu, "," + Widget_name + ",Click on Show Region Menu");
		com.sleepThread(1000);
		String Sort_tabs = Common.readPropertyByChart().getProperty("Sort_tabs");
		com.verifyElementEnabled("xpath", Sort_tabs, ",Chart,Verify the sort tabs");
	}

	@And("^Click on submenus in sort tabs$")
	public void Click_on_submenus_in_sort_tabs() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Sort_tabs = Common.readPropertyByChart().getProperty("Sort_tabs");
		com.MouseOverToElement("xpath", Sort_tabs, ",Chart,mouseover on sort tabs");
		com.sleepThread(1000);
		int size = driver
				.findElements(By.xpath("/html/body/div/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li/button"))
				.size();
		System.out.println("submenus in sort tabs Size:"+size);
		for (int i = 1; i <size; i++) {
			com.MouseOverToclickabl("xpath", "/html/body/div/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li["+i+"]/button",
					"ICTC-00174," + Widget_name + ",Click on submenus in sort tabs");
			com.sleepThread(1000);
			C = new Chart();
			C.Click_on_Show_Region_Menu();
			com.MouseOverToElement("xpath", Sort_tabs, ",Chart,mouseover on sort tabs");
			com.sleepThread(1000);
			com.MouseOverToElement("xpath", "/html/body/div/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[1]/button",
					"ICTC-00174," + Widget_name + ",Click on submenus in sort tabs");
		}

	}

	@And("^Verify the Show Region Labels check box$")
	public void Verify_the_Show_Region_Labels_check_box() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		C = new Chart();
		C.Click_on_Show_Region_Menu();
		String Show_Region_Labels = Common.readPropertyByChart().getProperty("Show_Region_Labels");
		com.verifyElementEnabled("xpath", Show_Region_Labels,
				"ICTC-00175," + Widget_name + ",Verify the Show Region Labels check box");
	}

	@And("^Uncheck Show Region Labels check box Principal Region menu is hiding or not$")
	public void Uncheck_Show_Region_Labels_check_box_Principal_Region_menu_is_hiding_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Show_Region_Labels = Common.readPropertyByChart().getProperty("Show_Region_Labels");
		com.click("xpath", Show_Region_Labels, "ICTC-00176," + Widget_name
				+ ",Uncheck Show Region Labels check box Principal Region menu is hiding or not");
		com.sleepThread(2000);
	}

	@And("^Select the Show Region Labels check box Principal Region menu is showing or not$")
	public void Select_the_Show_Region_Labels_check_box_Principal_Region_menu_is_showing_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Show_Region_Labels = Common.readPropertyByChart().getProperty("Show_Region_Labels");
		com.click("xpath", Show_Region_Labels, "ICTC-00177," + Widget_name
				+ ",Select the Show Region Labels check box Principal Region menu is showing or not");
		com.sleepThread(2000);
		String Principal_Region = Common.readPropertyByChart().getProperty("Principal_Region");
		com.verifyElementPresent("xpath", Principal_Region, ",Chart,Principal Region menu is showing or not");
	}

	@Then("^Verify the Tab Position$")
	public void Verify_the_Tab_Position() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Tab_Position = Common.readPropertyByChart().getProperty("Tab_Position");
		com.verifyElementEnabled("xpath", Tab_Position, "ICTC-00178," + Widget_name + ",Verify the Tab Position");
	}

	@And("^Click on submenus in tab position$")
	public void Click_on_submenus_in_tab_position() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Tab_Position = Common.readPropertyByChart().getProperty("Tab_Position");
		com.MouseOverToElement("xpath", Tab_Position, "," + Widget_name +",mouseover on tab position");
		int size = driver
				.findElements(
						By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li/button/label"))
				.size();
		System.out.println("submenus in tab position:"+size);
		for (int i = 1; i <=size; i++) {
			//int l = size - i;
			com.MouseOverToclickabl("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[" + i + "]/button/label",
					"ICTC-00179," + Widget_name + ",Click on submenus in tab position");
			C = new Chart();
			C.Click_on_Show_Region_Menu();
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Tab_Position, "," + Widget_name +",mouseover on tab position");
			com.sleepThread(1000);
			com.MouseOverToElement("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[1]/button/label",
					"ICTC-00179," + Widget_name + ",Click on submenus in tab position");
		}
		com.MouseOverToclickabl("xpath",
				"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[1]/button/label",
				"ICTC-00179," + Widget_name + ",Click on submenus in tab position");
	}

	@And("^Verify the zoom region$")
	public void Verify_the_zoom_region() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Zoom_Region = Common.readPropertyByChart().getProperty("Zoom_Region");
		com.verifyElementEnabled("xpath", Zoom_Region, "ICTC-00180," + Widget_name + ",Verify the zoom region");
	}

	@And("^Click on submenus in zoom region$")
	public void Click_on_submenus_in_zoom_region() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Zoom_Region = Common.readPropertyByChart().getProperty("Zoom_Region");
		com.MouseOverToElement("xpath", Zoom_Region, ",Chart,Mouseover on zoom region option");
		int size = driver
				.findElements(
						By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li/button/label"))
				.size();
		for (int i = 1; i <size; i++) {
			com.click("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li[" + i + "]/button/label",
					"ICTC-00181," + Widget_name + ",Click on submenus in zoom region");
			com.sleepThread(2000);
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li[5]/button/label",
					",Chart,click on zoom region 100 percentage");
		}
	}

	@And("^Verify the create new reggion$")
	public void Verify_the_create_new_reggion() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Create_New_Region = Common.readPropertyByChart().getProperty("Create_New_Region");
		com.verifyElementEnabled("xpath", Create_New_Region,
				"ICTC-00181," + Widget_name + ",Verify the create new reggion");
	}

	@And("^click on submenus in create new reggion$")
	public void click_on_submenus_in_create_new_reggion() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Create_New_Region = Common.readPropertyByChart().getProperty("Create_New_Region");
		com.MouseOverToElement("xpath", Create_New_Region, ",Chart,Mouse over on create new reggion");
		int size = driver
				.findElements(By.xpath("/html/body/div/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li/button"))
				.size();
		System.out.println("create new reggion:"+size);
		for (int i = 1; i <size; i++) {
			com.MouseOverToclickabl("xpath",
					"/html/body/div/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li["+i+"]/button",
					"ICTC-00182," + Widget_name + ",click on submenus in create new reggion");
			com.sleepThread(5000);
			C = new Chart();
			C.Click_on_Show_Region_Menu();
			com.sleepThread(6000);
			String Remove_Region = Common.readPropertyByChart().getProperty("Remove_Region");
			com.click("xpath", Remove_Region, ",Chart,Mouse over on Remove Region option");
			com.sleepThread(6000);
			String Options = Common.readPropertyByoptions().getProperty("Options");
			com.sleepThread(6000);
			com.click("xpath", Options, "IOTC-00002,Options,Click on Options");
			com.sleepThread(4000);			
			C.Click_on_Show_Region_Menu();
			com.sleepThread(4000);
			com.MouseOverToElement("xpath", Create_New_Region, ",Chart,Mouse over on create new reggion");
			com.sleepThread(4000);
			com.MouseOverToElement("xpath",
					"/html/body/div/div/div/div/div/div[5]/div/ul/li[4]/div/ul/li[1]/button",
					"ICTC-00182," + Widget_name + ",click on submenus in create new reggion");
		}

	}

	@And("^verify the Move Region Into a New Window$")
	public void verify_the_Move_Region_Into_a_New_Window() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Move_Region_Into_a_New_Window = Common.readPropertyByChart()
				.getProperty("Move_Region_Into_a_New_Window");
		com.verifyElementEnabled("xpath", Move_Region_Into_a_New_Window,
				"ICTC-00183," + Widget_name + ",verify the Move Region Into a New Window");
	}

	@And("^click on Move Region Into a New Window option$")
	public void click_on_Move_Region_Into_a_New_Window_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Move_Region_Into_a_New_Window = Common.readPropertyByChart()
				.getProperty("Move_Region_Into_a_New_Window");
		com.MouseOverToElement("xpath", Move_Region_Into_a_New_Window, ",Chart,ouse over on move region");
		com.sleepThread(2000);
		String New_Window = Common.readPropertyByChart().getProperty("New_Window");
		com.MouseOverToElement("xpath", New_Window, ",Chart,ouse over on New Window");
		com.sleepThread(10000);
		String New_window_widget_name = Common.readPropertyByChart().getProperty("New_window_widget_name");
		com.switch_to_new_window("xpath", New_Window,
				"ICTC-00184," + Widget_name + ",click on Move Region Into a New Window option", "xpath",
				New_window_widget_name, ",Chart,Switch to New Window verify the widget tab");
		com.sleepThread(2000);
		com.click("xpath", "//*[contains(text(),'Chart')]", ",Chart,Click on Chart widget");
		com.sleepThread(2000);
	}

	
/*	  @And("^Veirfy the Set as Principal Region$") 
	  public void  Veirfy_the_Set_as_Principal_Region() { 
	 String =
	  Common.readPropertyByChart().getProperty("");
	  com.verifyElementEnabled("xpath", , "ICTC-000,"+Widget_name+","); }
	  
	  @And("^Click on Set as Principal Region$") public void
	  Click_on_Set_as_Principal_Region() { String =
	  Common.readPropertyByChart().getProperty("");
	  com.verifyElementEnabled("xpath", , "ICTC-000,"+Widget_name+","); }*/
	 
	@When("^verify the hart lo header selected$")
	public void verify_the_hart_lo_header_selected() throws Exception {
		com.sleepThread(5000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String hart_lo_header_selected = Common.readPropertyByChart().getProperty("hart_lo_header_selected");
		com.MouseOverToElement("xpath", hart_lo_header_selected,
				"ICTC-00185," + Widget_name + ",Verify the hart lo header selected");
	}

	@Then("^Click on hart lo header selected it will showing plot options or not$")
	public void Click_on_hart_lo_header_selected_it_will_showing_plot_options_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String hart_lo_header_selected = Common.readPropertyByChart().getProperty("hart_lo_header_selected");
		com.MouseOverToclickabl("xpath", hart_lo_header_selected,
				"ICTC-00186," + Widget_name + ",Click on hart lo header selected it will showing plot options or not");
		String Plot_option = Common.readPropertyByChart().getProperty("Plot_option");
		com.MouseOverToclickabl("xpath", Plot_option, ",Chart,showing plot options or not");
		com.sleepThread(2000);
	}

	@And("^Select the each Plot Preferences option$")
	public void Select_the_each_Plot_Preferences_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li/button/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00187,Chart,Select the each Plot Preferences option");
			String Plot_option = Common.readPropertyByChart().getProperty("Plot_option");
			com.MouseOverToclickabl("xpath", Plot_option, ",Chart,showing plot options or not");
			com.sleepThread(2000);

		}
	}

	@When("^Right click on title-toolbar options$")
	public void Right_click_on_title_toolbar_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
		com.Rightclick("xpath", title_toolbar, "ICTC-00188," + Widget_name + ",Right click on title-toolbar options");

	}

	@Then("^verify the View option$")
	public void verify_the_View_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		String Rightclick_view_option = Common.readPropertyByChart().getProperty("Rightclick_view_option");
		com.verifyElementPresent("xpath", Rightclick_view_option,
				"ICTC-00189," + Widget_name + ",verify the View option");

	}

	@And("^Click on submenus in view option$")
	public void Click_on_submenus_in_view_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String Rightclick_view_option = Common.readPropertyByChart().getProperty("Rightclick_view_option");
		com.MouseOverToElement("xpath", Rightclick_view_option, ",Chart,mouse over on view option");
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[" + i + "]",
					"ICTC-00190," + Widget_name + ",Click on submenus in view option");
			com.sleepThread(2000);
			com.startAction();
			String second_widget = Common.readPropertyByChart().getProperty("second_widget");
			com.Rightclick("xpath", second_widget, ",Chart,Right click on open the new widget name");
			com.sleepThread(1000);
			String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
			com.click("xpath", Close_Tab, ",Chart,Click on Close Tab and verify the tab is closeing or not");
			com.sleepThread(5000);
			String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
			com.Rightclick("xpath", title_toolbar,
					"ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
			com.MouseOverToElement("xpath", Rightclick_view_option, ",Chart,mouse over on view option");
		}
	}

	@And("^Verify the Add to Symbol List option$")
	public void Verify_the_Add_to_Symbol_List_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
		com.Rightclick("xpath", title_toolbar, "ICTC-00191," + Widget_name + ",Right click on title-toolbar options");
		com.sleepThread(2000);
		String Add_to_Symbol_List = Common.readPropertyByChart().getProperty("Add_to_Symbol_List");
		com.verifyElementEnabled("xpath", Add_to_Symbol_List,
				"ICTC-00192," + Widget_name + ",Verify the Add to Symbol List option");
	}

	@And("^Click on Add to Symbol List option$")
	public void Click_on_Add_to_Symbol_List_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Add_to_Symbol_List = Common.readPropertyByChart().getProperty("Add_to_Symbol_List");
		com.click("xpath", Add_to_Symbol_List, "ICTC-00193," + Widget_name + ",Click on Add to Symbol List option");
	}

	@And("^Verify the Data View option$")
	public void Verify_the_Data_View_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
		com.Rightclick("xpath", title_toolbar, ",Chart,Right click on title-toolbar options");
		com.sleepThread(2000);
		String Data_view = Common.readPropertyByChart().getProperty("Data_view");
		com.verifyElementEnabled("xpath", Data_view, "ICTC-00194," + Widget_name + ",Verify the Data View option");
	}

	@And("^Click on Data view option$")
	public void Click_on_Data_view_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Data_view = Common.readPropertyByChart().getProperty("Data_view");
		com.click("xpath", Data_view, "ICTC-00195," + Widget_name + ",Click on Data view option");
		com.sleepThread(2000);
		com.startAction();
		String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
		com.Rightclick("xpath", title_toolbar, ",Chart,Right click on title-toolbar options");
		com.sleepThread(2000);
		com.click("xpath", Data_view, ",Chart,Click on Data view option");
		com.sleepThread(5000);
		String Date_pop = Common.readPropertyByChart().getProperty("Date_pop");
		com.verifyElementPresent("xpath", Date_pop, ",Chart,Date view pop showing or not");
	}

	@And("^All sessions is disabled option or not$")
	public void All_sessions_is_disabled_option_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
		com.Rightclick("xpath", title_toolbar, "ICTC-00196," + Widget_name + ",Right click on title-toolbar options");
		com.sleepThread(2000);
		String All_Sessions = Common.readPropertyByChart().getProperty("All_Sessions");
		com.verifyElementPresent("xpath", All_Sessions, ",Chart,All sessions is disabled option or not");
	}

	@And("^Gapless Intraday charts option is disabled or not$")
	public void Gapless_Intraday_charts_option_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Gapless_Intraday = Common.readPropertyByChart().getProperty("Gapless_Intraday");
		com.verifyElementPresent("xpath", Gapless_Intraday,
				"ICTC-00197," + Widget_name + ",Gapless Intraday charts option is disabled or not");
	}

	@And("^Verify the price Scale option$")
	public void Verify_the_price_Scale_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String price_Scale_option = Common.readPropertyByChart().getProperty("price_Scale_option");
		com.verifyElementPresent("xpath", price_Scale_option,
				"ICTC-00198," + Widget_name + ",Verify the price Scale option");
	}

	@And("^Verify the Subnemus options is disabled or not in price Scale option$")
	public void Verify_the_Subnemus_options_is_disabled_or_not_in_price_Scale_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String price_Scale_option = Common.readPropertyByChart().getProperty("price_Scale_option");
		com.MouseOverToElement("xpath", price_Scale_option, ",Chart,Mouseover on price scale option");
		int size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[8]/div/ul/li/button"))
				.size();
		for (int i = 1; i <= size; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[8]/div/ul/li[" + i + "]/button",
					"ICTC-00199," + Widget_name
							+ ",Verify the Subnemus options is disabled or not in price Scale option");
		}
	}

	@And("^Verify the Export Data option$")
	public void Verify_the_Export_Data_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Export_Data = Common.readPropertyByChart().getProperty("Export_Data");
		com.verifyElementPresent("xpath", Export_Data, "ICTC-00200," + Widget_name + ",Verify the Export Data option");
	}

	@And("^Click on submenus Export Data option$")
	public void Click_on_submenus_Export_Data_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Export_Data = Common.readPropertyByChart().getProperty("Export_Data");
		com.MouseOverToElement("xpath", Export_Data, ",Chart,Verify the Export Data option");
		int size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[10]/div/ul/li/button"))
				.size();
		for (int i = 1; i <= 2; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[10]/div/ul/li[" + i + "]/button",
					"ICTC-00201," + Widget_name + ",Click on submenus Export Data option");
			com.startAction();
			String title_toolbar = Common.readPropertyByChart().getProperty("title_toolbar");
			com.Rightclick("xpath", title_toolbar, ",Chart,Right click on title-toolbar options");
			com.sleepThread(2000);
			com.MouseOverToElement("xpath", Export_Data, ",Chart,Verify the Export Data option");
		}
	}

	@And("^Verify the Print option is disabled or not$")
	public void Verify_the_Print_option_is_disabled_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Print = Common.readPropertyByChart().getProperty("Print");
		com.verifyElementPresent("xpath", Print,
				"ICTC-00202," + Widget_name + ",Verify the Print option is disabled or not");
	}

	@And("^Verify the Defaults options$")
	public void Verify_the_Defaults_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		com.sleepThread(1000);
		String Defaults_option = Common.readPropertyByChart().getProperty("Defaults_option");
		com.MouseOverToElement("xpath", Defaults_option, "ICTC-00203," + Widget_name + ",Verify the Defaults options");
	}

	@And("^Verify the submenus in Defaults options$")
	public void Verify_the_submenus_in_Defaults_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();

		String Defaults_option = Common.readPropertyByChart().getProperty("Defaults_option");
		com.MouseOverToElement("xpath", Defaults_option,
				"ICTC-00204," + Widget_name + ",Verify the submenus in Defaults options");

		int size = driver
				.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/div/ul/li/button"))
				.size();
		for (int i = 1; i <= size; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/div/ul/li[" + i + "]/button",
					"," + Widget_name + ",Verify the submenus in Defaults options");
		}
	}

	@And("^Click on cross icon in compare pop$")
	public void Click_on_cross_icon_in_compare_pop() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Compare_pop_title = Common.readPropertyByChart().getProperty("Compare_pop_title");
		com.click("xpath", Compare_pop_title,"ICTC-00159," + Widget_name + ",Click on title in Compare pop");		
		String cross_icon_Compare_pop = Common.readPropertyByChart().getProperty("cross_icon_Compare_pop");
		com.click("xpath", cross_icon_Compare_pop, "ICTC-00203," + Widget_name + ",Click on cross icon in compare pop");
		com.sleepThread(3000);
	}

	@Then("^Click on Right click Display Preferences in Chart more icon$")
	public void Click_on_Right_click_Display_Preferences_in_Chart_more_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Right_click_Display_Preferences = Common.readPropertyByChart()
				.getProperty("Right_click_Display_Preferences");
		com.click("xpath", Right_click_Display_Preferences,
				"ICTC-00084," + Widget_name + ",Click on Right click Display Preferences in Chart more icon");
	}

	@And("^Click on Right click each plot colors it will showing more colors or not$")
	public void Click_on_Right_click_each_plot_colors_it_will_showing_more_colors_or_not() throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr/td[2]/div/span/button"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
							+ "]/td[2]/div/span/button",
					"ICTC-00100,Chart,Click on Right click each plot colors it will showing more colors or not");
			com.sleepThread(2000);
			com.verifyElementPresent("xpath", "//*[contains(text(),'More colors...')]",
					",Chart,showing more colors or not");
			com.sleepThread(2000);
			com.click("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/table/tbody/tr[" + i
							+ "]/td[2]/div/span/button",
					",Chart,Click on Right click each plot colors it will closing more colors or not");
		}
	}

	@And("^Click on Right click each Redio buttons Chart Header in Display Preferences pop$")
	public void Click_on_Right_click_each_Redio_buttons_Chart_Header_in_Display_Preferences_pop() throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver
				.findElements(By.xpath(
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/div/label[" + i
							+ "]",
					"ICTC-00103," + Widget_name
							+ ",Click on Right click each Redio buttons Chart Header in Display Preferences pop");
		}
	}

	@And("^Click on each check box Chart Header in Right click Display Preferences pop$")
	public void Click_on_each_check_box_Chart_Header_in_Right_click_Display_Preferences_pop() throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver
				.findElements(By
						.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[1]/div/div/label[" + i + "]",
					"ICTC-00104," + Widget_name
							+ ",Click on each check box Chart Header in Right click Display Preferences pop");
		}
	}

	@And("^Select on each value in symbol value marker drop down in Right click Display Preferences pop$")
	public void Select_on_each_value_in_symbol_value_marker_drop_down_in_Right_click_Display_Preferences_pop()
			throws Exception {
		com.sleepThread(2000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String symbol_value_marker_drop_down = Common.readPropertyByChart()
				.getProperty("symbol_value_marker_drop_down_in_Right_click");
		com.select_the_Drop_Down_values("xpath", symbol_value_marker_drop_down,
				"ICTC-00107," + Widget_name + ",Select on each value in symbol value marker drop down");

	}

	@And("^select the each value symbol Marker Location drop down in Right click Display Preferences pop$")
	public void select_the_each_value_symbol_Marker_Location_drop_down_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String symbol_Marker_Location = Common.readPropertyByChart()
				.getProperty("symbol_Marker_Location_in_Right_click");
		com.select_the_Drop_Down_values("xpath", symbol_Marker_Location,
				"ICTC-00108," + Widget_name + ",select the each value symbol Marker Location drop down");

	}

	@And("^select the each value study value marker drop down in Right click Display Preferences pop$")
	public void select_the_each_value_study_value_marker_drop_down_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String study_value_marker_drop_down = Common.readPropertyByChart()
				.getProperty("study_value_marker_drop_down_in_Right_click");
		com.select_the_Drop_Down_values("xpath", study_value_marker_drop_down,
				"ICTC-00109," + Widget_name + ",select the each value study value marker drop down");

	}

	@And("^select the each value study Marker Location drop down in Right click Display Preferences pop$")
	public void select_the_each_value_study_Marker_Location_drop_down_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String study_Marker_Location_drop_down = Common.readPropertyByChart()
				.getProperty("study_Marker_Location_drop_down_in_Right_click");
		com.select_the_Drop_Down_values("xpath", study_Marker_Location_drop_down,
				"ICTC-00110," + Widget_name + ",select the each value study Marker Location drop down");

	}

	@Then("^Click on each color option it will showing more colors or not in Right click Display Preferences pop$")
	public void Click_on_each_color_option_it_will_showing_more_colors_or_not_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int R_size = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr/td[3]/div/span/button"))
				.size();
		int C_size = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr[1]/td/div/span/button"))
				.size();
		for (int j = 3; j < 2; j++) {
			for (int i = 1; i < R_size; i++) {
				com.click("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
								+ i + "]/td[" + j + "]/div/span/button",
						"ICTC-00111," + Widget_name + ",Click on each color option it will showing more colors or not");
				com.sleepThread(2000);
				com.verifyElementPresent("xpath", "//*[contains(text(),'More colors...')]",
						"showing more colors or not");
				com.sleepThread(2000);
				com.click("xpath",
						"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
								+ i + "]/td[" + j + "]/div/span/button",
						"ICTC-00112," + Widget_name + ",Click on each color option it will closing more colors or not");
			}
		}

	}

	@And("^Click on each check box in Markers and Flage option in Right click Display Preferences pop$")
	public void Click_on_each_check_box_in_Markers_and_Flage_option_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath(
				"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr/td[2]/label/input"))
				.size();
		for (int i = 1; i < size; i++) {
			com.verifyElementisSelected("xpath",
					"/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[2]/div/div/table/tbody/tr["
							+ i + "]/td[2]/label/input",
					"ICTC-00113," + Widget_name + ",Click on each check box in Markers and Flage option");
		}
	}

	@And("^Click on each check box in Grid Lines option in Right click Display Preferences pop$")
	public void Click_on_each_check_box_in_Grid_Lines_option_in_Right_click_Display_Preferences_pop() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		int size = driver.findElements(By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/label"))
				.size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/label[" + i + "]",
					"ICTC-00115," + Widget_name + ",Click on each check box in Grid Lines option");
		}
	}

	@And("^Click on Grid color option it will showing more colors or not in Right click Display Preferences pop$")
	public void Click_on_Grid_color_option_it_will_showing_more_colors_or_not_in_Right_click_Display_Preferences_pop()
			throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Grid_Color = Common.readPropertyByChart().getProperty("Grid_Color_in_Right_click");
		com.click("xpath", Grid_Color,
				"ICTC-00116," + Widget_name + ",Click on Grid color option it will showing more colors or not");
		com.sleepThread(2000);
		String Grid_more_color = Common.readPropertyByChart().getProperty("Grid_more_color");
		com.click("xpath", Grid_more_color, "ICTC-00117," + Widget_name + ",showing more colors or not");

	}

	@When("^Click on Chart Object Properties in icon$")
	public void Click_on_Chart_Object_Properties_in_icon() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		String hart_lo_header_selected = Common.readPropertyByChart().getProperty("hart_lo_header_selected");
		com.double_click_an_element("xpath", hart_lo_header_selected,
				"ICTC-00186," + Widget_name + ",Click on hart lo header selected it will showing plot options or not");

	}
	
	
}