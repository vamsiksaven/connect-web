package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {

	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;

	public Login() {
		driver = Common.driver;
		login = Common.readPropertyByLogin().getProperty("Login_button");
	}

	// Verify_the_ligin_page_Logo
	@Given("^I have open the browser$")
	public void open_browser() throws Exception {
		String Browser = Common.readPropertyByLogin().getProperty("Browser");
		// com.startRecording();
		com.Setup(Browser,"ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// https://ida-idp.qa.market-q.com/ida-idp/
		com.maximiseBrowser();

	}

	@When("^Verify the logo$")
	public void Verify_the_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByLogin().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Login,Verify the logo");

	}

	// @Verify_the_login_page
	@And("^Verify Username field$")
	public void Verify_username_field() throws Exception {
		String un = Common.readPropertyByLogin().getProperty("User_name");
		com.sleepThread(2000);
		com.verifyElementPresent("xpath", un, "ILTC-00003,Login,Verify Username field");

	}

	@And("^Verify password field$")
	public void Verify_password_field() throws Exception {
		String Pwd = Common.readPropertyByLogin().getProperty("Passwod");
		com.verifyElementPresent("xpath", Pwd, "ILTC-00004,Login,Verify password field");

	}

	@And("^Verify Remember me link$")
	public void Verify_Remember_me() throws Exception {
		com.sleepThread(3000);
		String Remember_me = Common.readPropertyByLogin().getProperty("Remember_me");
		com.verifyElementPresent("xpath", Remember_me, "ILTC-00005,Login,Verify Remember me link");

	}

	@And("^Verify Forgot Password link$")
	public void Verify_Forgot_Password() throws Exception {
		String Forgot_Password_link = Common.readPropertyByLogin().getProperty("Forgot_Password_link");
		com.verifyElementPresent("xpath", Forgot_Password_link, "ILTC-00006,Login,Verify Forgot Password link");

	}

	@And("^Verify Change link$")
	public void Verify_Change() throws Exception {
		String Change_Password = Common.readPropertyByLogin().getProperty("Change_Password");
		com.verifyElementPresent("xpath", Change_Password, "ILTC-00007,Login,Verify Change link");
	}

	@And("^Verify Terms & Conditions of Use link$")
	public void Verify_Terms() throws Exception {
		String Terms = Common.readPropertyByLogin().getProperty("Terms");
		com.verifyElementPresent("xpath", Terms, "ILTC-00008,Login,Verify Terms & Conditions of Use link");
	}

	@And("^Verify Privacy Policy$")
	public void Verify_Privacy_Policy() throws Exception {
		String Privacy_Policy = Common.readPropertyByLogin().getProperty("Privacy_Policy");
		com.verifyElementPresent("xpath", Privacy_Policy, "ILTC-00009,Login,Verify Privacy Policy");
	}

	@And("^Verify login button$")
	public void Verify_login_button() throws Exception {
		String Login_button = Common.readPropertyByLogin().getProperty("Login_button");
		com.verifyElementPresent("xpath", Login_button, "ILTC-00010,Login,Verify login button");
	}

	@When("^verify password link$")
	public void verify_password_link() throws Exception {
		String pwd_link = Common.readPropertyByLogin().getProperty("Password_Link");
		com.verifyElementPresent("xpath", pwd_link, "ILTC-00011,Login,verify password link");
	}

	@And("^click on password link$")
	public void click_on_password_link() throws Exception {
		String Forgot_Password_link = Common.readPropertyByLogin().getProperty("Forgot_Password_link");
		com.click("xpath", Forgot_Password_link, "ILTC-00012,Login,Click on password link");
	}

	@And("^verify next page is navegating or not$")
	public void verify_next_page() throws Exception {
		com.sleepThread(6000);
		String forgot_password_title = Common.readPropertyByLogin().getProperty("forgot_password_title");
		com.verifyElementPresent("xpath", forgot_password_title, "ILTC-00013,Login,verify next page is navegating or not");

	}

	@When("^verify text box$")
	public void verify_text_box() throws Exception {
		String text_box = Common.readPropertyByLogin().getProperty("f_p_Email_pwd_text_box");
		com.verifyElementPresent("xpath", text_box, "ILTC-00014,Login,verify text box");
	}

	@And("^verify submit$")
	public void verify_submit() throws Exception {
		String submit = Common.readPropertyByLogin().getProperty("f_p_send_mail");
		com.verifyElementPresent("xpath", submit, "ILTC-00015,Login,verify submit");
	}

	@And("^verify captcha$")
	public void verify_captcha() throws Exception {	
		com.sleepThread(3000);
		String captcha = Common.readPropertyByLogin().getProperty("f_p_Captcha");
		com.verifyElementPresent("xpath", captcha, "ILTC-00016,Login,verify captcha");
	}

	@When("^verify validation message$")
	public void verify_validation_message() throws Exception {
		com.sleepThread(3000);
		String v_messag = Common.readPropertyByLogin().getProperty("f_p_Email_Add_req_msg");
		com.verifyElementPresent("xpath", v_messag, "ILTC-00017,Login,verify validation message");
	}

	@And("^Click on submit$")
	public void Click_on_submit() throws Exception {
		String submit = Common.readPropertyByLogin().getProperty("f_p_send_mail");
		com.click("xpath", submit, "ILTC-00018,Login,Click on submit");
	}

	@When("^Click on back link$")
	public void cluick_on_back() throws Exception {
		com.sleepThread(5000);
		String back = Common.readPropertyByLogin().getProperty("forgot_pwd_back");
		com.click("xpath", back, "ILTC-00019,Login,Click on back link");
	}
	
	@When("^Click on change password link$")
	public void Click_on_change_password_link() throws Exception
	{
		String Change_Password = Common.readPropertyByLogin().getProperty("Change_Password");
		com.click("xpath", Change_Password, ",Login,Click on change password link");

	}
	@Then("^Verify the change password title$")
	public void Verify_the_change_password_title() throws Exception
	{
		String  change_password_title= Common.readPropertyByLogin().getProperty("change_password_title");
		com.verifyElementPresent("xpath",change_password_title, ",Login,Verify the change password title");

	}
	@And("^Verify the user id text box$")
	public void Verify_the_user_id_text_box() throws Exception
	{
		String  user_id_text_box_in_Change_Password= Common.readPropertyByLogin().getProperty("user_id_text_box_in_Change_Password");
		com.verifyElementPresent("xpath",user_id_text_box_in_Change_Password , ",Login,Verify the user id text box");

	}
	@And("^Verify the old password text box$")
	public void Verify_the_old_password_text_box() throws Exception {
		String  old_password_text_box= Common.readPropertyByLogin().getProperty("old_password_text_box");
		com.verifyElementPresent("xpath",old_password_text_box , ",Login,Verify the old password text box");

	}
	
	@And("^Verify the new password text box$")
	public void Verify_the_new_password_text_box() throws Exception {
		String  new_password_text_box= Common.readPropertyByLogin().getProperty("new_password_text_box");
		com.verifyElementPresent("xpath",new_password_text_box ,",Login,Verify the new password text box");

	}
	@And("^Verify the new password confirm text box$")
	public void Verify_the_new_password_confirm_text_box() throws Exception
	{
		String  new_password_confirm_text_box= Common.readPropertyByLogin().getProperty("new_password_confirm_text_box");
		com.verifyElementPresent("xpath",new_password_confirm_text_box, ",Login,Verify the new password confirm text box");

	}
	@And("^Verify the show password link$")
	public void Verify_the_show_password_link() throws Exception
	{
		String  show_password_link= Common.readPropertyByLogin().getProperty("show_password_link");
		com.verifyElementPresent("xpath",show_password_link, ",Login,Verify the show password link");

	}
	@And("^Verify the change password button$")
	public void Verify_the_change_password_button() throws Exception
	{
		String  change_password_button= Common.readPropertyByLogin().getProperty("change_password_button");
		com.verifyElementPresent("xpath",change_password_button ,",Login,Verify the change password button");

	}
	@And("^Verify the back button$")
	public void Verify_the_back_button() throws Exception
	{
		String  back_button_in_Change_Password= Common.readPropertyByLogin().getProperty("back_button_in_Change_Password");
		com.verifyElementPresent("xpath",back_button_in_Change_Password,",Login,Verify the back button");

	}
	@And("^Click on change password button$")
	public void Click_on_change_password_button() throws Exception
	{	com.startAction();
		String  change_password_button= Common.readPropertyByLogin().getProperty("change_password_button");
		com.MouseOverToclickabl("xpath",change_password_button,",Login,Click on change password button");

	}
	@And("^Verify the alert in change password page$")
	public void Verify_the_alert_in_change_password_page()
	{	
		com.sleepThread(2000);
		com.handling_alerts_accecpt();
	}
	@And("^Click on back button$")
	public void Click_on_back_button() throws Exception {
		String  back_button_in_Change_Password= Common.readPropertyByLogin().getProperty("back_button_in_Change_Password");
		com.click("xpath",back_button_in_Change_Password,",Login,Click on back button");

	}
	
	@And("^click on Remember me link$")
	public void click_on_Remember_me_link() throws Exception {
		String Rem_link = Common.readPropertyByLogin().getProperty("Remember_me");
		com.click("xpath", Rem_link, "ILTC-00020,Login,click on Remember me link");
	}

	@When("^username and password are saving or not$")
	public void username_and_password_are_saving_or_not() throws Exception {
		com.verify_text_box_text("xpath", un, "vamsi.kamatam@theice.com",
				"ILTC-00021,Login,username are saving or not");
		com.verify_text_box_text("xpath", Pws, "Starts123", "ILTC-00022,Login,password are saving or not");
	}

	// correct_username_and_correct_password
	@SuppressWarnings("deprecation")
	@Given("^Login with IDE IDP credentials Username \"(.*?)\" and Password \"(.*?)\"$")
	public void Login_with_IDE_IDP_credentials_Username_and_Password(String Username, String Password)
			throws Exception {
		un = Common.readPropertyByLogin().getProperty("User_name");
		Pws = Common.readPropertyByLogin().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(4000);
		com.click("xpath",un,",Login,Click on user name");
		com.sleepThread(4000);
		com.sendKeys("xpath",un, Username,
				"ILTC-00023,Login,Enter the correct username and are given in associated text fields");
		com.sleepThread(1000);
		com.click("xpath", un,",Login,Click on user name");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Login,Enter the correct password are given in associated text fields");
	}

	@Then("^Click on login button$")
	public void login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Login,Click on login button");
		TimeUnit.MINUTES.sleep(3);
		// com.stopRecording();
		String launch_menu=Common.readPropertyByLogin().getProperty("launch_menu");
		com.verifyElementPresent("xpath",launch_menu, ",Login,Verify the launch_menu bar");	

	}

	@And("^Close the Browser$")
	public void Close_the_Browser() throws Exception {
		com.closeBrowser("ILTC-00026,Login,Close the Browser");
	}

	@And("^Quit the Object$")
	public void Quit_the_Object(ITestResult result) throws Exception {
		com.QuitObject("ILTC-00027,Login,Quit the Object");
	}

}
