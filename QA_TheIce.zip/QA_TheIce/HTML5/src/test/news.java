package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class V_options {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public V_options Opt;
	public V_options() {
		driver = Common.driver;
	}
	
	@Given("^Clicked on News widget$")
	//News
	public void Clicked_on_options_widget() throws Exception
	{
		//Clicking on + icon to add new widget
        String Add_Widget=Common.V_readPropertyByoptions().getProperty("Add_Widget");
        com.click("xpath",Add_Widget,"clicked on + icon");
        Thread.sleep(2000);
        //Clicking on News Widget
        String News=Common.V_readPropertyByoptions().getProperty("News");
        com.click("xpath",News,"clicked on news widget");
        Thread.sleep(2000);
        String Selected_Category=Common.V_readPropertyByoptions().getProperty("Selected_Category");
        if(Selected_Category!= null)
        {
        	System.out.println("Clicked on options widget");
        }
        else
        {
        	System.out.println("Did not Clicked on options widget");
        }
        
	}
	
	