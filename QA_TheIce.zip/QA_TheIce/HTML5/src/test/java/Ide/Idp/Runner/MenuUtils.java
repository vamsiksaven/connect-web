/*package Ide.Idp.Runner;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class MenuUtils {
	
	public static class TestRunner {
		static List list; 
		static WebDriver driver;
		
		public static void main(String[] args) throws Exception {
    	   
    	   File file = new File("E:\\Test Results\\Squish Results\\testdata.xlsx");
		   FileInputStream fis=new FileInputStream(file);		   
		   XSSFWorkbook workbook = new XSSFWorkbook(fis);
		   XSSFSheet sheet2= workbook.getSheetAt(0);
		
		//loginpage log=new loginpage();
		System.setProperty("webdriver.chromedriver", "C:\\Users\\srinivas\\Desktop\\selenium\\browser drivers\\chromedriver.exe");
		//System.setProperty("webdriver.firefox.marionette", "C:\\Users\\Srinivas\\robot framework\\geckodriver.exe");
		driver = (WebDriver) new ChromeDriver();  
		//WebDriver driver = new FirefoxDriver();
        
        //com.startBrowser();
        //com.sendKeys("username", , content);
        //driver.obj.getProperty("https://connect-web.staging.dataservices.theice.com/");
		
		 //Using properties file
		 
		 Properties obj = new Properties();
		 FileInputStream objfile = new FileInputStream(System.getProperty("user.dir") + "\\src\\properties\\xpath.properties");
		 obj.load(objfile);
		
		 //driver.get("https://connect-web.staging.dataservices.theice.com/");
		driver.get(obj.getProperty("URL"));
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("username"))).click();
        Thread.sleep(2000);
       
        driver.findElement(By.xpath(obj.getProperty("username"))).sendKeys("BMO2_FADYMONTREAL@theice.com");
        Thread.sleep(2000);
        driver.findElement(By.xpath(obj.getProperty("password"))).click();
        System.out.println("username and password entered successfully");
        sheet2.getRow(1).createCell(1).setCellValue("username and password entered successfully");
        sheet2.getRow(1).createCell(2).setCellValue("Pass");        
        Thread.sleep(2000);
        driver.findElement(By.xpath(obj.getProperty("password"))).sendKeys("Starts123");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);        
        driver.findElement(By.xpath(obj.getProperty("Submit"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
       
       
        
        //For 2FA
        Scanner scanner_user = new Scanner(System.in);
        System.out.println("Enter your 2FApasscode:");
        String user = scanner_user.nextLine();
        driver.findElement(By.xpath("//*[@id='loginHolder']/div[2]/div[2]/input")).sendKeys(user);
        Thread.sleep(1000);
        //driver.findElement(By.xpath("//*[@id='formLogin']/input")).click();
        //scanner_user.close();
        
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        
        if(driver.findElement(By.xpath("//span[@class='ice-icon ice-icon-tag css-3mzlur e5j0fb80']")) != null){
        	System.out.println("logged in successfully");
        	 sheet2.getRow(2).createCell(1).setCellValue("logged in successfully");
		     sheet2.getRow(2).createCell(2).setCellValue("Pass");
        	}else{
        	System.out.println("login failed");
        	sheet2.getRow(2).createCell(1).setCellValue("logged in not successfully");
		    sheet2.getRow(2).createCell(2).setCellValue("Fail");
        	}

        Thread.sleep(30);

//Menu options
        
        //File
        if(driver.findElement(By.xpath("//button[contains(text(),'File')]")) !=null){
        driver.findElement(By.xpath("//button[contains(text(),'File')]")).click();
        System.out.println("File menu option is exist");
        sheet2.getRow(3).createCell(1).setCellValue("File Menu option is exist");
	    sheet2.getRow(3).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("File menu option is not existed");
        	sheet2.getRow(3).createCell(1).setCellValue("File Menu option is not existed");
    	    sheet2.getRow(3).createCell(2).setCellValue("Fail");
        }
        
        //driver.findElement(By.xpath("//button[contains(text(),'File')]")).click();
        
        Thread.sleep(100);
        
        //Handling POP up window..
        String winHandleBefore = driver.getWindowHandle(); 
        // get all the window handles before the popup window appears
        Set beforePopup = driver.getWindowHandles();

       // click the link which creates the popup window
        driver.findElement(By.xpath("//button[contains(text(),'Open new console window...')]")).click();

       // get all the window handles after the popup window appears
       Set<?> afterPopup = driver.getWindowHandles();

       // remove all the handles from before the popup window appears
       afterPopup.removeAll(beforePopup);

       // there should be only one window handle left
       if(afterPopup.size() == 1) {
                 driver.switchTo().window((String)afterPopup.toArray()[0]);
        }
        driver.close();
        Thread.sleep(100);
        driver.switchTo().window(winHandleBefore);
        
        //Preferences
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        if(driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")) !=null){
        	//driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        	System.out.println("Preferences menu option existed");
        	sheet2.getRow(4).createCell(1).setCellValue("Preferences menu option exist");
    	    sheet2.getRow(4).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Preferences menu option is not existed");
        	sheet2.getRow(4).createCell(1).setCellValue("Preferences menu option is not exist");
    	    sheet2.getRow(4).createCell(2).setCellValue("Fail");	
        	}
        
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        if(driver.findElement(By.xpath("//button[contains(text(),'Manage Keyboard Shortcuts')]")) !=null){
        	//driver.findElement(By.xpath("//button[contains(text(),'Manage Keyboard Shortcuts')]")).click();
        	System.out.println("Manage  Keyboard Shortcut option available");
        	sheet2.getRow(5).createCell(1).setCellValue("Manage Keyboard Shortcut option available");
    	    sheet2.getRow(5).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Manage  Keyboard Shortcut option is not available");
        	sheet2.getRow(5).createCell(1).setCellValue("manage Keyboard shortcut option is not available");
    	    sheet2.getRow(5).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//button[contains(text(),'Manage Keyboard Shortcuts')]")).click();
        driver.findElement(By.xpath("//button[@title='Close']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        if(driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")) !=null){
        	System.out.println("Tab Sorting option is available");
        	sheet2.getRow(6).createCell(1).setCellValue("Tab sorting option is available");
    	    sheet2.getRow(6).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Tab Sorting option is not avilable");
        	sheet2.getRow(6).createCell(1).setCellValue("Tab Sorting option is not available");
    	    sheet2.getRow(6).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//div[@class='css-11zhy3w']//label[1]")) !=null){
        	System.out.println("Alphabetical radio bution present");
        	sheet2.getRow(7).createCell(1).setCellValue("Alphabetical radio button is present");
    	    sheet2.getRow(7).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Alphabetical radio button is not present");
        	sheet2.getRow(7).createCell(1).setCellValue("Tab Sorting option is not available");
    	    sheet2.getRow(7).createCell(2).setCellValue("Pass");
        }
        driver.findElement(By.xpath("//div[@class='css-11zhy3w']//label[1]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        if(driver.findElement(By.xpath("//label[contains(text(),'Reverse Alphabetical')]")) !=null) {
        	System.out.println("Reverse Alphabetical radio button is present");
        	sheet2.getRow(8).createCell(1).setCellValue("Reverse Alphabetical radio button is present");
    	    sheet2.getRow(8).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Reverse Alphabetical radio button is not present");
        	sheet2.getRow(8).createCell(1).setCellValue("Reverse Alphabetical radio button is not present");
    	    sheet2.getRow(8).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Reverse Alphabetical')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        if(driver.findElement(By.xpath("//label[contains(text(),'Manual')]")) !=null){
        	System.out.println("Manual radio button is present");
        	sheet2.getRow(9).createCell(1).setCellValue("Manual radio button is present");
    	    sheet2.getRow(9).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Manual radio button is not present");
        	sheet2.getRow(9).createCell(1).setCellValue("Manual radio button is not present");
    	    sheet2.getRow(9).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Manual')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//label[@class='ice-checkbox css-r4d1rt ejl8a250']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//button[@title='Close']")).click();
        System.out.println("Close button is enable and present");
        sheet2.getRow(10).createCell(1).setCellValue("Close button is enable and present");
	    sheet2.getRow(10).createCell(2).setCellValue("Pass");
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();
        System.out.println("Cancel button is enable and present");
        sheet2.getRow(11).createCell(1).setCellValue("Cancel button is enable and present");
	    sheet2.getRow(11).createCell(2).setCellValue("Pass");
        Thread.sleep(10);
        
        //Theme
        
//        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
//        driver.findElement(By.cssSelector("#container > div > div > div > div > div.css-n4hwqd > div > ul > li:nth-child(3) > button")).click();
//        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[2]/button")).click();
//        Thread.sleep(10);
//        //driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
//        //driver.findElement(By.xpath("//body/div[@id='container']/div/div[@class='ice-theme-provider light-theme css-jtnhee e9snama0']/div[@class='console-container']/div[@class='css-7gpoef']/div[@class='css-n4hwqd']/div[@class='css-135kypt']/ul[@class='ice-menu css-b2notx evgjxy0']/li[3]/button[1]")).click();
//        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[1]/button")).click();
//        Thread.sleep(10);  
        System.out.println("Checked preferences");
        sheet2.getRow(12).createCell(1).setCellValue("Checked preferences");
	    sheet2.getRow(12).createCell(2).setCellValue("Pass");
        
//Connect Utils  
        
        //Formatting
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //driver.findElement(By.xpath("//div[@class='d-hbox d-justify-space-between d-wrap']")).click();
        
        //driver.findElement(By.xpath("//*[@id='0']/div[2]//div[1]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")) !=null){
        	System.out.println("Connect Utils menu is present");
        	sheet2.getRow(13).createCell(1).setCellValue("Connect Utils menu is present");
    	    sheet2.getRow(13).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Connect Utils menu option is not present");
        	sheet2.getRow(13).createCell(1).setCellValue("Connect Utils menu is not present");
    	    sheet2.getRow(13).createCell(2).setCellValue("Fail");
        }
        //driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")) !=null) {
        	System.out.println("Formatting sub heading is present");
        	sheet2.getRow(14).createCell(1).setCellValue("Formatting sub heading is present");
    	    sheet2.getRow(14).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Formatting sub heading is not present");
        	sheet2.getRow(14).createCell(1).setCellValue("Formatting sub heading is not present");
    	    sheet2.getRow(14).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[contains(text(),'Classic')]")) !=null) {
        	System.out.println("Classic radio button is present");
        	sheet2.getRow(15).createCell(1).setCellValue("Classic radio button is present");
    	    sheet2.getRow(15).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Classic radio button is not present");
        	sheet2.getRow(15).createCell(1).setCellValue("Classic radio button is not present");
    	    sheet2.getRow(15).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Classic')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[@class='pt-control pt-radio'][contains(text(),'Decimal')]")) !=null) {
        	System.out.println("Decimal radio button is present");
        	sheet2.getRow(16).createCell(1).setCellValue("Decimal radio button is present");
    	    sheet2.getRow(16).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Descimal radio button is not present");
        	sheet2.getRow(16).createCell(1).setCellValue("Decimal radio button is not present");
    	    sheet2.getRow(16).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[@class='pt-control pt-radio'][contains(text(),'Decimal')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[contains(text(),'Show Full Precision on Trade Data')]")) !=null) {
        	System.out.println("Show Full Precision on trade Data check box is present");
        	sheet2.getRow(17).createCell(1).setCellValue("Show Full Precision on trade Data check box is present");
    	    sheet2.getRow(17).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Show Full Precision on trade Data check box is not present");
        	sheet2.getRow(17).createCell(1).setCellValue("Show Full Precision on trade Data check box is not present");
    	    sheet2.getRow(17).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Show Full Precision on Trade Data')]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);        
        
        driver.findElement(By.xpath("/html/body/div//fieldset[3]/label[1]/div")).click();
        Thread.sleep(10);        
        driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/span[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/fieldset[3]/label[1]/div[1]/select["+1+"]")).click();
        Thread.sleep(10);        
                
        driver.findElement(By.xpath("//label[contains(text(),'Use brackets on Negative Values (Decimal and Dolla')]")).click();
        Thread.sleep(10);
       //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Decimal and Dollar format drop down down is present");
        sheet2.getRow(18).createCell(1).setCellValue("Decimal and Dollar format drop down down is present");
	    sheet2.getRow(18).createCell(2).setCellValue("Pass");
        System.out.println("Use brackets on Negative Values check box is present"); 
        sheet2.getRow(19).createCell(1).setCellValue("Use brackets on Negative Values check box is present");
	    sheet2.getRow(19).createCell(2).setCellValue("Pass");
        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);        
        driver.findElement(By.xpath("/html/body/div//fieldset[4]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[4]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Checked Formatting"); 
        sheet2.getRow(20).createCell(1).setCellValue("Checked Formatting");
	    sheet2.getRow(20).createCell(2).setCellValue("Pass");
        
        
        //Timezone
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")) !=null) {
        	System.out.println("Time zone sub heading is present");
        	sheet2.getRow(21).createCell(1).setCellValue("Time zone sub heading is present");
    	    sheet2.getRow(21).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Time zone sub heading is not present");
        	sheet2.getRow(21).createCell(1).setCellValue("Time zone sub heading is not present");
    	    sheet2.getRow(21).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[contains(text(),'Display in Local')]")) !=null) {
        	System.out.println("Display in local radio button is present");
        	sheet2.getRow(22).createCell(1).setCellValue("Display in local radio button is present");
    	    sheet2.getRow(22).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Display in local radio button is not present");
        	sheet2.getRow(22).createCell(1).setCellValue("Display in local radio button is not present");
    	    sheet2.getRow(22).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Display in Local')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[contains(text(),'Display in Exchange')]")) !=null) {
        	System.out.println("Display in Exchange radio button is present");
        	sheet2.getRow(23).createCell(1).setCellValue("Display in Exchange radio button is present");
    	    sheet2.getRow(23).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Display in Exchange radio button is not present");
        	sheet2.getRow(23).createCell(1).setCellValue("Display in Exchange radio button is not present");
    	    sheet2.getRow(23).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Display in Exchange')]")).click();
        Thread.sleep(10);
        if(driver.findElement(By.xpath("//label[contains(text(),'Display in GMT')]")) !=null) {
        	System.out.println("Display in GMT radio button is present");
        	sheet2.getRow(24).createCell(1).setCellValue("Display in GMT radio button is present");
    	    sheet2.getRow(24).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Display in GMT radio button is not present");
        	sheet2.getRow(24).createCell(1).setCellValue("Display in GMT radio button is not present");
    	    sheet2.getRow(24).createCell(2).setCellValue("Fail");
        }
        driver.findElement(By.xpath("//label[contains(text(),'Display in GMT')]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        for(int i=1;i<=27;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);                
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
       // driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Timezone Offset drop down is present"); 
        sheet2.getRow(25).createCell(1).setCellValue("Timezone Offset drop down is present");
	    sheet2.getRow(25).createCell(2).setCellValue("Pass");
        for(int i=1;i<=16;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);                 
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[1]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[1]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Date format drop down is present");
        sheet2.getRow(26).createCell(1).setCellValue("Date format drop down is present");
	    sheet2.getRow(26).createCell(2).setCellValue("Pass");
	    
        for(int i=1;i<=4;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);                  
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[2]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[2]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Override market clock time format (time format nee')]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Time format drop down is present");
        sheet2.getRow(27).createCell(1).setCellValue("Date format drop down is present");
	    sheet2.getRow(27).createCell(2).setCellValue("Pass");
        System.out.println("Checked Timezone"); 
        sheet2.getRow(28).createCell(1).setCellValue("Date format drop down is present");
	    sheet2.getRow(28).createCell(2).setCellValue("Pass");
        
        //Appearance.    
        
        
        // For ICE Dark Theme validation
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);        	
        driver.findElement(By.xpath("/html/body/div//label[1]/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/label[1]/div/select/option[2]")).click();        
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        driver.findElement(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[3]/div/div/button[1]")).click();
        if(driver.findElements(By.xpath("//div[@class='ice-theme-provider dark-theme css-1w8uist e9snama0']")) !=null){
        	System.out.println("Theme ICE Dark is selected");
        	sheet2.getRow(29).createCell(1).setCellValue("Theme ICE Dark is selected");
    	    sheet2.getRow(29).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Theme ICE Dark is not selected"); 
        	sheet2.getRow(29).createCell(1).setCellValue("Theme ICE Dark is not selected");
    	    sheet2.getRow(29).createCell(2).setCellValue("Fail");
        	  }
        
        //For ICE Light theme validation
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);        	
        driver.findElement(By.xpath("/html/body/div//label[1]/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[2]/div/div[2]/div/label[1]/div/select/option[1]")).click();        
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        driver.findElement(By.xpath("/html/body/div[2]/div/span/div[2]/div/div[3]/div/div/button[1]")).click(); 
        if(driver.findElements(By.xpath("//div[@class='ice-theme-provider light-theme css-jtnhee e9snama0']")) !=null){
        	System.out.println("Theme ICE Light is selected");
        	sheet2.getRow(30).createCell(1).setCellValue("Theme ICE Light is selected");
    	    sheet2.getRow(30).createCell(2).setCellValue("Pass");
        }else {
        	System.out.println("Theme ICE Light is not selected"); 
        	sheet2.getRow(30).createCell(1).setCellValue("Theme ICE Light is selected");
    	    sheet2.getRow(30).createCell(2).setCellValue("Fail");
        	  }
        
        //up color
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div[1]/span/button")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Green']")).click();
        Thread.sleep(10);
        System.out.println("Green color is selected from Up drop down");
        sheet2.getRow(31).createCell(1).setCellValue("Green color is selected from Up drop down");
	    sheet2.getRow(31).createCell(2).setCellValue("pass");
	    Thread.sleep(10);
        driver.findElement(By.xpath("//a[contains(text(),'More colors...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Magenta 4']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//legend[contains(text(),'Market Indicators')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        //Down color
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div[2]/span/button")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Black']")).click();
        Thread.sleep(10);
        System.out.println("Blak color is selected from Down drop down");
        sheet2.getRow(32).createCell(1).setCellValue("Black color is selected from Down drop down");
	    sheet2.getRow(32).createCell(2).setCellValue("pass");
	    driver.findElement(By.xpath("//legend[contains(text(),'Market Indicators')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        System.out.println("Checked Appearance"); 
        sheet2.getRow(33).createCell(1).setCellValue("Checked Appearance");
	    sheet2.getRow(33).createCell(2).setCellValue("pass");
        
      //Symbol Extensions

        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Symbol Extensions')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//label/div/select")).click();      
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Inserted/Pasted Symbols')]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Verified all the option in symbol extenstions drop dwon and all the options are pesent");         
        sheet2.getRow(34).createCell(1).setCellValue("Verified all the option in symbol extenstions drop dwon and all the options are pesent");
	    sheet2.getRow(34).createCell(2).setCellValue("pass");
	    Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Symbol Extensions')]")).click();
        Thread.sleep(10);        
        driver.findElement(By.xpath("/html/body/div//label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//option[@value='Canada']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Delete')]")).isEnabled();
        Thread.sleep(10);
        System.out.println("Delete button is enable and clickble");
        sheet2.getRow(35).createCell(1).setCellValue("Delete button is enable and clickble");
	    sheet2.getRow(35).createCell(2).setCellValue("pass");
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Move Down')]")).isEnabled();
        Thread.sleep(10);
        System.out.println("Move Down button is enabled and clickable");
        sheet2.getRow(36).createCell(1).setCellValue("Move Down button is enabled and clickable");
	    sheet2.getRow(36).createCell(2).setCellValue("pass");
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[contains(text(),'[-TC] Toronto Stock Exchange')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//input[@value='-TC']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//input[@value='-TC']")).sendKeys("-TCI");
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Add')]")).isEnabled();
        Thread.sleep(10);
        System.out.println("Add button is enabled and clickable");
        sheet2.getRow(37).createCell(1).setCellValue("Add button is enabled and clickable");
	    sheet2.getRow(37).createCell(2).setCellValue("pass");
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Change')]")).isEnabled();
        Thread.sleep(10);
        System.out.println("Change button is enabled and clickable");
        sheet2.getRow(38).createCell(1).setCellValue("Change button is enabled and clickable");
	    sheet2.getRow(38).createCell(2).setCellValue("pass");
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[contains(text(),'[-VC] TSX Venture Exchange')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Move Up')]")).isEnabled();
        Thread.sleep(10);
        System.out.println("Move Up is enabled and clickable");
        sheet2.getRow(39).createCell(1).setCellValue("Change button is enabled and clickable");
	    sheet2.getRow(39).createCell(2).setCellValue("pass");
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        System.out.println("Verified Symbol Extensions options");
        sheet2.getRow(40).createCell(1).setCellValue("Verified Symbol Extensions options");
	    sheet2.getRow(40).createCell(2).setCellValue("pass");
        
        
        //Pre-market Settings.
        
        for(int i=1;i<=2;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Pre-Market Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div/label["+i+"]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
         }
        System.out.println("Checked Pre-widget settings"); 
        sheet2.getRow(41).createCell(1).setCellValue("Checked Pre-widget settings");
	    sheet2.getRow(41).createCell(2).setCellValue("pass");
        
        //General widget settings
        
        driver.findElement(By.xpath("//button[@title='Open Chart']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //Chart
        
        for(int i=1;i<=3;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'General Widget Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label["+i+"]")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
         }      	
      		
        System.out.println("General Widget Settings checked");
        sheet2.getRow(42).createCell(1).setCellValue("General Widget Settings checked");
	    sheet2.getRow(42).createCell(2).setCellValue("pass");
	    //driver.quit();
	       driver.close();
	       // FileOutputStream fout =new FileOutputStream(new File("D:\\testdata-result.xlsx"));
	        FileOutputStream fout=new FileOutputStream(file);
	        workbook.write(fout);
	        workbook.close();
 }
}
}
		

		*/