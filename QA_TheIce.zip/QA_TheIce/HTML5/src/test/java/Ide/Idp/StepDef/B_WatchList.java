/*package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LIB.Common;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class B_WatchList {

	private static final String Widget_name = null;
	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public B_WatchList() {
		driver = Common.driver;
		login = Common.readPropertyByWatch_List().getProperty("Login_button");
	}

	// Verify_the_login_page_Logo
	@Given("^open the web browser$")
	public void open_the_web_browser() throws Throwable {
		com.Setup("Chrome", "ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// https://ida-idp.qa.market-q.com/ida-idp/
		com.maximiseBrowser();
	}

	@When("^Verify the ice portal logo$")
	public void verify_the_ice_portal_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByWatch_List().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Login,Verify the logo");
	}
    
	//Login
	@Given("^Login with the IDE IDP credentials of  ICE Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void login_with_the_IDE_IDP_credentials_of_ICE_Username_and_Password(String Username, String Password) throws Throwable {
		un = Common.readPropertyByWatch_List().getProperty("User_name");
		Pws = Common.readPropertyByWatch_List().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(1000);
		com.sendKeys("xpath", un, Username,
				"ILTC-00023,Login,Enter the correct username and are given in associated text fields");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Login,Enter the correct password are given in associated text fields");
	}

	@Then("^Click on the user login button$")
	public void click_on_the_user_login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Login,Click on login button");
		TimeUnit.MINUTES.sleep(1);
		// com.stopRecording();
	}
	
    //WatchList
	@Given("^Click on WatchList tab$")
	public void click_on_WatchList_tab() throws Exception {
		String WatchListtab = Common.readPropertyByWatch_List().getProperty("WatchListtab");
		com.sleepThread(3000);
		com.startAction();
		com.MouseOverToElement("xpath", WatchListtab, "ILTC-00026,Options,Mouse hover on WatchList tab");
		com.click("xpath", WatchListtab, "ILTC-00026,Options,Click on WatchList tab");
	}
	
	  //Column set
	   @Then("^Click on default column set$")
	   public void click_on_default_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			com.sleepThread(7000);
			com.startAction();
			com.MouseOverToElement("xpath", Columnsetdropdown, "ILTC-00029,Options,Mouse hover on column set dropdown");
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on column set dropdown");			
	   }

	   @Then("^select the column set for which you want to get desired results$")
	   public void select_the_column_set_for_which_you_want_to_get_desired_results() throws Throwable {
		    String Defaultdropdown = Common.readPropertyByWatch_List().getProperty("Defaultdropdown");
			com.sleepThread(3000);
			com.startAction();
			com.MouseOverToElement("xpath", Defaultdropdown, "ILTC-00030,Options,Mouse hover on Default column set");
			com.click("xpath", Defaultdropdown, "ILTC-00030,Options,Click on Default column set");
	   }

	   @Then("^Verify the columns whether they are from selected column set or not$")
	   public void verify_the_columns_whether_they_are_from_selected_column_set_or_not() throws Throwable {
		    String Time = Common.readPropertyByWatch_List().getProperty("Timecolumnset");
			String Last = Common.readPropertyByWatch_List().getProperty("Lastcolumnset");
			String Date = Common.readPropertyByWatch_List().getProperty("Datecolumnset");
			String Open = Common.readPropertyByWatch_List().getProperty("Opencolumnset");
			String High = Common.readPropertyByWatch_List().getProperty("Highcolumnset");
			String NetChange = Common.readPropertyByWatch_List().getProperty("Netchangecolumnset");
			String Percentagechange = Common.readPropertyByWatch_List().getProperty("Percentagechangecolumnset");
			com.sleepThread(5000);
			String Timetext = "Time";
			String Lasttext = "Last";
			String Datetext = "Date";
			String Opentext = "Open";
			String Hightext = "High";
			String netchangetext = "Net Change";
			String Percentagechangetext = "% Change";
			com.verifyText("xpath", Time, Timetext, "ILTC-00030,Options,Verify Time text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Last, Lasttext, "ILTC-00030,Options,Verify Last text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Date, Datetext, "ILTC-00030,Options,Verify Date text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Open, Opentext, "ILTC-00030,Options,Verify Open Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", High, Hightext, "ILTC-00030,Options,Verify High Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", NetChange, netchangetext, "ILTC-00030,Options,Verify Net Change text column of Selected Watch List");
			com.sleepThread(5000);
			com.verifyText("xpath", Percentagechange, Percentagechangetext, "ILTC-00030,Options,Verify % Change text column of Selected Watch List and Selected columns set is verified");
	   }
	   
	   //Duplicate column set
	   @Given("^Click on the default column set and select New$")
	   public void click_on_the_default_column_set_and_select_New() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			String Newdropdown = Common.readPropertyByWatch_List().getProperty("Newdropdown");
			com.sleepThread(6000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on Default column set");
			com.sleepThread(5000);
			//com.waitUntilElementPresent(NewColumnset);
			com.startAction();
			com.MouseOverToElement("xpath", Newdropdown, "ILTC-00030,Options,Click on New column set dropdown");
			com.click("xpath", Newdropdown, "ILTC-00030,Options,Click on New column set dropdown");
	   }

	   @Then("^Enter Name \"([^\"]*)\" of new column set$")
	   public void enter_Name_of_new_column_set(String Name) throws Throwable {
		    String Nameinput = Common.readPropertyByWatch_List().getProperty("Nameinput");
			com.sleepThread(3000);
			com.sendKeys("xpath", Nameinput, Name, "ITLC-31,Options,Enter the name for column set");
	   }

	   @Then("^Select the available columns and click right arrow$")
	   public void select_the_available_columns_and_click_right_arrow() throws Throwable {
		    String Optionsavailablecolumns = Common.readPropertyByWatch_List().getProperty("Optionsavailablecolumns");
			String OptionTypecolumn = Common.readPropertyByWatch_List().getProperty("Optiontype");
			String Strikecolumn = Common.readPropertyByWatch_List().getProperty("Strike");
			String rightarrow = Common.readPropertyByWatch_List().getProperty("rightarrow");
			com.sleepThread(5000);
			com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", Strikecolumn, "ITLC-35,Options,click on Strike in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");		
	   }

	   @Then("^click on save and again click on default dropdown$")
	   public void click_on_save_and_again_click_on_default_dropdown() throws Throwable {
		    String savecolumnset = Common.readPropertyByWatch_List().getProperty("Savecolumnset");
			String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			com.sleepThread(5000);
			com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on default column set");
	   }

	   @Then("^Click on New and enter the Same Name \"([^\"]*)\"$")
	   public void click_on_New_and_enter_the_Same_Name(String Name) throws Throwable {
		    String Newdropdown = Common.readPropertyByWatch_List().getProperty("Newdropdown");
			String Nameinput = Common.readPropertyByWatch_List().getProperty("Nameinput");
			com.sleepThread(5000);
			com.click("xpath", Newdropdown, "ILTC-00029,Options,Click on New column set");
			com.sendKeys("xpath", Nameinput, Name, "ITLC-35,Options,Verify entering symbol input");
	   }

	   @Then("^Add available columns by clicking on the right arrow$")
	   public void add_available_columns_by_clicking_on_the_right_arrow() throws Throwable {
		    String Optionsavailablecolumns = Common.readPropertyByWatch_List().getProperty("Optionsavailablecolumns");
			String OptionTypecolumn = Common.readPropertyByWatch_List().getProperty("Optiontype");
			String underlyingsymbol = Common.readPropertyByWatch_List().getProperty("underlyingsymbol");
			String rightarrow = Common.readPropertyByLogin().getProperty("rightarrow");
			com.sleepThread(3000);
			com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
			com.sleepThread(3000);
			com.click("xpath", underlyingsymbol, "ITLC-35,Options,click on underlyingsymbol in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
	   }

	   @Then("^click on the save and duplicate column set should not be added and click on cancel after verification$")
	   public void click_on_the_save_and_duplicate_column_set_should_not_be_added_and_click_on_cancel_after_verification() throws Throwable {
		    String Savecolumnset = Common.readPropertyByWatch_List().getProperty("Savecolumnset");
			String cancelcolumnset = Common.readPropertyByWatch_List().getProperty("cancelcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Savecolumnset, "ILTC-00029,Options,Click on Save column set and colum set not added");
			com.sleepThread(9000);
			com.click("xpath", cancelcolumnset, "ILTC-00029,Options,Click on cancel column set");
	   }
	   
	   //Editing column set
	   @Given("^Click on the columnset dropdown and then click on manage column set$")
	   public void click_on_the_columnset_dropdown_and_then_click_on_manage_column_set() throws Throwable {
		    String Columnsetdropdown = Common.readPropertyByWatch_List().getProperty("Columnsetdropdown");
			String Managecolumnset = Common.readPropertyByWatch_List().getProperty("Managecolumnsset");
			com.sleepThread(5000);
			com.click("xpath", Columnsetdropdown, "ILTC-00029,Options,Click on Columnset");
			com.sleepThread(4000);
			com.click("xpath", Managecolumnset, "ILTC-00029,Options,Click on Manage column set"); 
	   }

	   @Then("^Select the column set that needs to be edited and click on edit$")
	   public void select_the_column_set_that_needs_to_be_edited_and_click_on_edit() throws Throwable {
		    String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String Editcolumnset = Common.readPropertyByWatch_List().getProperty("Editcolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnset, "ILTC-00029,Options,Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", Editcolumnset, "ILTC-00029,Options,Click on Edit column set");
	   }

	   @Then("^clear Name field and enter the New Name \"([^\"]*)\"$")
	   public void clear_Name_field_and_enter_the_New_Name(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByWatch_List().getProperty("Editnameinput");
			com.sleepThread(5000);
			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,Options,Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,Options,Verify entering Name input");
	   }

	   @Then("^Click on Save and verify columnset name$")
	   public void click_on_Save_and_verify_columnset_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByWatch_List().getProperty("Editsavecolumnset");
			String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(customcolumnset);
			String text ="Testcolumnset1";
			com.verifyText("xpath", customcolumnset, text, "ITLC-00029,Options, Verify Edited column set name");
			//com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on cancel column set");
	   }

	   //Copy column set
	   @Given("^Select the column set that needs to be copied and Click on copy column set$")
	   public void select_the_column_set_that_needs_to_be_copied_and_Click_on_copy_column_set() throws Throwable {
		    String customcolumnset = Common.readPropertyByWatch_List().getProperty("customcolumnset");
			String copycolumnset = Common.readPropertyByWatch_List().getProperty("copycolumnset");
			com.sleepThread(5000);
			com.click("xpath", customcolumnset, "ILTC-00029,Options,Click on custom Column set");
			com.sleepThread(4000);
			com.click("xpath", copycolumnset, "ILTC-00029,Options,Click on Copy column set");
	   }

	   @Then("^Clear the name and enter new column set Name \"([^\"]*)\" and add column$")
	   public void clear_the_name_and_enter_new_column_set_Name_and_add_column(String Name) throws Throwable {
		    String Editnameinput = Common.readPropertyByWatch_List().getProperty("Editnameinput");
			String Optiontypesn = Common.readPropertyByWatch_List().getProperty("optiontypesnsforcopy");
			String rightarrowforcopy = Common.readPropertyByWatch_List().getProperty("rightarrowforcopy");
			String Optionscolumnsforcopy = Common.readPropertyByWatch_List().getProperty("Optionscolumnsforcopy");
			com.sleepThread(5000);
			com.ClearTextField("xpath", Editnameinput, "ILTC-00029,Options,Clear name of column set");
			com.sleepThread(4000);
			com.sendKeys("xpath", Editnameinput, Name, "ITLC-35,Options,Verify entering Name input");
			com.sleepThread(3000);
			com.click("xpath", Optionscolumnsforcopy, "ITLC-32,Options,click on options in available columns");
			com.sleepThread(3000);
			com.click("xpath", Optiontypesn, "ITLC-35,Options,click on optiontypeSN in options");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", rightarrowforcopy, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
			com.click("xpath", rightarrowforcopy, "ITLC-35,Options,click on rightarrow to add columns");
	   }

	   @Then("^Click on save and verify copied column set name$")
	   public void click_on_save_and_verify_copied_column_set_name() throws Throwable {
		    String Editsavecolumnset = Common.readPropertyByWatch_List().getProperty("Editsavecolumnset");
			String Copiedcustomcolumnset = Common.readPropertyByWatch_List().getProperty("Copiedcustomcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(5000);
			com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
			com.sleepThread(4000);
			com.waitUntilElementPresent(Copiedcustomcolumnset);
			String text ="Test";
			com.verifyText("xpath", Copiedcustomcolumnset, text, "ITLC-00029,Options, Verify Copied column set name");
	   }
	   
	   //Delete column set
	   @Given("^Click on delete button and then click on Confirmation ok button$")
	   public void click_on_delete_button_and_then_click_on_Confirmation_ok_button() throws Throwable {
		    String Deletecolumnset = Common.readPropertyByWatch_List().getProperty("Deletecolumnset");
			String Deleteconfirmationcolumnset = Common.readPropertyByWatch_List().getProperty("Deleteconfirmationcolumnset");
			com.sleepThread(5000);
			com.click("xpath", Deletecolumnset, "ILTC-00029,Options,Click on Delete Column set");
			com.sleepThread(4000);
			com.startAction();
			com.MouseOverToElement("xpath", Deleteconfirmationcolumnset, "ILTC-00029,Options,Mouse hover on Delete Confirmation");
			com.click("xpath", Deleteconfirmationcolumnset, "ILTC-00029,Options,Click on Delete Confirmation");
	   }

	   @Then("^Verify whether column set is deleted or not$")
	   public void verify_whether_column_set_is_deleted_or_not() throws Throwable {
		    String Deltedcolumnset = Common.readPropertyByWatch_List().getProperty("Deletedcolumnset");
			String closecolumnset = Common.readPropertyByWatch_List().getProperty("closecolumnset");
			com.sleepThread(4000);
			com.waitUntilElementPresent(Deltedcolumnset);
			String text ="Test";
			com.verifyText("xpath", Deltedcolumnset, text, "ITLC-00029,Options, Verify Deleted column set name");
			com.sleepThread(4000);
			com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on Close");
	   }
    //Watch List dropdown
	@Given("^Click on the watch list dropdown$")
	public void click_on_the_watch_list_dropdown() throws Exception {
		String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,Options,Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on watch list dropdown");
	}

	@Then("^select the watch List for which you want to get results$")
	public void select_the_watch_List_for_which_you_want_to_get_results() throws Exception {
		String WatchList = Common.readPropertyByWatch_List().getProperty("WatchList");
		com.sleepThread(5000);
		com.waitUntilElementPresent(WatchList);
		com.startAction();
		com.MouseOverToElement("xpath", WatchList, "ILTC-00030,Options,Mouse hover on watch list");
		com.click("xpath", WatchList, "ILTC-00030,Options,Click on WatchList");
	}

	@Then("^Verify the columns whether they belong to watch list or not$")
	public void verify_the_columns_whether_they_belong_to_watch_list_or_not() throws Exception {
		String Time = Common.readPropertyByWatch_List().getProperty("Time");
		String Last = Common.readPropertyByWatch_List().getProperty("Last");
		String Date = Common.readPropertyByWatch_List().getProperty("Date");
		String Open = Common.readPropertyByWatch_List().getProperty("Open");
		String High = Common.readPropertyByWatch_List().getProperty("High");
		String NetChange = Common.readPropertyByWatch_List().getProperty("NetChange");
		String Percentagechange = Common.readPropertyByWatch_List().getProperty("Percentagechange");
		com.sleepThread(5000);
		String Timetext = "Time";
		String Lasttext = "Last";
		String Datetext = "Date";
		String Opentext = "Open";
		String Hightext = "High";
		String netchangetext = "Net Change";
		String Percentagechangetext = "% Change";
		com.verifyText("xpath", Time, Timetext, "ILTC-00030,Options,Verify Time text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Last, Lasttext, "ILTC-00030,Options,Verify Last text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Date, Datetext, "ILTC-00030,Options,Verify Date text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Open, Opentext, "ILTC-00030,Options,Verify Open Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", High, Hightext, "ILTC-00030,Options,Verify High Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", NetChange, netchangetext, "ILTC-00030,Options,Verify Net Change text column of Selected Watch List");
		com.sleepThread(5000);
		com.verifyText("xpath", Percentagechange, Percentagechangetext, "ILTC-00030,Options,Verify % Change text column of Selected Watch List and Selected Watch List verified");
	}
	
	//Adding new symbol list and verifying

    @Given("^Click on Watch List dropdown$")
    public void click_on_Watch_List_dropdown() throws Throwable {
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,Options,Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on watch list dropdown");
    }

    @Then("^Click on New in the dropdown$")
    public void click_on_New_in_the_dropdown() throws Throwable {
    	String Newwatchlist = Common.readPropertyByWatch_List().getProperty("Newwatchlist");
		com.sleepThread(4000);			
		com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", Newwatchlist, "ILTC-00030,Options,Mouse hiver on New");
		com.click("xpath", Newwatchlist, "ILTC-00029,Options,Click on New");
    }

    @Then("^Enter Symbol List Name \"([^\"]*)\" and click on Ok$")
    public void enter_Symbol_List_Name_and_click_on_Ok(String Name) throws Throwable {
    	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
    	String newsymbollistok = Common.readPropertyByWatch_List().getProperty("newsymbollistok");
    	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Symbol List Name");
		com.click("xpath", newsymbollistok, "ILTC-00029,Options,Click on Ok");
		
    }

    @Then("^Click on Wtachlist dropdown and Verify the Added Symbol List from dropdown$")
    public void verify_the_Added_Symbol_List_from_dropdown() throws Throwable {
    	String NewlyAddedsymbollist = Common.readPropertyByWatch_List().getProperty("NewlyAddedsymbollist");
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
    	com.sleepThread(4000);
    	com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on Watch List Dropdown");
    	com.sleepThread(4000);
    	String symbollisttext = "Test";
		com.verifyText("xpath", NewlyAddedsymbollist, symbollisttext, "ILTC-00030,Options,Verify Newly Added Symbol List");
    }
    
    //Adding symbols to the newly added watch list
    @Given("^Click on newly added watch list$")
    public void click_on_newly_added_watch_list() throws Throwable {
    	String NewlyAddedsymbollist = Common.readPropertyByWatch_List().getProperty("NewlyAddedsymbollist");
		com.sleepThread(4000);			
		//com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", NewlyAddedsymbollist, "ILTC-00030,Options,Mouse hover on Newly Added symbol list");
		com.click("xpath", NewlyAddedsymbollist, "ILTC-00029,Options,Click on Newly Added Symbol List");
    }

    @Then("^Double click on Enter symbol and select the symbol$")
    public void double_click_on_Enter_symbol_and_select_the_symbol() throws Throwable {
    	String Symbolinput = Common.readPropertyByWatch_List().getProperty("Symbolinput");
    	String Symbolinputdropdown = Common.readPropertyByWatch_List().getProperty("Symbolinputdropdown");
    	com.sleepThread(4000);
		com.double_click_an_element("xpath", Symbolinput, "ILTC-00029,Options,Double Click on Symbol Input");
		com.sleepThread(4000);
		com.click("xpath", Symbolinputdropdown, "ILTC-00029,Options,Select the symbol input");   
    }

    @Then("^Verify whether symbol is added or not$")
    public void verify_whether_symbol_is_added_or_not() throws Throwable {
    	String Symbolinput = Common.readPropertyByWatch_List().getProperty("Symbolinput");
    	com.sleepThread(4000);
    	String symbollisttext = "AAPL";
		com.verifyText("xpath", Symbolinput, symbollisttext, "ILTC-00030,Options,Verify Newly Added Symbol");
    }
    
    //Duplicate symbol list
    @Given("^Click on the WatchList Dropdown$")
    public void click_on_Watch_List_Dropdown() throws Throwable {
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
		com.sleepThread(9000);			
		com.waitUntilElementPresent(Watchlistdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", Watchlistdropdown, "ILTC-00030,Options,Mouse hover on watch listdropdown");
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on watch list dropdown");
    }

    @Then("^Click on New dropdown$")
    public void click_on_New_dropdown() throws Throwable {
    	String Newwatchlist = Common.readPropertyByWatch_List().getProperty("Newwatchlist");
		com.sleepThread(4000);			
		com.waitUntilElementPresent(Newwatchlist);
		com.startAction();
		com.MouseOverToElement("xpath", Newwatchlist, "ILTC-00030,Options,Mouse hover on New");
		com.click("xpath", Newwatchlist, "ILTC-00029,Options,Click on New");
    }

    @Then("^Enter same symbol list Name \"([^\"]*)\" and click on Ok$")
    public void enter_same_symbol_list_Name_and_click_on_Ok(String Name) throws Throwable {
    	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
    	String newsymbollistok = Common.readPropertyByWatch_List().getProperty("newsymbollistok");
    	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the existing Symbol List Name");
		com.click("xpath", newsymbollistok, "ILTC-00029,Options,Click on Ok");
    }

    @Then("^User should not be able to add so click on cancel$")
    public void user_should_not_be_able_to_add_and_click_on_cancel() throws Throwable {
    	String CancelSymbolList = Common.readPropertyByWatch_List().getProperty("CancelSymbolList");
    	com.sleepThread(3000);
		com.click("xpath", CancelSymbolList, "ILTC-00029,Options,User not able to add duplicate list so Click on Cancel");
    }
    
    //Save As Symbol List
    @Given("^Click on the WatchList Dropdown and click on save as$")
    public void click_on_the_WatchList_Dropdown_and_click_on_save_as() throws Throwable {
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
    	String SaveAs = Common.readPropertyByWatch_List().getProperty("SaveAs");
    	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", SaveAs, "ILTC-00029,Options,Click on Save As");
    }

    @Then("^Enter symbol list Name \"([^\"]*)\" and click on Ok$")
    public void enter_symbol_list_Name_and_click_on_Ok(String Name) throws Throwable {
    	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
    	String SaveAsOk = Common.readPropertyByWatch_List().getProperty("SaveAsOk");
    	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Save As Symbol List Name");
		com.click("xpath", SaveAsOk, "ILTC-00029,Options,Click on Save As Ok");
    }

    @Then("^Verify the added symbol list$")
    public void verify_the_added_symbol_list() throws Throwable {
    	String SaveAsverification = Common.readPropertyByWatch_List().getProperty("SaveAsverification");
    	com.sleepThread(4000);
    	String symboltext = "AAPL";
		com.verifyText("xpath", SaveAsverification, symboltext, "ILTC-00030,Options,Verify Newly Added Save As Symbol");
    }
    
    //Duplicate symbol list using Save As
    @Given("^Click on watch List dropdown and click Save As$")
    public void click_on_watch_List_dropdown_and_click_Save_As() throws Throwable {
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
    	String SaveAs = Common.readPropertyByWatch_List().getProperty("SaveAs");
    	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", SaveAs, "ILTC-00029,Options,Click on Save As for duplicate symbol list");
    }

    @Then("^Enter the exisitng Symbol List Name \"([^\"]*)\" and click on Ok$")
    public void enter_the_exisitng_Symbol_List_Name_and_click_on_Ok(String Name) throws Throwable {
    	String Symbollistinput = Common.readPropertyByWatch_List().getProperty("Symbollistinput");
    	String SaveAsOk = Common.readPropertyByWatch_List().getProperty("SaveAsOk");
    	com.sleepThread(3000);
		com.sendKeys("xpath", Symbollistinput, Name,
				"ILTC-00023,WatchList,Enter the Save As Symbol List Name for duplicate symbol list");
		com.click("xpath", SaveAsOk, "ILTC-00029,Options,Click on Save As Ok");
    }

    @Then("^User should not be able to add using Save As and click on Cancel$")
    public void user_should_not_be_able_to_add_using_Save_As_and_click_on_Cancel() throws Throwable {
    	String CancelSymbolList = Common.readPropertyByWatch_List().getProperty("CancelSymbolList");
    	com.sleepThread(3000);
		com.click("xpath", CancelSymbolList, "ILTC-00029,Options,User not able to add duplicate symbol list using Save As so Click on Cancel");
    }
    
    //Adding new column
    @Given("^Mouse Hover and click on Time$")
    public void mouse_Hover_and_click_on_Time() throws Throwable {
    	String Time = Common.readPropertyByWatch_List().getProperty("Time");
    	String Timedropdown = Common.readPropertyByWatch_List().getProperty("Timedropdown");
    	com.sleepThread(5000);
    	com.startAction();
		com.MouseOverToElement("xpath", Time,
				"ILTC-00023,WatchList,Mouse hover on Time column");
		com.click("xpath", Timedropdown, "ILTC-00029,Options,Click on Time column");
    }

    @Then("^Mouse hover on Add new column and click on column that you want to add$")
    public void mouse_hover_on_Add_new_column_and_click_on_column_that_you_want_to_add() throws Throwable {
    	String Addnewcolumn = Common.readPropertyByWatch_List().getProperty("Addnewcolumn");
    	String SelectingBid = Common.readPropertyByWatch_List().getProperty("SelectingBid");
    	com.sleepThread(3000);
    	com.startAction();
		com.MouseOverToElement("xpath", Addnewcolumn,
				"ILTC-00023,WatchList,Mouse hover on Add New column");
		com.click("xpath", SelectingBid, "ILTC-00029,Options,Click on Bid to Add as column");
    }

    @Then("^Verify the newly added column$")
    public void verify_the_newly_added_column() throws Throwable {
    	String Bid = Common.readPropertyByWatch_List().getProperty("Bid");
    	com.sleepThread(4000);
    	String columntext = "Bid";
		com.verifyText("xpath", Bid, columntext, "ILTC-00030,Options,Verify Newly Added column");
    }
    
    //Removing column
    @Given("^Mouse hover and click on column you want to delete$")
    public void mouse_hover_and_click_on_column_you_want_to_delete() throws Throwable {
    	String Bid = Common.readPropertyByWatch_List().getProperty("Bid");
    	String Columndropdown = Common.readPropertyByWatch_List().getProperty("Columndropdown");
    	com.sleepThread(3000);
    	com.startAction();
		com.MouseOverToElement("xpath", Bid,
				"ILTC-00023,WatchList,Mouse hover on column that has to be deleted");
		com.click("xpath", Columndropdown, "ILTC-00029,Options,Click on column that has to be deleted");
    }

    @Then("^Click on Remove This column and verify column is removed or not$")
    public void click_on_Remove_This_column_and_verify_column_is_removed_or_not() throws Throwable {
    	String Removethiscolumn = Common.readPropertyByWatch_List().getProperty("Removethiscolumn");
    	String Last = Common.readPropertyByWatch_List().getProperty("Last");
    	com.sleepThread(4000);
		com.click("xpath", Removethiscolumn, "ILTC-00029,Options,Click on Remove This column");
		com.sleepThread(4000);
    	String columntext = "Last";
		com.verifyText("xpath", Last, columntext, "ILTC-00030,Options,Verify Column is deleted or not");
    }
    
    //View Definition and verification
    @Given("^Mouse Hover on Time and click on Time$")
    public void mouse_Hover_on_Time_and_click_on_Time() throws Throwable {
    	String Time = Common.readPropertyByWatch_List().getProperty("Time");
    	String Timedropdown = Common.readPropertyByWatch_List().getProperty("Timedropdown");
    	com.sleepThread(5000);
    	com.startAction();
		com.MouseOverToElement("xpath", Time,
				"ILTC-00023,WatchList,Mouse hover on Time column");
		com.click("xpath", Timedropdown, "ILTC-00029,Options,Click on Time column for View Definition");
    }

    @Then("^Click on View Definiton and verify the definition$")
    public void click_on_View_Definiton_and_verify_the_definition() throws Throwable {
    	String ViewDefinition = Common.readPropertyByWatch_List().getProperty("ViewDefinition");
    	String Verifydefinition = Common.readPropertyByWatch_List().getProperty("Verifydefinition");
    	com.sleepThread(4000);
		com.click("xpath", ViewDefinition, "ILTC-00029,Options,Click on View Definition for column");
		com.sleepThread(4000);
    	String definitiontext = "Time of the last update (Includes Bids / Asks)";
		com.verifyText("xpath", Verifydefinition, definitiontext, "ILTC-00030,Options,Verify Column definition");
    }
    
    //Import from file
    @Given("^Click on watch List dropdown and click on Import from file$")
    public void click_on_watch_List_dropdown_and_click_on_Import_from_file() throws Throwable {
    	String Watchlistdropdown = Common.readPropertyByWatch_List().getProperty("Watchlistdropdown");
    	String importfromfile = Common.readPropertyByWatch_List().getProperty("importfromfile");
    	com.sleepThread(4000);
		com.click("xpath", Watchlistdropdown, "ILTC-00029,Options,Click on Watch List dropdown");
		com.sleepThread(4000);
		com.click("xpath", importfromfile, "ILTC-00029,Options,Click on Import from file");
    }

    @Then("^Select file to upload and click on Ok$")
    public void select_file_to_upload_and_click_on_Ok() throws Throwable {
    	String BrowseFile = Common.readPropertyByWatch_List().getProperty("BrowseFile");
    	String FileUploadOk = Common.readPropertyByWatch_List().getProperty("FileUploadOk");
    	com.sleepThread(4000);
    	String Fileupload = "C:\\Users\\bhaskarj\\Desktop\\Symbols.txt";
    	//com.sendKeys("xpath", BrowseFile, Fileupload, "ND-00060,Widgets,Upload file to import");
    	com.click("xpath", BrowseFile, "ILTC-00029,Options,Click on Select file to upload");
    	com.sleepThread(3000);
    	com.upload_file(Fileupload);
    	com.sleepThread(5000);
    	com.click("xpath", FileUploadOk, "ILTC-00029,Options,Click on Ok to upload file");
    }

   @Then("^Verify Imported File$")
   public void verify_imported_file() throws Exception{
	   String Importedsymbol = Common.readPropertyByWatch_List().getProperty("Importedsymbol");
   	   com.sleepThread(5000);
   	   String symboltext = "SYMBOLS";
	   com.verifyText("xpath", Importedsymbol, symboltext, "ILTC-00030,Options,Verify imported symbol");
   }
   
}
*/