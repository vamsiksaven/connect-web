package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Global_Preferences {
	private static final String Widget_name = null;
	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Global_Preferences() {
		driver = Common.driver;
		login = Common.readPropertyByLogin().getProperty("Login_button");
     }
     @When("^Verify File option exist$")
     public void Verify_File_option_exist () throws Exception {
     String File=Common.readPropertyByGlobal_Preferences().getProperty("File");
     com.verifyElementPresent("xpath", File, "Global Preferences,IGTC-00001,Verify File option exist");
     Thread.sleep(10);
     com.click("xpath",File,"Global Preferences,IGTC-00002,Click on File menu");
     Thread.sleep(11);
     }    
     @When("^Verify open new console window option$")
     public void Verify_Open_new_console_window_option() throws Exception {
	 com.verifyElementPresent("xpath","//button[contains(text(),'Open new console window...')]","Global Preferences,IGTC-00003,Verify Open New Console Window");
	 Thread.sleep(10);
	 }     
     @Then("^Close the open console window$")
     public void Close_the_open_console_window() throws Exception {
     com.switch_to_new_window("xpath","//button[contains(text(),'Open new console window...')]" , "Global Preferences,IGTC-00004,Click on Open console window option","xpath","//div[@class='css-1lmoh0']", "Global Preferences,IGTC-00005,Close the Open console window");
     Thread.sleep(50);     
     }	
	@When("^Verify_click save workspace option$")
	public void Verify_click_save_workspace_option() throws Exception {
	String File=Common.readPropertyByGlobal_Preferences().getProperty("File");
	com.click("xpath",File,"Global Preferences,IGTC-00005,Click on File menu");
	com.verifyElementPresent("xpath", "//button[contains(text(),'Save workspace...')]", "Global Preferences,IGTC-00006,Verify save workspace option");
	com.click("xpath", "//button[contains(text(),'Save workspace...')]", "Global Preferences,IGTC-00007,Click on save workspace option");
	Thread.sleep(60);
	}
	
	@When("^verify_click preferences drop down option$")
	public void Verify_click_Preferences_drop_down_option() throws Exception {
	String Pref=Common.readPropertyByGlobal_Preferences().getProperty("Pref");
	com.verifyElementPresent("xpath", Pref ,"Global Preferences,IGTC-00008,verify Preferences drop down option");
	com.click("xpath", Pref,"Global Preferences,IGTC-00009,click on preferences drop down option");
	}	
	@Then("^verify_click manage keyboard shortcuts option$")
	public void verify_click_manage_keyboard_shortcuts_option() throws Exception {	
	com.verifyElementPresent("xpath","//button[contains(text(),'Manage Keyboard Shortcuts')]","Global Preferences,IGTC-00010,verify manage keyboard shortcuts option");
	com.click("xpath","//button[contains(text(),'Manage Keyboard Shortcuts')]","Global Preferences,IGTC-00011,click on manage keyboard shortcuts option");
	}
	
	@Then("^close the manage keyboard shortcuts$")
	public void close_the_manage_keyboard_dialog() throws Exception {
	//com.click("xpath","//body/div[@id='container']/div/div[@class='ice-theme-provider light-theme css-aw120u e9snama0']/div/div[@class='css-1enaoom']/div[@class='css-11zhy3w']/div/div[@class='css-1ydaq69 fade in']/div[@class='ice-dialog keyboard-shortcuts-manager css-1udawuh']/div[@class='css-1qf7008']/div[@class='css-1mnke7y']/button[@class='ice-button css-13jiw8o e66scw10']/span[@class='ice-icon ice-icon-times css-1hc7rx0 e5j0fb80']/*[1]","Global Preferences,IGTC-00012,close manage keyboard shortcuts option");
	com.startAction();
	com.MouseOverToclickabl("xpath","//body/div[@id='container']/div/div[@class='ice-theme-provider light-theme css-aw120u e9snama0']/div/div[@class='css-1enaoom']/div[@class='css-11zhy3w']/div/div[@class='css-1ydaq69 fade in']/div[@class='ice-dialog keyboard-shortcuts-manager css-1udawuh']/div[@class='css-1qf7008']/div[@class='css-1mnke7y']/button[@class='ice-button css-13jiw8o e66scw10']/span[@class='ice-icon ice-icon-times css-1hc7rx0 e5j0fb80']/*[1]","Global Preferences,IGTC-00012,close manage keyboard shortcuts option");
	}
	
	@When("^verify tab sorting option$")
	public void verify_tab_sorting_option() throws Exception {
	String Pref=Common.readPropertyByGlobal_Preferences().getProperty("Pref");
	String Tab_Sorting=Common.readPropertyByGlobal_Preferences().getProperty("Tab_Sorting");
	com.click("xpath", Pref,"Global Preferences,IGTC-00013,click on preferences drop down option");
	com.verifyElementPresent("xpath",Tab_Sorting,"Global Preferences,IGTC-00014,verify tab sorting option");
	}
	@Then("^click on tab sorting option$")
	public void click_on_tab_sorting_option() throws Exception {	
	String Tab_Sorting=Common.readPropertyByGlobal_Preferences().getProperty("Tab_Sorting");
	com.click("xpath", Tab_Sorting, "Global Preferences,IGTC-00015,click on tab sorting option");
	}
	@Then("^verify tab sorting window open$")
	public void verify_tab_sorting_window_open() throws Exception {
	com.startAction();
	String Tab_Sorting=Common.readPropertyByGlobal_Preferences().getProperty("Tab_Sorting");
	com.click("xpath", Tab_Sorting, "Global Preferences,IGTC-000016,click on tab sorting option");
	com.sleepThread(15);
	com.MouseOverToclickabl("xpath",Tab_Sorting,"focus on tab sorting window");
	com.sleepThread(3030);
	}
	@Then("^verify-click alphabetical radio button$")
	public void verify_click_alphabetical_radio_button() throws Exception{
	com.startAction();	
	String Alphabetical=Common.readPropertyByGlobal_Preferences().getProperty("Alphabetical");	
	com.verifyElementPresent("xpath", Alphabetical,"Global Preferences,IGTC-00017,verify on alphabetical radio button");
	com.sleepThread(2000);
	com.MouseOverToclickabl("xpath",Alphabetical,"focus on tab sorting window");
	com.sleepThread(2000);
	com.click("xpath",Alphabetical,"Global Preferences,IGTC-00018,click on alphabetical radio button");
	}
	@Then("^verify-click reverse alphabetical radio button$")
	public void verify_click_reverse_alphabetical_radio_button() throws Exception{	
	String Reverse_Alphabetical=Common.readPropertyByGlobal_Preferences().getProperty("Reverse_Alphabetical");	
	com.sleepThread(11);
	com.verifyElementPresent("xpath",Reverse_Alphabetical,"Global Preferences,IGTC-00019,verify on reverse alphabetical radio button");
	com.sleepThread(11);
	com.click("xpath",Reverse_Alphabetical,"Global Preferences,IGTC-00020,click on reverse alphabetical radio button");
	}
	@Then("^verify-click manual radio button$")
	public void verify_click_manual_radio_button() throws Exception {	
	String Manual=Common.readPropertyByGlobal_Preferences().getProperty("Manual");	
	com.sleepThread(10);
	com.verifyElementPresent("xpath",Manual,"Global Preferences,IGTC-000021,verify on manual radio button");
	com.sleepThread(10);
	com.click("xpath",Manual,"Global Preferences,IGTC-00022,click on manual radio button");
	com.sleepThread(10);
	}
	@Then("^verify-click apply-save button$")
	public void verify_click_apply_save_button() throws Exception {	
	String Apply_Save=Common.readPropertyByGlobal_Preferences().getProperty("Apply_Save");	
	com.verifyElementPresent("xpath",Apply_Save,"Global Preferences,IGTC-00023,verify apply&save button");
	com.click("xpath",Apply_Save,"Global Preferences,IGTC-00024,click on apply&save button");
	}
	@Then("^verify-click cancel button$")
	public void verify_click_cancel_button() throws Exception {
	String Pref=Common.readPropertyByGlobal_Preferences().getProperty("Pref");
	String Tab_Sorting=Common.readPropertyByGlobal_Preferences().getProperty("Tab_Sorting");
	String Cancel=Common.readPropertyByGlobal_Preferences().getProperty("Cancel");
	com.sleepThread(10);
	com.click("xpath",Pref,"Global Preferences,IGTC-00025,click on preferences drop down option");
	com.sleepThread(100);
	com.click("xpath", Tab_Sorting, "Global Preferences,IGTC-00026,click on tab sorting option");
	com.sleepThread(100);
	com.verifyElementPresent("xpath",Cancel,"Global Preferences,IGTC-00027,verify cancel button");
	com.sleepThread(100);
	com.click("xpath",Cancel,"Global Preferences,IGTC-00028,click on cancel button");
	com.sleepThread(100);
	}
	
	@When("^veirfy display quick launch bar in primary console$")
	public void verify_display_quick_launch_bar_in_primary_console() throws Exception {
	String Pref=Common.readPropertyByGlobal_Preferences().getProperty("Pref");
	com.click("xpath",Pref,"Global Preferences,IGTC-00029,click on preferences drop down option");
	com.sleepThread(100);
	com.verifyElementPresent("xpath","//label[@class='ice-checkbox css-ppng4o ejl8a250']","Global Preferences,IGTC-00030,verify display quick launch bar in primary console check box");
	com.sleepThread(100);
	com.click("xpath","//label[@class='ice-checkbox css-ppng4o ejl8a250']","Global Preferences,IGTC-00031,click on display quick launch bar in primary console check box");
	com.sleepThread(100);
	com.verifyElementPresent("xpath","//label[@class='ice-checkbox css-ppng4o ejl8a250']","Global Preferences,IGTC-00032,verify application menu bar is showing");
	}

	@When("^Verify connect utils option$")
	public void Verify_connect_utils_option() throws Exception {
	com.verifyElementPresent("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00033,verify connect utils option");	
	com.sleepThread(3000);	
	}
	@Then("^click on preference option$")
	public void click_on_preference_option() throws Exception {
	com.startAction();
	com.MouseOverToElement("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00034,click on connect utils option");
	com.sleepThread(2000);
	com.MouseOverToclickabl("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00035,click on Preferences option");	
    }

	@When("^verify-click on formatting$")
	public void verify_click_on_formatting() throws Exception {	
	com.startAction();
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00036,Focus on fromatting sub heading");
	com.verifyElementPresent("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00037,verify fromatting sub heading");	
	}
	
	@Then("^verify-click on classic radio button$")
	public void verify_click_on_classic_radio_button() throws Exception {
	String Classic=Common.readPropertyByGlobal_Preferences().getProperty("Classic");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");		
	com.verifyElementPresent("xpath",Classic,"Global Preferences,IGTC-00038,verify Classic radio button");
	com.click("xpath",Classic,"Global Preferences,IGTC-00039,click on Classic radio button");
	com.click("xpath",Ok,"Global Preferences,IGTC-00040,click on save button");
	}
	@Then("^verify-click on formatted radio button$")
	public void verify_click_on_formatted_radio_button() throws Exception {
	com.startAction();
	String Formatted=Common.readPropertyByGlobal_Preferences().getProperty("Formatted");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00041,click on connect utils option");
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00042,click on preferences option");
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00043,Focus on fromatting sub heading");
	com.verifyElementPresent("xpath",Formatted,"Global Preferences,IGTC-00044,verify Formatted radio button");
	com.click("xpath",Formatted,"Global Preferences,IGTC-00045,click on Formatted radio button");
	com.click("xpath",Ok,"Global Preferences,IGTC-00046,click on save button");
	}
	@Then("^verify-click on decimal radio button$")
	public void verify_click_on_decimal_radio_button() throws Exception {
	com.startAction();
	String Decimal=Common.readPropertyByGlobal_Preferences().getProperty("Decimal");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00047,click on connect utils option");
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00048,click on preferences option");
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00049,click on formatting option");
	com.verifyElementPresent("xpath",Decimal,"Global Preferences,IGTC-00050,verify Decimal radio button");
	com.click("xpath",Decimal,"Global Preferences,IGTC-00051,click on Decimal radio button");
	com.click("xpath",Ok,"Global Preferences,IGTC-00052,click on save button");
	}
	@Then("^verify-click on show full precision on trade data$")
	public void verify_click_on_show_full_precision_on_trade_data() throws Exception {
	com.startAction();
	String Show_Full_Precision_on_Trade_Data=Common.readPropertyByGlobal_Preferences().getProperty("Show_Full_Precision_on_Trade_Data");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00053,click on connect utils option");
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00054,click on preferences option");
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00055,click on formatting option");
	com.verifyElementPresent("xpath",Show_Full_Precision_on_Trade_Data,"Global Preferences,IGTC-00056,verify Show Full Precision on Trade Data check box");
	com.click("xpath",Show_Full_Precision_on_Trade_Data,"Global Preferences,IGTC-00057,click on Show Full Precision on Trade Data check box");
	com.click("xpath",Ok,"Global Preferences,IGTC-00058,click on save button");
	}
	@Then("^verify decimal-dollar format drop down$")
	public void verify_decimal_dollar_format_drop_down() throws Exception {
	com.startAction();
	String Use_brackets_on_Negative_Values=Common.readPropertyByGlobal_Preferences().getProperty("Use_brackets_on_Negative_Values");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00059,click on connect utils option");
	com.sleepThread(1000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00060,click on preferences option");
	com.sleepThread(1000);
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00061,click on formatting option");
	com.sleepThread(1000);
	com.verifyElementPresent("xpath","//fieldset[3]//label[1]//div[1]//select[1]","Global Preferences,IGTC-00062,verify decimal-dollar drop down");
	com.sleepThread(1000);
	com.click("xpath","//fieldset[3]//label[1]//div[1]//select[1]","Global Preferences,IGTC-00063,click on decimal-dollar drop down");
	com.sleepThread(3000);
	int size = driver.findElements(By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[3]/label[1]/div/select/option")).size();			
	 System.out.println(size);
	 for (int i=1;i<=size;i++)
       {				
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[3]/label[1]/div/select/option["+i+"]","Global Preferences,IGTC-00064,Check all options in decimal-dollar drop down");
	com.sleepThread(1000);
	com.click("xpath",Use_brackets_on_Negative_Values,"Global Preferences,IGTC-00065,click on Show Full Precision on Trade Data option");
	com.sleepThread(1000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00066,click on save button");
	com.sleepThread(1000);		
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00067,click on connect utils option");
	com.sleepThread(1000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00068,click on preferences option");
	com.sleepThread(1000);
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00069,click on formatting option");	
	com.sleepThread(1000);
	com.click("xpath","/html/body/div//fieldset[3]/label[1]/div","Global Preferences,IGTC-00070,click on decimal-dollar drop down");
	com.sleepThread(3000);		
    }
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[3]/label[1]/div/select/option[1]", "Global Preferences,IGTC-00071,select default value decimal-dollar drop down");
	com.sleepThread(1000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00072,click on save button");
	}
	@Then("^verify percent format drop down$")
	public void verify_percent_format_drop_down() throws Exception {
	com.startAction();
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00073,click on connect utils option");
	com.sleepThread(1000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00074,click on preferences option");
	com.sleepThread(1000);
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00075,click on formatting option");
	com.sleepThread(1000);
	com.verifyElementPresent("xpath","//fieldset[4]//label[1]//div[1]//select[1]","Global Preferences,IGTC-00076,verify percent format drop down");
	com.sleepThread(1000);
	com.click("xpath","//fieldset[4]//label[1]//div[1]//select[1]","Global Preferences,IGTC-00077,click on percent format drop down");
	com.sleepThread(3000);
	int size = driver.findElements(By.xpath("/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[4]/label/div/select/option")).size();
	System.out.println(size);
		
	for(int i=1;i<=size;i++)
        {
	com.startAction();
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[4]/label/div/select/option["+i+"]","Global Preferences,IGTC-00078,Check all options in percent format drop down");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00079,click on save button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00080,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00081,click on preferences option");
	com.sleepThread(3000);
	com.MouseOverToclickabl("xpath","//button[contains(text(),'Formatting')]","Global Preferences,IGTC-00082,click on formatting option");
	com.sleepThread(3000);
	com.click("xpath","//fieldset[4]//label[1]//div[1]//select[1]","Global Preferences,IGTC-00083,click on percent format drop down");
	com.sleepThread(3000);
       }
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset[4]/label/div/select/option[1]", "Global Preferences,IGTC-00084,Select default value from percent format drop down");
	com.sleepThread(1000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00085,click on save button");
	}
	@When("^verify-click on time zone$")
	public void verify_click_on_time_zone() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");	
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00086,click on connect utils option");
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00087,click on preferences option");
	com.verifyElementPresent("xpath",Time_Zone,"Global Preferences,IGTC-00088,Verify Time Zone sub heading");
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00089,click on Time Zone button");
	}
	@Then ("^verify-click on display in local radio button$")
	public void verify_click_on_display_in_local_radio_button() throws Exception {	
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");	
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//label[contains(text(),'Display in Local')]","Global Preferences,IGTC-00090,Verify Display in Local radio button");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Display in Local')]","Global Preferences,IGTC-00091,click on Display in Local radio button");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00092,click on save button");
	com.sleepThread(3000);
	}
	@Then ("^verify-click on display in exchange radio button$")
	public void verify_click_on_display_in_exchange_radio_button() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");
	String Display_in_Exchange=Common.readPropertyByGlobal_Preferences().getProperty("Display_in_Exchange");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00093,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00094,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00095,click on Time Zone button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Display_in_Exchange,"Global Preferences,IGTC-00096,Verify Display in Exchange radio button");
	com.sleepThread(3000);
	com.click("xpath",Display_in_Exchange,"Global Preferences,IGTC-00097,Verify Display in Exchange radio button");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00098,click on save button");
	com.sleepThread(3000);
	}
	@Then ("^verify-click display in GMT radio button$")
	public void verify_click_display_in_GMT_radio_button() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");
	String Display_in_GMT=Common.readPropertyByGlobal_Preferences().getProperty("Display_in_GMT");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00099,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00100,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00101,click on Time Zone button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Display_in_GMT,"Global Preferences,IGTC-00102,Verify Display in GMT radio button");
	com.sleepThread(3000);
	com.click("xpath",Display_in_GMT,"Global Preferences,IGTC-00103,Verify Display in GMT radio button");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00104,click on save button");
	com.sleepThread(3000);
	}
	@Then("^verify-select timezone offset drop down$")
	public void verify_select_timezone_offset_drop_down() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00105,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00106,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00107,click on Time Zone button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","/html/body/div//fieldset[1]/label/div/select", "Global Preferences,IGTC-00108,Verify time zone offset drop down");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[1]/label/div/select","Global Preferences,IGTC-00109,click on time zone offset drop down");
	int size=driver.findElements(By.xpath("/html/body/div//fieldset[1]/label/div/select/option")).size();
	System.out.println(size);
	for(int i=1;i<=size;i++)
	{	
	com.click("xpath","/html/body/div//fieldset[1]/label/div/select/option["+i+"]","Global Preferences,IGTC-00110,checking time zone offset drop down options");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00111,click on save button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00112,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00113,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00114,click on Time Zone sub heading");	
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[1]/label/div/select","Global Preferences,IGTC-00115,click on time zone offset drop down");
	com.sleepThread(3000);
	}
	com.click("xpath","/html/body/div//fieldset[1]/label/div/select/option[1]","Global Preferences,IGTC-00116,selecting default option from time zone offset drop down");
	com.sleepThread(1000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00117,click on save button");
    }
	@Then("^verify-select date format drop down$")
	public void verify_select_date_format_drop_down() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00118,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00119,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00120,click on Time Zone button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","/html/body/div//fieldset[2]/div/div[1]/label/div/select", "Global Preferences,IGTC-00121,Verify date format drop down");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[2]/div/div[1]/label/div/select","Global Preferences,IGTC-00122,click on date format drop down");
	int size=driver.findElements(By.xpath("/html/body/div//fieldset[2]/div/div[1]/label/div/select/option")).size();
	System.out.println(size);
	
	for(int i=1;i<=size;i++)
	{
	com.click("xpath","/html/body/div//fieldset[2]/div/div[1]/label/div/select/option["+i+"]","Global Preferences,IGTC-00123,checking date format drop down options");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00124,click on save button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00125,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00126,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00127,click on Time Zone button");	
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[2]/div/div[1]/label/div/select","Global Preferences,IGTC-00128,click on date format drop down");
	com.sleepThread(3000);
	}
	com.click("xpath","/html/body/div//fieldset[2]/div/div[1]/label/div/select/option[1]", "Global Preferences,IGTC-00129,select default option on date format drop down");
	com.sleepThread(1000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00130,click on save button");
    }
	@Then("^verify-select time format drop down$")
	public void verify_select_time_format_drop_down() throws Exception {
	String Time_Zone=Common.readPropertyByGlobal_Preferences().getProperty("Time_Zone");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00131,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00132,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00133,click on Time Zone button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","/html/body/div//fieldset[2]/div/div[2]/label/div/select", "Global Preferences,IGTC-00134,Verify time format drop down");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[2]/div/div[2]/label/div/select","Global Preferences,IGTC-00135,click on time format drop down");
	int size=driver.findElements(By.xpath("/html/body/div//fieldset[2]/div/div[2]/label/div/select/option")).size();
	System.out.println(size);
	
	for(int i=1;i<=size;i++)
	{
	com.click("xpath","/html/body/div//fieldset[2]/div/div[2]/label/div/select/option["+i+"]","Global Preferences,IGTC-00136,checking time format drop down options");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00137,click on save button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00138,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00139,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Time_Zone,"Global Preferences,IGTC-00140,click on Time Zone button");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[2]/div/div[2]/label/div/select","Global Preferences,IGTC-00141,Check all options in time Format drop down");
	com.sleepThread(3000);
	}
	com.verifyElementPresent("xpath","//label[contains(text(),'Override market clock time format (time format nee')]","Global Preferences,IGTC-00142,verify override market clock time check box");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Override market clock time format (time format nee')]","Global Preferences,IGTC-00143,click on override market clock time check box");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div//fieldset[2]/div/div[2]/label/div/select/option[1]","Global Preferences,IGTC-00144,selecting default option from time format drop down");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00145,click on save button");
	
    }
	@When("^verify-click on Appearance$")
	public void verify_click_on_Appearance() throws Exception {
	String Appearance=Common.readPropertyByGlobal_Preferences().getProperty("Appearance");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00146,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00147,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Appearance,"Global Preferences,IGTC-00148,verify Appearance option");
	com.sleepThread(3000);
	com.click("xpath",Appearance,"Global Preferences,IGTC-00149,click on Appearance option");
	com.sleepThread(3000);
	}
	
	@Then("^verify-click on dark theme$")
	public void verify_click_on_dark_theme() throws Exception {	
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");	
	com.verifyElementPresent("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/label[1]/div","Global Preferences,IGTC-00150,verify theme drop down");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/label[1]/div/select","Global Preferences,IGTC-00151,click on theme drop down");
	com.sleepThread(3000);
	com.click("xpath","//option[contains(text(),'Dark Theme')]","Global Preferences,IGTC-00152,select dark theme option");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00153,click on save button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//*[@id=\"container\"]/div/div","Global Preferences,IGTC-00154,verifng selected theme color in application");
	com.sleepThread(3000);
	}
	@Then("^verify-click on light theme$")
	public void verify_click_on_light_theme() throws Exception {
	String Appearance=Common.readPropertyByGlobal_Preferences().getProperty("Appearance");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00155,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-pkibe5 e66scw10']","Global Preferences,IGTC-00156,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Appearance,"Global Preferences,IGTC-00157,click on appearance option");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/label[1]/div/select","Global Preferences,IGTC-00158,click on theme drop down");
	com.sleepThread(3000);
	com.click("xpath","//option[contains(text(),'Light Theme')]","Global Preferences,IGTC-00159,select light theme option");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00160,click on save button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//*[@id=\"container\"]/div/div","Global Preferences,IGTC-00161,verifng selected theme color in application");
	com.sleepThread(3000);
	}
	@Then("^verify-click show tool bar check box$")
	public void verify_click_show_tool_bar_check_box() throws Exception {
	String Appearance=Common.readPropertyByGlobal_Preferences().getProperty("Appearance");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00162,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00163,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Appearance,"Global Preferences,IGTC-00164,click on appearance option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","/html/body/div[4]/div/span/div[2]/div/div[2]/div/div[2]/div/label[2]","Global Preferences,IGTC-00165,verifing show tool bar check box");
	com.click("xpath","//label[contains(text(),'Show Toolbar')]","Global Preferences,IGTC-00166,click on show tool bar check box");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00167,click on save button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//*[@id=\"container\"]/div/div/div/div/div[2]/div/div/div[1]","Global Preferences,IGTC-00168,verifying tool bar in application");
	com.sleepThread(3000);
	}
	@Then("^verify-select color drop down$")
	public void verify_select_color_drop_down() throws Exception {
	String Appearance=Common.readPropertyByGlobal_Preferences().getProperty("Appearance");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00169,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00170,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Appearance,"Global Preferences,IGTC-00171,click on Appearance button");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//fieldset[@class='popup-content d-padded']//div[@class='pt-select']","Global Preferences,IGTC-00172,Verify color drop down");
	com.sleepThread(3000);
	com.click("xpath","//fieldset[@class='popup-content d-padded']//div[@class='pt-select']","Global Preferences,IGTC-00173,Click on color drop down");
	com.sleepThread(3000);
	int size=driver.findElements(By.xpath("/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset/label/div/select/option")).size();	                                       
	System.out.println(size);
	com.sleepThread(3000);
	for(int i=1;i<=size;i++)
	{	
	com.click("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset/label/div/select/option["+i+"]","Global Preferences,IGTC-00174,Check all options in color(based on net change) drop down");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00175,click on save button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00176,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00177,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",Appearance,"Global Preferences,IGTC-00178,click on Appearance button");
	com.sleepThread(3000);	
	com.click("xpath","//fieldset[@class='popup-content d-padded']//div[@class='pt-select']","Global Preferences,IGTC-00179,Click on color drop down");
	com.sleepThread(3000);
	}
	com.click("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/fieldset/label/div/select/option[3]","Global Preferences,IGTC-00180,Select default option from color drop down" );
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00181,click on save button");
	com.sleepThread(3000);
    }
	
	@When("^verify-click on symbol extension$")
	public void verify_click_on_symbol_extension() throws Exception {
	String Symbol_Extensions=Common.readPropertyByGlobal_Preferences().getProperty("Symbol_Extensions");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00182,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00183,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Symbol_Extensions,"Global Preferences,IGTC-00184,verifying symbol extensions option");
	com.sleepThread(3000);
	com.click("xpath",Symbol_Extensions,"Global Preferences,IGTC-00185,click on symbol extensions option");
	com.sleepThread(3000);
	}
	@Then("^verify symbol extension group drop down$")
	public void verify_symbol_extension_group_drop_down() throws Exception {	
	com.verifyElementPresent("xpath","//div[@class='pt-select']//select","Global Preferences,IGTC-00186,verifying symbol extension group drop down presents");
	com.sleepThread(3000);
	com.click("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/label/div/select","Global Preferences,IGTC-00187,click on symbol extension group drop down");
	com.sleepThread(3000);
	int size=driver.findElements(By.xpath("/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/label/div/select/option")).size();
	System.out.println(size);
	com.sleepThread(3000);
	for(int i=1;i<=size;i++) {
	com.click("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/label/div/select/option["+i+"]","Global Preferences,IGTC-00188,check all options on symbol extension group drop down");
	com.sleepThread(3000);
	com.click("xpath","//div[@class='pt-select']//select","Global Preferences,IGTC-00189,click on symbol extension group drop down");
	}
	com.sleepThread(3000);
	com.click("xpath","/html/body/div[3]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/label/div/select/option[2]","Global Preferences,IGTC-00190,select default option on symbol extension group drop down");
	}
	@Then("^verify extension text box$")
	public void verify_extension_text_box() throws Exception {	
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//div[@class='pt-portal']//div[3]//label[1]","Global Preferences,IGTC-00191,verifying symbol extension text box presents");
	com.sleepThread(3000);
    }
	@Then("^verify description text box$")
	public void verify_description_text_box() throws Exception {	
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//label[2]","Global Preferences,IGTC-00192,verifying symbol description text box presents");
    }
	@Then("^verify-click on add button$")
	public void verify_click_on_add_button() throws Exception {	
	String Add=Common.readPropertyByGlobal_Preferences().getProperty("Add");	
	com.click("xpath","//option[@value='Canada']","Global Preferences,IGTC-00193,select canada option");
	com.sleepThread(3000);
	com.click("xpath","//div[contains(text(),'[-TC] Toronto Stock Exchange')]","Global Preferences,IGTC-00194,select toronto stock exchange option");
	com.sleepThread(3000);
	com.click("xpath","//label[1]//div[1]//div[1]//input[1]","Global Preferences,IGTC-00195,click on extension text box");
	com.sleepThread(3000);
	com.sendKeys("xpath","//label[1]//div[1]//div[1]//input[1]","-TCI","Global Preferences,IGTC-00196,enter text on extensions text box");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Add,"Global Preferences,IGTC-00197,verifying Add button");
	com.sleepThread(3000);
	com.click("xpath",Add,"Global Preferences,IGTC-00198,click on Add button");
	com.sleepThread(3000);
    }
	@Then("^verify-click on change button$")
	public void verify_click_on_change_button() throws Exception {	
	String Change=Common.readPropertyByGlobal_Preferences().getProperty("Change");	
	com.click("xpath","//div[contains(text(),'[-TC-TCI] Toronto Stock Exchange')]","Global Preferences,IGTC-00199,select modified toronto stock exchange option");
	com.sleepThread(3000);
	com.click("xpath","//label[1]//div[1]//div[1]//input[1]","Global Preferences,IGTC-00200,click on extension text box");
	com.sleepThread(3000);
	com.sendKeys("xpath","//label[1]//div[1]//div[1]//input[1]","-TCTEST","Global Preferences,IGTC-00201,enter text on extensions text box");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Change,"Global Preferences,IGTC-00202,verifying Change button");
	com.sleepThread(3000);
	com.click("xpath",Change,"Global Preferences,IGTC-00203,click on Add button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on delete button$")
	public void verify_click_on_delete_button() throws Exception {	
	String Delete=Common.readPropertyByGlobal_Preferences().getProperty("Delete");	
	com.click("xpath","//div[contains(text(),'[-TC-TCI-TCTEST] Toronto Stock Exchange')]","Global Preferences,IGTC-00204,select modified toronto stock exchange option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Delete,"Global Preferences,IGTC-00205,verifying Delete button");
	com.sleepThread(3000);
	com.click("xpath",Delete,"Global Preferences,IGTC-00206,click on Delete button");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Yes')]","Global Preferences,IGTC-00207,click on yes button on pop up button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on move up button$")
	public void verify_click_on_move_up_button() throws Exception {	
	String Move_Up=Common.readPropertyByGlobal_Preferences().getProperty("Move_Up");	
	com.click("xpath","//div[contains(text(),'[-CN] Canadian National Stock Exchange (CNSX)')]","Global Preferences,IGTC-00208,select canadian national stock exchange option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Move_Up,"Global Preferences,IGTC-00209,verifying Move Up button");
	com.sleepThread(3000);
	com.click("xpath",Move_Up,"Global Preferences,IGTC-00210,click on Move Up button");	
	com.sleepThread(3000);
	}
	@Then("^verify-click on move down button$")
	public void verify_click_on_move_down_button() throws Exception {	
	String Move_Down=Common.readPropertyByGlobal_Preferences().getProperty("Move_Down");	
	com.click("xpath","//div[contains(text(),'[-CN] Canadian National Stock Exchange (CNSX)')]","Global Preferences,IGTC-00211,select canadian national stock exchange option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Move_Down,"Global Preferences,IGTC-00212,verifying Move Down button");
	com.sleepThread(3000);
	com.click("xpath",Move_Down,"Global Preferences,IGTC-00213,click on Move Down button");
	com.sleepThread(3000);
	}
	@Then("^verify gear drop down$")
	public void verify_gear_drop_down() throws Exception {	
	com.verifyElementPresent("xpath","//button[contains(@class,'pt-button pt-minimal d-flex-fix')]","Global Preferences,IGTC-00214,click on symbol extensions option");	
	com.sleepThread(3000);
	}
	@Then("^verify-click on apply to inserted/pasted symbols$")
	public void verify_click_on_apply_to_inserted_pasted_symbols() throws Exception {	
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");	
	com.verifyElementPresent("xpath","//label[contains(text(),'Apply to Inserted/Pasted Symbols')]","Global Preferences,IGTC-00215,verifying apply to inserted/pasted symbols check box");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Apply to Inserted/Pasted Symbols')]","Global Preferences,IGTC-00216,click on apply to inserted/pasted symbols check box");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00217,click on save button");	
	com.sleepThread(3000);
	}
	
	
	@When("^Verify-click on pre market settings$")
	public void Verify_click_on_pre_market_settings() throws Exception {	
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00218,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00219,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//button[contains(text(),'Pre-Market Settings')]","Global Preferences,IGTC-00220,Verify Pre market Settings option");
	com.sleepThread(3000);
	com.click("xpath","//button[contains(text(),'Pre-Market Settings')]","Global Preferences,IGTC-00221,click on symbol Pre-market Settings option");
	com.sleepThread(3000);
	}
	@Then("^verify-click on server blanks fields radio button$")
	public void verify_click_on_server_blanks_fields_radio_button() throws Exception {	
	com.verifyElementPresent("xpath","//label[contains(text(),'Server blanks fields. Values are cleared based on')]","Global Preferences,IGTC-00222,Verify 'Server blanks fields. Values are cleared based on' radio button");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Server blanks fields. Values are cleared based on')]","Global Preferences,IGTC-00223,click on 'Server blanks fields. Values are cleared based on' radio button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on blank fields until pre market display radio button$")
	public void verify_click_on_blank_fields_until_pre_market_display_radio_button() throws Exception {
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");	
	com.verifyElementPresent("xpath","//label[contains(text(),'Blank fields until pre-market display. Selected fi')]","Global Preferences,IGTC-00224,Verify 'Blank fields until pre-market display. Selected fi' radio button");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Blank fields until pre-market display. Selected fi')]","Global Preferences,IGTC-00225,click on 'Blank fields until pre-market display. Selected fi' radio button");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00226,click on save button");	
	com.sleepThread(3000);
	}
	
	@When("^verify-click on general widget settings$")
	public void verify_click_on_general_widget_settings() throws Exception {
	String General_Widget_Settings=Common.readPropertyByGlobal_Preferences().getProperty("General_Widget_Settings");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00227,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00228,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",General_Widget_Settings,"Global Preferences,IGTC-00229,Verify General Widget Settings option");
	com.sleepThread(3000);
	com.click("xpath",General_Widget_Settings,"Global Preferences,IGTC-00230,click on symbol General Widget Settings option");
	com.sleepThread(3000);
	}
	@Then("^verify-click on show study description check box$")
	public void verify_click_on_show_study_description_check_box() throws Exception {
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.verifyElementPresent("xpath","//label[contains(text(),'Show Study Description in Dialog')]","Global Preferences,IGTC-00231,Verify show study description Check box");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Show Study Description in Dialog')]","Global Preferences,IGTC-00232,click on show study description Check box");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00233,click on save button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on global cursor tracking check box$")
	public void verify_click_on_global_cursor_tracking_check_box() throws Exception {
	String General_Widget_Settings=Common.readPropertyByGlobal_Preferences().getProperty("General_Widget_Settings");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00234,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00235,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",General_Widget_Settings,"Global Preferences,IGTC-00236,click on symbol Pre-market Settings option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//label[contains(text(),'Global Cursor Tracking')]","Global Preferences,IGTC-00237,Verify global cursor tracking check box");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Global Cursor Tracking')]","Global Preferences,IGTC-00238,click on global cursor tracking check box");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00239,click on save button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on static data tracking check box$")
	public void verify_click_on_static_data_tracking_check_box() throws Exception {
	String General_Widget_Settings=Common.readPropertyByGlobal_Preferences().getProperty("General_Widget_Settings");
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00240,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00241,click on preferences option");
	com.sleepThread(3000);
	com.click("xpath",General_Widget_Settings,"Global Preferences,IGTC-00242,click on symbol Pre-market Settings option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath","//label[contains(text(),'Static Data Tracking')]","Global Preferences,IGTC-00243,Verify static data tracking check box");
	com.sleepThread(3000);
	com.click("xpath","//label[contains(text(),'Static Data Tracking')]","Global Preferences,IGTC-00244,click on static data tracking check box");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00245,click on save button");
	com.sleepThread(3000);
	}
	
	@Then("^verify-click on save$")
	public void verify_click_on_save() throws Exception {
	String Ok=Common.readPropertyByGlobal_Preferences().getProperty("Ok");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00246,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00247,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Ok,"Global Preferences,IGTC-00248,click on save button");
	com.sleepThread(3000);
	com.click("xpath",Ok,"Global Preferences,IGTC-00249,click on save button");
	com.sleepThread(3000);
	}
	@Then("^verify-click on cancel$")
	public void verify_click_on_cancel() throws Exception {
	String Cancel=Common.readPropertyByGlobal_Preferences().getProperty("Cancel");
	com.click("xpath","//button[contains(text(),'Connect Utils')]","Global Preferences,IGTC-00250,click on connect utils option");
	com.sleepThread(3000);
	com.click("xpath","//button[@class='ice-button e12espz23 css-1gkebzc e66scw10']","Global Preferences,IGTC-00251,click on preferences option");
	com.sleepThread(3000);
	com.verifyElementPresent("xpath",Cancel,"Global Preferences,IGTC-00252,verify Cancel button");
	com.sleepThread(3000);
	com.click("xpath",Cancel,"Global Preferences,IGTC-00253,click on cancel button");
	com.sleepThread(3000);
	}
}	


	


