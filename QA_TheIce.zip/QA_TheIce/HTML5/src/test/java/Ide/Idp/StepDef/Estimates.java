package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Estimates {
	
	private static String Widget_name = null;
	public Common com = new Common();
	public DetailedQuotes DQ;
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public Estimates() {
		driver = Common.driver;
		login = Common.readPropertyByEstimates().getProperty("Login_button");
	}
	
	//Verify and click on Estimates
	@Given("^Verify the Estimates$")
	public void verify_the_Estimates() throws Throwable {
		com.sleepThread(12000);
		String Estimates = Common.readPropertyByEstimates().getProperty("Estimates");
		System.out.println(Estimates);		
		com.verifyElementPresent("xpath", Estimates, "IDQTC-00001,Estimates,Verify the Estimates");
	}

	@Given("^Click on Estimates$")
	public void click_on_Estimates() throws Throwable {
		com.sleepThread(12000);	
		String Estimates = Common.readPropertyByEstimates().getProperty("Estimates");
		com.click("xpath", Estimates, "IDQTC-00002,Estimates,Click on Estimates");
	}
	
	//Verifying the entered symbol is displayed or not
	@Given("^Click on the symbol input field and clear the input field$")
	public void click_on_the_symbol_input_field_and_clear_the_input_field() throws Throwable {
		com.sleepThread(15000);
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		String SymbolInput = Common.readPropertyByEstimates().getProperty("SymbolInput");
		driver.findElement(By.xpath("//*[@class='d-w-inner-toolbar']")).click();
		com.sleepThread(6000);
		com.click("xpath", SymbolInput, "IDQTC-00007,"+Widget_name+",Click on Symbol Input");
		com.sleepThread(4000);
		com.ClearTextField("xpath", SymbolInput, "IDQTC-00008,"+Widget_name+",Clear symbol input");
	}

	@Then("^Enter the symbol \"([^\"]*)\" and select it from dropdown list$")
	public void enter_the_symbol_and_select_it_from_dropdown_list(String symbol) throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(2000);
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		String SymbolInput = Common.readPropertyByEstimates().getProperty("SymbolInput");
		String symbolinputdropdown = Common.readPropertyByEstimates().getProperty("symbolinputdropdown");
		com.sendKeys("xpath", SymbolInput, symbol, "IDQTC-00009,"+Widget_name+",Enter symbol");
		com.sleepThread(4000);
		com.sendKeys_fOR_Keybord("xpath", SymbolInput, Keys.ENTER, "IDQTC-00009,"+Widget_name+",Enter symbol");
		com.sleepThread(6000);
		driver.findElement(By.xpath("//*[@class='d-w-inner-toolbar']")).click();
//		com.MouseOverToElement("xpath", symbolinputdropdown, "IDQTC-00010,"+Widget_name+",Mouse hover on Symbol Input Dropdown");
//		com.sleepThread(2000);
//		System.out.println("Passed");
//		com.click("xpath", symbolinputdropdown, "IDQTC-00010,"+Widget_name+",Click on Symbol Input Dropdown");
	}

	@Then("^Verify the entered symbol$")
	public void verify_the_entered_symbol() throws Throwable {
		com.sleepThread(4000);
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		String MSFT = Common.readPropertyByEstimates().getProperty("MSFT");
		com.sleepThread(8000);
		String Symbolname = "Microsoft Corporation (MSFT)";
		com.verifyText("xpath", MSFT, Symbolname, "IDQTC-00011,"+Widget_name+",Verify the symbol name");
	}
	
	//Verify estimate currency options
	@Given("^Click on estimate currency options and then verify close$")
	public void click_on_estimate_currency_options_and_then_verify_close() throws Throwable {
		com.sleepThread(20000);
		com.startAction();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		//driver.findElement(By.xpath("//*[@id=\"9\"]/div[2]/div[2]/div/div/div/div/div[1]/div/div")).click();
		com.selectFrameById("frameID");
		String Estimatescurrencyoption = Common.readPropertyByEstimates().getProperty("Estimatescurrencyoption");
		String CloseEstimatescurrencyoption = Common.readPropertyByEstimates().getProperty("CloseEstimatescurrencyoption");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Estimatescurrencyoption, "IDQTC-00019,"+Widget_name+", mouse hover and click on estimate currency options");
		com.sleepThread(4000);
		com.click("xpath", CloseEstimatescurrencyoption, "IDQTC-00019,"+Widget_name+", click on close in estimate currency options");
	}

	@Then("^Click on estimate currency option and verify cancel$")
	public void click_on_estimate_currency_option_and_verify_cancel() throws Throwable {
		com.sleepThread(9000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		//com.selectFrameById("frameID");
		String Estimatescurrencyoption = Common.readPropertyByEstimates().getProperty("Estimatescurrencyoption");
		String EstimatescurrencyoptionCancel = Common.readPropertyByEstimates().getProperty("EstimatescurrencyoptionCancel");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Estimatescurrencyoption, "IDQTC-00019,"+Widget_name+", mouse hover and click on estimate currency options");
		com.sleepThread(4000);
		com.click("xpath", EstimatescurrencyoptionCancel, "IDQTC-00019,"+Widget_name+", click on close in estimate currency options");
	}
	
	@Then("^For local currency click on currency of most brokers estimates$")
	public void for_local_currency_click_on_currency_of_most_brokers_estimates() throws Throwable {
		com.sleepThread(9000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		//com.selectFrameById("frameID");
		String Estimatescurrencyoption = Common.readPropertyByEstimates().getProperty("Estimatescurrencyoption");
		String ForLocalcurrency = Common.readPropertyByEstimates().getProperty("ForLocalcurrency");
		String EstimatescurrencyoptionOk = Common.readPropertyByEstimates().getProperty("EstimatescurrencyoptionOk");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Estimatescurrencyoption, "IDQTC-00019,"+Widget_name+", mouse hover and click on estimate currency options");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", ForLocalcurrency, "IDQTC-00019,"+Widget_name+", click on currency of most broker's estimates");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", EstimatescurrencyoptionOk, "IDQTC-00019,"+Widget_name+", click on ok in estimate currency options");
	}
	@Then("^For exchange rate click on all estimates usign the rate on day prior to report$")
	public void for_exchange_rate_click_on_all_estimates() throws Throwable {
		com.sleepThread(10000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		//com.selectFrameById("frameID");
		String Estimatescurrencyoption = Common.readPropertyByEstimates().getProperty("Estimatescurrencyoption");
		String ForExchangeRate = Common.readPropertyByEstimates().getProperty("ForExchangeRate");
		String Exchangerateok = Common.readPropertyByEstimates().getProperty("Exchangerateok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Estimatescurrencyoption, "IDQTC-00019,"+Widget_name+", mouse hover and click on estimate currency options");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", ForExchangeRate, "IDQTC-00019,"+Widget_name+", click on all estimates");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Exchangerateok, "IDQTC-00019,"+Widget_name+", click on ok in estimate currency options");
	}
	
	//Verify Show Chart
	@Given("^Click on show chart to verify chart is being displayed or not$")
	public void click_on_show_chart_to_verify_chart_is_being_displayed_or_not() throws Throwable {
		com.sleepThread(20000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		String Showchart = Common.readPropertyByEstimates().getProperty("Showchart");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Showchart, "IDQTC-00019,"+Widget_name+", mouse hover and click on show chart");
		com.sleepThread(8000);
		com.MouseOverToclickabl("xpath", Showchart, "IDQTC-00019,"+Widget_name+", mouse hover and click on show chart");
		com.sleepThread(5000);
	}
	
	//Add or remove columns
	@Given("^Click on Add or remove columns and Click on columns to add$")
	public void click_on_Add_or_remove_columns_and_Click_on_columns_to_add() throws Throwable {
		com.sleepThread(7000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		String Addorremovecolumns = Common.readPropertyByEstimates().getProperty("Addorremovecolumns");
		String Addbrokercode = Common.readPropertyByEstimates().getProperty("Addbrokercode");
		String Addchangepercent = Common.readPropertyByEstimates().getProperty("Addchangepercent");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Addorremovecolumns, "IDQTC-00019,"+Widget_name+", mouse hover and click on add or remove columns");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Addbrokercode, "IDQTC-00019,"+Widget_name+", mouse hover and click on broker code to add");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Addchangepercent, "IDQTC-00019,"+Widget_name+", mouse hover and click on Change% to add");
		com.sleepThread(4000);
	}

	@Then("^Click on Ok to add columns$")
	public void click_on_Ok_to_add_columns() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		String AddcolumnOk = Common.readPropertyByEstimates().getProperty("AddcolumnOk");
		com.MouseOverToclickabl("xpath", AddcolumnOk, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok to add columns");
		com.sleepThread(4000);
	}

	@Then("^Click on Add or remove columns and click on columns to remove$")
	public void click_on_Add_or_remove_columns_and_click_on_columns_to_remove() throws Throwable {
		com.sleepThread(7000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(5000);
		String Addorremovecolumns = Common.readPropertyByEstimates().getProperty("Addorremovecolumns");
		String Removebrokercode = Common.readPropertyByEstimates().getProperty("Removebrokercode");
		String Removechangepercent = Common.readPropertyByEstimates().getProperty("Removechangepercent");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Addorremovecolumns, "IDQTC-00019,"+Widget_name+", mouse hover and click on add or remove columns");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Removebrokercode, "IDQTC-00019,"+Widget_name+", mouse hover and click on broker code to uncheck");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Removechangepercent, "IDQTC-00019,"+Widget_name+", mouse hover and click on Change% to uncheck");
		com.sleepThread(4000);
	}

	@Then("^click on ok to remove columns$")
	public void click_on_ok_to_remove_columns() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		String RemovecolumnOk = Common.readPropertyByEstimates().getProperty("RemovecolumnOk");
		com.MouseOverToclickabl("xpath", RemovecolumnOk, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok to remove columns");
		com.sleepThread(4000);
	}

	@Then("^Click on Add or remove columns and click on cancel button$")
	public void click_on_Add_or_remove_columns_and_click_on_cancel_button() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		String Addorremovecolumns = Common.readPropertyByEstimates().getProperty("Addorremovecolumns");
		String Addorremovecolumncancel = Common.readPropertyByEstimates().getProperty("Addorremovecolumncancel");
		com.MouseOverToclickabl("xpath", Addorremovecolumns, "IDQTC-00019,"+Widget_name+", mouse hover and click on add or remove columns");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Addorremovecolumncancel, "IDQTC-00019,"+Widget_name+", mouse hover and click on cancel");
		com.sleepThread(4000);
	}

	//Verify launch more options
	@Given("^Click on median and then click on ok$")
	public void click_on_median_and_then_click_on_ok() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		//Widget_name=driver.findElement(By.xpath(Common.readPropertyByEstimates().getProperty("Widget_name"))).getText();
		com.sleepThread(2000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String median = Common.readPropertyByEstimates().getProperty("median");
		String medianok = Common.readPropertyByEstimates().getProperty("medianok");
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", mouse hover and click on launch more options");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", median, "IDQTC-00019,"+Widget_name+", mouse hover and click on median");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", medianok, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok");
		com.sleepThread(4000);
	}
	
	//Estimate Date
	@Then("^Clear estimate date and give the input \"([^\"]*)\" and click on ok$")
	public void clear_estimate_date_and_give_the_input_and_click_on_ok(String input) throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		com.sleepThread(5000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String Estimatedateinput = Common.readPropertyByEstimates().getProperty("Estimatedateinput");
		String Estimatedateok = Common.readPropertyByEstimates().getProperty("Estimatedateok");
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", mouse hover and click on launch more options");
		com.sleepThread(4000);
		com.ClearTextField("xpath", Estimatedateinput, "IDQTC-00019,"+Widget_name+", Clear estimate date input");
		com.sleepThread(4000);
		com.sendKeys("xpath", Estimatedateinput, input, "IDQTC-00019,"+Widget_name+", Send estimate date input");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Estimatedateok, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok");
		com.sleepThread(4000);
	}
	
	@Then("^Click on estimate date calender and select date and click on ok$")
	public void click_on_estimate_date_calender_and_select_date_and_click_on_ok() throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		com.sleepThread(2000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String Calender = Common.readPropertyByEstimates().getProperty("Calender");
		String Calenderdate = Common.readPropertyByEstimates().getProperty("Calenderdate");
		String EstimatedateCalenderok = Common.readPropertyByEstimates().getProperty("EstimatedateCalenderok");
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", mouse hover and click on launch more options");
		com.sleepThread(6000);
		com.MouseOverToclickabl("xpath", Calender, "IDQTC-00019,"+Widget_name+", Click on estimate date calender");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Calenderdate, "IDQTC-00019,"+Widget_name+", mouse hover and click on calender date");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", EstimatedateCalenderok, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok");
		com.sleepThread(4000);
	}
	
	@Then("^Clear consensus window and give the input \"([^\"]*)\" and click on ok$")
	public void clear_consensus_window_and_give_the_input_and_click_on_ok(String input) throws Throwable {
		com.sleepThread(3000);
		com.startAction();
		com.sleepThread(2000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String Consensuswindow = Common.readPropertyByEstimates().getProperty("Consensuswindow");
		String Consensuswindowok = Common.readPropertyByEstimates().getProperty("Consensuswindowok");
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", mouse hover and click on launch more options");
		com.sleepThread(4000);
		com.ClearTextField("xpath", Consensuswindow, "IDQTC-00019,"+Widget_name+", Clear consensus window input");
		com.sleepThread(4000);
		com.sendKeys("xpath", Consensuswindow, input, "IDQTC-00019,"+Widget_name+", Send consensus window input");
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", Consensuswindowok, "IDQTC-00019,"+Widget_name+", mouse hover and click on ok");
		com.sleepThread(4000);
	}
	
	@Then("^Click on growth type and check period over period option$")
	public void click_on_growth_and_verify_all_its_options() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(5000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String Growthtype = Common.readPropertyByEstimates().getProperty("Growthtype");
		String periodoverperiod = Common.readPropertyByEstimates().getProperty("periodoverperiod");
		String Growthtypeok = Common.readPropertyByEstimates().getProperty("Growthtypeok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", click on more options");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Growthtype, "IDQTC-00019,"+Widget_name+", click on growth type");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", periodoverperiod,"IDQTC-00021,"+Widget_name+",Click on pewriodoverperiod growth type");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Growthtypeok, "IDQTC-00019,"+Widget_name+", click on growth type ok");
		com.sleepThread(2000);
	}
	
	@Then("^Click on post event and show sharp consensus indicator and click ok$")
	public void click_on_post_event_and_show_sharp_consensus_indicator_and_click_ok() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(5000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String posteventconsensus = Common.readPropertyByEstimates().getProperty("posteventconsensus");
		String Showsharpconsensusindicator = Common.readPropertyByEstimates().getProperty("Showsharpconsensusindicator");
		String consensuscheckboxok = Common.readPropertyByEstimates().getProperty("consensuscheckboxok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", click on more options");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", posteventconsensus, "IDQTC-00019,"+Widget_name+", click on post event consensus");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Showsharpconsensusindicator,"IDQTC-00021,"+Widget_name+",Click on show sharp indicator consensus");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", consensuscheckboxok, "IDQTC-00019,"+Widget_name+", click on consenus ok");
		com.sleepThread(2000);
	}
	
	@Then("^Verify cancel button in launch more options$")
	public void verify_cancel_button_in_launch_more_options() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String launchmoreoptionscancel = Common.readPropertyByEstimates().getProperty("launchmoreoptionscancel");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", click on more options");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", launchmoreoptionscancel, "IDQTC-00019,"+Widget_name+", click on cancel in launch more options");
	}
	
	@Then("^Verify close button in launch more options$")
	public void verify_close_button_in_launch_more_options() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Moreoptions = Common.readPropertyByEstimates().getProperty("Moreoptions");
		String moreoptionsclose = Common.readPropertyByEstimates().getProperty("moreoptionsclose");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Moreoptions, "IDQTC-00019,"+Widget_name+", click on more options");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", moreoptionsclose, "IDQTC-00019,"+Widget_name+", click on close in launch more options");
	}

	
	//Verify report type and its options
	@Given("^Click on report type dropdown and Verify all the options in report type$")
	public void click_on_report_type_dropdown() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(5000);
		String Reporttype = Common.readPropertyByEstimates().getProperty("Reporttype");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Reporttype, "IDQTC-00019,"+Widget_name+", click on report type dropdown");
		com.sleepThread(2000);
		int count = driver
				.findElements(By.xpath("/html/body/div[23]/div/ul/li")).size();
		System.out.println(count);
		for (int i = 1; i <= 2; i++) {
			com.MouseOverToclickabl("xpath", "/html/body/div[23]/div/ul/li[" + i + "]",
					"IDQTC-00021,"+Widget_name+",Click on each report type option");
			com.sleepThread(11000);
			com.MouseOverToclickabl("xpath", Reporttype, "IDQTC-00019,"+Widget_name+", click on report type");
			com.sleepThread(8000);
		}
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", "/html/body/div[25]/div/ul/li[3]", "IDQTC-00019,"+Widget_name+", click on report type");
	}
	
	//Categories dropdown and its options
	
	@Given("^Click on Categories dropdown and click Statement items$")
	public void click_on_Categories_dropdown_and_click_Statement_items() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(3000);
		String Categoriesdropdown = Common.readPropertyByEstimates().getProperty("Categoriesdropdown");
		String Staementitemcategory = Common.readPropertyByEstimates().getProperty("Staementitemcategory");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Categoriesdropdown, "IDQTC-00019,"+Widget_name+", click on categories dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Staementitemcategory, "IDQTC-00019,"+Widget_name+", click on statement item category");
		com.sleepThread(2000);
	}

	@Then("^Click on dividends per share item and click on ok$")
	public void click_on_dividends_per_share_item_and_click_on_ok() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Grossincome = Common.readPropertyByEstimates().getProperty("Grossincome");
		String Grossincomeok = Common.readPropertyByEstimates().getProperty("Grossincomeok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Grossincome, "IDQTC-00019,"+Widget_name+", click on gross income item");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Grossincomeok, "IDQTC-00019,"+Widget_name+", click on gross income item ok");
		com.sleepThread(2000);
	}

	@Then("^Click on Categories dropdown and click per share items$")
	public void click_on_Categories_dropdown_and_click_per_share_items() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(3000);
		String Categoriesdropdown = Common.readPropertyByEstimates().getProperty("Categoriesdropdown");
		String pershareitemcategory = Common.readPropertyByEstimates().getProperty("pershareitemcategory");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Categoriesdropdown, "IDQTC-00019,"+Widget_name+", click on categories dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", pershareitemcategory, "IDQTC-00019,"+Widget_name+", click on per share item category");
		com.sleepThread(2000);
	}

	@Then("^Click on dividend per share item and click on ok$")
	public void click_on_dividend_per_share_item_and_click_on_ok() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(3000);
		String dividendspershare = Common.readPropertyByEstimates().getProperty("dividendspershare");
		String dividendspershareok = Common.readPropertyByEstimates().getProperty("dividendspershareok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", dividendspershare, "IDQTC-00019,"+Widget_name+", click on dividend share item");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", dividendspershareok, "IDQTC-00019,"+Widget_name+", click on dividend share item ok");
		com.sleepThread(2000);
	}

	@Then("^CLick on Categories dropdown and click non periodic items and click on ok$")
	public void click_on_Categories_dropdown_and_click_non_periodic_items_and_click_on_ok() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Categoriesdropdown = Common.readPropertyByEstimates().getProperty("Categoriesdropdown");
		String Nonperiodicitems = Common.readPropertyByEstimates().getProperty("Nonperiodicitems");
		String Nonperiodicitemsok = Common.readPropertyByEstimates().getProperty("Nonperiodicitemsok");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Categoriesdropdown, "IDQTC-00019,"+Widget_name+", click on categories dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Nonperiodicitems, "IDQTC-00019,"+Widget_name+", click on non periodic items category");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Nonperiodicitemsok, "IDQTC-00019,"+Widget_name+", click on non periodic items category ok");
		com.sleepThread(2000);
	}

	@Then("^Click on Categories dropdown and then click on cancel$")
	public void click_on_Categories_dropdown_and_then_click_on_cancel() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(3000);
		String Categoriesdropdown = Common.readPropertyByEstimates().getProperty("Categoriesdropdown");
		String Categoriescancel = Common.readPropertyByEstimates().getProperty("Categoriescancel");
		String Reporttype = Common.readPropertyByEstimates().getProperty("Reporttype");
		String singleitem = Common.readPropertyByEstimates().getProperty("singleitem");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Categoriesdropdown, "IDQTC-00019,"+Widget_name+", click on categories dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", Categoriescancel, "IDQTC-00019,"+Widget_name+", click on categories dropdown cancel");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Reporttype, "IDQTC-00019,"+Widget_name+", click on report type dropdown");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", singleitem, "IDQTC-00019,"+Widget_name+", click on single item in report type dropdown");
		com.sleepThread(2000);
	}
	
	//Verify report basis and its options
	@Given("^Click on report basis dropdown and Verify all the options in report basis$")
	public void click_on_report_basis_dropdown() throws Throwable {
		com.sleepThread(4000);
		com.startAction();
		com.sleepThread(5000);
		String ReportBasis = Common.readPropertyByEstimates().getProperty("ReportBasis");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", ReportBasis, "IDQTC-00019,"+Widget_name+", click on report basis dropdown");
		com.sleepThread(2000);
		int count = driver
				.findElements(By.xpath("/html/body/div[35]/div/ul/li")).size();
		System.out.println(count);
		for (int i = 1; i <= 1; i++) {
			com.MouseOverToclickabl("xpath", "/html/body/div[35]/div/ul/li[" + i + "]",
					"IDQTC-00021,"+Widget_name+",Click on each report basis option");
			com.sleepThread(11000);
			com.MouseOverToclickabl("xpath", ReportBasis, "IDQTC-00019,"+Widget_name+", click on report basis");
			com.sleepThread(8000);
		}
		com.sleepThread(4000);
		com.MouseOverToclickabl("xpath", "/html/body/div[37]/div/ul/li[2]", "IDQTC-00019,"+Widget_name+", click on fiscal quarter in report basis");
	}
	
	//Verifying period dropdown
	@Given("^Click on period dropdown and then click on different period dropdowns$")
	public void click_on_period_dropdown_and_then_click_on_different_period_dropdowns() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Perioddropdown = Common.readPropertyByEstimates().getProperty("Perioddropdown");
		String perioddropdown1 = Common.readPropertyByEstimates().getProperty("perioddropdown1");
		String perioddropdown2 = Common.readPropertyByEstimates().getProperty("perioddropdown2");
		String perioddropdown3 = Common.readPropertyByEstimates().getProperty("perioddropdown3");
		String perioddropdown4 = Common.readPropertyByEstimates().getProperty("perioddropdown4");
		String perioddropdown5 = Common.readPropertyByEstimates().getProperty("perioddropdown5");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Perioddropdown, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", perioddropdown1, "IDQTC-00019,"+Widget_name+", click on period dropdown1");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Perioddropdown, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", perioddropdown2, "IDQTC-00019,"+Widget_name+", click on period dropdown2");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Perioddropdown, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", perioddropdown3, "IDQTC-00019,"+Widget_name+", click on period dropdown3");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Perioddropdown, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", perioddropdown4, "IDQTC-00019,"+Widget_name+", click on period dropdown4");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Perioddropdown, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", perioddropdown5, "IDQTC-00019,"+Widget_name+", click on period dropdown5");
	}

	//Verifying select currency dropdown
	@Given("^Click on select currency dropdown and then click on different currency dropdowns$")
	public void click_on_select_currency_dropdown_and_then_click_on_different_currency_dropdowns() throws Throwable {
		com.sleepThread(6000);
		com.startAction();
		com.sleepThread(3000);
		String Selectcurrency = Common.readPropertyByEstimates().getProperty("Selectcurrency");
		String AUD = Common.readPropertyByEstimates().getProperty("AUD");
		String EURO = Common.readPropertyByEstimates().getProperty("EURO");
		String AED = Common.readPropertyByEstimates().getProperty("AED");
		String SGD = Common.readPropertyByEstimates().getProperty("SGD");
		String CNY = Common.readPropertyByEstimates().getProperty("CNY");
		com.sleepThread(2000);
		com.MouseOverToclickabl("xpath", Selectcurrency, "IDQTC-00019,"+Widget_name+", click on select currency dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", AUD, "IDQTC-00019,"+Widget_name+", click on currency AUD");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Selectcurrency, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", EURO, "IDQTC-00019,"+Widget_name+", click on currency EURO");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Selectcurrency, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", AED, "IDQTC-00019,"+Widget_name+", click on currency AED");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Selectcurrency, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", SGD, "IDQTC-00019,"+Widget_name+", click on currency SGD");
		com.sleepThread(5000);
		com.MouseOverToclickabl("xpath", Selectcurrency, "IDQTC-00019,"+Widget_name+", click on period dropdown");
		com.sleepThread(3000);
		com.MouseOverToclickabl("xpath", CNY, "IDQTC-00019,"+Widget_name+", click on currency CNY");
	}
}
