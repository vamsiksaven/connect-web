package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import LIB.Common;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class B_Charts {
   
	private static final String Widget_name = null;
	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public B_Charts() {
		driver = Common.driver;
		login = Common.readPropertyByChart().getProperty("Login_button");
	}

	// Verify_the_login_page_Logo
	@Given("^open an browser$")
	public void open_an_web_browser() throws Throwable {
		com.Setup("Chrome", "ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// https://ida-idp.qa.market-q.com/ida-idp/
		com.maximiseBrowser();
	}

	@When("^Verifying the portal logo$")
	public void verifying_the_portal_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByChart().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Charts,Verify the logo");
	}
    
	//Login
	@Given("^Log in with the IDE IDP credentials of the Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void log_in_with_the_IDE_IDP_credentials_of_the_Username_and_Password(String Username, String Password) throws Throwable {
		un = Common.readPropertyByChart().getProperty("User_name");
		Pws = Common.readPropertyByChart().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(1000);
		com.sendKeys("xpath", un, Username,
				"ILTC-00023,Charts,Enter the correct username and are given in associated text fields");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Charts,Enter the correct password are given in associated text fields");
	}

	@Then("^Click the login button$")
	public void click_on_the_user_login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Charts,Click on login button");
		TimeUnit.MINUTES.sleep(2);
		// com.stopRecording();
	}
	
	//Symbol verification
	@Given("^Click on the charts tab$")
	public void click_on_the_charts_tab() throws Throwable {
		String ChartsTab = Common.readPropertyByChart().getProperty("ChartsTab");
		com.sleepThread(3000);
		com.startAction();
		com.MouseOverToElement("xpath", ChartsTab, "ILTC-00026,Options,Mouse hover on Charts tab");
		com.click("xpath", ChartsTab, "ILTC-00026,Charts,Click on Charts tab");
	}

	@Then("^Clear and Enter the symbol name \\\"([^\\\"]*)\\\" and select it from the dropdown$")
	public void enter_the_symbol_name_and_select_it_from_the_dropdown(String name) throws Throwable {
		String symbolinput = Common.readPropertyByChart().getProperty("symbolinput");
		String symboldropdown = Common.readPropertyByChart().getProperty("symboldropdown");
		com.sleepThread(3000);
		com.ClearTextField("xpath", symbolinput,"ILTC-00023,Charts,Clear the symbol name" );
		com.sendKeys("xpath", symbolinput, name,
				"ILTC-00023,Charts,Enter the symbol name");
		com.sleepThread(3000);
		com.click("xpath", symboldropdown, "ILTC-00026,Charts,Click on Symbol dropdown tab");
	}

	@Then("^verifying the symbol in the charts for selected symbol$")
	public void verifying_the_symbol_in_the_charts_for_selected_symbol() throws Throwable {
		String symbolname = Common.readPropertyByChart().getProperty("symbolname");
		com.sleepThread(5000);
		String Symboltext = "IBM";
		com.verifyText("xpath", symbolname, Symboltext, "ILTC-00030,Charts,Verify symbol text column of Selected symbol");
	}
	
    //Header/Footer-Display Preferences
	//Show Symbol Name
	@Given("^Right click and then click on display preferences$")
	public void right_click_and_then_click_on_display_preferences() throws Throwable {
		com.startAction();
		String rightclick = Common.readPropertyByChart().getProperty("rightclick");
		String DisplayPreferences = Common.readPropertyByChart().getProperty("DisplayPreferences");
		com.sleepThread(5000);
		com.Rightclick("xpath", rightclick, "ILTC-00023,Charts,Right click on charts");
		com.sleepThread(3000);
		com.click("xpath", DisplayPreferences, "ILTC-00026,Charts,Click on Display references");
	}

	@Then("^Click on the Header/Footer and click on Show Symbol name in chart header$")
	public void click_on_the_Header_Footer_and_click_on_Show_Symbol_name_in_chart_header() throws Throwable {
		String Headerorfooter = Common.readPropertyByChart().getProperty("Headerorfooter");
		String showsymbolinheader = Common.readPropertyByChart().getProperty("showsymbolinheader");
		com.sleepThread(3000);
		com.click("xpath", Headerorfooter, "ILTC-00026,Charts,Click on Header/Footer");
		com.sleepThread(3000);
		com.click("xpath", showsymbolinheader, "ILTC-00026,Charts,Click on Show symbol in chart header");
	}

	@Then("^Click on the Ok and verify the symbol name in the chart header$")
	public void click_on_the_Ok_and_verify_the_symbol_name_in_the_chart_header() throws Throwable {
		String Displaypreferencesok = Common.readPropertyByChart().getProperty("Displaypreferencesok");
		String showsymbolname = Common.readPropertyByChart().getProperty("showsymbolname");
		com.sleepThread(3000);
		com.click("xpath", Displaypreferencesok, "ILTC-00026,Charts,Click on ok in display preferences");
		com.sleepThread(3000);
		String Symboltext = "IBM";
		com.verifyText("xpath", showsymbolname, Symboltext, "ILTC-00030,Charts,Verify whether symbol is displayed or not");
	}
	
	//Show Company Name
	@Given("^Right click and click on the display preferences$")
	public void right_click_and_click_on_the_display_preferences() throws Throwable {
		com.startAction();
		String rightclick = Common.readPropertyByChart().getProperty("rightclick");
		String DisplayPreferences = Common.readPropertyByChart().getProperty("DisplayPreferences");
		com.sleepThread(3000);
		com.Rightclick("xpath", rightclick, "ILTC-00023,Charts,Right click on charts");
		com.sleepThread(3000);
		com.click("xpath", DisplayPreferences, "ILTC-00026,Charts,Click on Display references for company name");
	}

	@Then("^Click on the Header/Footer and click on the Show company name in chart header$")
	public void click_on_the_Header_Footer_and_click_on_the_Show_company_name_in_chart_header() throws Throwable {
		String Headerorfooter = Common.readPropertyByChart().getProperty("Headerorfooter");
		String showcompanynameinheader = Common.readPropertyByChart().getProperty("showcompanynameinheader");
		com.sleepThread(3000);
		com.click("xpath", Headerorfooter, "ILTC-00026,Charts,Click on Header/Footer");
		com.sleepThread(3000);
		com.click("xpath", showcompanynameinheader, "ILTC-00026,Charts,Click on Show company name in chart header");
	}

	@Then("^Click on Ok and verify the company name in the chart header$")
	public void click_on_Ok_and_verify_the_company_name_in_the_chart_header() throws Throwable {
		String Displaypreferencesok = Common.readPropertyByChart().getProperty("Displaypreferencesok");
		String showcompanyname = Common.readPropertyByChart().getProperty("showcompanyname");
		com.sleepThread(3000);
		com.click("xpath", Displaypreferencesok, "ILTC-00026,Charts,Click on ok in display preferences");
		com.sleepThread(6000);
		String Companytext = "INTERNATIONAL BUSINESS MACHS";
		com.verifyText("xpath", showcompanyname, Companytext, "ILTC-00030,Charts,Verify whether company name is displayed or not");
	}
	
	//Show Footer
	@Given("^Right click and then click on display preferences for chart footer$")
	public void right_click_and_then_click_on_display_preferences_for_chart_footer() throws Throwable {
		com.startAction();
		String rightclick = Common.readPropertyByChart().getProperty("rightclick");
		String DisplayPreferences = Common.readPropertyByChart().getProperty("DisplayPreferences");
		com.sleepThread(3000);
		com.Rightclick("xpath", rightclick, "ILTC-00023,Charts,Right click on charts");
		com.sleepThread(3000);
		com.click("xpath", DisplayPreferences, "ILTC-00026,Charts,Click on Display references for footer");
	}

	@Then("^Click on Header/Footer and click on Show Footer in chart footer$")
	public void click_on_Header_Footer_and_click_on_Show_Footer_in_chart_footer() throws Throwable {
		String Headerorfooter = Common.readPropertyByChart().getProperty("Headerorfooter");
		String showfooter = Common.readPropertyByChart().getProperty("showfooter");
		com.sleepThread(3000);
		com.click("xpath", Headerorfooter, "ILTC-00026,Charts,Click on Header/Footer");
		com.sleepThread(3000);
		com.click("xpath", showfooter, "ILTC-00026,Charts,Click on Show footer in chart footer");
	}

	@Then("^Click on Ok and then verify the footer in the chart$")
	public void click_on_Ok_and_then_verify_the_footer_in_the_chart() throws Throwable {
		String Displaypreferencesok = Common.readPropertyByChart().getProperty("Displaypreferencesok");
		String Footertext = Common.readPropertyByChart().getProperty("Footertext");
		com.sleepThread(3000);
		com.click("xpath", Displaypreferencesok, "ILTC-00026,Charts,Click on ok in display preferences");
		com.sleepThread(3000);
		String footertext = "Symbol:";
		com.verifyText("xpath", Footertext, footertext, "ILTC-00030,Charts,Verify whether footer is displayed or not");
	}
	
	@Given("^Right click on the title toolbar options$")
	public void Right_click_on_title_toolbar_options() throws Exception {
		com.startAction();
		String rightclick = Common.readPropertyByChart().getProperty("rightclick");
		com.Rightclick("xpath", rightclick, "ICTC-00188,Charts,Right click on title-toolbar options");
	}
	
	@Then("^verifying the View option$")
	public void verify_the_View_option() throws Exception {
		String View = Common.readPropertyByChart().getProperty("View");
		com.verifyElementPresent("xpath", View,
				"ICTC-00189,Charts,verify the View option");

	}
	
	@Then("^Click on the submenus in view option and verify each submenu$")
	public void Click_on_the_submenus_in_view_option() throws Exception {
		com.startAction();
		String click = Common.readPropertyByChart().getProperty("click");
		String View = Common.readPropertyByChart().getProperty("View");
		com.MouseOverToElement("xpath", View, "ICTC-00189,Chart,mouse over on view option");
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li"))
				.size();
		System.out.println(size);
		for (int i = 1; i <= size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[" + i + "]",
					"ICTC-00190,Charts,Click on submenus in view option");
			com.sleepThread(2000);
			com.startAction();
			String second_widget = Common.readPropertyByChart().getProperty("second_widget");
			String widgetname = driver.findElement(By.xpath(Common.readPropertyByChart().getProperty("second_widget"))).getText();
			com.verifyText("xpath", second_widget, widgetname, "ICTC-00189,Chart,Verify " + widgetname + " widget name");
			com.Rightclick("xpath", second_widget, "ICTC-00189,Chart,Right click on new widget name");
			com.sleepThread(1000);
			String closetab = Common.readPropertyByChart().getProperty("closetab");
			com.click("xpath", closetab, "ICTC-00189,Chart,Click on Close Tab and verify the tab is closing or not");
			com.sleepThread(5000);
			String rightclick = Common.readPropertyByChart().getProperty("rightclick");
			com.Rightclick("xpath", rightclick,
					"ICTC-00196,Charts,Right click on title-toolbar options");
			com.MouseOverToElement("xpath", View, "ICTC-00189,Chart,mouse over on view option");
       
		}
		com.sleepThread(4000);
		com.click("xpath", View, ",Chart,Click on view");
	}
	
	//time interval
    @Given("^Click on submenus in Time interval option and verify sub menu text$")
    public void Click_on_submenus_in_Time_interval_and_verify_text() throws Exception {
	    com.startAction();
	    String Timeintervalclick= Common.readPropertyByChart().getProperty("Timeintervalclick");
	    com.sleepThread(6000);
	    com.MouseOverToElement("xpath", Timeintervalclick, ",Chart,Mouse hover on Time-Interval");
	    com.sleepThread(3000);
	    com.click("xpath", Timeintervalclick, ",Chart,Click on Time-Interval");
	    int size = driver.findElements(By.xpath("/html/body/div[4]/div/span/div/div/div[2]/div/div/div")).size();
	    for (int i = 1; i <= size; i++) {
		com.click("xpath","/html/body/div[4]/div/span/div/div/div[2]/div/div/div[" + i + "]",
				"ICTC-00190,Charts,Click on submenus in Time Interval option");
		com.sleepThread(5000);
		String Timeintervalname= Common.readPropertyByChart().getProperty("Timeintervalname");
		String intervalname= driver.findElement(By.xpath(Common.readPropertyByChart().getProperty("Timeintervalname"))).getText();
		com.verifyText("xpath", Timeintervalname, intervalname, "ICTC-00189,Chart,Verify " + intervalname + " is displayed");
		com.sleepThread(4000);
		com.click("xpath", Timeintervalclick, ",Chart,Click on Time-Interval");
		com.sleepThread(4000);
	   }
	    com.sleepThread(4000);
		com.click("xpath", Timeintervalclick, ",Chart,Click on Time-Interval");
    }
    
    //Chart All
    @Given("^Click on Chart All check box$")
    public void click_on_Chart_All_check_box() throws Throwable {
    	String ChartAll= Common.readPropertyByChart().getProperty("ChartAll");
    	com.sleepThread(4000);
		com.click("xpath", ChartAll, ",Chart,Click on view");
    }

    @Then("^Clear the symbol input and enter the symbol \"([^\"]*)\"$")
    public void clear_the_symbol_input_and_enter_the_symbol(String symbol) throws Throwable {
    	String symbolinput= Common.readPropertyByChart().getProperty("symbolinput");
    	com.sleepThread(4000);
		com.ClearTextField("xpath", symbolinput, ",Chart,Click on view");
		com.sleepThread(4000);
		com.sendKeys("xpath", symbolinput, symbol,
				"ILTC-00024,Charts,Enter the symbol");
    }

    @Then("^Select the symbol from dropdown$")
    public void select_the_symbol_from_dropdown() throws Throwable {
    	String ChartAllSymboldropdown= Common.readPropertyByChart().getProperty("ChartAllSymboldropdown");
    	com.sleepThread(4000);
		com.click("xpath", ChartAllSymboldropdown, ",Chart,Click on symbol dropdown");
    }

    @Then("^Verify the added symbol as overlay in chart all$")
    public void verify_the_added_symbol_as_overlay_in_chart_all() throws Throwable {
    	String overlaydispalysymbol1= Common.readPropertyByChart().getProperty("overlaydispalysymbol1");
    	String overlaydisplaysymbol2= Common.readPropertyByChart().getProperty("overlaydisplaysymbol2");
    	String symbol1text = "INTERNATIONAL BUSINESS MACHS";
    	String Symbol2text = "APPLE INC";
		com.verifyText("xpath", overlaydispalysymbol1, symbol1text, "ICTC-00189,Chart,Verify symbol one is displayed or not");
		com.verifyText("xpath", overlaydisplaysymbol2, Symbol2text, "ICTC-00189,Chart,Verify symbol two is displayed or not");
    }
    
    @Then("^Remove the Added overlay symbol$")
    public void remove_the_Added_overlay_symbol() throws Throwable {
    	com.startAction();
    	String removeoverlaypane1 = Common.readPropertyByChart().getProperty("removeoverlaypane1");
		String Rightclickoverlaypane1 = Common.readPropertyByChart().getProperty("Rightclickoverlaypane1");
		com.sleepThread(3000);
		com.Rightclick("xpath", Rightclickoverlaypane1, "ILTC-00023,Charts,Right click on symbol in pane1");
		com.sleepThread(3000);
		com.click("xpath", removeoverlaypane1, "ILTC-00026,Charts,click on Remove symbol in pane 1");	
    }
	
	
    //Add
    //Add To New Pane
/*    @Given("^Right click and click on Data Cell$")
	public void right_click_and_click_on_Data_Cell() throws Throwable {
    	com.startAction();
    	String clickfordataview = Common.readPropertyByChart().getProperty("clickfordataview");
		String DataView = Common.readPropertyByChart().getProperty("DataView");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", clickfordataview, "ILTC-00023,Charts,mouse hover on charts title bar");
		com.sleepThread(1000);
		com.click("xpath", clickfordataview, "ILTC-00023,Charts,click on charts title bar");
		com.sleepThread(3000);
		com.click("xpath", DataView, "ILTC-00026,Charts,click on data cell");	
	}*/
    
	@Given("^Right click on existing pane and click on remove$")
	public void right_click_on_existing_pane_Click_on_remove() throws Exception {
		com.startAction();
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
		String Removeexistingpane = Common.readPropertyByChart().getProperty("Removeexistingpane");
		com.sleepThread(3000);
		com.Rightclick("xpath", existingpane, "ILTC-00023,Charts,Right click on existing pane");
		com.sleepThread(3000);
		com.click("xpath", Removeexistingpane, "ILTC-00026,Charts,click on remove in existing pane");	
	}
	
    @Then("^Click on Add and then click on Add to new pane$")
    public void click_on_Add_and_then_click_on_Add_to_new_pane() throws Throwable {
    	com.startAction();
    	String Add = Common.readPropertyByChart().getProperty("Add");
		String AddToNewPane = Common.readPropertyByChart().getProperty("AddToNewPane");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Add, "ILTC-00026,Charts,Mouse hover on Add");
		com.sleepThread(3000);
		com.click("xpath", Add, "ILTC-00026,Charts,Click on Add");
		com.sleepThread(3000);
		com.click("xpath", AddToNewPane, "ILTC-00026,Charts,Click on Add to new pane");
    }

    @Then("^Verify whether symbol chart is opened in the new pane or not$")
    public void verify_whether_symbol_chart_is_opened_in_the_new_pane_or_not() throws Throwable {
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
		com.sleepThread(3000);
		String newpanetext = "APPLE INC";
		com.verifyText("xpath", existingpane, newpanetext, "ILTC-00030,Charts,Verify whether new pane is opened or not");
    }

    @Then("^Right click on new pane and click on remove$")
    public void right_click_on_new_pane_click_remove() throws Throwable {
    	com.startAction();
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
		String Removeexistingpane = Common.readPropertyByChart().getProperty("Removeexistingpane");
		com.sleepThread(3000);
		com.Rightclick("xpath", existingpane, "ILTC-00023,Charts,Right click on existing pane");
		com.sleepThread(3000);
		com.click("xpath", Removeexistingpane, "ILTC-00026,Charts,click on remove in existing pane");	
    }
    
    //Add As Overlay
    @Given("^Clear existing symbol and enter the new symbol \"([^\"]*)\"$")
    public void clear_existing_symbol_and_enter_the_new_symbol(String symbol) throws Throwable {
    	String symbolinput = Common.readPropertyByChart().getProperty("symbolinput");
		com.sleepThread(5000);
		com.ClearTextField("xpath", symbolinput, "ILTC-00026,Charts,Clear the symbol input");
		com.sleepThread(3000);
		com.sendKeys("xpath", symbolinput, symbol, "ILTC-00026,Charts,Enter the symbol to add as overlay");
    }
    
    @Then("^Click on Add and then click on Add as overlay$")
    public void click_on_Add_and_then_click_on_Add_as_overlay() throws Throwable {
    	com.startAction();
    	String Add = Common.readPropertyByChart().getProperty("Add");
		String Addasoverlay = Common.readPropertyByChart().getProperty("Addasoverlay");
		com.sleepThread(4000);
		com.MouseOverToElement("xpath", Add, "ILTC-00026,Charts,Mouse hover on Add");
		com.sleepThread(3000);
		com.click("xpath", Add, "ILTC-00026,Charts,Click on Add");
		com.sleepThread(3000);
		com.click("xpath", Addasoverlay, "ILTC-00026,Charts,Click on Add As Overlay");
    }

    @Then("^Verify whether symbol chart is opened in the pane one or not$")
    public void verify_whether_symbol_chart_is_opened_in_the_pane_one_or_not() throws Throwable {
    	String Overlayinpane1 = Common.readPropertyByChart().getProperty("Overlayinpane1");
		com.sleepThread(3000);
		String newpanetext = "APPLE INC";
		com.verifyText("xpath", Overlayinpane1, newpanetext, "ILTC-00030,Charts,Verify wether symbol chart is opened in pane one or not");
    }

    @Then("^Right click on overlay pane and click on remove$")
    public void right_click_on_overlay_pane_and_click_on_remove() throws Throwable {
    	com.startAction();
    	String Overlayinpane1 = Common.readPropertyByChart().getProperty("Overlayinpane1");
		String removeoverlaypane1 = Common.readPropertyByChart().getProperty("removeoverlaypane1");
		com.sleepThread(3000);
		com.Rightclick("xpath", Overlayinpane1, "ILTC-00023,Charts,Right click on existing pane");
		com.sleepThread(3000);
		com.click("xpath", removeoverlaypane1, "ILTC-00026,Charts,click on remove in existing pane");	
    }
    
    //Add to existing scale
    @Given("^Clear the existing symbol and enter the new symbol \"([^\"]*)\"$")
    public void clear_the_existing_symbol_and_enter_the_new_symbol(String symbol) throws Throwable {
    	String symbolinput = Common.readPropertyByChart().getProperty("symbolinput");
		com.sleepThread(5000);
		com.ClearTextField("xpath", symbolinput, "ILTC-00026,Charts,Clear the symbol input");
		com.sleepThread(3000);
		com.sendKeys("xpath", symbolinput, symbol, "ILTC-00026,Charts,Enter the symbol to add as overlay");
    }

    @Then("^Click on Add and then click on Add to existing scale$")
    public void click_on_Add_and_then_click_on_Add_to_existing_scale() throws Throwable {
    	com.startAction();
    	String Add = Common.readPropertyByChart().getProperty("Add");
		String Addtoexistingscale = Common.readPropertyByChart().getProperty("Addtoexistingscale");
		com.sleepThread(4000);
		com.MouseOverToElement("xpath", Add, "ILTC-00026,Charts,Mouse hover on Add");
		com.sleepThread(3000);
		com.click("xpath", Add, "ILTC-00026,Charts,Click on Add");
		com.sleepThread(3000);
		com.click("xpath", Addtoexistingscale, "ILTC-00026,Charts,Click on Add to Existing Scale");
    }

    @Then("^Verify whether the symbol chart is opened in the pane one or not$")
    public void verify_whether_the_symbol_chart_is_opened_in_the_pane_one_or_not() throws Throwable {
    	String existingscaleoverlaypane = Common.readPropertyByChart().getProperty("existingscaleoverlaypane");
		com.sleepThread(3000);
		String newpanetext = "MICROSOFT CORP";
		com.verifyText("xpath", existingscaleoverlaypane, newpanetext, "ILTC-00030,Charts,Verify wether symbol chart is opened in pane one or not");
    }

    @Then("^Right click on the overlay pane and click on remove$")
    public void right_click_on_the_overlay_pane_and_click_on_remove() throws Throwable {
    	com.startAction();
    	String existingscaleoverlaypane = Common.readPropertyByChart().getProperty("existingscaleoverlaypane");
		String removeoverlaypane1 = Common.readPropertyByChart().getProperty("removeoverlaypane1");
		com.sleepThread(3000);
		com.Rightclick("xpath", existingscaleoverlaypane, "ILTC-00023,Charts,Right click on Overlay pane pane");
		com.sleepThread(3000);
		com.click("xpath", removeoverlaypane1, "ILTC-00026,Charts,click on remove in overlay pane");
    }
    
    //Studies
    @Given("^Click on studies and click on required to add$")
    public void click_on_studies_and_click_on_required_to_add() throws Throwable {
    	com.startAction();
    	String Studies = Common.readPropertyByChart().getProperty("Studies");
		String Accumulationordistribution = Common.readPropertyByChart().getProperty("Accumulationordistribution");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Studies, "ILTC-00023,Charts,Mouse hover on Studies");
		com.sleepThread(3000);
		com.click("xpath", Studies, "ILTC-00023,Charts,click on Studies");
		com.sleepThread(3000);
		com.click("xpath", Accumulationordistribution, "ILTC-00026,Charts,click on Required studies");
    }

    @Then("^Click on Add button in studies$")
    public void click_on_Add_button_in_studies() throws Throwable {
    	String AddStudies = Common.readPropertyByChart().getProperty("AddStudies");
		com.sleepThread(3000);
		com.click("xpath", AddStudies, "ILTC-00023,Charts,click on Studies");
    }

    @Then("^Verify whether the studies is opened in the new pane or not$")
    public void verify_whether_the_studies_is_opened_in_the_new_pane_or_not() throws Throwable {
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
		com.sleepThread(3000);
		String newpanetext = "ADL (IBM)";
		com.verifyText("xpath", existingpane, newpanetext, "ILTC-00030,Charts,Verify whether new pane is opened or not");
    }

    @Then("^Right click on the overlay pane studies and click on remove$")
    public void right_click_on_the_overlay_pane_studies_and_click_on_remove() throws Throwable {
    	com.startAction();
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
		String Removeexistingpane = Common.readPropertyByChart().getProperty("Removeexistingpane");
		com.sleepThread(3000);
		com.Rightclick("xpath", existingpane, "ILTC-00023,Charts,Right click on studies in existing pane");
		com.sleepThread(3000);
		com.click("xpath", Removeexistingpane, "ILTC-00026,Charts,click on remove studies in the pane");	
    }
    
    //Comparision
    @Given("^Click on compare and click on indices$")
    public void click_on_compare_and_click_on_indices() throws Throwable {
    	com.startAction();
    	String Compare = Common.readPropertyByChart().getProperty("Compare");
		String Indicesforcomparision = Common.readPropertyByChart().getProperty("Indicesforcomparision");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Compare, "ILTC-00023,Charts,Mouse hover on compare");
		com.sleepThread(2000);
		com.click("xpath", Compare, "ILTC-00023,Charts,click on compare");
		com.sleepThread(4000);
		com.click("xpath", Indicesforcomparision, "ILTC-00026,Charts,click on indices for comparision");
    }

    @Then("^Click on Add and then click on Add to New Pane$")
    public void click_on_Add_and_then_click_on_Add_to_New_Pane() throws Throwable {
    	com.startAction();
    	String Addcomparision = Common.readPropertyByChart().getProperty("Addcomparision");
		String Addtonewpanecomparision = Common.readPropertyByChart().getProperty("Addtonewpanecomparision");
		com.sleepThread(3000);
		com.MouseOverToElement("xpath", Addcomparision, "ILTC-00023,Charts,Mouse hover on Add comparision");
		com.sleepThread(2000);
		com.click("xpath", Addcomparision, "ILTC-00023,Charts,click on Add comparision");
		com.sleepThread(4000);
		com.click("xpath", Addtonewpanecomparision, "ILTC-00026,Charts,click on Add to new pane for comparision");
    }

    @Then("^Verify the newly added comparision indices and remove the indices$")
    public void verify_the_newly_added_comparision_indices_and_remove_the_indices() throws Throwable {
    	String existingpane = Common.readPropertyByChart().getProperty("existingpane");
    	String Removeexistingpane = Common.readPropertyByChart().getProperty("Removeexistingpane");
		com.sleepThread(4000);
		String newpanetext = "S & P 500 INDEX";
		com.verifyText("xpath", existingpane, newpanetext, "ILTC-00030,Charts,Verify wether indeces is added or not for comparision");
		com.sleepThread(4000);
		com.Rightclick("xpath", existingpane, "ILTC-00026,Charts,Right click on added indices");
		com.sleepThread(4000);
		com.click("xpath", Removeexistingpane, "ILTC-00026,Charts,click on Remove indices");
    }
    
    @Given("^Clear the symbol input and enter the new symbol \"([^\"]*)\" to add as overlay$")
    public void clear_the_symbol_input_and_enter_the_new_symbol_to_add_as_overlay(String symbol) throws Throwable {
    	String symbolinput = Common.readPropertyByChart().getProperty("symbolinput");
		com.sleepThread(4000);
		com.ClearTextField("xpath", symbolinput, "ILTC-00023,Charts,Mouse hover on Add comparision");
		com.sleepThread(4000);
		com.sendKeys("xpath", symbolinput, symbol, "ILTC-00026,Charts,Enter the new symbol");
    }

    @Then("^Click on dropdown to add the symbol and click on clear chart$")
    public void click_on_dropdown_to_add_the_symbol_and_click_on_clear_chart() throws Throwable {
    	com.startAction();
    	String clearchartsymboldropdwon = Common.readPropertyByChart().getProperty("clearchartsymboldropdwon");
    	String ClearChart = Common.readPropertyByChart().getProperty("ClearChart");
    	com.sleepThread(4000);
		com.MouseOverToElement("xpath", clearchartsymboldropdwon, "ILTC-00023,Charts,click on new symbol dropdown");
		com.sleepThread(1000);
		com.click("xpath", clearchartsymboldropdwon, "ILTC-00023,Charts,click on new symbol dropdown");
		com.sleepThread(4000);
		com.click("xpath", ClearChart, "ILTC-00026,Charts,Click on clear chart");
    }

    @Then("^Verify whether the chart is cleared or not$")
    public void verify_whether_the_chart_is_cleared_or_not() throws Throwable {
    	String overlayclearchart = Common.readPropertyByChart().getProperty("overlayclearchart");
		com.sleepThread(3000);
		String newpanetext = "ORACLE CORP";
		//com.verifyTextnotdisplaying("xpath", overlayclearchart, newpanetext, "ILTC-00030,Charts,Verify whether chart is cleared or not");
    }
}
