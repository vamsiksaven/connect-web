/*package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class V_options {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public V_options Opt;
	public V_options() {
		driver = Common.driver;
	}
	
	@Given("^Clicked on options widget$")
	//Options
	public void Clicked_on_options_widget() throws Exception
	{
		//Clicking on + icon to add new widget
        String Add_Widget=Common.V_readPropertyByoptions().getProperty("Add_Widget");
        com.click("xpath",Add_Widget,"clicked on + icon");
        Thread.sleep(2000);
      	//Clicking on DQ  		        		      		        
        String Options=Common.V_readPropertyByoptions().getProperty("Options");
        com.click("xpath",Options,",options,Clicked on options widget");
        Thread.sleep(1000);
        System.out.println("Clicked on options widget");

       // String Options = Common.V_readPropertyByoptions().getProperty("Options");
	}
	
	
	
		//Options Filters Dropdown.
	
	@And("^Clicked on All Expirations option in dropdown$")
	public void Clicked_on_All_Expirations_option_in_dropdown() throws Exception
	{
	
		String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
        //Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
        com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
        Thread.sleep(2000);
        
        String All_Expirations=Common.V_readPropertyByoptions().getProperty("All_Expirations");
    	//Next=Common.V_readPropertyByoptions().getProperty("Next");
        com.click("xpath",All_Expirations,"clicked on All Expirations");
        Thread.sleep(2000);
	
	
	}
	
	
	@And("^Click on next option in dropdown$")
	public void Click_on_next_option_in_dropdown() throws Exception
	{
	
		for(int i=1;i<=6;i++)
        {
			com.startAction();	
			Thread.sleep(5000);
			
		    String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            //Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
            Thread.sleep(2000);
            
            String Next=Common.V_readPropertyByoptions().getProperty("Next");
        	//Next=Common.V_readPropertyByoptions().getProperty("Next");
            com.mouseovercontextClick("xpath",Next,"mouse hover on Next dropdown");
            Thread.sleep(2000);
            
            com.click("xpath","//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li["+i+"]","clicking on next submenus");
            Thread.sleep(2000);
        }  
		System.out.println("Checked filters next dropdown");
	}
		
	@When("^Clicked on Weekly option in dropdown$")
	public void Clicked_on_Weekly_option_in_dropdown() throws Exception
	{
		
		for(int i=1;i<=1;i++)
        {
			
			com.startAction();	
			Thread.sleep(5000);
			
		    String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            //Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
            Thread.sleep(2000);	
			
            
            String Weekly=Common.V_readPropertyByoptions().getProperty("Weekly");
            com.mouseovercontextClick("xpath",Weekly,"mouse hover on Weekly dropdown");
            Thread.sleep(2000);
            
            com.click("xpath","//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li["+i+"]","clicking on next submenus");
            Thread.sleep(2000);
            
        	
        }
	
		System.out.println("Checked filters weekly dropdown");
	
	}
	
	@When("^Clicked on monthly option in dropdown$")
	public void Clicked_on_monthly_option_in_dropdown() throws Exception
	{

		for(int i=1;i<=7;i++)
        {
			com.startAction();	
			Thread.sleep(5000);
			
			String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
            Thread.sleep(2000);
            
            String Monthly=Common.V_readPropertyByoptions().getProperty("Monthly");
            com.mouseovercontextClick("xpath",Monthly,"mouse hover on Monthly dropdown");
            Thread.sleep(2000);
            
            com.click("xpath","//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li["+i+"]","clicking on monthly submenus");
        	 
            Thread.sleep(700);
            
            String Out_Area=Common.V_readPropertyByoptions().getProperty("Out_Area");
            com.click("xpath",Out_Area,"clicking on outside submenus");
            
            Thread.sleep(900);
        }
		
	System.out.println("Checked filters monthly dropdown");
	
	}
	
	@When("^Clicked on specific dates option in dropdown$")
	public void Clicked_on_specific_dates_option_in_dropdown() throws Exception
	{
		
		String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
        
        String Specific_Dates=Common.V_readPropertyByoptions().getProperty("Specific_Dates");
                    
        for(int i=2;i<=7;i++)
        {
        	
        	com.startAction();	
			Thread.sleep(5000);
			
        	//String Filter_Dropdown=Common.V_readPropertyByoptions().getProperty("Filter_Dropdown");
            com.click("xpath",Filter_Dropdown,"clicked on Filter dropdown");
            Thread.sleep(2000);
            
            //String Specific_Dates=Common.V_readPropertyByoptions().getProperty("Specific_Dates");
            com.MouseOverToElement("xpath",Specific_Dates,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            com.MouseOverToclickabl("xpath","//*[contains(@class,'pt-overlay pt-overlay-open pt-overlay-inline')]/span/div/div/div[2]/ul/li["+i+"]","clicking on specific_datessubmenus");    
            
            Thread.sleep(700);
            
            String Out_Area=Common.V_readPropertyByoptions().getProperty("Out_Area");
            com.click("xpath",Out_Area,"clicking on outside submenus");
            
            Thread.sleep(900);
            
        }
        
        System.out.println("Tested Filters option by selecting different Specific dates Also Checked options like Next, Weekly, Monthly options are working as intended.");
	}

	
	
	@When("^Clicked on Refresh button$")
	//Options
	public void Clicked_on_Refresh_button() throws Exception
	{
		
		String Refresh=Common.V_readPropertyByoptions().getProperty("Refresh");
        com.click("xpath",Refresh,"clicked on refersh button");
        Thread.sleep(2000);
        
        String Strike=Common.V_readPropertyByoptions().getProperty("Strike");
        //com.click("xpath",Strike,"clicked on strike button");
        Thread.sleep(2000);
		System.out.println("Tested Refresh button  it is functioning as intended");
	}
	
	@When("^Clicked on Filter button$")
	//Options
	public void Clicked_on_Filter_button() throws Exception
	{
		String Filter=Common.V_readPropertyByoptions().getProperty("Filter");
		com.click("xpath",Filter,"clicked on Filter button");
		
		String Strike=Common.V_readPropertyByoptions().getProperty("Strike");
		if(Strike != null)
        {
        System.out.println("Filter button is working fine.");
        
        }
        else
        {
        System.out.println("Filter button is not working.");
        }
		
		//String Filter=Common.V_readPropertyByoptions().getProperty("Filter");
        com.click("xpath",Filter,"clicked_on_Filter_button");
        Thread.sleep(2000);
        
        //String Strike=Common.V_readPropertyByoptions().getProperty("Strike");
        
        if(Strike != null)
        {
        System.out.println("Filter button is working fine.");
        
        }
        else
        {
        System.out.println("Filter button is not working.");
        }
        
		
		System.out.println("Checked whether the Show/Hide Filter button is working or not");
	}
	
	@Given("^Checking Symbol Quotes heading$")
	//Options
	public void Checking_Symbol_Quotes_heading() throws Exception
	{
		 String Symbol_data=Common.V_readPropertyByoptions().getProperty("Symbol_data");
		 com.click("xpath",Symbol_data,"clicked_on_symbol_data");
		
		 String Symbol_Quotes=Common.V_readPropertyByoptions().getProperty("Symbol_Quotes");
		 
		if(Symbol_Quotes != null)
        {
        System.out.println("Symbol quotes opened successfully");
        
        }
        else
        {
        System.out.println("Symbol quotes didnot opened");
        }
		
		//String Symbol_data=Common.V_readPropertyByoptions().getProperty("Symbol_data");
        com.click("xpath",Symbol_data,"clicked on symbol quotes heading");
        Thread.sleep(2000);
        
        //String Symbol_Quotes=Common.V_readPropertyByoptions().getProperty("Symbol_Quotes");
        
		System.out.println("Checked whether the symbol Quote fields are displaying or not");
		
		
	}
	
	//Right click
	@And("^clicked on view chart and other widgets$")
	//Options
	public void clicked_on_view_chart_and_other_widgest() throws Exception 
	{
		for(int i=1;i<=2;i++)
        {	
			com.startAction();	
			
			Thread.sleep(1000);    
        	
        	String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String View=Common.V_readPropertyByoptions().getProperty("View");
            //String Specific_Dates=Common.V_readPropertyByoptions().getProperty("Specific_Dates");
            com.mouseovercontextClick("xpath",View,"mouse hover on view");
            Thread.sleep(2000);
            
            com.click("xpath","//*[@id='container']/div//div[5]/div/ul/li[1]/div/ul/li["+i+"]/button","clicking on specific_datessubmenus");    
        	
            String Back=Common.V_readPropertyByoptions().getProperty("Back");
            com.click("xpath",Back,"getting back to options");
        	        	
        	Thread.sleep(1000);
        	
        
        }
		System.out.println("Checked View option");
	}
		
		@And("^Clicked on insert column$")
		//Options
		public void Clicked_on_insert_column() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
			String Insert=Common.V_readPropertyByoptions().getProperty("Insert");
			com.click("xpath",Insert,"inserting new row");
			Thread.sleep(100);
			
			String Insert_Column=Common.V_readPropertyByoptions().getProperty("Insert_Column");
			com.click("xpath",Insert_Column,"inserting new row");
			Thread.sleep(100);
			
			String Add_Column_Ok=Common.V_readPropertyByoptions().getProperty("Add_Column_Ok");
			com.click("xpath",Add_Column_Ok,"click OK");
			
			System.out.println("Checked insert option");
			
		}
		
		@And("^Clicked on Delete Inserted columns$")
		//Options
		public void Clicked_on_Delete_Inserted_columns() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
			String Delete_column=Common.V_readPropertyByoptions().getProperty("Delete_column");
			com.click("xpath",Delete_column,"Deleting inserted rows");
			
			System.out.println("Checked delete option");
			
		}
		

		@And("^Clicked on Copy as text$")
		//Options
		public void Clicked_on_Copy_as_text() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String Edit=Common.V_readPropertyByoptions().getProperty("Edit");
            com.mouseovercontextClick("xpath",Edit,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            String Copy_As_Text=Common.V_readPropertyByoptions().getProperty("Copy_As_Text");
            com.click("xpath",Copy_As_Text,"clicking on Copy As Text");    
			
            System.out.println("Checked copy as text option");
		}
		
		@And("^Clicked on select all$")
		//Options
		public void Clicked_on_select_all() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String Edit=Common.V_readPropertyByoptions().getProperty("Edit");
            com.mouseovercontextClick("xpath",Edit,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            String Select_All=Common.V_readPropertyByoptions().getProperty("Select_All");
            com.click("xpath",Select_All,"clicking on select all");    
			
            System.out.println("Checked select all options");
		}
		
		@And("^Clicked on clear selection$")
		//Options
		public void Clicked_on_clear_selection() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String Edit=Common.V_readPropertyByoptions().getProperty("Edit");
            com.mouseovercontextClick("xpath",Edit,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            String Clear_Selection=Common.V_readPropertyByoptions().getProperty("Clear_Selection");
            com.click("xpath",Clear_Selection,"clicking on clear selection");    
			
            System.out.println("Checked clear option");
		}
		
		@And("^Clicked on best fit$")
		//Options
		public void Clicked_on_best_fit() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String Edit=Common.V_readPropertyByoptions().getProperty("Edit");
            com.mouseovercontextClick("xpath",Edit,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            String Best_Fit_Symbol=Common.V_readPropertyByoptions().getProperty("Best_Fit_Symbol");
            com.click("xpath",Best_Fit_Symbol,"clicking on Copy As Text");    
			
            System.out.println("Checked best fit option");
		}
		
		@And("^Clicked on best fit all columns$")
		//Options
		public void Clicked_on_best_fit_all_columns() throws Exception
		{
			com.startAction();	
			Thread.sleep(1000);
			
			String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
            Thread.sleep(2000);
            
            String Edit=Common.V_readPropertyByoptions().getProperty("Edit");
            com.mouseovercontextClick("xpath",Edit,"mouse hover on Specific_Dates dropdown");
            Thread.sleep(2000);
            
            String Best_Fit_All_Columns=Common.V_readPropertyByoptions().getProperty("Best_Fit_All_Columns");
            com.click("xpath",Best_Fit_All_Columns,"clicking on best fit all");   
            
            System.out.println("Checked best fit all columns option");
			
		}
		
		@And("^Clicked on Show Selected Option Symbol Details$")
		//Options
		public void Clicked_on_Show_Selected_Option_Symbol_Details() throws Exception 
		{
	            
			    com.startAction();	
			    Thread.sleep(1000);
			
				String Show_Selected_Option_Symbol_Details=Common.V_readPropertyByoptions().getProperty("Show_Selected_Option_Symbol_Details");
	            //String Specific_Dates=Common.V_readPropertyByoptions().getProperty("Specific_Dates");
	            com.click("xpath",Show_Selected_Option_Symbol_Details,"Show Selected Option Symbol Details");
	            Thread.sleep(2000);
	            
	        
			String Verify_Show_Selected_Option_Symbol_Details=Common.V_readPropertyByoptions().getProperty("Verify_Show_Selected_Option_Symbol_Details");
			if( Verify_Show_Selected_Option_Symbol_Details!= null)
	        {
	        System.out.println("Show Selected Option Symbol Details is working");
	        
	        }
	        else
	        {
	        System.out.println("Show Selected Option Symbol Details is not working");
	        }
			System.out.println("Checked whether the Underlying Symbol Details and Show Selected Option Symbol Details were working or not");
			
		}
		
		@And("^clicked on save option properties as default$")
		public void clicked_on_save_option_properties_as_defaulty() throws Exception 
		{
			for(int i=1;i<=2;i++)
	        {	
				com.startAction();	
				Thread.sleep(1000); 
	        	
	        	String Right_click=Common.V_readPropertyByoptions().getProperty("Right_click");
	        	com.Rightclick("xpath",Right_click,"Right clicked on options data");
	            Thread.sleep(2000);
	            
	            String Defaults=Common.V_readPropertyByoptions().getProperty("Defaults");
	            //String Specific_Dates=Common.V_readPropertyByoptions().getProperty("Specific_Dates");
	            com.mouseovercontextClick("xpath",Defaults,"mouse hover on Specific_Dates dropdown");
	            Thread.sleep(2000);
	            
	            com.click("xpath","//*[@id=\"container\"]/div//div[5]/div/ul/li[13]/div/ul/li["+i+"]","clicking on Default options");    
	        	
	          
	        }
			System.out.println("Checked defaults");
		}
}
		
		
		
		
		
		
	

	
	
	
	*/