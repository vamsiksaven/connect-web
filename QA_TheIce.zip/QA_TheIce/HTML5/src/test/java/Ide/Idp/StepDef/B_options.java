/*package Ide.Idp.StepDef;

import java.awt.GraphicsConfiguration;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LIB.Common;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class B_options {
	private static final String Widget_name = null;
	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	public String login;
	public GraphicsConfiguration gc;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public B_options() {
		driver = Common.driver;
		login = Common.readPropertyByLogin().getProperty("Login_button");
	}

	// Verify_the_ligin_page_Logo
	@Given("^open the browser$")
	public void open_the_browser() throws Exception {
		// com.startRecording();
		com.Setup("Chrome", "ILTC-00001,Login,I have open the browser");
		com.starturl("https://connect-web.staging.dataservices.theice.com"); 
		//https://connect-web.qa.dataservices.theice.com/connectweb/		
		// https://ida-idp.qa.market-q.com/ida-idp/
		com.maximiseBrowser();

	}

	@When("^Verify the portal logo$")
	public void Verify_the_portal_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByLogin().getProperty("Logo");
		com.sleepThread(3000);
		com.verifyElementPresent("xpath", Applicationlogo, "ILTC-00002,Login,Verify the logo");

	}
    
	//Login
	@Given("^Login with IDE IDP credentials of Username \"(.*?)\" and Password \"(.*?)\"$")
	public void Login_with_IDE_IDP_credentials_of_Username_and_Password(String Username, String Password)
			throws Exception {
		un = Common.readPropertyByLogin().getProperty("User_name");
		Pws = Common.readPropertyByLogin().getProperty("Passwod");
		driver.navigate().refresh();
		com.sleepThread(1000);
		com.sendKeys("xpath", un, Username,
				"ILTC-00023,Login,Enter the correct username and are given in associated text fields");
		com.sendKeys("xpath", Pws, Password,
				"ILTC-00024,Login,Enter the correct password are given in associated text fields");
	}

	@Then("^Click on the login button$")
	public void click_login_button() throws Exception {
		com.sleepThread(2000);
		com.click("xpath", login, "ILTC-00025,Login,Click on login button");
		TimeUnit.MINUTES.sleep(1);
		// com.stopRecording();
	}
	
	//Options
	@Given("^Click on Options tab$")
	public void Click_on_Options_tab() throws Exception{
		String Options = Common.readPropertyByLogin().getProperty("Optionstab");
		com.sleepThread(3000);
		com.startAction();
		com.MouseOverToElement("xpath", Options, "ILTC-00026,Options,Mouse hover on Options tab");
		com.click("xpath", Options, "ILTC-00026,Options,Click on Options tab");
	}
	
	//Verify column set
	@Given("^Click on the default column set$")
	public void click_on_the_default_column_set() throws Throwable {
		String columnsetdropdown = Common.readPropertyByLogin().getProperty("columnsetdropdown");
		com.sleepThread(9000);
		com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on column set dropdown");			
		com.waitUntilElementPresent(columnsetdropdown);
		com.startAction();
		com.MouseOverToElement("xpath", columnsetdropdown, "ILTC-00030,Options,Click on New column set dropdown");
		
	}

	@Then("^select the column set for which you want to get results$")
	public void select_the_column_set_for_which_you_want_to_get_results() throws Throwable {
		String Defaultcolumnset = Common.readPropertyByLogin().getProperty("Defaultcolumnset");
		com.sleepThread(2000);
		com.click("xpath", Defaultcolumnset, "ILTC-00030,Options,Click on Default column set"); 
	}

	@Then("^Verify the columns whether they are from column set or not$")
	public void verify_the_columns_whether_they_are_from_column_set_or_not() throws Throwable {
		String Ask = Common.readPropertyByLogin().getProperty("Ask");
		String Bid = Common.readPropertyByLogin().getProperty("Bid");
		String Last = Common.readPropertyByLogin().getProperty("Last");
		String Netchange = Common.readPropertyByLogin().getProperty("Netchange");
		String OpenInterest = Common.readPropertyByLogin().getProperty("OpenInterest");
		com.sleepThread(5000);
		String AskYieldtext = "Ask";
		String BidYieldtext = "Bid";
		String Lasttext = "Last";
		String netchangetext = "Net Change";
		String Openinteresrtext = "Open Interest";
		com.verifyText("xpath", Bid, BidYieldtext, "ILTC-00030,Options,Verify Bid text column of Default column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Ask, AskYieldtext, "ILTC-00030,Options,Verify Ask text column of Deafult column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Last, Lasttext, "ILTC-00030,Options,Verify Last text column of Deafult column set");
		com.sleepThread(5000);
		com.verifyText("xpath", Netchange, netchangetext, "ILTC-00030,Options,Verify Net Change text column of Deafult column set and Deafult columns set verified");
		com.sleepThread(5000);
		com.verifyText("xpath", OpenInterest, Openinteresrtext, "ILTC-00030,Options,Verify open Interest text column of Deafult column set");
	}
	
	//Duplicate column set
			@Given("^Click on default column set and select New$")
			public void click_on_default_column_set_and_select_New() throws Throwable {
				String columnsetdropdown = Common.readPropertyByLogin().getProperty("columnsetdropdown");
				String NewColumnset = Common.readPropertyByLogin().getProperty("NewColumnset");
				com.sleepThread(6000);
				com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on Default column set");
				com.sleepThread(5000);
				//com.waitUntilElementPresent(NewColumnset);
				//com.startAction();
				//com.MouseOverToElement("xpath", NewColumnset, "ILTC-00030,Options,Click on New column set dropdown");
				com.click("xpath", NewColumnset, "ILTC-00030,Options,Click on New column set dropdown");
			}

			@Then("^Enter Name \"([^\"]*)\" of column set$")
			public void enter_Name_of_column_set(String Name) throws Throwable {
				String Nameinput = Common.readPropertyByLogin().getProperty("Nameinput");
				com.sleepThread(3000);
				com.sendKeys("xpath", Nameinput, Name, "ITLC-31,Options,Enter the name for column set");
			}

			@Then("^Select available columns and click right arrow$")
			public void select_available_columns_and_click_right_arrow() throws Throwable {
				String Optionsavailablecolumns = Common.readPropertyByLogin().getProperty("Optionsavailablecolumns");
				String OptionTypecolumn = Common.readPropertyByLogin().getProperty("OptionTypecolumn");
				String Strikecolumn = Common.readPropertyByLogin().getProperty("Strikecolumn");
				String rightarrow = Common.readPropertyByLogin().getProperty("rightarrow");
				com.sleepThread(5000);
				com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
				com.sleepThread(3000);
				com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
				com.sleepThread(4000);
				com.startAction();
				com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
				com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
				com.sleepThread(3000);
				com.click("xpath", Strikecolumn, "ITLC-35,Options,click on Strike in options");
				com.sleepThread(4000);
				com.startAction();
				com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
				com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");		
			}

			@Then("^click on save and again click on default$")
			public void click_on_save_and_again_click_on_default() throws Throwable {
				String savecolumnset = Common.readPropertyByLogin().getProperty("savecolumnset");
				String columnsetdropdown = Common.readPropertyByLogin().getProperty("columnsetdropdown");
				com.sleepThread(5000);
				com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set");
				com.sleepThread(5000);
				com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on default column set");
			}

			@Then("^Click on New and enter the SameName \"([^\"]*)\"$")
			public void click_on_New_and_enter_the_SameName(String SameName) throws Throwable {
				String NewColumnset = Common.readPropertyByLogin().getProperty("NewColumnset");
				String Nameinput = Common.readPropertyByLogin().getProperty("Nameinput");
				com.sleepThread(5000);
				com.click("xpath", NewColumnset, "ILTC-00029,Options,Click on New column set");
				com.sendKeys("xpath", Nameinput, SameName, "ITLC-35,Options,Verify entering symbol input");
			}

			@Then("^Add available columns by clicking on right arrow$")
			public void add_available_columns_by_clicking_on_right_arrow() throws Throwable {
				String Optionsavailablecolumns = Common.readPropertyByLogin().getProperty("Optionsavailablecolumns");
				String OptionTypecolumn = Common.readPropertyByLogin().getProperty("OptionTypecolumn");
				String underlyingsymbol = Common.readPropertyByLogin().getProperty("underlyingsymbol");
				String rightarrow = Common.readPropertyByLogin().getProperty("rightarrow");
				com.sleepThread(3000);
				com.click("xpath", Optionsavailablecolumns, "ITLC-32,Options,click on options in available columns");
				com.sleepThread(3000);
				com.click("xpath", OptionTypecolumn, "ITLC-35,Options,click on optiontype in options");
				com.sleepThread(4000);
				com.startAction();
				com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
				com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
				com.sleepThread(3000);
				com.click("xpath", underlyingsymbol, "ITLC-35,Options,click on underlyingsymbol in options");
				com.sleepThread(4000);
				com.startAction();
				com.MouseOverToElement("xpath", rightarrow, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
				com.click("xpath", rightarrow, "ITLC-35,Options,click on rightarrow to add columns");
			}

			@Then("^click on save and duplicate column set should not be added and click on cancel after verification$")
			public void click_on_save_and_duplicate_column_set_should_not_be_added() throws Throwable {
				String savecolumnset = Common.readPropertyByLogin().getProperty("savecolumnset");
				String cancelcolumnset = Common.readPropertyByLogin().getProperty("cancelcolumnset");
				com.sleepThread(5000);
				com.click("xpath", savecolumnset, "ILTC-00029,Options,Click on Save column set and colum set not added");
				com.sleepThread(9000);
				com.click("xpath", cancelcolumnset, "ILTC-00029,Options,Click on cancel column set");
			}
			
			//Edit columnset
			@Given("^Click on columnset dropdown and then click on manage column set$")
			public void click_on_columnset_dropdown_and_then_click_on_manage_column_set() throws Throwable {
				String columnsetdropdown = Common.readPropertyByLogin().getProperty("columnsetdropdown");
				String Managecolumnset = Common.readPropertyByLogin().getProperty("Managecolumnset");
				com.sleepThread(5000);
				com.click("xpath", columnsetdropdown, "ILTC-00029,Options,Click on Columnset");
				com.sleepThread(4000);
				com.click("xpath", Managecolumnset, "ILTC-00029,Options,Click on Manage column set");
			}

			@Then("^Select the column set that has to be edited and click on edit$")
			public void select_the_column_set_that_has_to_be_edited_and_click_on_edit() throws Throwable {
				String Customcolumnset = Common.readPropertyByLogin().getProperty("Customcolumnset");
				String Editcolumnset = Common.readPropertyByLogin().getProperty("Editcolumnset");
				com.sleepThread(5000);
				com.click("xpath", Customcolumnset, "ILTC-00029,Options,Click on custom Column set");
				com.sleepThread(4000);
				com.click("xpath", Editcolumnset, "ILTC-00029,Options,Click on Edit column set");
			}

			@Then("^clear the Name field and enter the New Name \"([^\"]*)\"$")
			public void clear_the_Name_field_and_enter_the_New_Name(String Name) throws Throwable {
				String EditNameinput = Common.readPropertyByLogin().getProperty("EditNameinput");
				//com.sleepThread(5000);
				//com.ClearTextField("xpath", EditNameinput, "ILTC-00029,Options,Clear name of column set");
				com.sleepThread(4000);
				com.sendKeys("xpath", EditNameinput, Name, "ITLC-35,Options,Verify entering Name input");
			}

			@Then("^Click on Save and verify the columnset name$")
			public void click_on_Save_and_verify_the_columnset_name() throws Throwable {
				String Editsavecolumnset = Common.readPropertyByLogin().getProperty("Editsavecolumnset");
				String Editedcustomcolumnset = Common.readPropertyByLogin().getProperty("Editedcustomcolumnset");
				String closecolumnset = Common.readPropertyByLogin().getProperty("closecolumnset");
				com.sleepThread(5000);
				com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
				com.sleepThread(4000);
				com.waitUntilElementPresent(Editedcustomcolumnset);
				String text ="WXYZINDI";
				com.verifyText("xpath", Editedcustomcolumnset, text, "ITLC-00029,Options, Verify Edited column set name");
				//com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on cancel column set");
			}
			
			//Copy colum set
			@Given("^Select the column set that has to be copied and Click on copy column set$")
			public void select_the_column_set_that_has_to_be_copied_and_Click_on_copy_column_set() throws Throwable {
				String Customcolumnset = Common.readPropertyByLogin().getProperty("Customcolumnset");
				String Copycolumnset = Common.readPropertyByLogin().getProperty("Copycolumnset");
				com.sleepThread(5000);
				com.click("xpath", Customcolumnset, "ILTC-00029,Options,Click on custom Column set");
				com.sleepThread(4000);
				com.click("xpath", Copycolumnset, "ILTC-00029,Options,Click on Copy column set");
			}

			@Then("^Clear the name and enter the new column set Name \"([^\"]*)\" and add column$")
			public void clear_the_name_and_enter_the_new_column_set_Name(String Name) throws Throwable {
				String EditNameinput = Common.readPropertyByLogin().getProperty("EditNameinput");
				String OptiontypeSN = Common.readPropertyByLogin().getProperty("OptiontypeSN");
				String rightarrowincopy = Common.readPropertyByLogin().getProperty("rightarrowincopy");
				String Optionscolumnsincopy = Common.readPropertyByLogin().getProperty("Optionscolumnsincopy");
				com.sleepThread(5000);
				com.ClearTextField("xpath", EditNameinput, "ILTC-00029,Options,Clear name of column set");
				com.sleepThread(4000);
				com.sendKeys("xpath", EditNameinput, Name, "ITLC-35,Options,Verify entering Name input");
				com.sleepThread(3000);
				com.click("xpath", Optionscolumnsincopy, "ITLC-32,Options,click on options in available columns");
				com.sleepThread(3000);
				com.click("xpath", OptiontypeSN, "ITLC-35,Options,click on optiontypeSN in options");
				com.sleepThread(4000);
				com.startAction();
				com.MouseOverToElement("xpath", rightarrowincopy, "ITLC-35,Options,Mouse hover on rightarrow to add columns");
				com.click("xpath", rightarrowincopy, "ITLC-35,Options,click on rightarrow to add columns");
			}

			@Then("^Click on save and verify the copied column set name$")
			public void click_on_save_and_verify_the_column_set_name() throws Throwable {
				String Editsavecolumnset = Common.readPropertyByLogin().getProperty("Editsavecolumnset");
				String Copiedcustomcolumnset = Common.readPropertyByLogin().getProperty("Copiedcustomcolumnset");
				String closecolumnset = Common.readPropertyByLogin().getProperty("closecolumnset");
				com.sleepThread(5000);
				com.click("xpath", Editsavecolumnset, "ILTC-00029,Options,Click on save column set");
				com.sleepThread(4000);
				com.waitUntilElementPresent(Copiedcustomcolumnset);
				String text ="LON";
				com.verifyText("xpath", Copiedcustomcolumnset, text, "ITLC-00029,Options, Verify Copied column set name");
			}
			
			//Delete column set
			@Given("^Click on delete and then click on Confirmatio ok button$")
			public void click_on_delete_and_then_click_on_Confirmatio_ok_button() throws Throwable {
				String Deletecolumnset = Common.readPropertyByLogin().getProperty("Deletecolumnset");
				String Columnsetdeleteconfirmation = Common.readPropertyByLogin().getProperty("Columnsetdeleteconfirmation");
				com.sleepThread(5000);
				com.click("xpath", Deletecolumnset, "ILTC-00029,Options,Click on Delete Column set");
				com.sleepThread(4000);
				com.click("xpath", Columnsetdeleteconfirmation, "ILTC-00029,Options,Click on Delete Confirmation");
			}

			@Then("^Verify whether the column set is deleted or not$")
			public void verify_whether_the_column_set_is_deleted_or_not() throws Throwable {
				String Deltedcolumnset = Common.readPropertyByLogin().getProperty("Deltedcolumnset");
				String closecolumnset = Common.readPropertyByLogin().getProperty("closecolumnset");
				com.sleepThread(4000);
				com.waitUntilElementPresent(Deltedcolumnset);
				String text ="LON";
				com.verifyText("xpath", Deltedcolumnset, text, "ITLC-00029,Options, Verify Deleted column set name");
				com.sleepThread(4000);
				com.click("xpath", closecolumnset, "ILTC-00029,Options,Click on Close");
			}
			
	
	//verify definition
	@Given("^Click on Bid and select Best Fit Bid$")
	public void Click_on_Bid_and_select_BestFitBid() throws Exception{
		String Bid = Common.readPropertyByLogin().getProperty("Bid");
		String Biddropdown = Common.readPropertyByLogin().getProperty("Biddropdown");
		String BestFitBid = Common.readPropertyByLogin().getProperty("BestFitBid");
		com.sleepThread(6000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		com.waitUntilElementPresent(BestFitBid);
		com.startAction();
		com.MouseOverToElement("xpath", BestFitBid, "ILTC-00028,Options,Mouse hover on Best Fit Bid");
		com.click("xpath", BestFitBid, "ILTC-00028,Options,Click on Best Fit Bid");
	}
	
	@Then("^Click on Bid and select Best Fit All columns$")
	public void Click_0n_Bid_and_select_BestFitAllColumns() throws Exception{
		String Bid = Common.readPropertyByLogin().getProperty("Bid");
		String Biddropdown = Common.readPropertyByLogin().getProperty("Biddropdown");
		String BestFitAllColums = Common.readPropertyByLogin().getProperty("BestFitAllColums");
		com.sleepThread(5000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.sleepThread(2000);
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		com.waitUntilElementPresent(BestFitAllColums);
		com.startAction();
		com.MouseOverToElement("xpath", BestFitAllColums, "ILTC-00028,Options,Mouse hover on Best Fit All Columns");
		com.click("xpath", BestFitAllColums, "ILTC-00028,Options,Click on Best Fit All Columns");
	}
	
	@Then("^Click on Bid and select View Definiton$")
	public void Click_0n_Bid_and_select_ViewDeifinition() throws Exception{
		String Bid = Common.readPropertyByLogin().getProperty("Bid");
		String Biddropdown = Common.readPropertyByLogin().getProperty("Biddropdown");
		String ViewDefinition = Common.readPropertyByLogin().getProperty("ViewDefinition");
		com.sleepThread(5000);
		com.startAction();
		com.MouseOverToElement("xpath", Bid, "ILTC-00027,Options,Click on Bid");
		com.click("xpath", Biddropdown, "ILTC-00027,Options,Click on Bid dropdown");
		com.sleepThread(3000);
		com.waitUntilElementPresent(ViewDefinition);
		com.startAction();
		com.MouseOverToElement("xpath", ViewDefinition, "ILTC-00028,Options,Mouse hover on View Definition");
		com.click("xpath", ViewDefinition, "ILTC-00028,Options,Click on View Definition");
		
	}
	
	@Then("^Verify Bid definition$")
	public void verify_bid_definition() throws Exception{
		String BidDefiniton = Common.readPropertyByLogin().getProperty("BidDefiniton");
		com.sleepThread(4000);
		com.waitUntilElementPresent(BidDefiniton);
		String text ="Bid price (highest available buying price)";
		com.verifyText("xpath", BidDefiniton, text, "ITLC-00029,Options, Verify Bid Definition");
	}

	//Symbol Verification
			@Given("^Clear the existing symbol and enter the symbol \"([^\"]*)\" for which you want to get result$")
			public void clear_the_existing_symbol_and_enter_the_symbol_for_which_you_want_to_get_result(String symbol) throws Throwable {
				String SymbolInput = Common.readPropertyByLogin().getProperty("SymbolInput");
				com.sleepThread(7000);
				com.waitUntilElementPresent(SymbolInput);
				com.ClearTextField("xpath", SymbolInput, "ITLC-34,Options,Verify Symbol input can be cleared or not");
				com.sleepThread(3000);
				com.sendKeys("xpath", SymbolInput, symbol, "ITLC-35,Options,Verify entering symbol input");
			}

			@Then("^Select the symbol from dropdown and the output should be displayed$")
			public void select_the_symbol_from_dropdown_and_the_output_should_be_displayed() throws Throwable {
				String Symboldropdown = Common.readPropertyByLogin().getProperty("Symboldropdown");
				com.sleepThread(6000);
				com.click("xpath", Symboldropdown, "ITLC-36,Options,Verify data is displayed or not by clciking on dropdown");
			}

			@Then("^verify whether the input symbol data is being displayed or not$")
			public void verify_whether_the_input_symbol_data_is_being_displayed_or_not() throws Throwable {
				String Icesymbol = Common.readPropertyByLogin().getProperty("Icesymbol");
				com.sleepThread(6000);
				String symboltext ="ICE";
				com.verifyText("xpath", Icesymbol, symboltext, "ITLC-00029,Options, User should get ICE symbol data");
			}
			
			
}
*/