package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//public class Fundamentals {
	public class Fundamentals {
		public Common com = new Common();
		public WebDriver driver;
		String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public Fundamentals() {
		driver = Common.driver;		
	}
	
	@Given("^Clicked on fundamentals widget\\.$")
	public void clicked_on_fundamentals_widget() throws Throwable {
		Thread.sleep(2000);
		com.startAction();
		//Clicking on + icon to add new widget
        String Add_Widget=Common.readPropertyByFundamentals().getProperty("Add_Widget");     
        //com.MouseOverToclickabl("xpath",Add_Widget,"clicked on + icon");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        com.click("xpath",Add_Widget,"clicked on + icon");
        Thread.sleep(200);
        
      	//Clicking on Fundamentals  		        		      		        
        String Fundamentals=Common.readPropertyByFundamentals().getProperty("Fundamentals");
        com.click("xpath",Fundamentals,"Clicked on Fundamentals widget");
        Thread.sleep(1000);
        System.out.println("Clicked on Fundamentals widget");
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	// driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).clear();
        String FDsymbolbox=Common.readPropertyByFundamentals().getProperty("FDsymbolbox");
        com.sendKeys("xpath", FDsymbolbox, Keys.CONTROL + "a", "clear text");
        com.sendKeys("xpath", FDsymbolbox, "ICE", "Enter symbol");
        com.sendKeys_fOR_Keybord("xpath", FDsymbolbox, Keys.ENTER , "Enter symbol");
        
        Thread.sleep(200);
	    
        //driver.navigate().refresh();
        
        Thread.sleep(2000);
             
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        
	}
        
    
        
	
	@Then("^check selected category text\\.$")
	public void check_selected_category_text() throws Throwable {
				
		 //driver.navigate().refresh();
		 Thread.sleep(2000);
		//Clicking on + icon to add new widget
        String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
        com.click("xpath",category_text,"checked text");
        Thread.sleep(2000);
        
        System.out.println("checked selected category text");
	     
        
	}
	
	
	
	@Given("^Clicked on corporate reference option and its sub options\\.$")
	public void clicked_on_corporate_reference_option_and_its_sub_options() throws Exception  {
	    		
		//int Widget_size=driver.findElements(By.xpath("//*[@id=\"11\"]/div[2]/div[2]/div//div[2]/div/div[1]/div[2]/ul/li[1]/div[2]/div/ul/li[1]")).size();
		for (int i = 1; i <= 4; i++) {
			
			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//com.MouseOverToclickabl("xpath","//*[@id='11']/div[2]/div[2]/div//div[2]/div/div[1]/div[2]/ul/li[1]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on corporate reference sub options");    
			com.click("xpath","//*[@id='119']/div[2]/div[2]/div//div[2]/div/div[1]/div[2]/ul/li[1]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on corporate reference sub options");
			//com.click("xpath","/html[1]/body[1]/div[1]//div[3]/div[1]//div[2]/div[2]/div[1]//div[2]/div[1]//div[2]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li[1]/div[1]/span[2]/div[1]","clicking on corporate reference sub options");
			Thread.sleep(500);
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			
			
		}
		System.out.println("checked Corporate_reference option");
	}

	@Then("^check any Corporate_reference option\\.$")
	public void Corporate_reference_option() throws Exception  {
	    // Write code here tht turns the phrase above into concrete actions
		    String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
	        com.click("xpath",category_text,"checked text");
	        Thread.sleep(2000);
	        System.out.println("checked text");
	    
	}

	@Given("^Clicked on Ownership option and its sub options\\.$")
	public void clicked_on_Ownership_option_and_its_sub_options() throws Exception  {
	    
		//int Widget_size=driver.findElements(By.xpath("//*[@id=\"11\"]/div[2]/div[2]/div//div[2]/div/div[1]/div[2]/ul/li[1]/div[2]/div/ul/li[1]")).size();
				for (int i = 1; i <= 2; i++) {
					
					Thread.sleep(1000);
					
					com.click("xpath","//*[@id='119']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div[2]/ul/li[2]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on corporate reference sub options");    
					
					//com.click("xpath","/html[1]/body[1]//div[3]/div[1]/div[1]/div[2]/div[2]/div[1]//div[1]/div[2]/div[1]//div[2]/ul[1]/li[2]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[2]/div[1]","clicking on corporate reference sub options");
					Thread.sleep(500);
					driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
					
				}
				System.out.println("checked Ownership_option");
				
	}

	
	@Then("^check any Ownership option\\.$")
	public void check_any_Ownership_option() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		    String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
	        com.click("xpath",category_text,"checked text");
	        Thread.sleep(2000);
	        System.out.println("checked text");
	    
	}
	
	@Given("^Clicked on corporate events option and its sub options\\.$")
	public void clicked_on_corporate_events_option_and_its_sub_options() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		
		for (int i = 1; i <= 2; i++) {
			
			Thread.sleep(100);
			
			com.click("xpath","//*[@id='119']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div[2]/ul/li[3]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on corporate reference sub options");    
			
			//com.click("xpath","/html[1]/body[1]/div[1]//div[3]/div[1]//div[2]//div[1]/div[1]//div[2]/div[1]/div[1]/div[2]/ul[1]/li[3]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[2]/div[1]","clicking on corporate reference sub options");    
			Thread.sleep(500);
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);		
			
			
		}
		System.out.println("checked corporate events option");
	}
	
	@Then("^check any Corporate_events option\\.$")
	public void check_any_Corporate_events_option() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		    String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
	        com.click("xpath",category_text,"checked text");
	        Thread.sleep(2000);
	        System.out.println("checked text");
	    
	}

	@Given("^Clicked on consensus estimates option and its sub options\\.$")
	public void clicked_on_consensus_estimates_option_and_its_sub_options() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		
		for (int i = 1; i <= 6; i++) {
			
			Thread.sleep(1000);
			
			com.click("xpath","//*[@id='119']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div[2]/ul/li[4]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on corporate reference sub options");    
			
			//com.click("xpath"," /html[1]/body[1]//div[3]/div[1]//div[2]//div[1]//div[2]/div[1]//div[2]/ul[1]/li[4]/div[2]/div[1]/ul[1]/li[6]/div[1]/span[2]/div[1]","clicking on corporate reference sub options");
			Thread.sleep(500);
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);		
			
		}
		System.out.println("checked consensus_estimates_option");
	    
	}
	
	@Then("^check any Consensus_Estimates option\\.$")
	public void check_any_Consensus_Estimates_option() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		    String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
	        com.click("xpath",category_text,"checked text");
	        Thread.sleep(2000);
	        System.out.println("checked text");
	    
	}

	@Given("^Clicked on Detailed Financials option and its sub options\\.$")
	public void clicked_on_Detailed_Financials_option_and_its_sub_options() throws Exception  {
	    
		
		for (int i = 1; i <= 3; i++) {
			
			Thread.sleep(1000);
			
			com.click("xpath","//*[@id='119']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]/div[2]/ul/li[5]/div[2]/div/ul/li["+i+"]/div[1]/span[2]/div","clicking on Detailed Financials option and its sub options");
			
			
			
		//Original/restated
			com.click("xpath","//label[1]//div[1]//select[1]//option[1]","clicking on Annual ");
			for (int l = 1; l <= 2; l++)
				
			{
			
			Thread.sleep(1000);
			com.click("xpath","//label[3]//div[1]//select[1]//option["+l+"]","clicking on Original/restated dropdown");
							
			
			}		
			
			
		//Annual dropdown	
			  for (int m = 1; m <= 3; m++) {
				
				Thread.sleep(1000);
				com.click("xpath","//label[1]//div[1]//select[1]//option["+m+"]","clicking on Annual dropdown");
		//Period dropdown						
					for (int a = 1; a <= 4; a++)
				
					{
					
					Thread.sleep(1000);
					com.click("xpath","//label[2]//div[1]//select[1]//option["+a+"]","clicking on period dropdown");						
					
					}		
		//Detailed/summary dropdown		
						for (int j = 1; j <= 2; j++)
					
						{
				
				Thread.sleep(1000);
				com.click("xpath","//label[4]//div[1]//select[1]//option["+j+"]","clicking on Detailed/summary dropdown");
				
						}		
								
				}
				
			Thread.sleep(1000);
			
					
	}
		
		
		
	System.out.println("checked Detailed Financials option");
		}
		
	
	@Then("^check any Detailed_Financials option\\.$")
	public void check_any_Detailed_Financials_option() throws Exception  {
		
		 	String category_text=Common.readPropertyByFundamentals().getProperty("category_text");
	        com.click("xpath",category_text,"checked text");
	        Thread.sleep(2000);
	        System.out.println("checked text");
		   
		    
		}
	
	@Given("^Checking rightclick properties\\.$")
	public void Checking_rightclick_properties() throws Exception  {
		
		String Click_area=Common.readPropertyByFundamentals().getProperty("Click_area");

		
	//Hide tree
		com.startAction();
		com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(2000);
        String Hide_tree=Common.readPropertyByFundamentals().getProperty("Hide_tree");
        com.click("xpath",Hide_tree,"clicked on hide tree");
        System.out.println("checked hide tree");
        
     //Show tree        
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(2000);
        
        String Show_tree=Common.readPropertyByFundamentals().getProperty("Show_tree");
        com.click("xpath",Show_tree,"clicked on show tree");
        
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        System.out.println("checked show tree");
        
      //Export data 
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        String Export_data=Common.readPropertyByFundamentals().getProperty("Export_data");
        com.startAction();
        com.MouseOverToElement("xpath",Export_data,"clicked on export data");
        
        String Export_pdf=Common.readPropertyByFundamentals().getProperty("Export_pdf");
        com.click("xpath",Export_pdf,"clicked on hide tree");
        
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        //Common.readPropertyByFundamentals().getProperty("Export_data");
        com.startAction();
        com.MouseOverToElement("xpath",Export_data,"clicked on export data");
        
        String Export_excel=Common.readPropertyByFundamentals().getProperty("Export_excel");
        com.click("xpath",Export_excel,"clicked on export to excel"); 
        
  
        
        
        //Defaults
        
       // for (int i = 3; i >= 1; i--)
        for (int i = 1; i <= 2; i++)	
        
        {
        	
		Thread.sleep(1000);
        
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        
        String Defaults=Common.readPropertyByFundamentals().getProperty("Defaults");
        com.startAction();
        com.MouseOverToElement("xpath",Defaults,"clicked on defaults");
        
        com.click("xpath","//*[@id='container']/div/div/div/div/div[5]/div/ul/li[9]/div/ul/li["+i+"]/button","clicking on defaults sub options");
           
        
        }
              
        
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        
        String Defaults=Common.readPropertyByFundamentals().getProperty("Defaults");
        com.startAction();
        com.MouseOverToElement("xpath",Defaults,"clicked on defaults");
        
        com.click("xpath","//*[@id='container']/div/div/div/div/div[5]/div/ul/li[9]/div/ul/li[3]/button","clicking on defaults sub options");
        
        
        String Overwriteyes = Common.readPropertyByFundamentals().getProperty("Overwriteyes");
 
       
        //String Overwriteyes = Common.readPropertyByFundamentals().getProperty("Overwriteyes");
        com.sleepThread(2000);
        com.click("xpath", Overwriteyes,"Click on overwrite Yes");
        com.sleepThread(2000);
        com.click("xpath", Overwriteyes,"Click on overwrite Ok");
        
           
         
        //Mark Field
        
        Thread.sleep(200);
        
        String Company_profile=Common.readPropertyByFundamentals().getProperty("Company_profile"); 
        com.startAction();
        com.MouseOverToclickabl("xpath",Company_profile,"clicked Company profile");
        com.click("xpath",Company_profile,"clicked Company profile");
        
        for (int i = 3; i <= 7; i++)
            
        {
        	
		Thread.sleep(1000);
		String Click_area1=Common.readPropertyByFundamentals().getProperty("Click_area1");
        com.startAction();
        com.Rightclick("xpath",Click_area1, "Right clicked on Fundamental data");
        Thread.sleep(200);
        
        String Mark_field=Common.readPropertyByFundamentals().getProperty("Mark_field");
        com.startAction();
        com.MouseOverToElement("xpath",Mark_field,"clicked on Mark field");
        
        com.click("xpath","//*[@id='container']/div//div[5]/div/ul/li[1]/div/ul/li["+i+"]/button","clicking on defaults sub options");
           
        }
        
       //Clear All Marks 
        String Click_area1=Common.readPropertyByFundamentals().getProperty("Click_area1");
        com.startAction();
        com.Rightclick("xpath",Click_area1, "Right clicked on Fundamental data");
        Thread.sleep(200);
        String Mark_field=Common.readPropertyByFundamentals().getProperty("Mark_field");
        com.startAction();
        com.MouseOverToElement("xpath",Mark_field,"clicked on Mark field");
        
        com.click("xpath","//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li[9]","clicking on defaults sub options");
        
        
        System.out.println("checked Right click");
		
	}
	
	//Display Preferences
	@Given("^Checking display preferences options\\.$")
	public void Checking_display_preferences_options() throws Exception  {
		
		String Estimates_Summary=Common.readPropertyByFundamentals().getProperty("Estimates_Summary"); 
		com.startAction();
        com.MouseOverToclickabl("xpath",Estimates_Summary,"clicked Estimates_Summary");
        com.click("xpath",Estimates_Summary,"clicked Estimates_Summary");
		
		for (int i = 1; i <= 2; i++)
            
        {
		//Export data button 
        String Export_data_button=Common.readPropertyByFundamentals().getProperty("Export_data_button");
	    com.click("xpath",Export_data_button,"Export data button");
	    Thread.sleep(2000);
	    
	    com.click("xpath","/html/body/div[1]/div/div/div/div/div[5]/div/ul/li["+i+"]/button","clicked on display prefernces");
        Thread.sleep(2000);
	     
	    /*String Export_to_PDf=Common.readPropertyByFundamentals().getProperty("Export_to_PDf");
	    com.click("xpath",Export_to_PDf,"Export data to pdf");
	    Thread.sleep(2000);
	    */
        }
		
	    System.out.println("checked export data button");
	    
	    
        for (int i = 1; i <= 6; i++)
            
        {
        	
		Thread.sleep(1000);
		String Click_area=Common.readPropertyByFundamentals().getProperty("Click_area");
        com.startAction();
        com.Rightclick("xpath",Click_area, "Right clicked on Fundamental data");
        Thread.sleep(200);
        
        String Display_preferences=Common.readPropertyByFundamentals().getProperty("Display_preferences");
        com.click("xpath",Display_preferences,"clicked on display prefernces");
        
        com.click("xpath","//div[@class='pt-select']//select//option["+i+"]","clicked on display prefernces");
        Thread.sleep(200);
        
        String Save=Common.readPropertyByFundamentals().getProperty("Save");
        com.click("xpath",Save,"clicked on display prefernces save button");
        }
		
        System.out.println("checked Display preferences");
            
		
	}
	
	
	
	
	}
	
		
		
	


