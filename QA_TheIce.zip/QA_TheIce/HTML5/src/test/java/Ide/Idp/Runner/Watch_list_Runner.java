package Ide.Idp.Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(plugin = { "html:target/cucumber-html-report", "json:target/cucumber.json",
		"pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
		"junit:target/cucumber-results.xml" }, features = "../HTML5/Featuresfiles/Watch List.feature", glue = "Ide.Idp.StepDef")
public class Watch_list_Runner extends AbstractTestNGCucumberTests {
}