package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.experimental.theories.Theory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.mongodb.connection.Stream;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class news {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public String Widget_name;
	public news news;
	public news() {
		driver = Common.driver;
	}
	@Given("^Verify the News$")
	public void Verify_the_OPtions() throws Exception {
		com.sleepThread(12000);
		String Options = Common.readPropertyByNews().getProperty("News");
		System.out.println(Options);
		com.verifyElementPresent("xpath", Options, "INTC-00001,News,Verify the News");

	}
	@And("^clicked on news widget$")
	public void Click_on_Options() throws Exception {
		String Options = Common.readPropertyByNews().getProperty("News");
		com.sleepThread(12000);
		com.click("xpath", Options, "INTC-00002,Options,Click on News");		
	}
	
	
	@When("^Verify the Symbol Linking in news$")
	public void Verify_the_Symbol_Linking_in_news() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking,
				"ICTC-00003," + Widget_name + ",Verify the Symbol Linking in news");
	}

	@And("^Click on Symbol Linking in News$")
	public void click_on_Symbol_Linking_in_news() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Symbol_Linking = Common.readPropertyByNews().getProperty("Symbol_Linking");
		com.sleepThread(3000);
		com.click("xpath", Symbol_Linking, "ICTC-00004," + Widget_name + ",Click on Symbol Linking in news");
	}

	@And("^click on each Check Functionalities in News$")
	public void check_Functionalities_in_news() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		news = new news();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00005," + Widget_name + ",Verify the each Check Functionalities in news");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label",
					"ICTC-00006," + Widget_name + ",Click on each Check Functionalities in news");
			com.sleepThread(3000);
			news.click_on_Symbol_Linking_in_news();
		}

		news = new news();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label",
					"ICTC-00005," + Widget_name + ",Verify the each Check Functionalities in Chart");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label",
					"ICTC-00006," + Widget_name + ",Click on each Check Functionalities in news");
			com.sleepThread(3000);
			news.click_on_Symbol_Linking_in_news();
		}
	}
}