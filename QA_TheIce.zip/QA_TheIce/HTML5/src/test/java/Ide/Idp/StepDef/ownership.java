package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ownership {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
public ownership() {
	driver = Common.driver;		
}

@Given("^Clicked on Ownership widget\\.$")
public void clicked_on_Ownership_Widget() throws Throwable {
	Thread.sleep(2000);
	com.startAction();
	//Clicking on + icon to add new widget
    String Add_Widget=Common.readPropertyByOwnership().getProperty("Add_Widget");     
    //com.MouseOverToclickabl("xpath",Add_Widget,"clicked on + icon");
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    com.click("xpath",Add_Widget,"clicked on + icon");
    Thread.sleep(200);
    
  	//Clicking on ownership 		        		      		        
    String Ownership=Common.readPropertyByOwnership().getProperty("Ownership");
    com.click("xpath",Ownership,"Clicked on Ownership widget");
    Thread.sleep(6000);
    System.out.println("Clicked on Ownership widget");
    
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    
    String FDsymbolbox=Common.readPropertyByOwnership().getProperty("FDsymbolbox");
    //com.sendKeys("xpath", FDsymbolbox, Keys.CONTROL + "a", "clear text");
    //com.sendKeys("xpath", FDsymbolbox, "AAPL", "Enter symbol");
    //com.sendKeys_fOR_Keybord("xpath", FDsymbolbox, Keys.ENTER , "Enter symbol");   
    Thread.sleep(200);
    //System.out.println("entered symbol");
    //driver.navigate().refresh();    
    //Thread.sleep(2000);       
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    
}


@Given("^Clicked on Company_reports and its sub options\\.$")
public void clicked_on_Company_reports_and_its_suboptions() throws Throwable {
	
	for (int i = 2; i <= 13; i++) {
		
		Thread.sleep(100);
		com.startAction();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//com.MouseOverToElement("xpath","//*[@id='tf-nav-pane-group-gen272']/ul/li[1]","clicking on company reports and its sub options");
		//com.MouseOverToclickabl("xpath","//*[@id='tf-nav-pane-group-gen272']/ul/li[1]","clicking on company reports and its sub options");
		com.click("xpath","//*[@id='tf-nav-pane-group-gen272']/ul/li["+i+"]","clicking on company reports and its sub options");
		Thread.sleep(500);
		
	}
	
}
		
@Given("^Clicked on Holder_reports and its sub options\\.$")
public void Clicked_on_Holder_reports_and_its_sub_options() throws Throwable {
		
		for (int i = 1; i <= 8; i++) {
			
			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			com.click("xpath","//*[@id='tf-nav-pane-group-gen273']/ul/li["+i+"]/div[2]","clicking on company reports and its sub options");
			Thread.sleep(500);
			
		}
	
	
}


@Given("^Clicked on Symbol_lookup and its sub options\\.$")
public void Clicked_on_Symbol_lookup_and_its_sub_options() throws Throwable {

	//Clicking on Symbol lookup 		        		      		        
    String Symbol_lookup=Common.readPropertyByOwnership().getProperty("Symbol_lookup");
    com.click("xpath",Symbol_lookup,"Clicked on Symbol_lookup");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup");
   //Clicking on Symbol lookup_dropdown
    String Symbol_lookup_dropdown=Common.readPropertyByOwnership().getProperty("Symbol_lookup_dropdown");
    com.click("xpath",Symbol_lookup_dropdown,"Clicked on Symbol_lookup_dropdown");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup_dropdown");
    
    //Clicking on equity
    String Symbol_lookup_equity=Common.readPropertyByOwnership().getProperty("Symbol_lookup_equity");
    com.click("xpath",Symbol_lookup_equity,"Clicked on Symbol_lookup equity");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup equity");
    
    //Clicking on clear all and close
    String Symbol_lookup_clear_all=Common.readPropertyByOwnership().getProperty("Symbol_lookup_clear_all");
    com.click("xpath",Symbol_lookup_clear_all,"Clicked on Symbol_lookup_clear_all");
    Thread.sleep(6000);
    System.out.println("Clicked on Symbol_lookup_clear_all");
    Thread.sleep(6000);
    
    String Symbol_lookup_close=Common.readPropertyByOwnership().getProperty("Symbol_lookup_close");
    com.click("xpath",Symbol_lookup_close,"Clicked on Symbol_lookup_close");
    
}
       
    @Given("^Clicked on Institutions_dropdown and its sub options\\.$")
    public void clicked_on_Institutions_dropdown_and_its_sub_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @Given("^Clicked on Currency_dropdown and its sub options\\.$")
    public void clicked_on_Currency_dropdown_and_its_sub_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @Given("^Clicked on Identifier_lookup and its sub options\\.$")
    public void clicked_on_Identifier_lookup_and_its_sub_options() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }
	
}



