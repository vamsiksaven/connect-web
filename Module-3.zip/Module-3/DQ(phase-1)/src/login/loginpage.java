package login;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
//import org.testng.annotations.Test;

/*import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import LIB.*;
import okhttp3.internal.connection.RouteSelector.Selection;*/

public class loginpage {
		
	//static WebDriver driver;
	//static Actions act;
	
	public static class TestRunner {
		static WebDriver driver;
		static Actions act;
	  @Test
	  public static void main(String[] args) throws Exception {
		
		//loginpage log=new loginpage();
		System.setProperty("webdriver.chromedriver", "C:\\Users\\vamsikrishnak\\robot framework\\chromedriver.exe");
		//System.setProperty("webdriver.firefox.marionette", "C:\\Users\\vamsikrishnak\\robot framework\\geckodriver.exe");
		 driver = new ChromeDriver();  
		//WebDriver driver = new FirefoxDriver();
        
        //com.startBrowser();
        //com.sendKeys("username", , content);
        //driver.obj.getProperty("https://connect-web.staging.dataservices.theice.com/");
		
		 //Using properties file
		 
		 Properties obj = new Properties();
		 FileInputStream objfile = new FileInputStream(System.getProperty("user.dir") + "\\src\\properties\\login.properties");
		 obj.load(objfile);
		
		 //driver.get("https://connect-web.staging.dataservices.theice.com/");
		driver.get(obj.getProperty("URL"));
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("username"))).click();
        Thread.sleep(2000);
       
        driver.findElement(By.xpath(obj.getProperty("username"))).sendKeys("vamsi.kamatam@theice.com");
        Thread.sleep(2000);
        driver.findElement(By.xpath(obj.getProperty("password"))).click();
        System.out.println("username and password entered successfully");
        
        Thread.sleep(2000);
        driver.findElement(By.xpath(obj.getProperty("password"))).sendKeys("Starts123");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("Submit"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //For 2FA
        /*Scanner scanner_user = new Scanner(System.in);
        System.out.println("Enter your 2FApasscode:");
        String user = scanner_user.nextLine();
        driver.findElement(By.xpath("//*[@id='loginHolder']/div[2]/div[2]/input")).sendKeys(user);
        Thread.sleep(1000);*/
        //driver.findElement(By.xpath("//*[@id='formLogin']/input")).click();
        //scanner_user.close();
        
        
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        
        if(driver.findElement(By.xpath("//span[contains(text(),'Principal Region')]")) != null){
        	System.out.println("logged in successfully");
        	}else{
        	System.out.println("login failed");
        	}
        
        /*if(driver.getPageSource().contains("File")){
        	System.out.println("logged in successfully");
        	}else{
        	System.out.println("login failed");
        	}
        
      /*  if(isElementPresent(By.xpath("//button[contains(text(),'File')]")))
        {
        System.out.println("logged in successfully");
        }
        else
        {
        System.out.println("login failed");
        }
        //driver.findElement(By.xpath("//span[contains(text(),'Principal Region')]"));
        //System.out.println("logged in successfully");
        
        
      /*  driver.findElement(By.xpath("//button[@title='Open Chart']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        System.out.println("Clicked on Chart tab ");
        driver.findElement(By.xpath("//button[@title='Open Detailed Quote']")).click();
        System.out.println("Clicked on Detailed Quotes tab");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[@title='Open Watch List']")).click();
        System.out.println("Clicked on Watchlist tab");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        Thread.sleep(1000);
        //User clicked on Internal
        driver.findElement(By.xpath("//span[contains(text(),'New Watch List')]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        String text1=driver.findElement(By.xpath("//span[contains(text(),'New Watch List')]")).getText();
        System.out.println(text1);
        
        
        Thread.sleep(1000);
       
        driver.findElement(By.xpath("//div[text()='Dow Jones Industrial Average']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);*/
        
        
        driver.findElement(By.xpath(obj.getProperty("DetailedQuote"))).click();
        Thread.sleep(1000);
        
        if(driver.findElement(By.xpath("//span[contains(text(),'Last Trade Time')]")) != null){

        System.out.println("Detailed Quotes tab opened succesfully");
        }
        else
        {
        System.out.println("Detailed Quotes tab did not opened");
        }
                
        //System.out.println("Clicked on Detailed Quotes tab");
        
        // to click on symbol text box.
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("DQsymbolbox"))).sendKeys("IBM",Keys.ENTER);
        Thread.sleep(1000);
        
        //if(isElementPresent(By.xpath("//span[text()='IBM']")))
        if(driver.findElement(By.xpath(obj.getProperty("IBM"))) != null)
        {
        System.out.println("Entered IBM symbol");
        }
        else
        {
        System.out.println("Did not Entered IBM symbol");
        }
        
        
        //DQ chart time intervals
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        driver.findElement(By.xpath(obj.getProperty("ScaleCheckbox"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("1D"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("1M"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("3M"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("6M"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("1Y"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("5Y"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        System.out.println("Checked all time intervals");
        
        //DQ right click Field.
        
        Actions act1=new Actions(driver);
        act1.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea")))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        act1.contextClick(driver.findElement(By.xpath(obj.getProperty("Fieldsbutton")))).perform();
        Thread.sleep(100);
        
        driver.findElement(By.xpath(obj.getProperty("Fieldsbutton"))).click();
       
        for(int i=3;i<=11;i++)
        {
        	Actions act2=new Actions(driver);
            act2.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea")))).perform();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            Thread.sleep(100);
            act2.contextClick(driver.findElement(By.xpath(obj.getProperty("Fieldsbutton")))).perform();
            Thread.sleep(100);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/div/ul/li["+i+"]/button")).click();
        	
        }
        Thread.sleep(1000);
        
        if(driver.getPageSource().contains("Exchange")){
        	System.out.println("Text is present");
        	}else{
        	System.out.println("Text is absent");
        	}
        System.out.println("Checked all Fields");
        
        Thread.sleep(5000);
    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	
        //DQ right click Font size.
    	
        for(int j=1;j<=3;j++)
        {	
        	Thread.sleep(5000);    
        	
        	Actions act3=new Actions(driver);
        	act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        	act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontsize")))).perform();
        	Thread.sleep(100);
        	
        	driver.findElement(By.xpath("//ul[contains(@class,'ice-menu css-b2notx evgjxy0')]//li[3]//div[1]//ul[1]//li["+j+"]//button[1]")).click();
        	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        	
        	Thread.sleep(1000);
        	
        
        }
                        
        Thread.sleep(5000); 
        
    	
        Actions act3=new Actions(driver);
        act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	act3.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontsize")))).perform();    	Thread.sleep(100);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("Clearfontsize"))).click();	
        System.out.println("Checked Font size");
        
        //DQ right click Font Color.
       
         for(int i=1;i<=5;i++)
        	{	
        		//log.right_click();
        		Actions act=new Actions(driver);
                act.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        		Thread.sleep(100);
        		act.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontcolor")))).perform();
        		Thread.sleep(100);
        	    Thread.sleep(5000);    
         	    //right_click();
         	    
        		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        		driver.findElement(By.xpath("//ul[contains(@class,'ice-menu css-b2notx evgjxy0')]//li[4]//div[1]//ul[1]//li["+i+"]//button[1]")).click();
        		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        		Thread.sleep(1000);
        
        	}
        Thread.sleep(5000);    
     	
        Actions act=new Actions(driver);
        act.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(10);
		act.contextClick(driver.findElement(By.xpath(obj.getProperty("Fontcolor")))).perform();
		Thread.sleep(10);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("Clearfontcolor"))).click();	
        System.out.println("Checked Font color");
        
        //DQ Right-click Bold and Italic
        
        for(int i=5;i<=6;i++)
        {
        Actions act4=new Actions(driver);
        act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(10);
        act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Bold")))).perform();
        Thread.sleep(10);
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li["+i+"]/button")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        }
        System.out.println("Checked Bold and Italic Fonts");
        
        Thread.sleep(5000);    
    	
        Actions act4=new Actions(driver);
        act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        act4.contextClick(driver.findElement(By.xpath(obj.getProperty("Bold")))).perform();
        Thread.sleep(100);
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(obj.getProperty("Italic"))).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        System.out.println("Checked clear all styles");
        
       //DQ Right-click Insert.
        
        for(int i=1;i<=2;i++)
        {
        
           	Actions act5=new Actions(driver);
           	act5.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            Thread.sleep(100);
            act5.contextClick(driver.findElement(By.xpath(obj.getProperty("Insert")))).perform();
            Thread.sleep(100); 	
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[8]/div/ul/li["+i+"]/button")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        }
        System.out.println("Checked insert option");
        
      //DQ Right-click Delete.
        
        for(int i=1;i<=2;i++)
        {
        Actions act6=new Actions(driver);
        act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Delete")))).perform();
        Thread.sleep(100);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[9]/div/ul/li["+i+"]/button")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(1000);
        }
        System.out.println("Checked delete option");
        
        for(int i=1;i<=2;i++)
        {
       
        Actions act6=new Actions(driver);
        act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        act6.contextClick(driver.findElement(By.xpath(obj.getProperty("Default")))).perform();
        Thread.sleep(100);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[12]/div/ul/li["+i+"]/button")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(1000);
        }
        System.out.println("Checked default option");
        
 //Display Preferences
        
        //Widget Templetes
        
        for(int i=1;i<=16;i++)
        {
        	Actions act8=new Actions(driver);
        	act8.contextClick(driver.findElement(By.xpath(obj.getProperty("Clickarea1")))).perform();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button")).click();
            //act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
            Thread.sleep(100);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div/div["+i+"]")).click();
            Thread.sleep(10);
            driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
            driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            Thread.sleep(1000);
            }
        if(driver.getPageSource().contains("Volume")){
        	System.out.println("Text is present");
        	}else{
        	System.out.println("Text is absent");
        	}
        
         System.out.println("Checked Widget templetes option");
        //Fields
        for(int i=1;i<=6;i++)
        {
        	Actions act8=new Actions(driver);
            act8.contextClick(driver.findElement(By.xpath("//div[@class='d-hbox d-wrap d-dq-flex']//div[3]"))).perform();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button")).click();
            driver.findElement(By.xpath("//button[contains(text(),'Fields')]")).click();
            //act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
            driver.findElement(By.xpath("//label[contains(text(),'Show Short Field Names')]")).click();
            Thread.sleep(100);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div/div["+i+"]")).click();
            Thread.sleep(10);
            driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
            driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            Thread.sleep(1000);
            }
        if(driver.getPageSource().contains("Volume")){
        	System.out.println("Text is present");
        	}else{
        	System.out.println("Text is absent");
        	}
        
        System.out.println("Checked fields option");
        //Formatting        
        for(int i=1;i<=5;i++)
        {
        	Actions act8=new Actions(driver);
            act8.contextClick(driver.findElement(By.xpath("//div[contains(@class,'d-dq-container d-hbox')]//div[contains(@class,'d-flex-1')]"))).perform();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("//button[contains(text(),'Display Preferences...')]")).click();
            driver.findElement(By.xpath("//button[contains(text(),'Formatting')]")).click();
            //act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[14]/button"))).click();
            Thread.sleep(100);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath("/html/body/div[5]/div/span/div[2]/div/div[2]/div/div[2]/div/label["+i+"]")).click();
            Thread.sleep(10);
            driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
            driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            Thread.sleep(1000);
            }
        System.out.println("Checked formatting option");
        //Testing Fields Customize
        Actions act8=new Actions(driver);
        act8.contextClick(driver.findElement(By.xpath("//div[contains(@class,'d-dq-container d-hbox')]//div[contains(@class,'d-flex-1')]"))).perform();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        act8.contextClick(driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[1]/button"))).perform();
        Thread.sleep(100);
        driver.findElement(By.xpath("//button[contains(text(),'Customize...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'New')]")).click();
        driver.findElement(By.xpath("//input[contains(@placeholder,'Enter name for your column set')]")).sendKeys("AuTest");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[2]/div/div[2]/div[2]/button[3]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(100);
        WebElement element = driver.findElement(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[3]/div/div/button[1]"));
        Actions action = new Actions(driver);
        action.moveToElement(element).click().perform();
        //driver.findElement(By.xpath("/html/body/div[7]/div/span/div[2]/div/div[3]/div/div/button[1]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //checking edit option
        WebElement element1 = driver.findElement(By.xpath("//button[contains(text(),'Edit')]"));
        Actions action1 = new Actions(driver);
        action1.moveToElement(element1).click().perform();
        //driver.findElement(By.xpath("//button[contains(text(),'Edit')]")).click();
        Thread.sleep(10);
        WebElement element2 = driver.findElement(By.xpath("//button[contains(text(),'Cancel')]"));
        Actions action2 = new Actions(driver);
        action2.moveToElement(element2).click().perform();
           //driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();
       //Checking delete option
        driver.findElement(By.xpath("//button[contains(text(),'Delete')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'No')]")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();
        System.out.println("Checked Fields Customize along with new edit and delete options");
        
//Menu options
        
        //File
        
        driver.findElement(By.xpath("//button[contains(text(),'File')]")).click();
        
        Thread.sleep(100);
        
        //Handling POP up window..
        String winHandleBefore = driver.getWindowHandle(); 
        // get all the window handles before the popup window appears
        Set beforePopup = driver.getWindowHandles();

       // click the link which creates the popup window
        driver.findElement(By.xpath("//button[contains(text(),'Open new console window...')]")).click();

       // get all the window handles after the popup window appears
       Set<?> afterPopup = driver.getWindowHandles();

       // remove all the handles from before the popup window appears
       afterPopup.removeAll(beforePopup);

       // there should be only one window handle left
       if(afterPopup.size() == 1) {
                 driver.switchTo().window((String)afterPopup.toArray()[0]);
        }
        driver.close();
        Thread.sleep(100);
        driver.switchTo().window(winHandleBefore);
        
        //Preferences
        
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Manage Keyboard Shortcuts')]")).click();
        driver.findElement(By.xpath("//button[@title='Close']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@class='css-19tzmjm']//label[1]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//label[contains(text(),'Reverse Alphabetical')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//label[contains(text(),'Manual')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();
        /*Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//label[@class='ice-checkbox css-r4d1rt ejl8a250']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply & Save')]")).click();*/
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//button[@title='Close']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Tab Sorting')]")).click();
        driver.findElement(By.xpath("//button[contains(text(),'Cancel')]")).click();
        Thread.sleep(10);
        
        //Theme
        
        driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        driver.findElement(By.cssSelector("#container > div > div > div > div > div.css-n4hwqd > div > ul > li:nth-child(3) > button")).click();
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[2]/button")).click();
        Thread.sleep(10);
        //driver.findElement(By.xpath("//button[contains(text(),'Preferences')]")).click();
        //driver.findElement(By.xpath("//body/div[@id='container']/div/div[@class='ice-theme-provider light-theme css-jtnhee e9snama0']/div[@class='console-container']/div[@class='css-7gpoef']/div[@class='css-n4hwqd']/div[@class='css-135kypt']/ul[@class='ice-menu css-b2notx evgjxy0']/li[3]/button[1]")).click();
        driver.findElement(By.xpath("//*[@id='container']/div/div/div/div/div[5]/div/ul/li[3]/div/ul/li[1]/button")).click();
        Thread.sleep(10);  
        System.out.println("Checked preferences");     
        
//Connect Utils  
        
        //Formatting
        
        //driver.findElement(By.xpath("//button[@title='Open Detailed Quote']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //driver.findElement(By.xpath("//div[@class='d-hbox d-justify-space-between d-wrap']")).click();
        driver.findElement(By.xpath("//*[@id='0']/div[2]/div[2]/div/div/div/div/div[2]/div/div[1]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Classic')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[@class='pt-control pt-radio'][contains(text(),'Decimal')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Show Full Precision on Trade Data')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[3]/label[1]/div")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[3]/label[1]/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Use brackets on Negative Values (Decimal and Dolla')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
                
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[@class='pt-button pt-minimal pt-active']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[4]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[4]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Checked Formatting"); 
        
        //Timezone
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Display in Local')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Display in Exchange')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Display in GMT')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        for(int i=1;i<=27;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        for(int i=1;i<=16;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[1]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[1]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        for(int i=1;i<=4;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Time Zone')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[2]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/div/div[2]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Override market clock time format (time format nee')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Checked Timezone"); 
        
        //Appearance.
        
        for(int i=1;i<=2;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//label[1]/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//label[1]/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Show Toolbar')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        for(int i=1;i<=8;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//fieldset[@class='popup-content d-padded']//select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        
        //up color
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div[1]/span/button")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Green']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//a[contains(text(),'More colors...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Magenta 4']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        //Down color
        
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Appearance')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div[2]/span/button")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//div[@title='Black']")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        System.out.println("Checked Appearance"); 
        
        //Symbol Extensions
        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Symbol Extensions')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//label[contains(text(),'Inserted/Pasted Symbols')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        System.out.println("Checked Symbol extensions"); 
        
        //Pre-market Settings.
        
        for(int i=1;i<=2;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Pre-Market Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset/div/label["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
         }
        System.out.println("Checked Pre-widget settings"); 
        
        //General widget settings
        
        driver.findElement(By.xpath("//button[@title='Open Chart']")).click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //Chart
        
        for(int i=1;i<=3;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'General Widget Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[1]/label["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
         }
        
        //Symbol lookup
        
        for(int i=1;i<=2;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'General Widget Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/label["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        
        for(int i=1;i<=2;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'General Widget Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/label["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        }
        
        for(int i=1;i<=5;i++)
        {
        driver.findElement(By.xpath("//button[contains(text(),'Connect Utils')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Preferences...')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'General Widget Settings')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/label[1]/label/div/select")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("/html/body/div//fieldset[2]/label[1]/label/div/select/option["+i+"]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(@class,'pt-intent-primary')]")).click();
        Thread.sleep(10);
        
        }
        System.out.println("Checked General widget settings"); 
        
        //Help
        
        driver.findElement(By.xpath("//button[contains(text(),'Help')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'About')]")).click();
        Thread.sleep(10);
        driver.findElement(By.xpath("//button[contains(text(),'Close')]")).click();
        Thread.sleep(10);
        System.out.println("Checked all connect utils options"); 
        
        
      
        
        
	}
		private static boolean isElementPresent(By xpath) {
			// TODO Auto-generated method stub
			return false;
		}
	
}
}

       

	
	
	
	
	
        
        
