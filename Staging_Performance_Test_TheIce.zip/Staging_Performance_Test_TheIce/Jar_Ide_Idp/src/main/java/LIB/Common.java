package LIB;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Common {
	public static WebDriver driver;
	/** The Report logger. */
	String imageLocation;
	// public static String imageLocation = "./images/";

	protected static ExtentTest extentTest = null;
	Actions action;

	// Start Chrome Browser
	public void Setup(String Browser) throws Exception {
		if (Browser.equals("Firefox")) {
			driver = new FirefoxDriver();
		} else if (Browser.equals("IE")) {
			driver = new InternetExplorerDriver();
		} else if (Browser.equals("Chrome")) {
			// imageLocation = new
			// SimpleDateFormat("yyyy_MM_dd").format(Calendar.getInstance().getTime());
			// File directory=new File(imageLocation);
			// FileUtils.cleanDirectory(directory);
			//System.setProperty("webdriver.chrome.driver", "D:\\TheIce\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.out.println("Invalid Driver");
		}
	}

	public void starturl(String url) {

		driver.navigate().to(url);
	}

	// Maximize Browser
	public void maximiseBrowser() {
		driver.manage().window().maximize();
	}

	// WebElement
	public WebElement webElementId(String identifier, String locator) {
		WebElement e = null;
		switch (identifier) {
		case "id":
			e = driver.findElement(By.id(locator));
			break;
		case "className":
			e = driver.findElement(By.className(locator));
			break;
		case "tagName":
			e = driver.findElement(By.tagName(locator));
			break;
		case "name":
			e = driver.findElement(By.name(locator));
			break;
		case "linkText":
			e = driver.findElement(By.linkText(locator));
			break;
		case "partialLinkText":
			e = driver.findElement(By.partialLinkText(locator));
			break;
		case "cssSelector":
			e = driver.findElement(By.cssSelector(locator));
			break;
		case "xpath":
			e = driver.findElement(By.xpath(locator));
			break;
		default:
			System.out.println("Locator not found");
			e = null;
		}
		return e;
	}

	// Sendkey general method
	public void sendKeys(String identifier, String locator, String content) {

		WebElement e = webElementId(identifier, locator);
		e.sendKeys(content);
	}

	// Clear text field method
	public void ClearTextField(String identifier, String locator) {

		WebElement e = webElementId(identifier, locator);
		e.clear();
	}

	// click general method
	public void click(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		e.click();
	}

	// verify title of the page
	public void verifyTitle(String title) {
		if (driver.getTitle().equals(title)) {
			System.out.println(title + " displayed");
		} else {
			System.out.println("Failed to display " + title);
			return;
		}
	}

	// Wait until the Element is present
	public void waitUntilElementPresent(String elementpath) {

		WebElement elementpresent = (new WebDriverWait(driver, 10))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath(elementpath)));
	}

	// Verify Text
	public void verifyText(String identifier, String locator, String text) {
		WebElement e = webElementId(identifier, locator);
		if (e.getText().equals(text)) {
			System.out.println(text + " displayed");
		} else {
			System.out.println(text + "Did not displayed");
		}
	}

	// Verify Text Using String
	public void verifyText_Using_String(String identifier, String locator, String text) {
		String e = webElementId(identifier, locator).getText();
		if (e.equals(text)) {
			System.out.println(text + " displayed");
		} else {
			System.out.println(text + "Did not displayed");
		}
	}

	// Verify Text box text text
	public void verify_text_box_text(String identifier, String locator, String text) {
		String e = webElementId(identifier, locator).getAttribute("value");
		if (e.equals(text)) {
			System.out.println(text + "is displayed");
		} else {
			System.out.println(text + "Did not displayed");
		}
	}

	// verify element present
	public void verifyElementPresent(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);

		if (e.isDisplayed()) {
			System.out.println("Element present");
		} else {
			System.out.println("Element is not present");
		}
	}

	// Element is Enabled or not
	public void verifyElementEnabled(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		if (e.isEnabled()) {
			System.out.println("Element Enabled");
		} else {
			System.out.println("Element is not Enabled");
		}

	}

	// Element is disable or not
	public void verifyElementdisable(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		if (e.isEnabled()) {
			System.out.println("Element is Enabled");
		} else {
			System.out.println("Element is disable");
		}
	}

	// Element is is Selected or not
	public void verifyElementisSelected(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		if (e.isSelected()) {
			System.out.println("Element is Selected");
		} else {
			System.out.println("Element is not Selected");
		}

	}

	// Thread sleep
	public void sleepThread(long sleeptime) {
		try {
			Thread.sleep(sleeptime);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// Wait for page to load
	public void waitForPageToLoad() {
		try {
			for (int i = 0; i < 50;) {
				if (driver.getTitle().length() != 0) {
					System.out.println("Page loaded");
					i = 51;
					break;
				} else {
					Thread.sleep(1000);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// select frame by id
	public void selectFrameById(String locator) {
		driver.switchTo().frame(locator);
	}

	// Select frame default method
	public void selectFrameDefault() {
		driver.switchTo().defaultContent();
	}

	// getting data from table and verifying it with the required text
	public void verifyElementInTable(String xpathlocator, String text) {
		boolean a = false;
		List<WebElement> tdlist = driver.findElements(By.xpath(xpathlocator));
		for (WebElement el : tdlist) {
			if (el.getText().equals(text)) {
				a = true;
				break;
			}
		}

		if (a == true) {
			System.out.println(text + " was identifed");
		} else {
			System.out.println(text + " was not identifed");
		}
	}

	// Start action
	public void startAction() {
		action = new Actions(driver);
	}

	// move to element
	public void MouseOverToElement(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		action.moveToElement(e).perform();
	}

	// move to click
	public void MouseOverToclickabl(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		action.moveToElement(e).click().perform();
	}

	// click on Right click
	public void Rightclick(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		action.contextClick(e).build().perform();
	}

	public void double_click_an_element(String identifier, String locator) {
		WebElement e = webElementId(identifier, locator);
		action.doubleClick(e).perform();
	}

	//
	public void Click_on_drop_down_list(String xpathlocator, String text, String identifier, String locator) {
		boolean a = false;
		List<WebElement> tdlist = driver.findElements(By.xpath(xpathlocator));
		for (WebElement el : tdlist) {
			el.click();
		}

	}
	
	public void sendKeys_fOR_Keybord(String identifier, String locator, Keys content) throws Exception {

		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.sendKeys(content);
			System.out.println("Pass");
		} else {
			System.out.println("Fail");
		}
	}
	
	public void mouseovercontextClick(String identifier, String locator) throws Exception
	{
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			action.contextClick(e).perform();			
			System.out.println("Pass");
		} else {			
			System.out.println("Fail");
		}
	}
	
	
	// Sendkey general method
		public void sendKeys(String identifier, String locator, String content, String Report) throws Exception {

			WebElement e = webElementId(identifier, locator);
			if (e.isDisplayed()) {
				e.sendKeys(content);
				System.out.println("Pass");
			} else {
				System.out.println("Fail");
			}
		}
	
	
	public void switch_to_new_window(String identifier, String locator, String Report, String V_identifier,
			String V_locator, String V_Report) throws Exception {
		// Store the current window handle
		String winHandleBefore = driver.getWindowHandle();
		// Perform the click operation that opens new window
		WebElement e = webElementId(identifier, locator);
		if (e.isDisplayed()) {
			e.click();
	
		} else {
		
		}
		Thread.sleep(3000);
		// Switch to new window opened
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		// Perform the actions on new window
		WebElement V_e = webElementId(V_identifier, V_locator);
		if (V_e.isEnabled()) {
			
			System.out.println("Element Enabled");
		} else {
		
			System.out.println("Element is not Enabled");
		}
		// Close the new window, if that window no more required
		Thread.sleep(3000);
		driver.close();
		// Switch back to original browser (first window)
		driver.switchTo().window(winHandleBefore);

		// Continue with original browser (first window)
	}

	

	
	// verify pop closeing or not
		public void verify_pop_closeing_or_not(String identifier, String locator) throws Exception {
			WebElement e = webElementId(identifier, locator);

			if (e.isDisplayed()) {
				
				System.out.println("Element is not present");
			} else {
				
				System.out.println("Element present");
			}
		}


	// put path to your image in a clipboard
	public void upload_file(String upload_file) throws Exception {
		StringSelection ss = new StringSelection(upload_file);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		// imitate mouse events like ENTER, CTRL+C, CTRL+V
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	// Read property file
	public static Properties readPropertyByLogin() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Login.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	
	public static Properties readPropertyByFundamentals() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Fundamentals.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	
	public static Properties readPropertyByNews() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/News.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	
	public static Properties readPropertyByoptions() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Options.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}
	
	public static Properties readPropertyByGlobal_Preferences() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Global_Preferences.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}

	public static Properties readPropertyByWatch_List() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Watch_List.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}

	public static Properties readPropertyByChart() {
		Properties prop = new Properties();
		File dir1 = new File("/QA_Load_Test_TheIce/Jar_Ide_Idp/Ide.Idp.Properties/Chart.properties");
		try {
			prop.load(new FileInputStream(dir1.getCanonicalPath()));
		} catch (FileNotFoundException e) {
			// LowLevelLogs.getLogger().error("FileNotFoundException in readProperty: " +
			// e.getMessage(), e);
		} catch (IOException e) {
			// LowLevelLogs.getLogger().error("IOException in readProperty: " +
			// e.getMessage(), e);
		}
		return prop;
	}

	// Capture Screenshot
	public String captureScreenshot() throws Exception {

		// final UUID uuid = UUID.randomUUID();
		imageLocation = new SimpleDateFormat("yyyy_MM_dd").format(Calendar.getInstance().getTime());
		String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH-mm-ss").format(Calendar.getInstance().getTime());
		final File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(imageLocation + "/" + timeStamp + ".png"));
		} catch (final IOException e) {
			e.printStackTrace();
		}
		try {
			extentTest.log(LogStatus.INFO, extentTest.addScreenCapture(imageLocation + "/" + timeStamp + ".png"));
		} catch (Exception e) {
			// logError("IOException thrown in SvmBaseTestCase.captureScreenshot", e);
		}
		// logDebug("Capturing :" + testNGReport + imageLocation + uuid + ".png");
		return imageLocation + "/" + timeStamp + ".png";
	}

	// close

	public void closeBrowser() {
		driver.close();
	}

	// Quit
	public void QuitObject() {
		driver.quit();
	}
}