/*package Ide.Idp.StepDef;

import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {

	public Common com = new Common();
	public WebDriver driver;
	public String un;
	public String Pws;
	//public String login;
	Login Login;

	public Login() {
		driver = Common.driver;
		// un= Common.readPropertyByName().getProperty("User_name");
		// Pws=Common.readPropertyByName().getProperty("Passwod");
		

	}
	// Verify_the_ligin_page_Logo
	@Given("^I have open the browser$")
	public void open_browser() throws Exception {
		com.Setup("Chrome");
		com.starturl("https://ida-idp.qa.market-q.com/ida-idp/");
		com.maximiseBrowser();
		com.captureScreenshot();
	}

	@When("^Verify the logo$")
	public void Verify_the_logo() throws Exception {
		String Applicationlogo = Common.readPropertyByLogin().getProperty("Logo");
		com.sleepThread(5000);
		com.verifyElementPresent("xpath", Applicationlogo);
		com.captureScreenshot();
	}
	// correct_username_and_correct_password
		@SuppressWarnings("deprecation")
		@Given("^Login with IDE IDP credentials Username \"(.*?)\" and Password \"(.*?)\"$")
		public void Login_with_IDE_IDP_credentials_Username_and_Password(String Username, String Password)
				throws Exception {
			un = Common.readPropertyByLogin().getProperty("User_name");
			Pws = Common.readPropertyByLogin().getProperty("Passwod");
			driver.navigate().refresh();
			com.sleepThread(2000);
			com.sendKeys("xpath", un, Username);
			com.captureScreenshot();
			com.sendKeys("xpath", Pws, Password);
			com.captureScreenshot();
		}

		@Then("^Click on login button$")
		public void login_button() throws Exception {
			com.sleepThread(3000);
			String login = Common.readPropertyByLogin().getProperty("Login_button");
			com.click("xpath", login);
			com.captureScreenshot();
			// Login=new Login();
			// Login.login_loop();
		}
		

	@And("^Close the Browser$")
	public void Close_the_Browser() throws Exception {
		 com.closeBrowser();
	}

	@And("^Quit the Object$")
	public void Quit_the_Object() throws Exception {
		 com.QuitObject();
	}

}
*/