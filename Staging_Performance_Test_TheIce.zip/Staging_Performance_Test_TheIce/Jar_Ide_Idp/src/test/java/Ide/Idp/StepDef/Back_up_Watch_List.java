/*package Ide.Idp.StepDef;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Back_up_Watch_List {
	public Common com = new Common();
	public Watch_List wl;
	public WebDriver driver;
	public String whatch_list;
	public Watch_List Watch_List;
	public String Chart;

	public Back_up_Watch_List() {
		driver = Common.driver;
	}
	@Given("^I have open the browser$")
	public void open_browser() throws Exception {
		com.Setup("Chrome");		
	}
	@When("^Verify the logo$")
	public void Verify_the_logo() throws Exception {
		com.starturl("https://connect-web.staging.dataservices.theice.com");https://connect-web.staging.dataservices.theice.com
		com.maximiseBrowser();  //https://ida-idp.qa.market-q.com/ida-idp/
		com.captureScreenshot();
		//String Applicationlogo = Common.readPropertyByLogin().getProperty("Logo");
		com.sleepThread(5000);
		//com.verifyElementPresent("xpath", Applicationlogo);
		com.captureScreenshot();
	}
	// correct_username_and_correct_password
		@SuppressWarnings("deprecation")
		@Given("^Login with IDE IDP credentials Username \"(.*?)\" and Password \"(.*?)\"$")
		public void Login_with_IDE_IDP_credentials_Username_and_Password(String Username, String Password)
				throws Exception {
			String un = Common.readPropertyByLogin().getProperty("User_name");
			String Pws = Common.readPropertyByLogin().getProperty("Passwod");
			driver.navigate().refresh();
			com.sleepThread(2000);
			com.sendKeys("xpath", un, Username);
			com.captureScreenshot();
			com.sendKeys("xpath", Pws, Password);
			com.captureScreenshot();
		}

		@Then("^Click on login button$")
		public void login_button() throws Exception {
			com.sleepThread(3000);
			String login = Common.readPropertyByLogin().getProperty("Login_button");
			com.click("xpath", login);
			com.sleepThread(3000);
			com.captureScreenshot();
			// Login=new Login();
			// Login.login_loop();
		}
	
	@Given("^Verify the Watch List$")
	public void Verify_the_Watch_List() throws Exception {
		TimeUnit.MINUTES.sleep(10);
		if(driver.getTitle().equals("Chart")) {
		whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		com.click("xpath", whatch_list);
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Watch List,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			TimeUnit.MINUTES.sleep(10);
			list.Verify_the_logo();
			TimeUnit.MINUTES.sleep(10);
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Verify_the_Watch_List();
			list.Click_on_Watch_List();
			
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Watch List,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
		if(driver.getTitle().equals("Watch List"))
		{
		whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		System.out.println(whatch_list);
		com.verifyElementPresent("xpath", whatch_list);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Watch List,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Watch List,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}

	@And("^Click on Watch List$")
	public void Click_on_Watch_List() throws Exception {
		if(driver.getTitle().equals("Watch List")) {
		whatch_list = Common.readPropertyByWatch_List().getProperty("whatch_list");
		com.click("xpath", whatch_list);
		com.captureScreenshot();
		Watch_List = new Watch_List();
		Watch_List.Watch_list_loop();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Watch List,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Watch_List();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Watch List,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@When("^Verify the Symbol Linking$")
	public void Verify_the_Symbol_Linking() throws Exception {
		if (driver.getTitle().equals("Watch List")) {		
		com.sleepThread(3000);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Symbol Linking,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Symbol Linking,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^Click on Symbol Linking$")
	public void click_on_Symbol_Linking() throws Exception {
		if(driver.getTitle().equals("Watch List"))
		{
			
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.sleepThread(2000);
		com.click("xpath", Symbol_Linking);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Symbol Linking,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Symbol Linking,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^click on each Check Functionalities$")
	public void check_Functionalities() throws Exception {
		if(driver.getTitle().equals("Watch List")) {
		wl = new Watch_List();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			if (driver.getTitle().equals("Watch List")) {
				
			
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label");
			com.captureScreenshot();
			com.sleepThread(5000);
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + i + "]/button/label");
			com.captureScreenshot();
			com.sleepThread(5000);
			wl.click_on_Symbol_Linking();
			TimeUnit.MINUTES.sleep(60);			
			com.captureScreenshot();
		} 
			 else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",click on each Check Functionalities,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",click on each Check Functionalities,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
		}	
		wl = new Watch_List();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			if(driver.getTitle().equals("Watch List")) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label");
			com.captureScreenshot();
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[5]/div/ul/li[" + j + "]/button/label");
			com.captureScreenshot();
			com.sleepThread(3000);
			wl.click_on_Symbol_Linking();
			com.captureScreenshot();
			}else if(driver.getTitle().equals("404 Not Found"))
			{
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",click on each Check Functionalities,404 Not Found"+"\n");
				C_outputfile.close();
				com.captureScreenshot();
			}else {
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",click on each Check Functionalities,webpage not available"+"\n");
				C_outputfile.close();
				System.out.println("webpage not available");
			}
			}
			
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",click on each Check Functionalities,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",click on each Check Functionalities,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@When("^Click on my wath lists Drop Down$")
	public void Click_on_my_wath_lists_Drop_Down() throws Exception {
		if(driver.getTitle().equals("Watch List")) {
		com.sleepThread(3000);
		String my_wath_list = Common.readPropertyByWatch_List().getProperty("my_wath_lists_Drop_Down");
		com.verifyElementPresent("xpath", my_wath_list);
		com.click("xpath", my_wath_list);
		TimeUnit.MINUTES.sleep(1);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on my wath lists Drop Down,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Chart();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_ICE_Drop_Down();						
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on my wath lists Drop Down,webpage not available"+"\n");
			C_outputfile.close();
			
			System.out.println("webpage not available");
		}
	}
	@And("^Verify and Click on My watch lists and Server Watch Lists$")
	public void Verify_and_Click_on_My_watch_lists_and_Server_Watch_Lists() throws Exception {
		if(driver.getTitle().equals("Watch List")) {
		wl = new Watch_List();
		int count = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[1]/div[1]/span[2]/div"))
				.size();

		int mylist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();
		System.out.println("mylist:" + mylist);
		int Serverlist = driver.findElements(By.xpath(
				"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println("Serverlist:" + Serverlist);
		for (int i = 2; i < mylist; i++) {
			if(driver.getTitle().equals("Watch List")) {
			TimeUnit.MINUTES.sleep(3);
			com.verifyElementPresent("xpath",
					"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li[" + i
							+ "]/div[1]/span[2]/div");
			com.captureScreenshot();			
			com.click("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[1]/div[2]/div/ul/li["
					+ i + "]/div[1]/span[2]/div");
			com.captureScreenshot();
			TimeUnit.MINUTES.sleep(30);
			wl.Click_on_my_wath_lists_Drop_Down();
			com.captureScreenshot();
			}else if(driver.getTitle().equals("404 Not Found"))
			{
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,404 Not Found"+"\n");
				C_outputfile.close();
				com.captureScreenshot();
			}else {
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,webpage not available"+"\n");
				C_outputfile.close();
				System.out.println("webpage not available");
			}
		}
		for (int j = 1; j <= Serverlist; j++) {
			if(driver.getTitle().equals("Watch List")) {
			TimeUnit.MINUTES.sleep(3);
			com.verifyElementPresent("xpath",
					"/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div");
			com.captureScreenshot();
			com.click("xpath", "/html/body/div[2]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li[2]/div[2]/div/ul/li["
					+ j + "]/div[1]/span[2]/div");
			com.captureScreenshot();
			TimeUnit.MINUTES.sleep(30);
			wl.Click_on_my_wath_lists_Drop_Down();
			}else if(driver.getTitle().equals("404 Not Found"))
			{
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,404 Not Found"+"\n");
				C_outputfile.close();
				com.captureScreenshot();
			}else {
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,webpage not available"+"\n");
				C_outputfile.close();
				System.out.println("webpage not available");
			}
		}
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify and Click on My watch lists and Server Watch Lists,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@When("^Pre defined Column Sets Drop Down$")
	public void Pre_defined_Column_Sets_Drop_Down() throws Exception {
		if(driver.getTitle().equals("Watch List")) {
		com.sleepThread(2000);
		String Pre_defined_Column_Sets_Drop_Down = Common.readPropertyByWatch_List()
				.getProperty("Pre_defined_Column_Sets_Drop_Down");
		com.click("xpath", Pre_defined_Column_Sets_Drop_Down);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Pre defined Column Sets Drop Down,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Pre defined Column Sets Drop Down,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^Verify and Click on Custom Column Sets and Predefined Column Sets$")
	public void Verify_and_Click_on_Custom_Column_Sets_and_Predefined_Column_Sets() throws Exception {
		if(driver.getTitle().equals("Watch List")){
		wl = new Watch_List();
		int Predefined = driver.findElements(By.xpath(
				"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li/div[1]/span[2]/div"))
				.size();

		System.out.println(Predefined + "---------------");
		for (int j = 1; j <= Predefined; j++) {
			if(driver.getTitle().equals("Watch List")) {
			com.captureScreenshot();
			TimeUnit.MINUTES.sleep(30);
			com.captureScreenshot();
			com.verifyElementPresent("xpath",
					"/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li[" + j
							+ "]/div[1]/span[2]/div");
			com.captureScreenshot();
			com.click("xpath", "/html/body/div[3]/div/span/div/div/div[2]/div/div/div[1]/div/ul/li/div[2]/div/ul/li["
					+ j + "]/div[1]/span[2]/div");
			com.captureScreenshot();
			TimeUnit.MINUTES.sleep(30);
			wl.Pre_defined_Column_Sets_Drop_Down();
			com.captureScreenshot();
			}else if(driver.getTitle().equals("404 Not Found"))
			{
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on Custom Column Sets and Predefined Column Sets,404 Not Found"+"\n");
				C_outputfile.close();
				com.captureScreenshot();
			}else {
				String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
				BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
				C_outputfile.append(Date_Time+",Verify and Click on Custom Column Sets and Predefined Column Sets,webpage not available"+"\n");
				C_outputfile.close();
				System.out.println("webpage not available");
			}
		}
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify and Click on Custom Column Sets and Predefined Column Sets,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify and Click on Custom Column Sets and Predefined Column Sets,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	public void Watch_list_loop() throws Exception {
		

		Watch_List = new Watch_List();
		Watch_List.Verify_the_Symbol_Linking();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.click_on_Symbol_Linking();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.check_Functionalities();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.Click_on_my_wath_lists_Drop_Down();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.Verify_and_Click_on_My_watch_lists_and_Server_Watch_Lists();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.Pre_defined_Column_Sets_Drop_Down();
		TimeUnit.MINUTES.sleep(10);
		Watch_List.Verify_and_Click_on_Custom_Column_Sets_and_Predefined_Column_Sets();
		TimeUnit.MINUTES.sleep(10);
	
}
	
	@Given("^Verify the Chart$")
	public void Verify_the_chart() throws Exception {
		com.sleepThread(100000);		
		if (driver.getTitle().equals("Chart")) {
			com.captureScreenshot();
			com.sleepThread(1000);
			Chart = Common.readPropertyByChart().getProperty("Chart");
			System.out.println(Chart);
			com.verifyElementPresent("xpath", Chart);
			com.captureScreenshot();
			
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Chart,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Verify the Chart,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
		
	}	
	@And("^Click on Chart$")
	public void Click_on_Chart() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		Chart = Common.readPropertyByChart().getProperty("Chart");
		com.click("xpath", Chart);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Chart,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Chart();
			list.Click_on_ICE_Drop_Down();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Chart,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^Click on ICE Drop Down$")
	public void Click_on_ICE_Drop_Down() throws Exception {
		if(driver.getTitle().equals("Chart")) {
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.click("xpath", ICE_Drop_Down);
		com.captureScreenshot();
		
		System.out.println("suggestion item--------------");
		TimeUnit.MINUTES.sleep(1);
	int size=driver.findElements(By.xpath("/html/body/div[2]/div/span/div/div/div[2]/div/div/span/span")).size();
			 System.out.println("suggestion item "+size);
			 System.out.println("suggestion item--------------");
	for (int i = 2; i <=size; i++) {
		if(driver.getTitle().equals("Chart")) {			
		TimeUnit.MINUTES.sleep(60);
			System.out.println(i);
		com.startAction();	
		com.MouseOverToclickabl("xpath","/html/body/div[2]/div/span/div/div/div[2]/div/div["+i+"]/span/span");							  
		TimeUnit.MINUTES.sleep(60);
		com.captureScreenshot();
		Watch_List Chart = new Watch_List();
		
		Chart.Click_on_checkbox();
		TimeUnit.MINUTES.sleep(10);
		Chart.Click_on_Delete_button();
		TimeUnit.MINUTES.sleep(10);
		Chart.Click_on_Add_button();
		TimeUnit.MINUTES.sleep(10);	
		com.click("xpath", ICE_Drop_Down);
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Select the suggestion item,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Chart();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Select the suggestion item,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}			
		}
		
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on ICE Drop Down,404 Not Found"+"\n");
			C_outputfile.close();	
			com.captureScreenshot();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on ICE Drop Down,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
//	@And("^Select the suggestion item$")
//	public void select_the_suggestion_item() throws Exception
//	{
//		System.out.println("suggestion item--------------");
//		if(driver.getTitle().equals("Chart")) {
//			
//		}else if(driver.getTitle().equals("404 Not Found"))
//		{
//			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
//			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
//			C_outputfile.append(Date_Time+",Select the suggestion item,404 Not Found"+"\n");
//			C_outputfile.close();
//		}else {
//			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
//			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
//			C_outputfile.append(Date_Time+",Select the suggestion item,webpage not available"+"\n");
//			C_outputfile.close();
//			System.out.println("webpage not available");
//		}
//	}
	@And("^Click on checkbox$")
	public void Click_on_checkbox() throws Exception {
		if(driver.getTitle().equals("Chart")) {
		String checkbox = Common.readPropertyByChart().getProperty("checkbox");
		com.click("xpath", checkbox);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on checkbox,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_checkbox();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on checkbox,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}

	@Then("^Click on Delete button$")
	public void Click_on_Delete_button() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		String Delete_button = Common.readPropertyByChart().getProperty("Delete_button");
		com.click("xpath", Delete_button);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Delete button,404 Not Found"+"\n");
			C_outputfile.close();
			com.captureScreenshot();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Delete_button();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Delete button,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}

	@Then("^Click on Add button$")
	public void Click_on_Add_button() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		String Add_Button = Common.readPropertyByChart().getProperty("Add_Button");
		com.click("xpath", Add_Button);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Add button,404 Not Found"+"\n");
			C_outputfile.close();
			Watch_List list=new Watch_List();
			list.Verify_the_logo();
			//list.Login_with_IDE_IDP_credentials_Username_and_Password("vamsi.kamatam@theice.com","Starts123");
			//list.login_button();
			TimeUnit.MINUTES.sleep(10);
			list.Click_on_Add_button();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",Click on Add button,webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	
	@When("^Click on right click on option in widget name$")
	public void Click_on_right_click_on_option_in_widget_name() throws Exception {
		com.startAction();
		String Widget_tab = Common.readPropertyByChart().getProperty("Widget_tab");
		com.MouseOverToElement("xpath", Widget_tab);
		com.Rightclick("xpath", Widget_tab);
	}

	@And("^Click on Close Other Tabs all tabs$")
	public void Click_on_Close_Other_Tabs_all_tabs() throws Exception {
		com.sleepThread(1000);
		String Close_Other_Tabs = Common.readPropertyByChart().getProperty("Close_Other_Tabs");
		com.click("xpath", Close_Other_Tabs);
	}
	
	@And("^Click on Close Tab in widget name$")
	public void Click_on_Close_Tab_in_widget_name() throws Exception {
		
		com.sleepThread(1000);
		String Close_Tab = Common.readPropertyByChart().getProperty("Close_Tab");
		com.click("xpath", Close_Tab);

	}
	
	
	
	
	}
*/