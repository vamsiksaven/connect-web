/*package Ide.Idp.StepDef;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Chart {

	public Common com = new Common();
	//public Watch_List wl;
	public WebDriver driver;
	public String Chart;
	{
		driver = Common.driver;
	}
	@Given("^Verify the Chart$")
	public void Verify_the_chart() throws Exception {
		
		if (driver.getTitle().equals("Chart")) {
			com.captureScreenshot();
			com.sleepThread(1000);
			Chart = Common.readPropertyByChart().getProperty("Chart");
			System.out.println(Chart);
			com.verifyElementPresent("xpath", Chart);
			com.captureScreenshot();
			
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
		
	}	
	@And("^Click on Chart$")
	public void Click_on_Chart() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		Chart = Common.readPropertyByChart().getProperty("Chart");
		com.click("xpath", Chart);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^Click on ICE Drop Down$")
	public void Click_on_ICE_Drop_Down() throws Exception {
		if(driver.getTitle().equals("Chart")) {
		String ICE_Drop_Down = Common.readPropertyByChart().getProperty("ICE_Drop_Down");
		com.click("xpath", ICE_Drop_Down);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^select the suggestion item$")
	public void select_the_suggestion_item() throws Exception
	{
		if(driver.getTitle().equals("Chart")) {
		int size=driver.findElements(By.xpath("/html/body/div[2]/div/span/div/div/div[2]/div/div/span/span")).size();
		for (int i = 2; i <=size; i++) {
			//TimeUnit.MINUTES.sleep(60);
			com.click("xpath","/html/body/div[2]/div/span/div/div/div[2]/div/div["+i+"]/span/span");							  
			//TimeUnit.MINUTES.sleep(60);
			com.captureScreenshot();
			Chart Chart = new Chart();
			
			Chart.Click_on_checkbox();
			//TimeUnit.MINUTES.sleep(10);
			Chart.Click_on_Delete_button();
			//TimeUnit.MINUTES.sleep(10);
			Chart.Click_on_Add_button();
			//TimeUnit.MINUTES.sleep(10);	
			Chart.Click_on_ICE_Drop_Down();
		}
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	@And("^Click on checkbox$")
	public void Click_on_checkbox() throws Exception {
		if(driver.getTitle().equals("Chart")) {
		String checkbox = Common.readPropertyByChart().getProperty("checkbox");
		com.click("xpath", checkbox);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}

	@Then("^Click on Delete button$")
	public void Click_on_Delete_button() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		String Delete_button = Common.readPropertyByChart().getProperty("Delete_button");
		com.click("xpath", Delete_button);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}

	@Then("^Click on Add button$")
	public void Click_on_Add_button() throws Exception {
		if(driver.getTitle().equals("Chart"))
		{
		String Add_Button = Common.readPropertyByChart().getProperty("Add_Button");
		com.click("xpath", Add_Button);
		com.captureScreenshot();
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
	}
	
	
	
	
	
	
	
	
	
	public void Verify_the_Chart_widget() throws Exception
	{
		if(driver.getTitle().equals("Chart"))
		{
			Chart Chart=new Chart();
			Chart.Verify_the_chart();
			Chart.Click_on_Chart();
			Chart.Click_on_ICE_Drop_Down();
			Chart.select_the_suggestion_item();	
			
		}else if(driver.getTitle().equals(""))
		{
			
		}else if(driver.getTitle().equals("404 Not Found"))
		{
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",404 Not Found"+"\n");
			C_outputfile.close();
		}else {
			String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
			BufferedWriter  C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+".txt", true));
			C_outputfile.append(Date_Time+",webpage not available"+"\n");
			C_outputfile.close();
			System.out.println("webpage not available");
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
*/