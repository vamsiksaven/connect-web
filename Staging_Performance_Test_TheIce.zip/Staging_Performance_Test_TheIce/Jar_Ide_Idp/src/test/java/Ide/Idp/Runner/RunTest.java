package Ide.Idp.Runner;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class) 

@CucumberOptions(plugin = { "html:target/cucumber-html-report",
        "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
        "usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml" },
        features = {"../Jar_Ide_Idp/Featuresfiles/Watch List.feature"},
        glue = { "Ide.Idp.StepDef" })//, tags={"@Verify_the_ligin_page_Logo,@Verify_the_login_page"})

public class RunTest {
}






//
/*"../Jar_Ide_Idp/Featuresfiles/Login.feature",
,
"../Jar_Ide_Idp/Featuresfiles/Chart.feature"*/
//../Jar_Ide_Idp/Featuresfiles/IDE_IDP.feature","../Jar_Ide_Idp/Featuresfiles/Watch List.feature