package System_InfoTest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import org.testng.Reporter;
import org.testng.annotations.Test;
import com.opencsv.CSVWriter;
//import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import System_Info.hardware.GlobalMemory;
import System_Info.hardware.HardwareAbstractionLayer;
import System_Info.software.os.OSProcess;
import System_Info.software.os.OperatingSystem;
import System_Info.software.os.OperatingSystem.ProcessSort;
import System_Info.util.FormatUtil;
import System_Info.SystemInfo;
import System_Info.hardware.CentralProcessor.TickType;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

public class SystemInfoTest extends TimerTask {

	private static final String FILE_HEADER = "Date/Time,  ProcessID, Total CPU load(counting ticks),CPU load,Total_RAM_MemorySize,Allocate_RAM_MemorySize,Chrome_CPU,  MEM,  VirtualSize, ResidentSetSize, Browser_Name\n";
	public static BufferedWriter file;
	public static Logger LOG;
	public static OperatingSystem os;
	public static HardwareAbstractionLayer hal;
	//public static CSVWriter writer;
	private static final String C_FILE_HEADER = "Date/Time,CPU load,Allocate_RAM_MemorySize\n";
	public static CSVWriter C_writer;
	public static BufferedWriter hwriter;
	public static String MiB;
	public static String percentage;
	public static String AppendMiB;
	public static FileWriter fWriter;
	public static String data;
	public static BufferedWriter C_outputfile;

	public static final double SPACE_KB = 1024;
	public static final double SPACE_MB = 1024 * SPACE_KB;
	public static final double SPACE_GB = 1024 * SPACE_MB;
	public static final double SPACE_TB = 1024 * SPACE_GB;
	public static OperatingSystemMXBean operatingSystemMXBean;
	public static long sizeInBytes;
	public static Date date;
	public static Date Time;
	public static String Date_Time;
	public static long TotalPhysicalMemorySize;
	public static long FreePhysicalMemorySize;
	public static long allocate;

	public static String Step1 = "<script src=\"https://code.highcharts.com/highcharts.js\"></script>\r\n"
			+ "<script src=\"https://code.highcharts.com/modules/data.js\"></script>\r\n"
			+ "<script src=\"https://code.highcharts.com/modules/exporting.js\"></script>\r\n" + "\r\n"
			+ "<div id=\"container\" style=\"min-width: 310px; height: 400px; margin: 0 auto\"></div>\r\n" + "\r\n"
			+ "<pre id=\"csv\" style=\"display:none\">"+C_FILE_HEADER+"";
	public static String Step2 = "</pre>\r\n" + "<script>\r\n" + "\r\n" + "Highcharts.chart('container', {\r\n" + "\r\n"
			+ "    title: {\r\n" + "        text: 'Global temperature change'\r\n" + "    },\r\n" + "\r\n"
			+ "    subtitle: {\r\n" + "        text: 'Data input from CSV'\r\n" + "    },\r\n" + "\r\n"
			+ "    data: {\r\n" + "        csv: document.getElementById('csv').innerHTML\r\n" + "    },\r\n" + "\r\n"
			+ "    plotOptions: {\r\n" + "        series: {\r\n" + "            marker: {\r\n"
			+ "                enabled: false\r\n" + "            }\r\n" + "        }\r\n" + "    },\r\n"
			+ "	xAxis: {\r\n" + "        tickInterval: 5\r\n" + "    },\r\n" + "    series: [{\r\n"
			+ "        lineWidth: 1\r\n" + "    }, {\r\n" + "        type: 'areaspline',\r\n"
			+ "        color: '#c4392d',\r\n" + "        negativeColor: '#5679c4',\r\n" + "        fillOpacity: 0.5\r\n"
			+ "    }]\r\n" + "});\r\n" + "</script>";

	@Test
	public void System_Processes() throws Exception {
		// Options: ERROR > WARN > INFO > DEBUG > TRACE
		System.setProperty(org.slf4j.impl.SimpleLogger.DEFAULT_LOG_LEVEL_KEY, "INFO");
		System.setProperty(org.slf4j.impl.SimpleLogger.LOG_FILE_KEY, "System.err");
		LOG = LoggerFactory.getLogger(SystemInfo.class);
		Date_Time = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
		C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+"Charts_Results.txt", true));
		Thread.sleep(1000);
		C_outputfile.append(C_FILE_HEADER);
		C_outputfile.append("\n");
		Thread.sleep(1000);
		C_outputfile.close();	

		// Write the Txt file
		file = new BufferedWriter(new FileWriter("./"+Date_Time+"All_result.txt", true));
		Thread.sleep(1000);
		file.append(FILE_HEADER);
		
		Thread.sleep(1000);
		file.close();
		fWriter = new FileWriter(""+Date_Time+"Chart_Report.html");
		hwriter = new BufferedWriter(fWriter);
		hwriter.write(Step1);
		LOG.info("Initializing System...");
		SystemInfo si = new SystemInfo();
		hal = si.getHardware();
		os = si.getOperatingSystem();
		System.out.println(os);
		TimerTask timerTask = new SystemInfoTest();
		// running timer task as daemon thread //10*2000
		Timer timer = new Timer(true);
		// one minute 
		timer.scheduleAtFixedRate(timerTask, 0, 6*10000);
		System.out.println("TimerTask started");
		// cancel after sometime
		try {
			//12 hours time
			TimeUnit.MINUTES.sleep(720);
			// Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		timer.cancel();
		System.out.println("TimerTask cancelled");
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		hwriter.write(Step2);		
		// closing writer connection in CSV
		Thread.sleep(1000);
		//writer.close();		
		hwriter.newLine();
		hwriter.close();
	}
	@Override
	public void run() {
		LOG.info("Checking Processes...");
		try {
			printProcesses(os, hal.getMemory(), hal.getProcessor());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void completeTask() {
		try {
			// assuming it takes 20 secs to complete the task
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private static void printProcesses(OperatingSystem os, GlobalMemory memory,
			System_Info.hardware.CentralProcessor processor) throws Exception {
		// -----------------------------------------getProcessor---------------------------------------------------------
		long[] prevTicks = processor.getSystemCpuLoadTicks();
		long[][] prevProcTicks = processor.getProcessorCpuLoadTicks();
		processor.updateAttributes();
		long[] ticks = processor.getSystemCpuLoadTicks();
		// System.out.println("CPU, IOWait, and IRQ ticks @ 1 sec:" +
		// Arrays.toString(ticks));
		long user = ticks[TickType.USER.getIndex()] - prevTicks[TickType.USER.getIndex()];
		long nice = ticks[TickType.NICE.getIndex()] - prevTicks[TickType.NICE.getIndex()];
		long sys = ticks[TickType.SYSTEM.getIndex()] - prevTicks[TickType.SYSTEM.getIndex()];
		long idle = ticks[TickType.IDLE.getIndex()] - prevTicks[TickType.IDLE.getIndex()];
		long iowait = ticks[TickType.IOWAIT.getIndex()] - prevTicks[TickType.IOWAIT.getIndex()];
		long irq = ticks[TickType.IRQ.getIndex()] - prevTicks[TickType.IRQ.getIndex()];
		long softirq = ticks[TickType.SOFTIRQ.getIndex()] - prevTicks[TickType.SOFTIRQ.getIndex()];
		long steal = ticks[TickType.STEAL.getIndex()] - prevTicks[TickType.STEAL.getIndex()];
		long totalCpu = user + nice + sys + idle + iowait + irq + softirq + steal;
		System.out.format("CPU load: %.1f%% (counting ticks)%n",
				processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100);
		System.out.format("CPU load: %.1f%% (OS MXBean)%n", processor.getSystemCpuLoad() * 100);
		double[] loadAverage = processor.getSystemLoadAverage(3);
		System.out.println("CPU load averages:" + (loadAverage[0] < 0 ? " N/A" : String.format(" %.2f", loadAverage[0]))
				+ (loadAverage[1] < 0 ? " N/A" : String.format(" %.2f", loadAverage[1]))
				+ (loadAverage[2] < 0 ? " N/A" : String.format(" %.2f", loadAverage[2])));
		// per core CPU
		StringBuilder procCpu = new StringBuilder("CPU load per processor:");
		double[] load = processor.getProcessorCpuLoadBetweenTicks(prevProcTicks);
		for (double avg : load) {
			procCpu.append(String.format(" %.1f%%", avg * 100));
		}
		System.out.println(procCpu.toString());
		long freq = processor.getVendorFreq();
		if (freq > 0) {
			System.out.println("Vendor Frequency: " + FormatUtil.formatHertz(freq));
		}
		freq = processor.getMaxFreq();
		if (freq > 0) {
			System.out.println("Max Frequency: " + FormatUtil.formatHertz(freq));
		}
		long[] freqs = processor.getCurrentFreq();
		if (freqs[0] > 0) {
			StringBuilder sb = new StringBuilder("Current Frequencies: ");
			for (int i = 0; i < freqs.length; i++) {
				if (i > 0) {
					sb.append(", ");
				}
				sb.append(FormatUtil.formatHertz(freqs[i]));
			}
			// System.out.println(sb.toString());
		}
		com.sun.management.OperatingSystemMXBean OperatingSystem = (com.sun.management.OperatingSystemMXBean) java.lang.management.ManagementFactory
				.getOperatingSystemMXBean();
		TotalPhysicalMemorySize = OperatingSystem.getTotalPhysicalMemorySize();
		FreePhysicalMemorySize = OperatingSystem.getFreePhysicalMemorySize();

		System.out.println("Total" + TotalPhysicalMemorySize);
		System.out.println("Free" + FreePhysicalMemorySize);
		allocate = TotalPhysicalMemorySize - FreePhysicalMemorySize;
		System.out.println(allocate);
		System.out.println(FormatUtil.formatBytes(allocate));

		System.out.println("Processes: " + os.getProcessCount() + ", Threads: " + os.getThreadCount());
		// Sort by highest CPU
		List<OSProcess> procs = Arrays.asList(os.getProcesses(10, ProcessSort.CPU));

		System.out.println("   PID  %CPU %MEM       VSZ       RSS Name");
		System.out.println(FILE_HEADER);

		operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();

		for (int i = 0; i < procs.size() && i < 10; i++) {
			OSProcess p = procs.get(i);
			if (String.format("%s%n", p.getName()).contains("chrome")) {

				// String Comma=",";
				Date date = new Date();
				Date Time = new Date();
				String data = String.format("%tD%tr, %5d,%.1f%%,%.1f%%,%9s,%9s, %5.1f, %4.1f, %9s, %9s, %s%n", date,
						Time, p.getProcessID(), (processor.getSystemCpuLoadBetweenTicks(prevTicks)) * 100,
						(processor.getSystemCpuLoad()) * 100, FormatUtil.formatBytes(TotalPhysicalMemorySize),
						FormatUtil.formatBytes(allocate), 100d * (p.getKernelTime() + p.getUserTime()) / p.getUpTime(),
						100d * p.getResidentSetSize() / memory.getTotal(), FormatUtil.formatBytes(p.getVirtualSize()),
						FormatUtil.formatBytes(p.getResidentSetSize()), p.getName());
				System.out.println(data);
				Reporter.log(data);
				file = new BufferedWriter(new FileWriter("./"+Date_Time+"All_result.txt", true));
				Thread.sleep(2000);
				file.append(data);
				file.close();
				Thread.sleep(2000);
				String[] split = data.split(" ");
				//writer.writeNext(split);
				// Chart data
				System.out.println("getSystemCpuLoad"+processor.getSystemCpuLoad());
				
				String C_data = String.format("%tD%tr,%.1f%%, %9s", date, Time,
						(processor.getSystemCpuLoad()) * 100, FormatUtil.formatBytes(allocate));
				 System.out.println(C_data);
				String GiB = C_data.replaceAll("GiB", "");
				MiB = GiB.replaceAll("MiB", "");
				percentage =MiB.replaceAll("%"," ");
				C_outputfile = new BufferedWriter(new FileWriter("./"+Date_Time+"Charts_Results.txt", true));
				Thread.sleep(2000);
				C_outputfile.append(C_data+"\n");
				Thread.sleep(1000);
				C_outputfile.close();		
				Reporter.log(percentage);
				String[] C_split = percentage.split(" ");				
				AppendMiB = percentage + "\n";
				hwriter.write(AppendMiB);
				break;
			}
		}
	}
}
