package Ide.Idp.StepDef;

import java.awt.Robot;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.sun.glass.events.KeyEvent;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.lexer.Ro;

public class CNBC {
	public Common com = new Common();
	public Watch_List wl;
	public WebDriver driver;
	public CNBC Cnbc;
	public String Widget_name;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());

	public CNBC() {
		driver = Common.driver;
	}

	@When("^Verify the CNBC$")
	public void Verify_the_CNBC() throws Exception {
		com.sleepThread(12000);
		String CNBC = Common.readPropertyByCNBC().getProperty("CNBC");
		com.verifyElementPresent("xpath", CNBC, "ICNTC-00001,CNBC,Verify the CNBC");
	}

	@Then("^Click on CNBC$")
	public void Click_on_CNBC() throws Exception {
		String CNBC = Common.readPropertyByCNBC().getProperty("CNBC");
		com.sleepThread(12000);
		com.click("xpath", CNBC, "ICNTC-00002,CNBC,Click on CNBC");
	}

	@When("^Verify the streans dropdown$")
	public void Verify_the_streans_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Streams_name = Common.readPropertyByCNBC().getProperty("Streams_name");
		com.verifyElementPresent("xpath", Streams_name, "ICNTC-00003," + Widget_name + ",Verify the streans dropdown");

	}

	@Then("^Click on streams dropdown$")
	public void Click_on_streams_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Streams = Common.readPropertyByCNBC().getProperty("Streams");
		com.click("xpath", Streams, "ICNTC-00004," + Widget_name + ",Click on streams dropdown");

	}

	@And("^Select the streams dropdown all option$")
	public void Select_the_streams_dropdown_all_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li/button")).size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[" + i + "]/button",
					"ICNTC-00005," + Widget_name + ",Select the streams dropdown all option");
		}
	}

	@When("^Verify the select video dropdown$")
	public void Verify_the_select_video_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Select_video_name = Common.readPropertyByCNBC().getProperty("Select_video_name");
		com.verifyElementPresent("xpath", Select_video_name,
				"ICNTC-00006," + Widget_name + ",Verify the select video dropdown");
	}

	@Then("^Click on select video dropdown$")
	public void Click_on_select_video_dropdown() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Select_video = Common.readPropertyByCNBC().getProperty("Select_video");
		com.click("xpath", Select_video, "ICNTC-00007," + Widget_name + ",Click on select video dropdown");
	}

	@And("^Select the CNBC US option$")
	public void Select_the_CNBC_US_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String CNBC_US_option = Common.readPropertyByCNBC().getProperty("CNBC_US_option");
		com.click("xpath", CNBC_US_option, "ICNTC-00008," + Widget_name + ",Select the CNBC US option");
		// String
		// Downloading_video_info=Common.readPropertyByCNBC().getProperty("Downloading_video_info");
		// com.verifyText_Using_String("xpath",Downloading_video_info,"Downloading video
		// info",",,");
	}

	@When("^Check whether Pause button is working or not$")
	public void Check_whether_Pause_button_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(9000);
		com.startAction();
		String Video = Common.readPropertyByCNBC().getProperty("Video");
		com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
		com.sleepThread(2000);
		String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
		com.MouseOverToclickabl("xpath", Pause_button,
				"," + Widget_name + ",Check whether Pause button is working or not");

		/*com.sleepThread(9000);
		try {
		String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
		com.MouseOverToclickabl("xpath", Pause_button,
				"," + Widget_name + ",Check whether Pause button is working or not");
		} catch (FileNotFoundException e) {
			com.sleepThread(3000);
			String Play_button = Common.readPropertyByCNBC().getProperty("Play_button");
			com.MouseOverToclickabl("xpath", Play_button, "," + Widget_name + ",Click on play button is working or not");

		}*/
	}

	@Then("^Click on play button is working or not$")
	public void Click_on_play_button_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(7000);
		com.startAction();
		String Video = Common.readPropertyByCNBC().getProperty("Video");
		com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
//		com.sleepThread(2000);
//		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
//		com.MouseOverToclickabl("xpath", menu_bar, "," + Widget_name + ",Mouse over on menu bar");
		try {
		com.sleepThread(3000);
		String Play_button = Common.readPropertyByCNBC().getProperty("Play_button");
		com.verifyElementPresent("xpath", Play_button, "," + Widget_name + ",Verify the play button is working or not");
		}catch(ArithmeticException t){
			System.out.println("unable to click on play button");
		}
	}

	@When("^Check whether Mute button is working or not$")
	public void Check_whether_Mute_button_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(7000);
		com.startAction();
		String Video = Common.readPropertyByCNBC().getProperty("Video");
		com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
//		com.sleepThread(2000);
//		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
//		com.MouseOverToclickabl("xpath", menu_bar, "," + Widget_name + ",Mouse over on menu bar");
		com.sleepThread(2000);
		String mute_button = Common.readPropertyByCNBC().getProperty("mute_button");
		com.MouseOverToclickabl("xpath", mute_button,
				"," + Widget_name + ",Check whether Mute button is working or not");
	}

	@Then("^Click on unmute button$")
	public void Click_on_unmute_button() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		com.startAction();
		String Video = Common.readPropertyByCNBC().getProperty("Video");
		com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
//		com.sleepThread(2000);
//		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
//		com.MouseOverToclickabl("xpath", menu_bar, "," + Widget_name + ",Mouse over on menu bar");
		com.sleepThread(2000);
		String unmute_button = Common.readPropertyByCNBC().getProperty("unmute_button");
		com.verifyElementPresent("xpath", unmute_button, "ICNTC-00008," + Widget_name + ",Verify the unmute button");

	}

	@When("^Check whether Captions off option is working or not$")
	public void Check_whether_Captions_off_option_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(5000);
		com.startAction();
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
				.click();
		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
		com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
		com.sleepThread(3000);
		String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
		com.MouseOverToElement("xpath", Captions_option,
				"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
		System.out.println("****************");
		com.sleepThread(3000);
		// String
		// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
		com.click("xpath", Captions_option,
				"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
		com.sleepThread(3000);
		String captions_off = Common.readPropertyByCNBC().getProperty("captions_off");
		com.MouseOverToclickabl("xpath", captions_off,
				"ICNTC-00008," + Widget_name + ",Check whether Captions off option is working or not");

	}

	@When("^Check whether cc1 cc Captions option is working or not$")
	public void Check_whether_cc1_cc_Captions_option_is_working_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.startAction();
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
				.click();
		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
		com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
		com.sleepThread(3000);
		String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
		com.MouseOverToElement("xpath", Captions_option,
				"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
		System.out.println("****************");
		com.sleepThread(3000);
		// String
		// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
		com.click("xpath", Captions_option,
				"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
		com.sleepThread(3000);
		String CC1 = Common.readPropertyByCNBC().getProperty("CC1");
		com.click("xpath", CC1,
				"ICNTC-00008," + Widget_name + ",Check whether cc1 cc Captions option is working or not");
	}

	@When("^Mouse over on captions option in CNBC us video$")
	public void Mouser_over_on_captions_option_in_CNBC_us_video() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(8000);
		com.startAction();
		driver.findElement(By.xpath(
				"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
				.click();
		// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
		// com.click("xpath",play_button,",,Click on play button");
		String video = Common.readPropertyByCNBC().getProperty("video");
		com.MouseOverToElement("xpath", video, "ICNTC-00009," + Widget_name + ",Mouse over on live video");
		String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
		com.MouseOverToclickabl("xpath", menu_bar, "," + Widget_name + ",Mouse over on menu bar");
		com.sleepThread(3000);
		String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
		com.MouseOverToElement("xpath", Captions_option,
				"," + Widget_name + ",Mouse over on captions option in CNBC us video");
		System.out.println("****************");
	}

	@Then("^Check whether Captions option is working or not in CNBC us video$")
	public void Verify_the_captions_option_in_CNBC_us_video() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
		com.verifyElementPresent("xpath", Captions_option, "ICNTC-00010," + Widget_name
				+ ",Check whether Captions option is working or not in CNBC us video in CNBC us video");

	}

	@And("^Click on captions option in CNBC us video$")
	public void Click_on_captions_option_in_CNBC_us_video() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
		com.click("xpath", Captions_option,
				"ICNTC-00011," + Widget_name + ",Click on captions option in CNBC us video");
	}

	@Then("^Verify the captions settings option is showing or not$")
	public void Verify_the_captions_settings_option_is_showing_or_not() throws Exception {

		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
		com.verifyElementPresent("xpath", captions_settings,
				"ICNTC-00012," + Widget_name + ",Verify the captions settings option is showing or not");

	}

	@And("^Click on captions settings option$")
	public void Click_on_captions_settings_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
		com.startAction();
		com.MouseOverToclickabl("xpath", captions_settings,
				"ICNTC-00013," + Widget_name + ",Click on captions settings option");

	}

	@And("^modal dialog content is showing or not$")
	public void modal_dialog_content_is_showing_or_not() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String modal_dialog_content = Common.readPropertyByCNBC().getProperty("modal_dialog_content");
		com.verifyElementPresent("xpath", modal_dialog_content,
				"ICNTC-00014," + Widget_name + ",modal dialog content is showing or not");

	}

	public void click_on_Done_button() throws Exception {
		String Done_button = Common.readPropertyByCNBC().getProperty("Done_button");
		com.click("xpath", Done_button, "ICNTC-00015," + Widget_name + ",Click on Done button");
	}

	@When("^Verify the all Text dropdowns options$")
	public void Verify_the_all_Text_dropdowns_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Text_Color = Common.readPropertyByCNBC().getProperty("Text_Color");
		Select sel = new Select(driver.findElement(By.xpath(Text_Color)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Text_Color" + list.size());
		for (int i = 1; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}

		String Text_opacity = Common.readPropertyByCNBC().getProperty("Text_opacity");
		Select sel1 = new Select(driver.findElement(By.xpath(Text_opacity)));
		List<WebElement> list1 = sel1.getOptions();
		System.out.println("Text_opacity:" + list1.size());
		for (int i = 1; i < list1.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}

	}

	@When("^Verify the all Background dropdown options$")
	public void Verify_the_all_Background_dropdown_options() throws Exception {

		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Background_color = Common.readPropertyByCNBC().getProperty("Background_color");
		Select sel = new Select(driver.findElement(By.xpath(Background_color)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Background_color" + list.size());
		for (int i = 1; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}

		String Background_opacity = Common.readPropertyByCNBC().getProperty("Background_opacity");
		Select sel1 = new Select(driver.findElement(By.xpath(Background_opacity)));
		List<WebElement> list1 = sel1.getOptions();
		System.out.println("Background_opacity:" + list1.size());
		for (int i = 1; i < list1.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}
	}

	@When("^Verify the all Window dropdown options$")
	public void Verify_the_all_Window_dropdown_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Window_color = Common.readPropertyByCNBC().getProperty("Window_color");
		Select sel = new Select(driver.findElement(By.xpath(Window_color)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Window_color" + list.size());
		for (int i = 1; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}

		String Window_opacity = Common.readPropertyByCNBC().getProperty("Window_opacity");
		Select sel1 = new Select(driver.findElement(By.xpath(Window_opacity)));
		List<WebElement> list1 = sel1.getOptions();
		System.out.println("Window_opacity:" + list1.size());
		for (int i = 1; i < list1.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}
	}

	@When("^Verify the all Font Size dropdown options$")
	public void Verify_the_all_Font_Size_dropdown_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Font_Size = Common.readPropertyByCNBC().getProperty("Font_Size");
		Select sel = new Select(driver.findElement(By.xpath(Font_Size)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Font_Size" + list.size());
		for (int i = 1; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}

	}

	@When("^Verify the all Text Edge Style dropdown options$")
	public void Verify_the_all_Text_Edge_Style_dropdown_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Text_Edge_Style = Common.readPropertyByCNBC().getProperty("Text_Edge_Style");
		Select sel = new Select(driver.findElement(By.xpath(Text_Edge_Style)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Text_Edge_Style" + list.size());
		for (int i = 1; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}
	}

	@When("^Verify the all Font Family dropdown options$")
	public void Verify_the_all_Font_Family_dropdown_options() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(3000);
		String Font_Family = Common.readPropertyByCNBC().getProperty("Font_Family");
		Select sel = new Select(driver.findElement(By.xpath(Font_Family)));
		List<WebElement> list = sel.getOptions();
		System.out.println("Font_Family" + list.size());
		for (int i = 0; i < list.size(); i++) {
			System.out.println(i);
			sel.selectByIndex(i);
			Cnbc = new CNBC();
			com.sleepThread(3000);
			Cnbc.click_on_Done_button();
			com.sleepThread(9000);
			com.startAction();
			// String video=Common.readPropertyByCNBC().getProperty("video");
			// com.MouseOverToElement("xpath",video,",,Mouse over on live video");
			// com.sleepThread(4000);
			// String play_button=Common.readPropertyByCNBC().getProperty("play_button");
			// com.click("xpath",play_button,",,Click on play button");
			driver.findElement(By.xpath(
					"/html/body/div/div/div/div/div/div[4]/div/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/button[1]"))
					.click();
			String menu_bar = Common.readPropertyByCNBC().getProperty("menu_bar");
			com.MouseOverToclickabl("xpath", menu_bar, "ICNTC-00016," + Widget_name + ",Mouse over on menu bar");
			com.sleepThread(3000);
			String Captions_option = Common.readPropertyByCNBC().getProperty("Captions_option");
			com.MouseOverToElement("xpath", Captions_option,
					"ICNTC-00017," + Widget_name + ",Mouse over on captions option in CNBC us video");
			System.out.println("****************");
			com.sleepThread(3000);
			// String
			// Captions_option=Common.readPropertyByCNBC().getProperty("Captions_option");
			com.click("xpath", Captions_option,
					"ICNTC-00018," + Widget_name + ",Click on captions option in CNBC us video");
			com.sleepThread(3000);
			String captions_settings = Common.readPropertyByCNBC().getProperty("captions_settings");
			com.startAction();
			com.MouseOverToclickabl("xpath", captions_settings,
					"ICNTC-00019," + Widget_name + ",Click on captions settings option");
			com.sleepThread(3000);
		}
	}

	@Then("^Verify the reset button in modal dialog content$")
	public void Verify_the_reset_button_in_modal_dialog_content() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Reset_button = Common.readPropertyByCNBC().getProperty("Reset_button");
		com.verifyElementPresent("xpath", Reset_button,
				"ICNTC-00020," + Widget_name + ",Verify the reset button in modal dialog content");

	}

	@And("^Click on reset button in modal dialog content$")
	public void Click_on_reset_button_in_modal_dialog_content() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Reset_button = Common.readPropertyByCNBC().getProperty("Reset_button");
		com.click("xpath", Reset_button,
				"ICNTC-00021," + Widget_name + ",Click on reset button in modal dialog content");

	}

	@Then("^Verify the Close icon in modal dialog content$")
	public void Verify_the_Close_icon_in_modal_dialog_content() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Close_button = Common.readPropertyByCNBC().getProperty("Close_button");
		com.verifyElementPresent("xpath", Close_button,
				"ICNTC-00022," + Widget_name + ",Verify the Close icon in modal dialog content");

	}

	@And("^Click on close icon in modal dialog content$")
	public void Click_on_close_icon_in_modal_dialog_content() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		com.sleepThread(2000);
		String Close_button = Common.readPropertyByCNBC().getProperty("Close_button");
		com.click("xpath", Close_button, "ICNTC-00023," + Widget_name + ",Click on close icon in modal dialog content");
	}

	@Then("^Verify the full screen and click on it$")
	public void Verify_the_full_screen_and_click_on_it() throws Exception {

		String Fullscreen_button = Common.readPropertyByCNBC().getProperty("Fullscreen_button");
		com.verifyElementPresent("xpath", Fullscreen_button,
				"ICNTC-00024," + Widget_name + ",Verify the full screen and click on it");
		com.click("xpath", Fullscreen_button, "ICNTC-00025," + Widget_name + ",Click on full screen");
		com.sleepThread(1000);
		com.startAction();
		String Video = Common.readPropertyByCNBC().getProperty("Video");
		com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
	//	String Non_Fullscreen_button = Common.readPropertyByCNBC().getProperty("Non_Fullscreen_button");
	//	com.click("xpaths",Non_Fullscreen_button, "ICNTC-00026," + Widget_name + ",Click on Non Fullscreen button");
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ESCAPE);
		robot.keyRelease(KeyEvent.VK_ESCAPE);
	}

	@And("^Select the CNBC EUROPE option$")
	public void Select_the_CNBC_EUROPE_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String CNBC_EUROPE_option = Common.readPropertyByCNBC().getProperty("CNBC_EUROPE_option");
		com.click("xpath", CNBC_EUROPE_option, "ICNTC-00027," + Widget_name + ",Select the CNBC EUROPE option");
		try {
			com.sleepThread(4000);
			com.startAction();
			String Video = Common.readPropertyByCNBC().getProperty("Video");
			com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
			com.sleepThread(2000);
			String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
			com.MouseOverToclickabl("xpath", Pause_button,
					"," + Widget_name + ",Check whether Pause button is working or not");
			
		}catch(ArithmeticException t){
		String Downloading_video_info = Common.readPropertyByCNBC().getProperty("Downloading_video_info");
		com.verifyText_Using_String("xpath", Downloading_video_info, "Downloading video info",
				"ICNTC-00028," + Widget_name + ",");

	}}

	@And("^Select the CNBC ASIA option$")
	public void Select_the_CNBC_ASIA_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String CNBC_ASIA_option = Common.readPropertyByCNBC().getProperty("CNBC_ASIA_option");
		com.click("xpath", CNBC_ASIA_option, "ICNTC-00020," + Widget_name + ",Select the CNBC ASIA option");
		try {
			com.sleepThread(4000);
			com.startAction();
			String Video = Common.readPropertyByCNBC().getProperty("Video");
			com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
			com.sleepThread(2000);
			String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
			com.MouseOverToclickabl("xpath", Pause_button,
					"," + Widget_name + ",Check whether Pause button is working or not");
			
		}catch(ArithmeticException t){
		String Downloading_video_info = Common.readPropertyByCNBC().getProperty("Downloading_video_info");
		com.verifyText_Using_String("xpath", Downloading_video_info, "Downloading video info", ",,");
	}}

	@When("^Select the on demand option$")
	public void Select_the_on_demand_option() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		Cnbc = new CNBC();
		Cnbc.Click_on_streams_dropdown();
		String On_Demand = Common.readPropertyByCNBC().getProperty("On_Demand");
		com.click("xpath", On_Demand, ",,Select the on demand option");
	}

	@Then("^Verify the Choose a video item text$")
	public void Verify_the_Choose_a_video_item_text() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		try {
			com.sleepThread(4000);
			com.startAction();
			String Video = Common.readPropertyByCNBC().getProperty("Video");
			com.MouseOverToElement("xpath", Video, "," + Widget_name + ",Mouse over on video");
			com.sleepThread(2000);
			String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
			com.verifyElementPresent("xpath", Pause_button,
					"," + Widget_name + ",Check whether Pause button is working or not");
			
		}catch(ArithmeticException t){
		String Choose_a_video_item = Common.readPropertyByCNBC().getProperty("Downloading_video_info");
		com.verifyText_Using_String("xpath", Choose_a_video_item, "Choose a video item",
				",,Verify the Choose a video item text");
	}}

	@And("^Select the videos list$")
	public void Select_the_videos_list() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		Cnbc = new CNBC();
		Cnbc.Click_on_streams_dropdown();
		int size = driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[6]/div/ul/li/button")).size();
		for (int i = 1; i < size; i++) {
			com.click("xpath", "//*[@id='container']/div/div/div/div/div[6]/div/ul/li[" + i + "]/button", "");
			com.sleepThread(4000);
			com.startAction();
			String Video = Common.readPropertyByCNBC().getProperty("Video");
			com.MouseOverToclickabl("xpath", Video, "," + Widget_name + ",Mouse over on video");
			com.sleepThread(2000);
			String Pause_button = Common.readPropertyByCNBC().getProperty("Pause_button");
			com.verifyElementPresent("xpath", Pause_button, ",,Verify the pause button");
			com.sleepThread(3000);
			Cnbc.Click_on_streams_dropdown();

		}

	}

}
