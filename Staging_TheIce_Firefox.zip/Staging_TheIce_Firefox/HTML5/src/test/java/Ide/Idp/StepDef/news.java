package Ide.Idp.StepDef;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.experimental.theories.Theory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.mongodb.connection.Stream;

import LIB.Common;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.lu.wann;

public class news {
	public Common com = new Common();
	public WebDriver driver;
	String Date_Time = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
	public String Widget_name;
	public news news;
	public news() {
		driver = Common.driver;
	}
	@Given("^Verify the News$")
	public void Verify_the_news() throws Exception {
		com.sleepThread(12000);
		String News = Common.readPropertyByNews().getProperty("News");
		com.verifyElementPresent("xpath", News, "INTC-00001,News,Verify the News");

	}
	@And("^clicked on news widget$")
	public void Click_on_news() throws Exception {
		String News = Common.readPropertyByNews().getProperty("News");
		com.sleepThread(12000);
		com.click("xpath", News, "INTC-00002,Options,Click on News");		
	}
	
	
	@When("^Verify the Symbol Linking in news$")
	public void Verify_the_Symbol_Linking_in_news() throws Exception {
		com.sleepThread(3000);
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		System.out.println(Widget_name);
		String Symbol_Linking = Common.readPropertyByWatch_List().getProperty("Symbol_Linking");
		com.verifyElementPresent("xpath", Symbol_Linking,
				"INTC-00003," + Widget_name + ",Verify the Symbol Linking in news");
	}

	@And("^Click on Symbol Linking in News$")
	public void click_on_Symbol_Linking_in_news() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		String Symbol_Linking = Common.readPropertyByNews().getProperty("Symbol_Linking");
		com.sleepThread(3000);
		com.click("xpath", Symbol_Linking, "INTC-00004," + Widget_name + ",Click on Symbol Linking in news");
	}

	@And("^click on each Check Functionalities in News$")
	public void check_Functionalities_in_news() throws Exception {
		Widget_name = driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name")))
				.getText();
		news = new news();
		int count = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
		System.out.println(count);

		com.sleepThread(2000);

		for (int i = 1; i < 2; i++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
					"INTC-00005," + Widget_name + ",Verify the each Check Functionalities in news");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + i + "]/button/label",
					"INTC-00006," + Widget_name + ",Click on each Check Functionalities in news");
			com.sleepThread(3000);
			news.click_on_Symbol_Linking_in_news();
		}

		news = new news();
		int count1 = driver
				.findElements(By.xpath("//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li/button/label")).size();
		System.out.println(count1);

		com.sleepThread(2000);

		for (int j = 4; j <= 10; j++) {
			com.verifyElementPresent("xpath",
					"//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
					"INTC-00005," + Widget_name + ",Verify the each Check Functionalities in Chart");
			com.click("xpath", "//*[@id=\"container\"]/div/div/div/div/div[6]/div/ul/li[" + j + "]/button/label",
					"INTC-00006," + Widget_name + ",Click on each Check Functionalities in news");
			com.sleepThread(3000);
			news.click_on_Symbol_Linking_in_news();
		}
	}

	@When("^Verify the show hide filter option$")
	public void Verify_the_show_hide_filteroption() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String show_hide_filter=Common.readPropertyByNews().getProperty("show_hide_filter");
		com.verifyElementPresent("xpath",show_hide_filter ,"INTC-00007,"+Widget_name+",Verify the show hide filter option");
	}
	@Then("^Sub options hide or not when our Click on show hider filter option$")
	public void Sub_options_hide_or_not_when_our_Click_on_show_hider_filter_option() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String show_hide_filter=Common.readPropertyByNews().getProperty("show_hide_filter");
		com.click("xpath",show_hide_filter ,"INTC-00008,"+Widget_name+",Sub options hide or not when our Click on show hider filter option");
		String Sub_options_hide=Common.readPropertyByNews().getProperty("Sub_options_hide");
		com.verify_pop_closeing_or_not("xpath",Sub_options_hide,"INTC-00009,"+Widget_name+",Sub options hide or not");
	}
	public void Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols() throws Exception {
		
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String News_headline=Common.readPropertyByNews().getProperty("News_headline");
		com.verifyElementPresent("xpath",News_headline,"INTC-00010,"+Widget_name+",Check whether the news is displaying or not for selected Active symbols");

	}
	
	public void Verify_whether_the_selected_news_story_is_displaying_the_news_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(3000);
		String related_news_open_left=Common.readPropertyByNews().getProperty("related_news_open_left");
		com.verifyElementPresent("xpath",related_news_open_left,"INTC-00011,"+Widget_name+",Verify whether the selected news story is displaying the news or not");
	}

	public void Verify_Previous_button_is_working_or_not_in_News_story() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Previous_button=Common.readPropertyByNews().getProperty("Previous_button");
		com.verifyElementPresent("xpath",Previous_button,"INTC-00012,"+Widget_name+",Verify Previous button is working or not in News story");
		com.click("xpath",Previous_button,"INTC-00013,"+Widget_name+",Clickable or not on Previous button in News story");
		com.sleepThread(3000);
	}
	public void Verify_Next_button_is_working_or_not_in_News_story() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Next_button=Common.readPropertyByNews().getProperty("Next_button");
		com.verifyElementPresent("xpath",Next_button,"INTC-00014,"+Widget_name+",Verify Next button is working or not in News story");
		com.click("xpath",Next_button,"INTC-00015,"+Widget_name+",Clickable or not on Next button in News story");
		com.sleepThread(3000);
	}
	public void Verify_Flag_option_is_working_or_not_in_News_story() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Flag_option=Common.readPropertyByNews().getProperty("Flag_option");
		com.verifyElementPresent("xpath",Flag_option,"INTC-00016,"+Widget_name+",Verify Flag option is working or not in News story");
		com.click("xpath",Flag_option,"INTC-00017,"+Widget_name+",Clickable or not on Flag option in News story");
		com.sleepThread(3000);
	}
	
	public void Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Copy_New_story_text=Common.readPropertyByNews().getProperty("Copy_New_story_text");
		com.verifyElementPresent("xpath",Copy_New_story_text,"INTC-00018,"+Widget_name+",Verify Copy New story text to the clipboard option is working or not in News Story");
		com.click("xpath",Copy_New_story_text,"INTC-00019,"+Widget_name+",Clickable or not on clipboard option in News story");
		com.sleepThread(3000);
	}

	public void Verify_X_close_button_is_working_or_not() throws Exception
{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Verify_X_close_button=Common.readPropertyByNews().getProperty("Verify_X_close_button");
		com.verifyElementPresent("xpath",Verify_X_close_button,"INTC-00004,"+Widget_name+",Verify X close button is working or not");
		com.click("xpath",Verify_X_close_button,"INTC-00020,"+Widget_name+",click X close button is working or not");		
		com.sleepThread(3000);
		String News_headline=Common.readPropertyByNews().getProperty("News_headline");
		com.verifyElementPresent("xpath",News_headline,"INTC-00021,"+Widget_name+",Verify whether the selected news story is closeing or not");
}
	@When("^Verify the Industries Drop down$")
	public void Verify_the_Industries_Drop_down() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String show_hide_filter=Common.readPropertyByNews().getProperty("show_hide_filter");
		com.click("xpath",show_hide_filter ,"INTC-00008,"+Widget_name+",Sub options hide or not when our Click on show hider filter option");
		String Industries_Drop_down=Common.readPropertyByNews().getProperty("Industries_Drop_down");
		com.verifyElementPresent("xpath",Industries_Drop_down ,"INTC-00022,"+Widget_name+",Verify the Industries Drop down");
	}
	@Then("^Click on Industries Drop down$")
	public void Click_on_Industries_Drop_down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Industries_Drop_down=Common.readPropertyByNews().getProperty("Industries_Drop_down");
		com.click("xpath",Industries_Drop_down ,"INTC-00023,"+Widget_name+",Click on Industries Drop down");

	}
	@When("^Check Industries Drop down is working or not$")
	public void Check_Industries_Drop_down_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Industries_Drop_down=Common.readPropertyByNews().getProperty("Industries_Drop_down");	
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]/label[1]")).size();
		for (int i = 1; i <3; i++) {
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]/label[1]","INTC-00024,"+Widget_name+",Check Industries Drop down is working or not");
			com.sleepThread(3000);
			if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
			com.sleepThread(6000);
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
			com.sleepThread(3000);
			news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(3000);
			String Industries_close_icon=Common.readPropertyByNews().getProperty("Industries_close_icon");
			com.click("xpath",Industries_close_icon,"INTC-00026,"+Widget_name+",Click on Industries close icon");
			com.sleepThread(3000);
			news.Click_on_Industries_Drop_down();
			}else
			{
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
		}
	}
		
	@When("^Verify the Services Drop down$")
	public void Verify_the_Services_Drop_down() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Services_Drop_down=Common.readPropertyByNews().getProperty("Services_Drop_down");
		com.verifyElementPresent("xpath",Services_Drop_down ,"INTC-00027,"+Widget_name+",Verify the Services Drop down");
	}
	@Then("^Click on Services Drop down$")
	public void Click_on_Services_Drop_down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(3000);
		String Menu_bar_options=Common.readPropertyByNews().getProperty("Menu_bar_options");
		com.click("xpath",Menu_bar_options,"INTC-00057,"+Widget_name+",click on menu bar option in news widget");
		String Services_Drop_down=Common.readPropertyByNews().getProperty("Services_Drop_down");
		com.click("xpath",Services_Drop_down ,"INTC-00028,"+Widget_name+",Click on Services Drop down");

	}
	@When("^Check Services Drop down is working or not$")
	public void Check_Services_Drop_down_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Services_Drop_down=Common.readPropertyByNews().getProperty("Services_Drop_down");	
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]/label[1]")).size();
		for (int i = 1; i <3; i++) {
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]/label[1]","INTC-00029,"+Widget_name+",Check Services Drop down is working or not");
			com.sleepThread(6000);
			try{driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,"INTC-00030,"+Widget_name+",Verify the Services related news");
			news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(3000);
			String Services_close_icon=Common.readPropertyByNews().getProperty("Services_close_icon");
			com.click("xpath",Services_close_icon,"INTC-00031,"+Widget_name+",Click on Services close icon");
			com.sleepThread(3000);
			news.Click_on_Services_Drop_down();
			}catch(Exception t){
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
		}
	}
	@When("^Verify the Date Drop down$")
	public void Verify_the_Date_Drop_down() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Date_Drop_down=Common.readPropertyByNews().getProperty("Date_Drop_down");
		com.verifyElementPresent("xpath",Date_Drop_down ,"INTC-00032,"+Widget_name+",Verify the Date Drop down");
	}
	@Then("^Click on Date Drop down$")
	public void Click_on_Date_Drop_down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(3000);
		com.startAction();
		String Menu_bar_options=Common.readPropertyByNews().getProperty("Menu_bar_options");
		com.click("xpath",Menu_bar_options,"INTC-00057,"+Widget_name+",click on menu bar option in news widget");
		String Date_Drop_down=Common.readPropertyByNews().getProperty("Date_Drop_down");
		com.MouseOverToclickabl("xpath",Date_Drop_down ,"INTC-00033,"+Widget_name+",Click on Date Drop down");

	}
	@When("^Check Date Drop down is working or not$")
	public void Check_Date_Drop_down_is_working_or_not() throws Exception {
		news=new news();
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Date_Drop_down=Common.readPropertyByNews().getProperty("Date_Drop_down");	
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[3]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div")).size();
		System.out.println("Date_Drop_down:"+size);
		for (int i = 1; i <3; i++) {
			com.sleepThread(8000);
			com.startAction();
			com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[3]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div["+i+"]","INTC-00034,"+Widget_name+",Check Date Drop down is working or not");
			driver.navigate().refresh();
			com.sleepThread(15000);
			try{
				driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.verifyElementPresent("xpath", related_news,"Verify the news");
				com.click("xpath", related_news,"click on news");
				String  News_headline=Common.readPropertyByNews().getProperty("News_headline");
				String  News_headline1=driver.findElement(By.xpath(News_headline)).getText();
				System.out.println("News_headline1: "+News_headline1+i+"");
				com.sleepThread(3000);
				String  related_news_open_left=Common.readPropertyByNews().getProperty("related_news_open_left");
				String  related_news_open_left1=driver.findElement(By.xpath(related_news_open_left)).getText();
				System.out.println("related_news_open_left1 :"+related_news_open_left1+i+"");
				news=new news();
				news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
				news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
				news.Verify_Previous_button_is_working_or_not_in_News_story();
				news.Verify_Next_button_is_working_or_not_in_News_story();
				news.Verify_Flag_option_is_working_or_not_in_News_story();
				news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
				news.Verify_X_close_button_is_working_or_not();
				//com.verifyText_Using_String("xpath", News_headline, related_news_open_left1, "Varify the news related");

			com.verifyElementPresent("xpath",related_news,"INTC-00035,"+Widget_name+",Verify the Date related news");
			com.sleepThread(5000);			
			news.Click_on_Date_Drop_down();
			}catch(Exception t){
				com.sleepThread(9000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyElementPresent("xpath",No_stories_matching_your_selection,","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
		}
	}
	
	
	@When("^Verify the Geography Drop down$")
	public void Verify_the_Geography_Drop_down() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Geography_Drop_down=Common.readPropertyByNews().getProperty("Geography_Drop_down");
		com.verifyElementPresent("xpath",Geography_Drop_down ,"INTC-00036,"+Widget_name+",Verify the Geography Drop down");
	}
	@Then("^Click on Geography Drop down$")
	public void Click_on_Geography_Drop_down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.sleepThread(3000);
		String Menu_bar_options=Common.readPropertyByNews().getProperty("Menu_bar_options");
		com.click("xpath",Menu_bar_options,"INTC-00057,"+Widget_name+",click on menu bar option in news widget");
		String Geography_Drop_down=Common.readPropertyByNews().getProperty("Geography_Drop_down");
		com.click("xpath",Geography_Drop_down ,"INTC-00037,"+Widget_name+",Click on Geography Drop down");

	}
	@When("^Check Geography Drop down is working or not$")
	public void Check_Geography_Drop_down_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Geography_Drop_down=Common.readPropertyByNews().getProperty("Geography_Drop_down");
		//com.click("xpath",Topics_Drop_down,"INTC-00039,"+Widget_name+",Click on Geography drop down");
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]/label[1]")).size();
		for (int i = 1; i <3; i++) {
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]/label[1]","INTC-00038,"+Widget_name+",Check Geography Drop down is working or not");
			com.sleepThread(6000);	
			if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
			news=new news();
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,"INTC-00039,"+Widget_name+",Verify the Geography related news");
			news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(3000);
			String Geography_close_icon=Common.readPropertyByNews().getProperty("Geography_close_icon");
			com.click("xpath",Geography_close_icon,"INTC-00040,"+Widget_name+",Click on Geography close icon");
			com.sleepThread(3000);
			news.Click_on_Geography_Drop_down();
			}else
			{
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
			}
	}
	
	
	@When("^Verify the Topics Drop down$")
	public void Verify_the_Topics_Drop_down() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Topics_Drop_down=Common.readPropertyByNews().getProperty("Topics_Drop_down");
		com.verifyElementPresent("xpath",Topics_Drop_down ,"INTC-00041,"+Widget_name+",Verify the Topics Drop down");
	}
	@Then("^Click on Topics Drop down$")
	public void Click_on_Topics_Drop_down() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Menu_bar_options=Common.readPropertyByNews().getProperty("Menu_bar_options");
		com.click("xpath",Menu_bar_options,"INTC-00057,"+Widget_name+",click on menu bar option in news widget");
		String Topics_Drop_down=Common.readPropertyByNews().getProperty("Topics_Drop_down");
		com.click("xpath",Topics_Drop_down ,"INTC-00042,"+Widget_name+",Click on Topics Drop down");

	}
	@When("^Check Topics Drop down is working or not$")
	public void Check_Topics_Drop_down_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Topics_Drop_down=Common.readPropertyByNews().getProperty("Topics_Drop_down");	
		int size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li/button[1]/label[1]")).size();
		for (int i = 1; i <3; i++) {			
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/ul[1]/li["+i+"]/button[1]/label[1]","INTC-00043,"+Widget_name+",Check Topics Drop down is working or not");
			com.sleepThread(6000);	
			if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,"INTC-00044,"+Widget_name+",Verify the Topics related news");
			news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(3000);
			String Topics_close_icon=Common.readPropertyByNews().getProperty("Topics_close_icon");
			com.click("xpath",Topics_close_icon,"INTC-00045,"+Widget_name+",Click on Topics close icon");
			com.sleepThread(3000);
			news.Click_on_Topics_Drop_down();
			}else
			{
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}	
		}
	}
	
	@When("^Verify Clear Filter Option is working or not$")
	public void Verify_Clear_Filter_Option_is_working_or_not() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String  Clear_Filter=Common.readPropertyByNews().getProperty("Clear_filter");
		com.click("xpath",Clear_Filter,"INTC-00046,"+Widget_name+",Verify Clear Filter Option is working or not");
		com.sleepThread(5000);
		String Industries_select=Common.readPropertyByNews().getProperty("Industries_select");
		com.verifyText_Using_String("xpath",Industries_select,"Select",","+Widget_name+",Verify the Industries drop down is clear or not");
		String Services_select=Common.readPropertyByNews().getProperty("Services_select");
		com.verifyText_Using_String("xpath",Services_select,"Select",","+Widget_name+",Verify the Services drop down is clear or not");
		String Date_select=Common.readPropertyByNews().getProperty("Date_select");
		com.verifyText_Using_String("xpath",Date_select,"Select",","+Widget_name+",Verify the Date drop down is clear or not");
		String Geography_select=Common.readPropertyByNews().getProperty("Geography_select");
		com.verifyText_Using_String("xpath",Geography_select,"Select",","+Widget_name+",Verify the Geography drop down is clear or not");
		String Topics_select=Common.readPropertyByNews().getProperty("Topics_select");
		com.verifyText_Using_String("xpath",Topics_select,"Select",","+Widget_name+",Verify the Topics drop down is clear or not");
	}
	
	@When("^Verify the Save News filter button$")
	public void Verify_the_Save_News_filter_button() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_button=Common.readPropertyByNews().getProperty("Save_News_filter_button");
		com.verifyElementPresent("xpath",Save_News_filter_button,"INTC-00047,"+Widget_name+",Verify the Save News filter button");

	}
	@Then("^Click on Save News filter button$")
	public void Click_on_Save_News_filter_button() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Save_News_filter_button=Common.readPropertyByNews().getProperty("Save_News_filter_button");
		com.MouseOverToclickabl("xpath",Save_News_filter_button,"INTC-00048,"+Widget_name+",Click on Save News filter button");

	}
	@And("^Verify the Save News filter pop title$")
	public void Verify_the_Save_News_filter_pop_title() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_title=Common.readPropertyByNews().getProperty("Save_News_filter_pop_title");
		com.verifyElementPresent("xpath",Save_News_filter_pop_title ,"INTC-00049,"+Widget_name+",Verify the Save News filter pop title");

	}
	@And("^Verify the close icon in Save News filter pop$")
	public void Verify_the_closeicon_in_Save_News_filter_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_close_icon=Common.readPropertyByNews().getProperty("Save_News_filter_pop_close_icon");
		com.verifyElementPresent("xpath",Save_News_filter_pop_close_icon,"INTC-00050,"+Widget_name+",Verify the close icon in Save News filter pop");
	}
	@And("^Verify the ok button in Save News filter pop$")
	public void Verify_the_ok_button_in_Save_News_filter_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_ok_button=Common.readPropertyByNews().getProperty("Save_News_filter_pop_ok_button");
		com.verifyElementPresent("xpath",Save_News_filter_pop_ok_button ,"INTC-00051,"+Widget_name+",Verify the ok button in Save News filter pop");

	}
	@And("^Verify the cancel button in Save News filter pop$")
	public void Verify_the_cancel_button_in_Save_News_filter_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_cancel_button=Common.readPropertyByNews().getProperty("Save_News_filter_pop_cancel_button");
		com.verifyElementPresent("xpath",Save_News_filter_pop_cancel_button,"INTC-00052,"+Widget_name+",Verify the cancel button in Save News filter pop");

	}
	@And("^Click on close icon in Save News filter pop$")
	public void Click_on_close_icon_in_Save_News_filter_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_close_icon=Common.readPropertyByNews().getProperty("Save_News_filter_pop_close_icon");
		com.click("xpath",Save_News_filter_pop_close_icon,"INTC-00053,"+Widget_name+",Click on close icon in Save News filter pop");

	}
	@And("^Click on cancel button in Save News filter pop$")
	public void Click_on_cancel_button_in_Save_News_filter_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_cancel_button=Common.readPropertyByNews().getProperty("Save_News_filter_pop_cancel_button");
		com.click("xpath",Save_News_filter_pop_cancel_button,"INTC-00054,"+Widget_name+",Click on cancel button in Save News filter pop");
	}
	@When("^Verify Name Field text box is working or not$")
	public void Verify_Name_Field_text_box_is_working_or_not() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Name_Field_text_box=Common.readPropertyByNews().getProperty("Name_Field_text_box");
		com.verifyElementPresent("xpath",Name_Field_text_box,"INTC-00055,"+Widget_name+",Verify Name Field text box is working or not");

	}
	@Then("^Enter the \"(.*?)\" name field text box is working or not$")
	public void Enter_the_name_field_text_box_is_working_or_not(String name) throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Name_Field_text_box=Common.readPropertyByNews().getProperty("Name_Field_text_box");
		com.ClearTextField("xpath",Name_Field_text_box,","+Widget_name+",Clear the text field");
		com.sendKeys("xpath",Name_Field_text_box,name,"INTC-00056,"+Widget_name+",Verify Name Field text box is working or not");

	}
	@And("^click on ok button in Save News filter pop$")
	public void click_on_ok_button_in_Save_News_filter_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Save_News_filter_pop_ok_button=Common.readPropertyByNews().getProperty("Save_News_filter_pop_ok_button");
		com.click("xpath",Save_News_filter_pop_ok_button ,"INTC-00057,"+Widget_name+",click on ok button in Save News filter pop");
	}
	
	
	@And("^Delete the created my saved searches list$")
	public void Delete_the_created_my_saved_searches_list() throws Exception {
		com.sleepThread(2000);
		com.startAction();
	String My_Saved_Searches=Common.readPropertyByNews().getProperty("My_Saved_Searches");
	com.MouseOverToclickabl("xpath",My_Saved_Searches,",,Click on my saved searches");
		com.sleepThread(2000);
		com.click("xpath",My_Saved_Searches,",,Click on my saved searches");
	int size=driver.findElements(By.xpath("	/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[3]/div[2]/div[1]/ul[1]/li/div[1]/span[2]")).size();	
	System.out.println("My_Saved_Searches"+size);
	for (int i =1; i <=size; i++) {
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[3]/div[2]/div[1]/ul[1]/li/div[1]/span[2]",",,Click on created my saved searches list");
		com.sleepThread(2000);
		com.startAction();
		com.MouseOverToElement("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[3]/div[2]/div[1]/ul[1]/li/div[1]/span[2]",",,MouseOver on created my saved searches list");
		String Delete_icon=Common.readPropertyByNews().getProperty("Delete_icon");	
		com.MouseOverToclickabl("xpath", Delete_icon, ",,Delete the created my saved searches list");
		System.out.println("*****"+i);
	}	
		}
	
	
	@When("^Right click on Menu_bar_options$")
	public void Right_click_on_Menu_bar_options() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();	
		com.startAction();
		String Menu_bar_options=Common.readPropertyByNews().getProperty("Menu_bar_options");
		com.Rightclick("xpath",Menu_bar_options,"INTC-00058,"+Widget_name+",Right click on menu bar option in news widget");
		com.sleepThread(3000);
	}
	@Then("^Verify the Fields option$")
	public void Verify_the_Fields_option() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Fields=Common.readPropertyByNews().getProperty("Fields");
		com.verifyElementPresent("xpath", Fields,"INTC-00059,"+Widget_name+",Verify the Fields option");
	}
	@And("^Click on Fields option$")
	public void Click_on_Fields_option() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.startAction();
		String Fields=Common.readPropertyByNews().getProperty("Fields");
		com.MouseOverToclickabl("xpath", Fields,"INTC-00060,"+Widget_name+",Click on Fields option");
	}
	@Then("^Verify the News Field selection pop title$")
	public void Verify_the_News_Field_selection_pop_title() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String News_Field_Selection=Common.readPropertyByNews().getProperty("News_Field_Selection");
		com.verifyElementPresent("xpath", News_Field_Selection,"INTC-00061,"+Widget_name+",Verify the News Field selection pop title");
	}
	@And("^Verify the close icon in News Field selection pop$")
	public void Verify_the_close_icon_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_icon_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("close_icon_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath", close_icon_in_News_Field_selection_pop,"INTC-00062,"+Widget_name+",Verify the close icon in News Field selection pop");

	}
	@And("^Verify the close button in News Field selection pop$")
	public void Verify_the_close_button_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("close_button_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath", close_button_in_News_Field_selection_pop,"INTC-00063,"+Widget_name+",Verify the close button in News Field selection pop");

	}
	@And("^Click on close icon in News Field selection pop$")
	public void Click_on_close_icon_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_icon_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("close_icon_in_News_Field_selection_pop");
		com.click("xpath", close_icon_in_News_Field_selection_pop,"INTC-00064,"+Widget_name+",Click on close icon in News Field selection pop");

	}
	@And("^Click on close button in News Field selection pop$")
	public void Click_on_close_button_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("close_button_in_News_Field_selection_pop");
		com.click("xpath", close_button_in_News_Field_selection_pop,"INTC-00065,"+Widget_name+",Click on close button in News Field selection pop");

	}

	@And("^Verify the available columns name in News Field selection pop$")
	public void Verify_the_available_columns_name_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String available_columns_name=Common.readPropertyByNews().getProperty("available_columns_name");
		com.verifyElementPresent("xpath",available_columns_name,"INTC-00066,"+Widget_name+",Verify the available columns name in News Field selection pop");

	}
	@And("^Verify the search field name in available columns in News Field selection pop$")
	public void Verify_the_search_field_name_in_available_columns_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String search_field_name_in_available_columns=Common.readPropertyByNews().getProperty("search_field_name_in_available_columns");
		com.verifyElementPresent("xpath",search_field_name_in_available_columns,"INTC-00067,"+Widget_name+",Verify the search field nmae in available columns in News Field selection pop");
	}
	@And("^Entrer the \"(.*?)\" related available columen name is displayed or not in News Field selection pop$")
	public void Entrer_the_related_available_columen_name_is_displayed_or_not_in_News_Field_selection_pop(String text) throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String search_field_name_in_available_columns=Common.readPropertyByNews().getProperty("search_field_name_in_available_columns");
		com.sendKeys("xpath",search_field_name_in_available_columns,text,"INTC-00068,"+Widget_name+",Entrer the related available columen name is displayed or not in News Field selection pop");
		String related_available_columen_name_in_News_Field=Common.readPropertyByNews().getProperty("related_available_columen_name_in_News_Field");
		com.verifyText_Using_String("xpath", related_available_columen_name_in_News_Field,"Category", "INTC-00069,"+Widget_name+",Verify the right arrow in News Field selection pop");
	
	}
	
	@And("^Verify the right arrow in News Field selection pop$")
	public void Verify_the_right_arrow_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String right_arrow_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("right_arrow_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",right_arrow_in_News_Field_selection_pop ,"INTC-00070,"+Widget_name+",Verify the right arrow in News Field selection pop");
	}
	@And("^Verify the left arrow in News Field selection pop$")
	public void Verify_the_left_arrow_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String left_arrow_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("left_arrow_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",left_arrow_in_News_Field_selection_pop,"INTC-00071,"+Widget_name+",Verify the left arrow in News Field selection pop");
	}	
	@And("^Verify the double Arrow right icon in News Field selection pop$")
	public void Verify_the_double_Arrow_right_icon_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String double_Arrow_right_icon_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("double_Arrow_right_icon_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",double_Arrow_right_icon_in_News_Field_selection_pop,"INTC-00072,"+Widget_name+",Verify the double Arrow right icon in News Field selection pop");
	}
	
	@And("^Verify the double Arrow left icon in News Field selection pop$")
	public void Verify_the_double_Arrow_left_icon_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String double_Arrow_left_icon_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("double_Arrow_left_icon_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",double_Arrow_left_icon_in_News_Field_selection_pop,"INTC-00073,"+Widget_name+",Verify the double Arrow left icon in News Field selection pop");
	}	
	@And("^Verify the selected columns name in News Field selection pop$")
	public void Verify_the_selected_columns_name_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String selected_columns_name_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("selected_columns_name_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",selected_columns_name_in_News_Field_selection_pop,"INTC-00074,"+Widget_name+",Verify the selected columns name in News Field selection pop");
	}
		
	@And("^Verify the search field name in selected columns in News Field selection pop")
	public void Verify_the_search_field_name_in_selected_columns_in_News_Field_selection_pop() throws Exception
	{ 
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String search_field_name_in_selected_columns_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("search_field_name_in_selected_columns_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",search_field_name_in_selected_columns_in_News_Field_selection_pop ,"INTC-00075,"+Widget_name+",Verify the search field nmae in selected columns in News Field selection pop");
	}
	@And("^Entrer the \"(.*?)\" related selected columen name is displayed or not in News Field selection pop$")
	public void Entrer_the_related_selected_columen_name_is_displayed_or_not_in_News_Field_selection_pop(String Time) throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String search_field_name_in_available_columns=Common.readPropertyByNews().getProperty("search_field_name_in_available_columns");
		com.sendKeys("xpath",search_field_name_in_available_columns,Time,"INTC-00076,"+Widget_name+",Entrer the related available columen name is displayed or not in News Field selection pop");
		String related_selected_columen_name_in_News_Field=Common.readPropertyByNews().getProperty("related_selected_columen_name_in_News_Field");
		com.verifyText_Using_String("xpath", related_selected_columen_name_in_News_Field,"Time","INTC-00077,"+Widget_name+",Verify the related available columen name is displayed or not");
		}
	
	@And("^Verify down arrow default disable or not in News Field selection pop$")
	public void Verify_down_arrow_default_disable_or_not_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String down_arrow_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("down_arrow_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",down_arrow_in_News_Field_selection_pop,"INTC-00078,"+Widget_name+",Verify down arrow default disable or not in News Field selection pop");
	}
	@And("^Verify up arrow default disable or not in News Field selection pop$")
	public void Verify_up_arrow_default_disable_or_not_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String up_arrow_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("up_arrow_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",up_arrow_in_News_Field_selection_pop,"INTC-00079,"+Widget_name+",Verify the up arrow in News Field selection pop");
	}
	
	@And("^Verify the save button in News Field selection pop$")
	public void Verify_the_save_button_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String save_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("save_button_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",save_button_in_News_Field_selection_pop,"INTC-00080,"+Widget_name+",Verify the save button in News Field selection pop");
	}
	@And("^Verify the cancel button in News Field selection pop$")
	public void Verify_the_cancel_button_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("cancel_button_in_News_Field_selection_pop");
		com.verifyElementPresent("xpath",cancel_button_in_News_Field_selection_pop,"INTC-00081,"+Widget_name+",Verify the cancel button in News Field selection pop");
	}	
	@And("^Click on cancel button in News Field selection pop$")
	public void Click_on_cancel_button_in_News_Field_selection_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String cancel_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("cancel_button_in_News_Field_selection_pop");
		com.click("xpath",cancel_button_in_News_Field_selection_pop,"INTC-00082,"+Widget_name+",Click on cancel button in News Field selection pop");

	}
	@And("^Click on save button in News Field selection pop$")
	public void Click_on_save_button_in_News_Field_selection_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String save_button_in_News_Field_selection_pop=Common.readPropertyByNews().getProperty("save_button_in_News_Field_selection_pop");
		com.click("xpath",save_button_in_News_Field_selection_pop,"INTC-00083,"+Widget_name+",Click on save button in News Field selection pop");

	}
	
	@When("^Verify the Sort Ascending by option$")
	public void Verify_the_Sort_Ascending_by_option() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_Ascending_by_option=Common.readPropertyByNews().getProperty("Sort_Ascending_by_option");
		com.verifyElementPresent("xpath",Sort_Ascending_by_option,"INTC-00084,"+Widget_name+",Verify the Sort Ascending by option");

	}
	@Then("^Click on all sub options in Sort Ascending by option$")
	public void Click_on_all_sub_options_in_Sort_Ascending_by_option() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_Ascending_by_option=Common.readPropertyByNews().getProperty("Sort_Ascending_by_option");
		com.startAction();
		com.MouseOverToElement("xpath",Sort_Ascending_by_option,"INTC-00085,"+Widget_name+",Click on all sub options in Sort Ascending by option");
		int size=driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[4]/div/ul/li[3]/div/ul/li")).size();
		for (int i =1; i <=size; i++) {
			 com.click("xpath","//*[@id='container']/div/div/div/div/div[4]/div/ul/li[3]/div/ul/li["+i+"]","INTC-00086,"+Widget_name+",Click on all sub options in Sort Ascending by option");
		}
		news=new news();
		news.Right_click_on_Menu_bar_options();
		com.MouseOverToElement("xpath",Sort_Ascending_by_option,"INTC-00087,"+Widget_name+",Click on all sub options in Sort Ascending by option");
	
	}
	@When("^Verify the Sort Decending by options$")
	public void Verify_the_Sort_Decending_by_options() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_Decending_by_options=Common.readPropertyByNews().getProperty("Sort_Decending_by_options");
		com.verifyElementPresent("xpath",Sort_Decending_by_options,"INTC-00088,"+Widget_name+",Verify the Sort Decending by options");
	}
	
	@Then("^Click on all sub options Sort Decending by options$")
	public void Click_on_all_sub_options_Sort_Decending_by_options() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Sort_Decending_by_options=Common.readPropertyByNews().getProperty("Sort_Decending_by_options");
		com.click("xpath",Sort_Decending_by_options,"INTC-00089,"+Widget_name+",Click on all sub options Sort Decending by options");
		com.startAction();
		com.MouseOverToElement("xpath",Sort_Decending_by_options,"INTC-00090,"+Widget_name+",Mouseover on sub options Sort Decending by options");
		int size=driver.findElements(By.xpath("//*[@id='container']/div/div/div/div/div[4]/div/ul/li[3]/div/ul/li")).size();
		for (int i =1; i <=size; i++) {
			 com.click("xpath","//*[@id='container']/div/div/div/div/div[4]/div/ul/li[3]/div/ul/li["+i+"]","INTC-00091,"+Widget_name+",Click on all sub options Sort Decending by options");
		}
		news=new news();
		news.Right_click_on_Menu_bar_options();
		com.MouseOverToElement("xpath",Sort_Decending_by_options,"INTC-00092,"+Widget_name+",Mouseover on sub options Sort Decending by options");
	}
	@When("^Verify Print option in News$")
	public void Verify_Print_option_in_News() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Print_option_in_News=Common.readPropertyByNews().getProperty("Print_option_in_News");
		com.verifyElementPresent("xpath",Print_option_in_News,"INTC-00093,"+Widget_name+",Verify Print option in News");
	}
	@Then("^Verify Defaults option in News$")
	public void Verify_Defaults_option_in_News() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Defaults_option_in_News=Common.readPropertyByNews().getProperty("Defaults_option_in_News");
		com.verifyElementPresent("xpath",Defaults_option_in_News,"INTC-00094,"+Widget_name+",Verify Defaults option in News");
	}
			
	@Then("^Verify the Display preferences$")
	public void Verify_the_Display_preferences() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_preferences=Common.readPropertyByNews().getProperty("Display_preferences");
		com.verifyElementPresent("xpath",Display_preferences,"INTC-00010,"+Widget_name+",Verify the Display preferences");
	}
	
	@And("^Click on Display preferences$")
	public void Click_on_Display_preferences() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Display_preferences=Common.readPropertyByNews().getProperty("Display_preferences");
		com.click("xpath",Display_preferences,"INTC-00010,"+Widget_name+",Click on Display preferences");

	}
	@Then("^Verify the Display preferences pop title$")
	public void Verify_the_Display_preferences_pop_title() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String News_Display_Preferences_title=Common.readPropertyByNews().getProperty("News_Display_Preferences_title");
		com.verifyElementPresent("xpath",News_Display_Preferences_title,"INTC-00010,"+Widget_name+",Verify the Display preferences pop title");

	}
	@And("^Verify the close icon in Display preferences pop$")
	public void Verify_the_close_icon_in_Display_preferences_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_icon_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("close_icon_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",close_icon_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify the close icon in Display preferences pop");

	}
	@And("^Verify the close button in Display preferences pop$")
	public void Verify_the_close_button_in_Display_preferences_pop() throws Exception{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_button_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("close_button_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",close_button_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify the close button in Display preferences pop");
	}
	
	@And("^Click on close icon in Display preferences pop$")
	public void Click_on_close_icon_in_Display_preferences_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_icon_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("close_icon_in_Display_preferences_pop");
		com.click("xpath",close_icon_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on close icon in Display preferences pop");
	}
	@And("^Click on close button in Display preferences pop$")
	public void Click_on_close_button_in_Display_preferences_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String close_button_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("close_button_in_Display_preferences_pop");
		com.click("xpath",close_button_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on close button in Display preferences pop");
	}
	@When("^Verify option compact function accordingly in Display preferences pop$")
	public void Verify_option_compact_function_accordingly_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String compact_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("compact_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",compact_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option compact function accordingly in Display preferences pop");

	}
	
	@Then("^Click on compact function in Display preferences pop$")
	public void Click_on_compact_function_in_Display_preferences_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String compact_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("compact_function_in_Display_preferences_pop");
		com.click("xpath",compact_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on compact function in Display preferences pop");

	}
	@And("^Click on ok button in Display preferences pop$")
	public void Click_on_ok_button_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Ok_button_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Ok_button_in_Display_preferences_pop");
		com.click("xpath",Ok_button_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on ok button in Display preferences pop");
	}
	@When("^Verify option Preview function accordingly in Display preferences pop$")
	public void Verify_option_Preview_function_accordingly_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Preview_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Preview_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",Preview_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option Preview function accordingly in Display preferences pop");
	}
	@Then("^Click on Preview function in Display preferences pop$")
	public void Click_on_Preview_function_in_Display_preferences_pop() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Preview_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Preview_function_in_Display_preferences_pop");
		com.click("xpath",Preview_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on Preview function in Display preferences pop");
	}
	@When("^Verify option Grid function accordingly in Display preferences pop$")
	public void Verify_option_Grid_function_accordingly_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Grid_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Grid_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",Grid_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option Grid function accordingly in Display preferences pop");
	}
	@Then("^Click on Grid function in Display preferences pop$")
	public void Click_on_Grid_function_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Grid_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Grid_function_in_Display_preferences_pop");
		com.click("xpath",Grid_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on Grid function in Display preferences pop");
	}
	@And("^Check Wrap Headline Check box is working or not in Display preferences pop$")
	public void Check_Wrap_Headline_Check_box_is_working_or_not_in_Display_preferences_pop() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Wrap_Headline_Check_box_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Wrap_Headline_Check_box_in_Display_preferences_pop");
		com.click("xpath",Wrap_Headline_Check_box_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Check Wrap Headline Check box is working or not in Display preferences pop");
	}
	
	
	@When("^Verify option Story on Right function accordingly$")
	public void Verify_option_Story_on_Right_function_accordingly() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_on_Right_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_on_Right_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",Story_on_Right_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option Story on Right function accordingly");

	}
	@Then("^click on option Story on Right function accordingly$")
	public void click_on_option_Story_on_Right_function_accordingly() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_on_Right_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_on_Right_function_in_Display_preferences_pop");
		com.click("xpath",Story_on_Right_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",click on option Story on Right function accordingly");

	}
	@When("^Verify option Story on Bottom function accordingly$")
	public void Verify_option_Story_on_Bottom_function_accordingly() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_on_Bottom_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_on_Bottom_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",Story_on_Bottom_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option Story on Bottom function accordingly");
	}
	
	
	@Then("^click on option Story on Bottom function accordingly$")
	public void click_on_option_Story_on_Bottom_function_accordingly() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_on_Bottom_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_on_Bottom_function_in_Display_preferences_pop");
		com.click("xpath",Story_on_Bottom_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",click on option Story on Bottom function accordingly");
	}
	@When("^Verify option Story in new window function accordingly$")
	public void Verify_option_Story_in_new_window_function_accordingly() throws Exception{
		
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_in_new_window_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_in_new_window_function_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",Story_in_new_window_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Verify option Story in new window function accordingly");

		
	}
	@Then("^Click on option Story in new window function accordingly$")
	public void Click_on_option_Story_in_new_window_function_accordingly() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String Story_in_new_window_function_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("Story_in_new_window_function_in_Display_preferences_pop");
		com.click("xpath",Story_in_new_window_function_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Click on option Story in new window function accordingly");
	}
	@When("^Check Reuse News Story Window Check box is working or not$")
	public void Check_Reuse_News_Story_Window_Check_box_is_working_or_not() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String News_Story_Window_Check_box_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("News_Story_Window_Check_box_in_Display_preferences_pop");
		com.verifyElementPresent("xpath",News_Story_Window_Check_box_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",Check Reuse News Story Window Check box is working or not");

	}
	@Then("^click on Reuse News Story Window Check box is working or not$")
	public void click_on_Reuse_News_Story_Window_Check_box_is_working_or_not() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String News_Story_Window_Check_box_in_Display_preferences_pop=Common.readPropertyByNews().getProperty("News_Story_Window_Check_box_in_Display_preferences_pop");
		com.click("xpath",News_Story_Window_Check_box_in_Display_preferences_pop,"INTC-00010,"+Widget_name+",click on Reuse News Story Window Check box is working or not");
	}
	@When("^Verify the all options is working or not in symbol action dropdown$")
	public void Verify_the_all_options_is_working_or_not_in_symbol_action_dropdown() throws Exception
	{
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		String symbol_action_dropdown=Common.readPropertyByNews().getProperty("symbol_action_dropdown");	
		WebElement e = driver.findElement(By.xpath(symbol_action_dropdown));
		Select sel = new Select(e);
		List<WebElement> list = sel.getOptions();
		for (int i = 1; i < list.size(); i++) {
			if (e.isDisplayed()) {
				sel.selectByIndex(i);				
				com.Creatlogfile(Date_Time + "," + "INTC-00010,"+Widget_name+",Verify the all options is working or not in symbol action dropdown" + ",Pass");
				news=new news();
			    news.Click_on_ok_button_in_Display_preferences_pop();
			    com.sleepThread(2000);
			    news.Right_click_on_Menu_bar_options();
			    com.sleepThread(1000);
			    news.Click_on_Display_preferences();
			    com.sleepThread(2000);	
			} else {
				com.Creatlogfile(Date_Time + "," + "INTC-00010,"+Widget_name+",Verify the all options is working or not in symbol action dropdown" + ",Fail");
			}
		}
		//com.select_the_Drop_Down_values("xpath",symbol_action_dropdown,"INTC-00010,"+Widget_name+",Verify the all options is working or not in symbol action dropdown");
	}

//	List<WebElement> list=driver.findElements(By.xpath(related_news));
//	for(int j=1; j<=list.size();j++) {
		
	@When("^Verify All Categories Drop Down and sub Drop Downs is working or not$")
	public void Verify_All_Categories_Drop_Down_and_sub_Drop_Downs_is_working_or_not() throws Exception
	{	
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		int All_Categories=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li/div[1]/span[3]/div[1]")).size();
		System.out.println("All_Categories:"+All_Categories);
		if(All_Categories!=0) {
		for (int l =7; l <=7; l++) {
			com.startAction();
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
			com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
			com.sleepThread(9000);
		if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
			com.sleepThread(9000);
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
			com.sleepThread(3000);		
			news=new news();
		news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
		news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
		news.Verify_Previous_button_is_working_or_not_in_News_story();
		news.Verify_Next_button_is_working_or_not_in_News_story();
		news.Verify_Flag_option_is_working_or_not_in_News_story();
		news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
		news.Verify_X_close_button_is_working_or_not();
		com.sleepThread(2000);
		//String  All_Categories_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
		//com.verifyElementPresent("xpath",All_Categories_drop_down_icon,"INTC-00010,"+Widget_name+",Verify 'All Categories' Drop Down icon");
		com.sleepThread(2000);
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click 'All Categories' Drop Down icon is working or not");
		}else
			{
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
		}
		int All_categories_size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li/div[1]/span[3]/div[1]")).size();
		System.out.println("All_categories_size:"+All_categories_size);
		if(All_categories_size!=0) {
		for (int i =1; i <=2; i++) {
			com.startAction();
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
			//com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
			com.sleepThread(6000);
			if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
				String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
				com.sleepThread(3000);
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			//com.sleepThread(2000);	
//			String  Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
//			com.verifyElementPresent("xpath",Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the Commodities-Agriculture Drop Down");
			com.sleepThread(8000);
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click on Commodities-Agriculture Drop Down icon is working or not");
			}else
			{
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
			int sub_categories_list=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li/div[1]/span[3]/div[1]")).size();
			System.out.println("sub_categories_list:"+sub_categories_list);
			if(sub_categories_list!=0) {
			for (int j =sub_categories_list; j <sub_categories_list; j++) {			
				com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
				com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
				com.sleepThread(6000);
				if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
					String related_news=Common.readPropertyByNews().getProperty("related_news");
					com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
					com.sleepThread(3000);
				news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
				news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
				news.Verify_Previous_button_is_working_or_not_in_News_story();
				news.Verify_Next_button_is_working_or_not_in_News_story();
				news.Verify_Flag_option_is_working_or_not_in_News_story();
				news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
				news.Verify_X_close_button_is_working_or_not();
				com.sleepThread(2000);	
				//String  Sub_Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
				//com.verifyElementPresent("xpath",Sub_Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the sub Commodities-Agriculture Drop Down");
				com.sleepThread(2000);
				com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click on sub Commodities-Agriculture Drop Down icon is working or not");
				}else
				{
					com.sleepThread(3000);
					String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
					com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
				}
				int s=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[2]/div[1]/ul[1]/li/div[1]/span[3]/div[1]")).size();
				if(s!=0) {
				for (int k =s; k <=s; k++) {
					com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[2]/div[1]/ul[1]/li["+k+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
					com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li["+l+"]/div[2]/div[1]/ul[1]/li["+i+"]/div[2]/div[1]/ul[1]/li["+j+"]/div[2]/div[1]/ul[1]/li["+k+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
					com.sleepThread(6000);
					if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
						String related_news=Common.readPropertyByNews().getProperty("related_news");
						com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
						com.sleepThread(3000);
					news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
					news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
					news.Verify_Previous_button_is_working_or_not_in_News_story();
					news.Verify_Next_button_is_working_or_not_in_News_story();
					news.Verify_Flag_option_is_working_or_not_in_News_story();
					news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
					news.Verify_X_close_button_is_working_or_not();
					com.sleepThread(2000);
					String  Sub_Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
					com.verifyElementPresent("xpath",Sub_Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the sub Commodities-Agriculture Drop Down");
					com.sleepThread(2000);
					com.click("xpath",Sub_Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Click on sub Commodities-Agriculture Drop Down icon is working or not");
				}else
				{
					com.sleepThread(3000);
					String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
					com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
				}
					}
				}else {
					System.out.println("s:"+s);
				}
				
			}}else {
				System.out.println("sub_categories_list:"+sub_categories_list);
			}
			
			
			}}else {
				System.out.println("All_categories_size:"+All_categories_size);
			}
			
		}}else {
			System.out.println("All_Categories:"+All_Categories);
		}
		
	}
	@When("^Verify_All_Categories$")
	public void Verify_All_Categories () throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click 'All Categories' Drop Down icon is working or not");
		com.sleepThread(2000);
		int All_categories_size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[2]/div[1]/ul[1]/li/div[1]/span[3]/div[1]")).size();
		System.out.println("All_categories_size:"+All_categories_size);
		if(All_categories_size!=0) {
		for (int i =1; i <2; i++) {
			//com.sendKeys_fOR_Keybord("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", Keys.DOWN, "");
			com.startAction();
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
			com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
			com.sleepThread(6000);			
			try{
				driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			//if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
				String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
				com.sleepThread(3000);
				news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(2000);	
//			String  Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
//			com.verifyElementPresent("xpath",Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the Commodities-Agriculture Drop Down");
			com.sleepThread(2000);
			com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click 'All Categories' Drop Down icon is working or not");
			}catch(Exception t){
			//}else{		
			
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}}
	
	
	}
}
	@When("^Verify My Watchlist News$")
	public void Verify_My_Watchlist_News() throws Exception {
		Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click on 'My Watchlist News' Drop Down icon is working or not");
		com.sleepThread(2000);
		int My_Watchlist_News_size=driver.findElements(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/div[2]/div[1]/ul[1]/li/div[1]/span[2]/div[1]")).size();
		System.out.println("My_Watchlist_News_size:"+My_Watchlist_News_size);
		if(My_Watchlist_News_size!=0) {
		for (int i =1; i <=2; i++) {
			com.startAction();
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[2]/div[1]", "INTC-00010,"+Widget_name+",Verify the My Watchlist News drop down list");
			com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[2]/div[1]", "INTC-00010,"+Widget_name+",click on each My Watchlist News drop down list");
			com.sleepThread(15000);
			try{driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
				String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
				com.sleepThread(3000);
				news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(2000);	
//			String  Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
//			com.verifyElementPresent("xpath",Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the Commodities-Agriculture Drop Down");
			}catch(Exception t){
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}}
		com.sleepThread(2000);
		com.click("xpath","/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[4]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click 'All Categories' Drop Down icon is working or not");
	}
	}
	
	
	@When("^Verify Flagged New Option is working or not$")
	public void Verify_Flagged_New_Option_is_working_or_not() throws Exception {
	
		String Flagged_New_Option=Common.readPropertyByNews().getProperty("Flagged_New_Option");
		com.startAction();
		com.MouseOverToclickabl("xpath",Flagged_New_Option,","+Widget_name+",Verify Flagged New Option is working or not");
		com.sleepThread(15000);
		
		try{driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,","+Widget_name+",Verify the Flagged New Option related news");
			com.sleepThread(3000);
			news=new news();
		news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
		news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
		news.Verify_Previous_button_is_working_or_not_in_News_story();
		news.Verify_Next_button_is_working_or_not_in_News_story();
		news.Verify_Flag_option_is_working_or_not_in_News_story();
		news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
		news.Verify_X_close_button_is_working_or_not();
		com.sleepThread(2000);	
		}catch(Exception t){
			com.sleepThread(3000);
			String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
			com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
		}
	}
	
	@When("^Verify Recently Read Option is working or not$")
	public void Verify_Recently_Read_Option_is_working_or_not() throws Exception {
		
		String Recently_Read_Option=Common.readPropertyByNews().getProperty("Recently_Read_Option");
		com.startAction();
		com.MouseOverToclickabl("xpath",Recently_Read_Option,","+Widget_name+",Verify Recently Read Option is working or not");
		com.sleepThread(15000);
		try{
			driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			String related_news=Common.readPropertyByNews().getProperty("related_news");
			com.click("xpath",related_news,","+Widget_name+",Verify the Recently Read Option related news");
			com.sleepThread(3000);
			news=new news();
		news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
		news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
		news.Verify_Previous_button_is_working_or_not_in_News_story();
		news.Verify_Next_button_is_working_or_not_in_News_story();
		news.Verify_Flag_option_is_working_or_not_in_News_story();
		news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
		news.Verify_X_close_button_is_working_or_not();
		com.sleepThread(2000);	
		}catch(Exception t){
		//}else{
			com.sleepThread(3000);
			String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
			com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
		}
		
		
	}
 @Then("^Verify the Symbol Category dropdown option is working or not$")
 public void Verify_the_Symbol_Category_dropdown_option_is_working_or_not() throws Exception {
	 Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
	 String Symbol_Category=Common.readPropertyByNews().getProperty("Symbol_Category");
	 com.sleepThread(3000);
	 com.click("xpath", Symbol_Category,","+Widget_name+",Verify the Symbol Category dropdown option is working or not");
	 int size=driver.findElements(By.xpath("/html/body/div[6]/div/span/div/div/div[2]/div/div/div/ul/li/div[1]/span[2]/div")).size();
	 System.out.println(size+"******************");
	 for (int i = 2; i < 3; i++) {
		 com.sleepThread(3000);
		 com.startAction();
		 com.MouseOverToclickabl("xapth", "/html/body/div[6]/div/span/div/div/div[2]/div/div/div/ul/li["+i+"]/div[1]/span[2]/div", ",,Click on each list");
		 com.sleepThread(6000);
			
			try{
				driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			//if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
				String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
				com.sleepThread(3000);
				news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(2000);	
//			String  Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
//			com.verifyElementPresent("xpath",Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the Commodities-Agriculture Drop Down");
			com.sleepThread(2000);
			 com.click("xpath", Symbol_Category,","+Widget_name+",Verify the Symbol Category dropdown option is working or not");
			}catch(Exception t){
			//}else{		
			
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}
 
			
		}
		 
		
	}
 @And("^Click on each list in All Categories$")
 public void Click_on_each_list_in_All_Categories() throws Exception {
	 
	 Widget_name=driver.findElement(By.xpath(Common.readPropertyByWatch_List().getProperty("Widget_name"))).getText();
	 String Symbol_Category=Common.readPropertyByNews().getProperty("Symbol_Category");
	 com.click("xpath", Symbol_Category,","+Widget_name+",Verify the Symbol Category dropdown option is working or not");
	 com.sleepThread(2000);
	 com.click("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[1]/span[2]","INTC-00010,"+Widget_name+",Click 'All Categories' Drop Down icon is working or not");
		com.sleepThread(2000);
		int All_categories_size=driver.findElements(By.xpath("/html[1]/body[1]/div[6]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[2]/div[1]/ul[1]/li/div[1]/span[3]")).size();
		System.out.println(All_categories_size+"All_categories_size");
		System.out.println("All_categories_size:"+All_categories_size);
		if(All_categories_size!=0) {
		for (int i =1; i <2; i++) {
			//com.sendKeys_fOR_Keybord("xpath", "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/ul[1]/li[7]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]/div[1]", Keys.DOWN, "");
			com.startAction();
			com.verifyElementPresent("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]", "INTC-00010,"+Widget_name+",Verify the all categories drop down list");
			com.MouseOverToclickabl("xpath","/html[1]/body[1]/div[6]/div[1]/span[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[2]/div[1]/ul[1]/li["+i+"]/div[1]/span[3]", "INTC-00010,"+Widget_name+",click on each categories drop down list");
			com.sleepThread(6000);
			
			try{
				driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed();
			//if(driver.findElement(By.xpath(Common.readPropertyByNews().getProperty("related_news"))).isDisplayed()) {
				String related_news=Common.readPropertyByNews().getProperty("related_news");
				com.click("xpath",related_news,"INTC-00025,"+Widget_name+",Verify the Industries related news");
				com.sleepThread(3000);
				news=new news();
			news.Check_whether_the_news_is_displaying_or_not_for_selected_Active_symbols();
			news.Verify_whether_the_selected_news_story_is_displaying_the_news_or_not();
			news.Verify_Previous_button_is_working_or_not_in_News_story();
			news.Verify_Next_button_is_working_or_not_in_News_story();
			news.Verify_Flag_option_is_working_or_not_in_News_story();
			news.Verify_Copy_New_story_text_to_the_clipboard_option_is_working_or_not_in_News_Story();
			news.Verify_X_close_button_is_working_or_not();
			com.sleepThread(2000);	
//			String  Commodities_Agriculture_drop_down_icon=Common.readPropertyByNews().getProperty("All_Categories_drop_down_icon");
//			com.verifyElementPresent("xpath",Commodities_Agriculture_drop_down_icon,"INTC-00010,"+Widget_name+",Verify the Commodities-Agriculture Drop Down");
			com.sleepThread(2000);
			com.click("xpath", Symbol_Category,","+Widget_name+",Verify the Symbol Category dropdown option is working or not");
			}catch(Exception t){
			//}else{		
			
				com.sleepThread(3000);
				String No_stories_matching_your_selection=Common.readPropertyByNews().getProperty("No_stories_matching_your_selection");
				com.verifyText_Using_String("xpath",No_stories_matching_your_selection,"No stories matching your selection",","+Widget_name+",Verify the No stories matching your selection massage is showing or not");
			}}}
	
	
	 
	 
	 
 }







}
	
	
	