package Ide.Idp.Runner;


import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(plugin = { "html:target/cucumber-html-report", "json:target/cucumber.json",
		"pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
		"junit:target/cucumber-results.xml" }, features = "../HTML5/Featuresfiles/Options.feature", glue = "Ide.Idp.StepDef")
public class Options_Runner extends AbstractTestNGCucumberTests{

}
