/*package Ide.Idp.StepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TC1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","D:/QA_TheIce/Firefox/geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://connect-web.staging.dataservices.theice.com");
		
	}

}
*/